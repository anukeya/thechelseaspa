/* =========================================================================
   ADMIN UI KIT — reusable primitives & charts (token-driven, theme-aware).
   All exported to window for module files.
   ========================================================================= */

/* ---- Panel ---------------------------------------------------------- */
function Panel({ children, style, pad = true, className = "" }) {
  return (
    <div className={`panel ${className}`} style={{ ...(pad ? { padding: "22px 24px" } : {}), ...style }}>
      {children}
    </div>
  );
}

/* ---- Section header (page title row) -------------------------------- */
function PageHead({ eyebrow, title, children }) {
  return (
    <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-end", gap: 16, flexWrap: "wrap", marginBottom: 24 }}>
      <div>
        {eyebrow && <div className="eyebrow">{eyebrow}</div>}
        <h2 style={{ marginTop: 6, fontSize: "1.9rem" }}>{title}</h2>
      </div>
      {children && <div style={{ display: "flex", gap: 8, alignItems: "center", flexWrap: "wrap" }}>{children}</div>}
    </div>
  );
}

/* ---- Stat card ------------------------------------------------------ */
function AStat({ label, value, delta, deltaDir = "up", spark, icon }) {
  const deltaColor = deltaDir === "down" ? "var(--danger)" : "var(--success)";
  return (
    <div className="astat">
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
        <span className="caption">{label}</span>
        {icon && <span style={{ color: "var(--ink-3)" }}><Icon name={icon} size={16}/></span>}
      </div>
      <div style={{ display: "flex", alignItems: "baseline", gap: 10, marginTop: 10 }}>
        <span style={{ fontFamily: "var(--font-display)", fontSize: "1.9rem", fontWeight: 300, letterSpacing: "-0.03em" }}>{value}</span>
        {delta && <span style={{ fontFamily: "var(--font-display)", fontSize: "0.76rem", color: deltaColor }}>{deltaDir === "down" ? "↓" : "↑"} {delta}</span>}
      </div>
      {spark && <div style={{ marginTop: 12 }}><Sparkline data={spark}/></div>}
    </div>
  );
}

/* ---- Pill ----------------------------------------------------------- */
function Pill({ color = "var(--ink-2)", bg = "var(--bg-shell)", dot, children }) {
  return (
    <span className="pill" style={{ color, background: bg }}>
      {dot && <span className="dot" style={{ background: color }}/>}
      {children}
    </span>
  );
}
function StatusPillAdmin({ status }) {
  const s = AD.STATUSES[status] || AD.STATUSES.pending;
  return <Pill color={s.color} bg={s.bg} dot>{s.label}</Pill>;
}

/* ---- Avatar --------------------------------------------------------- */
function Avatar({ name, size = 34, color }) {
  const initials = name.split(" ").filter(Boolean).map(p => p[0]).slice(0, 2).join("");
  return (
    <span className="avatar" style={{
      width: size, height: size, fontSize: size * 0.36,
      background: color ? color : "var(--bg-shell)",
      color: color ? "#fff" : "var(--ink)",
    }}>{initials}</span>
  );
}

/* ---- Icon button ---------------------------------------------------- */
function IconBtn({ icon, onClick, title, badge, size = 18 }) {
  return (
    <button className="icon-btn" onClick={onClick} title={title}>
      <Icon name={icon} size={size}/>
      {badge != null && (
        <span style={{
          position: "absolute", top: 6, right: 6,
          minWidth: 15, height: 15, padding: "0 3px", borderRadius: 8,
          background: "var(--gold-deep)", color: "var(--ink-on-dark)",
          fontFamily: "var(--font-display)", fontSize: "0.6rem",
          display: "flex", alignItems: "center", justifyContent: "center",
        }}>{badge}</span>
      )}
    </button>
  );
}

/* ---- Tabs ----------------------------------------------------------- */
function Tabs({ tabs, active, onChange }) {
  return (
    <div style={{ display: "flex", borderBottom: "1px solid var(--line)", overflowX: "auto" }} className="hide-scroll">
      {tabs.map(t => (
        <button key={t.id} className={`atab ${active === t.id ? "active" : ""}`} onClick={() => onChange(t.id)}>
          {t.label}{t.count != null && <span style={{ color: "var(--ink-3)", marginLeft: 6 }}>{t.count}</span>}
        </button>
      ))}
    </div>
  );
}

/* ---- Search input --------------------------------------------------- */
function SearchInput({ value, onChange, placeholder = "Search…", width = 260 }) {
  return (
    <div style={{
      display: "flex", alignItems: "center", gap: 9,
      padding: "8px 13px", background: "var(--bg)", border: "1px solid var(--line-strong)",
      borderRadius: 999, width, maxWidth: "100%",
    }}>
      <Icon name="search" size={14} className="text-ink-3"/>
      <input value={value} onChange={e => onChange(e.target.value)} placeholder={placeholder} style={{
        background: "transparent", border: "none", outline: "none", flex: 1,
        fontFamily: "var(--font-body)", fontSize: "0.88rem", color: "var(--ink)",
      }}/>
    </div>
  );
}

/* ---- Toggle --------------------------------------------------------- */
function Toggle({ checked, onChange, size = 40 }) {
  return (
    <button onClick={() => onChange(!checked)} style={{
      width: size, height: size * 0.58, borderRadius: 999,
      background: checked ? "var(--gold-deep)" : "var(--line-strong)",
      position: "relative", transition: "background 240ms var(--ease)", flexShrink: 0,
    }}>
      <span style={{
        position: "absolute", top: "10%", left: checked ? `${100 - 90 * 0.58}%` : "5%",
        width: size * 0.46, height: size * 0.46, borderRadius: "50%",
        background: "#fff", boxShadow: "0 1px 3px rgba(0,0,0,0.3)",
        transition: "left 240ms var(--ease)",
      }}/>
    </button>
  );
}

/* ---- Progress bar --------------------------------------------------- */
function ProgressBar({ pct, color = "var(--gold-deep)", height = 6 }) {
  return (
    <div style={{ height, background: "var(--bg-shell)", borderRadius: height, overflow: "hidden", width: "100%" }}>
      <div style={{ width: `${Math.min(100, pct)}%`, height: "100%", background: color, borderRadius: height, transition: "width 700ms var(--ease)" }}/>
    </div>
  );
}

/* ====================================================================
   CHARTS — lightweight SVG, theme-aware via currentColor / tokens
   ==================================================================== */

/* Sparkline */
function Sparkline({ data, color = "var(--gold-deep)", w = 120, h = 28 }) {
  const max = Math.max(...data), min = Math.min(...data);
  const range = max - min || 1;
  const pts = data.map((v, i) => `${(i / (data.length - 1)) * w},${h - ((v - min) / range) * (h - 4) - 2}`).join(" ");
  return (
    <svg width="100%" height={h} viewBox={`0 0 ${w} ${h}`} preserveAspectRatio="none" className="kpi-spark">
      <polyline points={pts} fill="none" stroke={color} strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
  );
}

/* Vertical bar chart */
function BarChart({ data, labels, height = 200, highlightLast = true, prefix = "£" }) {
  const max = Math.max(...data);
  return (
    <div style={{ display: "flex", alignItems: "flex-end", gap: 10, height }}>
      {data.map((v, i) => (
        <div key={i} style={{ flex: 1, display: "flex", flexDirection: "column", alignItems: "center", gap: 8, height: "100%" }}>
          <div style={{ position: "relative", flex: 1, width: "100%", display: "flex", alignItems: "flex-end" }}>
            <div style={{
              width: "100%", height: `${(v / max) * 100}%`,
              background: highlightLast && i === data.length - 1 ? "var(--gold-deep)" : "var(--ink)",
              borderRadius: "4px 4px 0 0", position: "relative", minHeight: 4,
              transition: "height 600ms var(--ease)",
            }}>
              <span style={{
                position: "absolute", top: -20, left: 0, right: 0, textAlign: "center",
                fontFamily: "var(--font-display)", fontSize: "0.66rem", color: "var(--ink-2)", whiteSpace: "nowrap",
              }}>{prefix}{v}</span>
            </div>
          </div>
          {labels && <span className="caption" style={{ fontSize: "0.68rem" }}>{labels[i]}</span>}
        </div>
      ))}
    </div>
  );
}

/* Line / area chart */
function LineChart({ data, height = 180, color = "var(--gold-deep)" }) {
  const w = 600, h = height;
  const max = Math.max(...data), min = Math.min(...data);
  const range = max - min || 1;
  const px = (i) => (i / (data.length - 1)) * w;
  const py = (v) => h - ((v - min) / range) * (h - 24) - 12;
  const line = data.map((v, i) => `${px(i)},${py(v)}`).join(" ");
  const area = `0,${h} ${line} ${w},${h}`;
  return (
    <svg width="100%" height={h} viewBox={`0 0 ${w} ${h}`} preserveAspectRatio="none">
      <defs>
        <linearGradient id="areaFill" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor={color} stopOpacity="0.22"/>
          <stop offset="100%" stopColor={color} stopOpacity="0"/>
        </linearGradient>
      </defs>
      <polygon points={area} fill="url(#areaFill)"/>
      <polyline points={line} fill="none" stroke={color} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
  );
}

/* Donut chart */
function Donut({ segments, size = 150, thickness = 18, centerLabel, centerSub }) {
  const r = (size - thickness) / 2;
  const c = 2 * Math.PI * r;
  let acc = 0;
  return (
    <div style={{ position: "relative", width: size, height: size }}>
      <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`} style={{ transform: "rotate(-90deg)" }}>
        <circle cx={size/2} cy={size/2} r={r} fill="none" stroke="var(--bg-shell)" strokeWidth={thickness}/>
        {segments.map((s, i) => {
          const len = (s.pct / 100) * c;
          const el = (
            <circle key={i} cx={size/2} cy={size/2} r={r} fill="none"
              stroke={s.color} strokeWidth={thickness}
              strokeDasharray={`${len} ${c - len}`} strokeDashoffset={-acc}
              strokeLinecap="butt"/>
          );
          acc += len;
          return el;
        })}
      </svg>
      {centerLabel && (
        <div style={{ position: "absolute", inset: 0, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center" }}>
          <span style={{ fontFamily: "var(--font-display)", fontSize: "1.4rem", letterSpacing: "-0.02em" }}>{centerLabel}</span>
          {centerSub && <span className="caption" style={{ fontSize: "0.66rem" }}>{centerSub}</span>}
        </div>
      )}
    </div>
  );
}

/* Horizontal bars (rankings) */
function HBars({ rows }) {
  const max = Math.max(...rows.map(r => r.value));
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
      {rows.map((r, i) => (
        <div key={i}>
          <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 6 }}>
            <span style={{ fontFamily: "var(--font-display)", fontSize: "0.86rem" }}>{r.label}</span>
            <span style={{ fontFamily: "var(--font-display)", fontSize: "0.84rem", color: "var(--ink-2)" }}>{r.display ?? r.value}</span>
          </div>
          <ProgressBar pct={(r.value / max) * 100} color={r.color || "var(--gold-deep)"}/>
        </div>
      ))}
    </div>
  );
}

/* ---- Drawer --------------------------------------------------------- */
function Drawer({ open, onClose, title, subtitle, children, footer }) {
  useEffect(() => {
    const onKey = (e) => { if (e.key === "Escape") onClose(); };
    if (open) window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open]);
  if (!open) return null;
  return (
    <>
      <div className="drawer-scrim" onClick={onClose}/>
      <div className="drawer">
        <div style={{ padding: "22px 26px", borderBottom: "1px solid var(--line)", display: "flex", alignItems: "flex-start", justifyContent: "space-between", gap: 16 }}>
          <div>
            {subtitle && <div className="caption" style={{ marginBottom: 4 }}>{subtitle}</div>}
            <h3 style={{ fontSize: "1.3rem" }}>{title}</h3>
          </div>
          <button className="icon-btn" onClick={onClose}><Icon name="x" size={18}/></button>
        </div>
        <div className="hide-scroll" style={{ flex: 1, overflowY: "auto", padding: "24px 26px" }}>
          {children}
        </div>
        {footer && <div style={{ padding: "18px 26px", borderTop: "1px solid var(--line)", display: "flex", gap: 10, justifyContent: "flex-end" }}>{footer}</div>}
      </div>
    </>
  );
}

/* ---- Empty state ---------------------------------------------------- */
function EmptyBlock({ icon = "search", title, sub, action }) {
  return (
    <div style={{ padding: "56px 32px", textAlign: "center", border: "1px dashed var(--line-strong)", borderRadius: 10 }}>
      <div style={{ display: "inline-flex", padding: 16, background: "var(--bg-nude)", borderRadius: "50%", marginBottom: 16, color: "var(--gold-deep)" }}>
        <Icon name={icon} size={20}/>
      </div>
      <h4 style={{ fontSize: "1.05rem" }}>{title}</h4>
      {sub && <p className="text-ink-2" style={{ marginTop: 6, fontSize: "0.9rem" }}>{sub}</p>}
      {action && <div style={{ marginTop: 18 }}>{action}</div>}
    </div>
  );
}

/* ---- Skeleton row --------------------------------------------------- */
function SkeletonRows({ rows = 5 }) {
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
      {Array.from({ length: rows }).map((_, i) => (
        <div key={i} className="skeleton" style={{ height: 52, borderRadius: 8 }}/>
      ))}
    </div>
  );
}

Object.assign(window, {
  Panel, PageHead, AStat, Pill, StatusPillAdmin, Avatar, IconBtn, Tabs,
  SearchInput, Toggle, ProgressBar, Sparkline, BarChart, LineChart, Donut, HBars,
  Drawer, EmptyBlock, SkeletonRows,
});
