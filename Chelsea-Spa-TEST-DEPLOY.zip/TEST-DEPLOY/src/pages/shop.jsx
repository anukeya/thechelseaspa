/* =========================================================================
   SHOP PAGE — The Chelsea Spa retail store
   Products load from the REAL WooCommerce database (src/services/db.js,
   imported from shop.thechelseaspa.co.uk) — live names, prices, imagery.
   Interactive: filters, sort, wishlist, add-to-basket + slide-in basket.
   ========================================================================= */

function wpToShop(p) {
  let name = p.name, brand = "The Chelsea Spa", size = "";
  const m = name.match(/^(.*?)\s+by\s+CRYSTAL\s*CLEAR\s*(?:\((.*?)\))?$/i);
  if (m) { name = m[1]; brand = "Crystal Clear"; size = m[2] || ""; }
  name = name.replace(/\s*[–-]\s*£\d+\s*per couple\s*$/i, "");
  return { id: p.id, name, brand, size, price: p.sale ?? p.price, regular: p.regular, sale: p.sale,
    cat: p.cat, blurb: p.short || p.desc, img: p.image, gallery: p.gallery, gift: p.gift, sku: p.sku };
}

// Fetch products from the real WooCommerce database (via Supabase)

const SHOP_PRODUCTS = const { data, error } = await window.supabaseClient
  .from("products")
  .select("*")
  .eq("is_active", true)
  .order("name");

if (error) {
  throw error;
}

const products = data;

function ProductImg({ p, style, onClick }) {
  const [err, setErr] = useState(false);
  if (!p.img || err) return <div className="img-placeholder" style={style} onClick={onClick}>{p.gift ? "gift voucher" : `${p.brand.toLowerCase()} · product`}</div>;
  return <img src={p.img} alt={p.name} onError={() => setErr(true)} onClick={onClick}
    style={{ width: "100%", objectFit: "cover", display: "block", background: "var(--bg-nude)", ...style }}/>;
}
window.ProductImg = ProductImg;

function ShopPage() {
  const { navigate } = useRouter();
  const toast = useToast();

  const [cat, setCat] = useState("All");
  const [brand, setBrand] = useState("All");
  const [sort, setSort] = useState("featured");
  const [search, setSearch] = useState("");
  const [cart, setCart] = useState([]);           // [{id, qty}]
  const [wishlist, setWishlist] = useState([]);
  const [cartOpen, setCartOpen] = useState(false);
  const [quick, setQuick] = useState(null);

  const cats = ["All", ...Array.from(new Set(SHOP_PRODUCTS.map(p => p.cat)))];
  const brands = ["All", ...Array.from(new Set(SHOP_PRODUCTS.map(p => p.brand)))];

  const filtered = useMemo(() => {
    let list = [...SHOP_PRODUCTS];
    if (cat !== "All") list = list.filter(p => p.cat === cat);
    if (brand !== "All") list = list.filter(p => p.brand === brand);
    if (search) {
      const q = search.toLowerCase();
      list = list.filter(p => (p.name + p.brand + p.blurb).toLowerCase().includes(q));
    }
    if (sort === "price-low") list.sort((a, b) => a.price - b.price);
    if (sort === "price-high") list.sort((a, b) => b.price - a.price);
    if (sort === "name") list.sort((a, b) => a.name.localeCompare(b.name));
    return list;
  }, [cat, brand, sort, search]);

  const addToCart = (p, qty = 1) => {
    setCart(prev => {
      const ex = prev.find(i => i.id === p.id);
      if (ex) return prev.map(i => i.id === p.id ? { ...i, qty: i.qty + qty } : i);
      return [...prev, { id: p.id, qty }];
    });
    toast(`${p.name} added to basket`, "success");
    setCartOpen(true);
  };
  const setQty = (id, qty) => {
    if (qty <= 0) return setCart(prev => prev.filter(i => i.id !== id));
    setCart(prev => prev.map(i => i.id === id ? { ...i, qty } : i));
  };
  const toggleWish = (id) => {
    setWishlist(prev => prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id]);
  };

  const cartCount = cart.reduce((s, i) => s + i.qty, 0);

  return (
    <div>
      <Nav />

      {/* HEADER */}
      <section style={{ padding: "180px 0 56px", background: "var(--bg-cream)", borderBottom: "1px solid var(--line)" }}>
        <div className="container-wide">
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-end", flexWrap: "wrap", gap: 24 }}>
            <div style={{ maxWidth: 720 }}>
              <div className="eyebrow">The shop</div>
              <h1 style={{ marginTop: 12, marginBottom: 20 }}>
                Take the ritual <em className="serif-italic" style={{ color: "var(--gold-deep)" }}>home</em>.
              </h1>
              <p className="body-lg" style={{ maxWidth: "54ch" }}>
                The same apothecary-grade products our therapists reach for — chosen for what they do, not for what they sell.
                Members enjoy 15% off everything below.
              </p>
            </div>
            <button onClick={() => setCartOpen(true)} className="btn btn-ghost" style={{ position: "relative" }}>
              <Icon name="wallet" size={16}/> Basket
              {cartCount > 0 && (
                <span style={{
                  position: "absolute", top: -8, right: -8, minWidth: 22, height: 22, padding: "0 6px",
                  borderRadius: 11, background: "var(--gold-deep)", color: "var(--ink-on-dark)",
                  fontFamily: "var(--font-display)", fontSize: "0.7rem",
                  display: "flex", alignItems: "center", justifyContent: "center",
                }}>{cartCount}</span>
              )}
            </button>
          </div>
        </div>
      </section>

      {/* FILTER BAR */}
      <div style={{
        position: "sticky", top: 84, zIndex: 40,
        background: "rgba(246,241,232,0.92)", backdropFilter: "blur(20px)", WebkitBackdropFilter: "blur(20px)",
        borderBottom: "1px solid var(--line)",
      }}>
        <div className="container-wide" style={{ padding: "18px 32px", display: "flex", alignItems: "center", gap: 20, flexWrap: "wrap" }}>
          <div style={{ display: "flex", gap: 4, flexWrap: "wrap" }}>
            {cats.map(c => (
              <button key={c} onClick={() => setCat(c)} style={{
                padding: "9px 16px", fontFamily: "var(--font-display)", fontSize: "0.76rem",
                letterSpacing: "0.14em", textTransform: "uppercase", borderRadius: "var(--r-pill)",
                background: cat === c ? "var(--ink)" : "transparent",
                color: cat === c ? "var(--ink-on-dark)" : "var(--ink-2)",
                border: `1px solid ${cat === c ? "var(--ink)" : "var(--line-strong)"}`,
                transition: "all 220ms var(--ease)",
              }}>{c}</button>
            ))}
          </div>

          <div style={{ flex: 1 }}/>

          <div style={{ display: "flex", alignItems: "center", gap: 10, padding: "8px 14px", border: "1px solid var(--line-strong)", borderRadius: "var(--r-pill)", background: "var(--bg-cream)", width: 220 }}>
            <Icon name="search" size={14} className="text-ink-3"/>
            <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search products…" style={{ background: "transparent", border: "none", outline: "none", flex: 1, fontFamily: "var(--font-body)", fontSize: "0.9rem" }}/>
          </div>

          <select value={brand} onChange={e => setBrand(e.target.value)} style={selStyle}>
            {brands.map(b => <option key={b} value={b}>{b === "All" ? "All brands" : b}</option>)}
          </select>

          <select value={sort} onChange={e => setSort(e.target.value)} style={selStyle}>
            <option value="featured">Featured</option>
            <option value="price-low">Price · low</option>
            <option value="price-high">Price · high</option>
            <option value="name">A – Z</option>
          </select>
        </div>
      </div>

      {/* GRID */}
      <section style={{ padding: "48px 0 96px" }}>
        <div className="container-wide">
          <div className="caption" style={{ marginBottom: 28 }}>
            {filtered.length} {filtered.length === 1 ? "product" : "products"}
            {cat !== "All" && ` · ${cat}`}{brand !== "All" && ` · ${brand}`}
          </div>

          {filtered.length === 0 ? (
            <div style={{ padding: "80px 32px", textAlign: "center", border: "1px dashed var(--line-strong)", borderRadius: 8 }}>
              <div style={{ display: "inline-flex", padding: 20, background: "var(--bg-nude)", borderRadius: "50%", marginBottom: 20 }}><Icon name="search" size={24}/></div>
              <h3>Nothing matches just yet.</h3>
              <p style={{ marginTop: 12, color: "var(--ink-2)" }}>Try clearing a filter, or browse the full range.</p>
            </div>
          ) : (
            <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 24 }} className="shop-grid">
              {filtered.map((p, i) => (
                <ProductCard key={p.id} p={p} index={i}
                  wished={wishlist.includes(p.id)}
                  onWish={() => toggleWish(p.id)}
                  onAdd={() => addToCart(p)}
                  onQuick={() => setQuick(p)}/>
              ))}
            </div>
          )}
        </div>
        <style>{`
          @media (max-width: 1080px) { .shop-grid { grid-template-columns: repeat(3, 1fr) !important; } }
          @media (max-width: 760px)  { .shop-grid { grid-template-columns: repeat(2, 1fr) !important; } }
          @media (max-width: 460px)  { .shop-grid { grid-template-columns: 1fr !important; } }
        `}</style>
      </section>

      {/* SHIPPING STRIP */}
      <section style={{ paddingBottom: 96 }}>
        <div className="container-wide">
          <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 1, background: "var(--line)", border: "1px solid var(--line)" }} className="ship-grid">
            {[
              { icon: "package", t: "Complimentary delivery", s: "On all UK orders over £50" },
              { icon: "leaf", t: "Apothecary-grade only", s: "Therapist-tested, never tested on animals" },
              { icon: "gift", t: "Hand-finished wrapping", s: "Add a note at checkout, free of charge" },
            ].map(x => (
              <div key={x.t} style={{ background: "var(--bg)", padding: "32px 28px", display: "flex", gap: 16, alignItems: "flex-start" }}>
                <span className="text-gold" style={{ marginTop: 2 }}><Icon name={x.icon} size={20}/></span>
                <div>
                  <div style={{ fontFamily: "var(--font-display)", fontSize: "1rem" }}>{x.t}</div>
                  <div className="caption" style={{ marginTop: 4 }}>{x.s}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
        <style>{`@media (max-width: 760px) { .ship-grid { grid-template-columns: 1fr !important; } }`}</style>
      </section>

      <Footer />

      {/* QUICK VIEW */}
      {quick && <QuickView p={quick} onClose={() => setQuick(null)} onAdd={(qty) => { addToCart(quick, qty); setQuick(null); }} wished={wishlist.includes(quick.id)} onWish={() => toggleWish(quick.id)}/>}

      {/* BASKET DRAWER */}
      <BasketDrawer open={cartOpen} onClose={() => setCartOpen(false)} cart={cart} setQty={setQty}
        onCheckout={() => { setCartOpen(false); toast("Taking you to checkout…"); navigate("/checkout"); }}/>
    </div>
  );
}

const selStyle = {
  padding: "10px 16px", borderRadius: "var(--r-pill)", border: "1px solid var(--line-strong)",
  background: "var(--bg-cream)", fontFamily: "var(--font-display)", fontSize: "0.76rem",
  letterSpacing: "0.12em", textTransform: "uppercase", cursor: "pointer",
};

/* ---------- Product card ---------- */
function ProductCard({ p, index, wished, onWish, onAdd, onQuick }) {
  const [hover, setHover] = useState(false);
  return (
    <div className="card fade-up" style={{ animationDelay: `${index * 60}ms`, display: "flex", flexDirection: "column",
      borderColor: hover ? "var(--gold-soft)" : "var(--line)", transform: hover ? "translateY(-4px)" : "none",
      boxShadow: hover ? "var(--shadow-3)" : "none" }}
      onMouseEnter={() => setHover(true)} onMouseLeave={() => setHover(false)}>
      <div style={{ position: "relative" }}>
        <ProductImg p={p} style={{ height: 260, cursor: "pointer" }} onClick={onQuick}/>
        <button onClick={onWish} title="Save" style={{
          position: "absolute", top: 12, right: 12, width: 34, height: 34, borderRadius: "50%",
          background: "var(--bg-cream)", display: "flex", alignItems: "center", justifyContent: "center",
          color: wished ? "var(--gold-deep)" : "var(--ink-3)", boxShadow: "var(--shadow-1)",
        }}>
          <Icon name="heart" size={15}/>
        </button>
        {hover && (
          <button onClick={onQuick} className="fade-in" style={{
            position: "absolute", bottom: 12, left: 12, right: 12, padding: "10px",
            background: "rgba(42,38,34,0.86)", color: "var(--ink-on-dark)", borderRadius: 4,
            fontFamily: "var(--font-display)", fontSize: "0.7rem", letterSpacing: "0.16em", textTransform: "uppercase",
            display: "flex", alignItems: "center", justifyContent: "center", gap: 8,
          }}><Icon name="eye" size={14}/> Quick view</button>
        )}
      </div>
      <div style={{ padding: 22, display: "flex", flexDirection: "column", flex: 1 }}>
        <div className="eyebrow" style={{ color: "var(--ink-3)", fontSize: "0.66rem" }}>{p.brand}{p.size ? ` · ${p.size}` : ""}</div>
        <h4 style={{ marginTop: 8, fontSize: "1.02rem", lineHeight: 1.25 }}>{p.name}</h4>
        <p className="body-sm text-ink-2" style={{ marginTop: 8, fontSize: "0.84rem", lineHeight: 1.5, flex: 1 }}>{p.blurb}</p>
        <div style={{ marginTop: 18, display: "flex", justifyContent: "space-between", alignItems: "center", gap: 12 }}>
          <span style={{ fontFamily: "var(--font-display)", fontSize: "1.2rem", color: "var(--gold-deep)" }}>£{p.price}</span>
          <Button variant="ghost" size="sm" onClick={onAdd} icon="plus">Add</Button>
        </div>
      </div>
    </div>
  );
}

/* ---------- Quick view modal ---------- */
function QuickView({ p, onClose, onAdd, wished, onWish }) {
  const [qty, setQty] = useState(1);
  useEffect(() => {
    const onKey = (e) => { if (e.key === "Escape") onClose(); };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);
  return (
    <>
      <div onClick={onClose} style={{ position: "fixed", inset: 0, zIndex: 100, background: "rgba(42,38,34,0.5)", backdropFilter: "blur(3px)" }} className="fade-in"/>
      <div className="fade-up" style={{
        position: "fixed", top: "50%", left: "50%", transform: "translate(-50%, -50%)", zIndex: 110,
        width: "min(880px, 94vw)", maxHeight: "90vh", overflow: "auto",
        background: "var(--bg-cream)", borderRadius: 10, boxShadow: "var(--shadow-3)",
        display: "grid", gridTemplateColumns: "1fr 1fr",
      }} className="qv-grid">
        <ProductImg p={p} style={{ minHeight: 420, height: "100%" }}/>
        <div style={{ padding: 36, position: "relative" }}>
          <button onClick={onClose} className="icon-btn" style={{ position: "absolute", top: 16, right: 16 }}><Icon name="x" size={18}/></button>
          <div className="eyebrow" style={{ color: "var(--ink-3)" }}>{p.brand}{p.size ? ` · ${p.size}` : ""}</div>
          <h2 style={{ marginTop: 10, fontSize: "1.9rem" }}>{p.name}</h2>
          <div style={{ fontFamily: "var(--font-display)", fontSize: "1.6rem", color: "var(--gold-deep)", marginTop: 14 }}>£{p.price}</div>
          <p className="body" style={{ marginTop: 18, lineHeight: 1.65 }}>{p.blurb}</p>
          <div className="divider" style={{ margin: "24px 0" }}/>
          <div style={{ display: "flex", alignItems: "center", gap: 16 }}>
            <div style={{ display: "flex", alignItems: "center", border: "1px solid var(--line-strong)", borderRadius: 4 }}>
              <button onClick={() => setQty(Math.max(1, qty - 1))} style={{ padding: "10px 14px" }}><Icon name="minus" size={14}/></button>
              <span style={{ fontFamily: "var(--font-display)", minWidth: 28, textAlign: "center" }}>{qty}</span>
              <button onClick={() => setQty(qty + 1)} style={{ padding: "10px 14px" }}><Icon name="plus" size={14}/></button>
            </div>
            <Button variant="primary" onClick={() => onAdd(qty)} style={{ flex: 1 }} iconRight="arrow-right">Add to basket · £{p.price * qty}</Button>
            <button onClick={onWish} className="icon-btn" style={{ width: 46, height: 46, border: "1px solid var(--line-strong)", color: wished ? "var(--gold-deep)" : "var(--ink-2)" }}><Icon name="heart" size={18}/></button>
          </div>
          <div style={{ marginTop: 22, display: "flex", flexDirection: "column", gap: 10 }}>
            <span className="body-sm" style={{ display: "flex", gap: 10, alignItems: "center", color: "var(--ink-2)" }}><Icon name="leaf" size={14} className="text-gold"/> Apothecary-grade · cruelty-free</span>
            <span className="body-sm" style={{ display: "flex", gap: 10, alignItems: "center", color: "var(--ink-2)" }}><Icon name="package" size={14} className="text-gold"/> Free UK delivery over £50</span>
          </div>
        </div>
      </div>
      <style>{`@media (max-width: 680px) { .qv-grid { grid-template-columns: 1fr !important; } .qv-grid > .img-placeholder { min-height: 220px !important; } }`}</style>
    </>
  );
}

/* ---------- Basket drawer ---------- */
function BasketDrawer({ open, onClose, cart, setQty, onCheckout }) {
  if (!open) return null;
  const lines = cart.map(i => ({ ...i, p: SHOP_PRODUCTS.find(x => x.id === i.id) }));
  const subtotal = lines.reduce((s, l) => s + l.p.price * l.qty, 0);
  const delivery = subtotal >= 50 || subtotal === 0 ? 0 : 5;
  return (
    <>
      <div onClick={onClose} style={{ position: "fixed", inset: 0, zIndex: 100, background: "rgba(42,38,34,0.45)" }} className="fade-in"/>
      <aside className="fade-up" style={{
        position: "fixed", top: 0, right: 0, bottom: 0, zIndex: 110, width: "min(440px, 94vw)",
        background: "var(--bg-cream)", borderLeft: "1px solid var(--line)", boxShadow: "var(--shadow-3)",
        display: "flex", flexDirection: "column", animation: "drawerIn 360ms var(--ease) both",
      }}>
        <div style={{ padding: "22px 26px", borderBottom: "1px solid var(--line)", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
          <h3 style={{ fontSize: "1.2rem" }}>Your basket {cart.length > 0 && <span className="text-ink-3">· {lines.reduce((s,l)=>s+l.qty,0)}</span>}</h3>
          <button onClick={onClose} className="icon-btn"><Icon name="x" size={18}/></button>
        </div>

        <div className="hide-scroll" style={{ flex: 1, overflowY: "auto", padding: "20px 26px" }}>
          {lines.length === 0 ? (
            <div style={{ padding: "60px 0", textAlign: "center" }}>
              <div style={{ display: "inline-flex", padding: 18, background: "var(--bg-nude)", borderRadius: "50%", marginBottom: 18, color: "var(--gold-deep)" }}><Icon name="wallet" size={22}/></div>
              <h4>Your basket is empty.</h4>
              <p className="body-sm text-ink-2" style={{ marginTop: 8 }}>Add a little something to begin.</p>
              <Button variant="ghost" size="sm" onClick={onClose} style={{ marginTop: 18 }}>Continue browsing</Button>
            </div>
          ) : lines.map(l => (
            <div key={l.id} style={{ display: "grid", gridTemplateColumns: "64px 1fr auto", gap: 14, padding: "14px 0", borderBottom: "1px solid var(--line)" }}>
              <ProductImg p={l.p} style={{ width: 64, height: 64, fontSize: "0.5rem", borderRadius: 4 }}/>
              <div>
                <div style={{ fontFamily: "var(--font-display)", fontSize: "0.9rem", lineHeight: 1.25 }}>{l.p.name}</div>
                <div className="caption" style={{ marginTop: 2 }}>{l.p.size || l.p.cat}</div>
                <div style={{ display: "flex", alignItems: "center", gap: 8, marginTop: 8 }}>
                  <div style={{ display: "flex", alignItems: "center", border: "1px solid var(--line-strong)", borderRadius: 4 }}>
                    <button onClick={() => setQty(l.id, l.qty - 1)} style={{ padding: "5px 9px" }}><Icon name="minus" size={12}/></button>
                    <span style={{ fontFamily: "var(--font-display)", minWidth: 22, textAlign: "center", fontSize: "0.84rem" }}>{l.qty}</span>
                    <button onClick={() => setQty(l.id, l.qty + 1)} style={{ padding: "5px 9px" }}><Icon name="plus" size={12}/></button>
                  </div>
                  <button onClick={() => setQty(l.id, 0)} className="caption" style={{ color: "var(--ink-3)" }}>Remove</button>
                </div>
              </div>
              <div style={{ fontFamily: "var(--font-display)", color: "var(--gold-deep)" }}>£{l.p.price * l.qty}</div>
            </div>
          ))}
        </div>

        {lines.length > 0 && (
          <div style={{ padding: "20px 26px", borderTop: "1px solid var(--line)" }}>
            <div style={{ display: "flex", justifyContent: "space-between", padding: "4px 0" }}>
              <span className="text-ink-2">Subtotal</span><span style={{ fontFamily: "var(--font-display)" }}>£{subtotal}</span>
            </div>
            <div style={{ display: "flex", justifyContent: "space-between", padding: "4px 0" }}>
              <span className="text-ink-2">Delivery</span><span style={{ fontFamily: "var(--font-display)" }}>{delivery === 0 ? "Free" : `£${delivery}`}</span>
            </div>
            {subtotal < 50 && subtotal > 0 && (
              <div className="caption" style={{ marginTop: 8, color: "var(--gold-deep)" }}>Add £{50 - subtotal} more for free delivery</div>
            )}
            <div className="divider" style={{ margin: "12px 0" }}/>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "baseline" }}>
              <span style={{ fontFamily: "var(--font-display)", letterSpacing: "0.06em", textTransform: "uppercase", fontSize: "0.78rem" }}>Total</span>
              <span style={{ fontFamily: "var(--font-display)", fontSize: "1.5rem", color: "var(--gold-deep)" }}>£{subtotal + delivery}</span>
            </div>
            <Button variant="primary" size="lg" onClick={onCheckout} style={{ width: "100%", marginTop: 16 }} iconRight="arrow-right">Checkout</Button>
          </div>
        )}
      </aside>
    </>
  );
}

window.ShopPage = ShopPage;
