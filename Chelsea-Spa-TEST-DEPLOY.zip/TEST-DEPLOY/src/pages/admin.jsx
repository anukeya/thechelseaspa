/* =========================================================================
   ADMIN / STAFF DASHBOARD — Appointments, calendar, customers, revenue
   ========================================================================= */

function AdminPage() {
  const { navigate } = useRouter();
  const [view, setView] = useState("today"); // today | calendar | customers | revenue

  return (
    <div style={{ background: "var(--bg)", minHeight: "100vh" }}>
      {/* Admin top bar */}
      <header style={{
        position: "sticky", top: 0, zIndex: 50,
        background: "var(--ink)", color: "var(--ink-on-dark)",
        borderBottom: "1px solid rgba(246,241,232,0.1)",
      }}>
        <div className="container-wide" style={{
          height: 64, display: "flex", alignItems: "center", justifyContent: "space-between", gap: 24,
        }}>
          <div style={{ display: "flex", alignItems: "center", gap: 32 }}>
            <button onClick={() => navigate("/")} style={{ display: "flex" }}><Logo light size={22}/></button>
            <span className="chip chip-gold" style={{ background: "var(--gold-deep)", color: "var(--ink-on-dark)" }}>Staff console</span>
          </div>
          <nav style={{ display: "flex", gap: 4 }}>
            {[
              { id: "today",     icon: "calendar", label: "Today" },
              { id: "calendar",  icon: "calendar", label: "Calendar" },
              { id: "customers", icon: "users",    label: "Customers" },
              { id: "revenue",   icon: "trending", label: "Revenue" },
            ].map(t => (
              <button key={t.id} onClick={() => setView(t.id)} style={{
                padding: "8px 16px", borderRadius: 6,
                background: view === t.id ? "rgba(246,241,232,0.08)" : "transparent",
                color: view === t.id ? "var(--gold-soft)" : "rgba(246,241,232,0.7)",
                fontFamily: "var(--font-display)", fontSize: "0.78rem",
                letterSpacing: "0.12em", textTransform: "uppercase",
                display: "flex", alignItems: "center", gap: 8,
              }}>
                <Icon name={t.icon} size={14}/> {t.label}
              </button>
            ))}
          </nav>
          <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
            <button style={{
              padding: 8, color: "rgba(246,241,232,0.7)",
              position: "relative",
            }}>
              <Icon name="search" size={16}/>
            </button>
            <div style={{
              width: 32, height: 32, borderRadius: "50%",
              background: "var(--gold-deep)", color: "var(--ink-on-dark)",
              display: "flex", alignItems: "center", justifyContent: "center",
              fontFamily: "var(--font-display)", fontSize: "0.8rem",
            }}>AW</div>
          </div>
        </div>
      </header>

      {view === "today"     && <AdminToday/>}
      {view === "calendar"  && <AdminCalendar/>}
      {view === "customers" && <AdminCustomers/>}
      {view === "revenue"   && <AdminRevenue/>}
    </div>
  );
}

/* ------------------ TODAY ------------------ */
function AdminToday() {
  const appts = [
    { time: "09:00", duration: 60, customer: "Saskia R.", treatment: "Oxygen Glow", therapist: "Amara", status: "completed", room: "Suite 1" },
    { time: "10:30", duration: 75, customer: "Lily W.",   treatment: "Signature Facial", therapist: "Amara", status: "in-progress", room: "Suite 1" },
    { time: "11:00", duration: 60, customer: "Marcus T.", treatment: "Deep Tissue", therapist: "Isolde", status: "upcoming", room: "Suite 2" },
    { time: "12:30", duration: 90, customer: "Eloise W.", treatment: "Hot Stone", therapist: "Isolde", status: "upcoming", room: "Suite 2", note: "Tree nut allergy" },
    { time: "14:00", duration: 75, customer: "Anika P.",  treatment: "Botanical Cocoon", therapist: "Noor", status: "upcoming", room: "Suite 3" },
    { time: "15:30", duration: 90, customer: "James K.",  treatment: "Two Together", therapist: "Amara + Noor", status: "upcoming", room: "Couples", note: "Anniversary" },
    { time: "17:00", duration: 60, customer: "Sophia L.", treatment: "Cashmere Polish", therapist: "Noor", status: "upcoming", room: "Suite 3" },
  ];

  return (
    <section style={{ padding: "32px 0 96px" }}>
      <div className="container-wide">
        {/* Header */}
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-end", marginBottom: 24, flexWrap: "wrap", gap: 16 }}>
          <div>
            <div className="eyebrow">Operations · 23 May 2026</div>
            <h2 style={{ marginTop: 8 }}>Today</h2>
          </div>
          <div style={{ display: "flex", gap: 8 }}>
            <Button variant="ghost" size="sm" icon="filter">Filter</Button>
            <Button variant="primary" size="sm" icon="plus">New booking</Button>
          </div>
        </div>

        {/* KPIs */}
        <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 16, marginBottom: 32 }} className="admin-stats">
          <AdminStat label="Bookings" value="7" delta="+2"/>
          <AdminStat label="Revenue (today)" value="£985" delta="+12%"/>
          <AdminStat label="Utilisation" value="78%" delta="+4%"/>
          <AdminStat label="No-shows" value="0" delta="—"/>
        </div>

        {/* Schedule */}
        <div style={{ display: "grid", gridTemplateColumns: "1.6fr 1fr", gap: 24 }} className="admin-grid">
          <div style={{
            background: "var(--bg-cream)", border: "1px solid var(--line)", borderRadius: 8,
            padding: 24,
          }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 16 }}>
              <h3>Today's schedule</h3>
              <div style={{ display: "flex", gap: 4 }}>
                {["All", "Amara", "Isolde", "Noor"].map((t, i) => (
                  <button key={t} style={{
                    padding: "6px 12px", borderRadius: 999,
                    background: i === 0 ? "var(--ink)" : "transparent",
                    color: i === 0 ? "var(--ink-on-dark)" : "var(--ink-2)",
                    border: `1px solid ${i === 0 ? "var(--ink)" : "var(--line-strong)"}`,
                    fontFamily: "var(--font-display)", fontSize: "0.72rem",
                    letterSpacing: "0.12em", textTransform: "uppercase",
                  }}>{t}</button>
                ))}
              </div>
            </div>
            <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
              {appts.map(a => <ApptRow key={a.time} a={a}/>)}
            </div>
          </div>

          {/* Side: live activity */}
          <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
            <div style={{
              background: "var(--bg-cream)", border: "1px solid var(--line)", borderRadius: 8,
              padding: 24,
            }}>
              <h3 style={{ fontSize: "1rem", marginBottom: 12 }}>In progress</h3>
              <div style={{ padding: 16, background: "var(--bg-nude)", borderRadius: 6 }}>
                <div className="caption" style={{ color: "var(--gold-deep)" }}>10:30 · Suite 1</div>
                <div style={{ fontFamily: "var(--font-display)", fontSize: "1rem", marginTop: 4 }}>Lily W. — Signature Facial</div>
                <div className="caption" style={{ marginTop: 4 }}>Amara · 35 min remaining</div>
                <div style={{
                  marginTop: 14, height: 3, background: "rgba(42,38,34,0.1)", borderRadius: 2, overflow: "hidden",
                }}>
                  <div style={{ width: "53%", height: "100%", background: "var(--gold-deep)" }}/>
                </div>
              </div>
            </div>

            <div style={{
              background: "var(--bg-cream)", border: "1px solid var(--line)", borderRadius: 8,
              padding: 24,
            }}>
              <h3 style={{ fontSize: "1rem", marginBottom: 14 }}>Recent activity</h3>
              <Activity time="just now" text="Saskia R. checked out · £145 paid"/>
              <Activity time="14 min ago" text="James K. confirmed couples booking"/>
              <Activity time="32 min ago" text="Lily W. checked in"/>
              <Activity time="1 hr ago" text="Marcus T. rescheduled to 11:00"/>
              <Activity time="2 hr ago" text="New review · ★★★★★ from Saskia"/>
            </div>
          </div>
        </div>
        <style>{`
          @media (max-width: 980px) {
            .admin-grid { grid-template-columns: 1fr !important; }
            .admin-stats { grid-template-columns: 1fr 1fr !important; }
          }
        `}</style>
      </div>
    </section>
  );
}

function AdminStat({ label, value, delta }) {
  return (
    <div style={{
      background: "var(--bg-cream)", border: "1px solid var(--line)", borderRadius: 8,
      padding: "20px 24px",
    }}>
      <div className="caption">{label}</div>
      <div style={{ display: "flex", alignItems: "baseline", gap: 10, marginTop: 8 }}>
        <span style={{ fontFamily: "var(--font-display)", fontSize: "1.8rem", fontWeight: 300, letterSpacing: "-0.02em" }}>{value}</span>
        <span style={{ fontFamily: "var(--font-display)", fontSize: "0.78rem", color: "var(--success)" }}>{delta}</span>
      </div>
    </div>
  );
}

function ApptRow({ a }) {
  const statusMap = {
    completed:    { color: "var(--ink-3)", dot: "var(--ink-3)", label: "Completed" },
    "in-progress":{ color: "var(--gold-deep)", dot: "var(--gold)", label: "In room" },
    upcoming:     { color: "var(--ink)", dot: "var(--line-strong)", label: "Upcoming" },
  };
  const s = statusMap[a.status];
  return (
    <div style={{
      display: "grid", gridTemplateColumns: "70px 8px 1fr auto", gap: 14, alignItems: "center",
      padding: "14px 16px",
      background: a.status === "in-progress" ? "var(--bg-nude)" : "transparent",
      border: "1px solid var(--line)",
      borderRadius: 6,
      opacity: a.status === "completed" ? 0.55 : 1,
    }}>
      <div>
        <div style={{ fontFamily: "var(--font-display)", fontSize: "1rem" }}>{a.time}</div>
        <div className="caption">{a.duration}m</div>
      </div>
      <span style={{ width: 6, height: 6, borderRadius: "50%", background: s.dot, alignSelf: "center" }}/>
      <div>
        <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
          <span style={{ fontFamily: "var(--font-display)", fontSize: "0.95rem" }}>{a.customer}</span>
          {a.note && <span className="chip chip-gold" style={{ fontSize: "0.62rem", padding: "2px 8px" }}>{a.note}</span>}
        </div>
        <div className="caption" style={{ marginTop: 2 }}>{a.treatment} · {a.therapist} · {a.room}</div>
      </div>
      <span style={{ fontFamily: "var(--font-display)", fontSize: "0.7rem", letterSpacing: "0.14em", textTransform: "uppercase", color: s.color }}>
        {s.label}
      </span>
    </div>
  );
}

function Activity({ time, text }) {
  return (
    <div style={{
      display: "grid", gridTemplateColumns: "80px 1fr", gap: 12,
      padding: "10px 0", borderTop: "1px solid var(--line)",
      alignItems: "flex-start",
    }}>
      <span className="caption" style={{ paddingTop: 2 }}>{time}</span>
      <span className="body-sm" style={{ fontSize: "0.86rem" }}>{text}</span>
    </div>
  );
}

/* ------------------ CALENDAR ------------------ */
function AdminCalendar() {
  const hours = ["09", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19"];
  const therapists = ["Amara", "Isolde", "Noor"];
  // grid bookings: [therapistIdx, startHour offset, length hours, title]
  const bookings = [
    [0, 0, 1,    "Saskia · Oxygen Glow",        "completed"],
    [0, 1.5, 1.25, "Lily · Signature",          "active"],
    [0, 6.5, 1.5, "James · Couples",            "upcoming"],
    [1, 2, 1,    "Marcus · Deep Tissue",        "upcoming"],
    [1, 3.5, 1.5, "Eloise · Hot Stone",         "upcoming"],
    [1, 8, 1.5,  "Reuben · Hot Stone",          "upcoming"],
    [2, 5, 1.25, "Anika · Botanical Cocoon",    "upcoming"],
    [2, 8, 1,    "Sophia · Cashmere Polish",    "upcoming"],
  ];

  return (
    <section style={{ padding: "32px 0 96px" }}>
      <div className="container-wide">
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-end", marginBottom: 24, flexWrap: "wrap", gap: 16 }}>
          <div>
            <div className="eyebrow">Saturday 23 May 2026</div>
            <h2 style={{ marginTop: 8 }}>Calendar</h2>
          </div>
          <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
            <Button variant="ghost" size="sm" icon="chevron-up">Prev</Button>
            <Button variant="ghost" size="sm">Today</Button>
            <Button variant="ghost" size="sm" iconRight="chevron-down">Next</Button>
            <span className="divider-v" style={{ height: 24, margin: "0 8px" }}/>
            <Button variant="primary" size="sm" icon="plus">New booking</Button>
          </div>
        </div>

        <div style={{
          background: "var(--bg-cream)", border: "1px solid var(--line)", borderRadius: 8,
          overflow: "hidden",
        }}>
          {/* therapist header */}
          <div style={{
            display: "grid", gridTemplateColumns: `80px repeat(3, 1fr)`,
            borderBottom: "1px solid var(--line)",
            background: "var(--bg-shell)",
          }}>
            <div style={{ padding: "16px 12px" }}><span className="caption">Time</span></div>
            {therapists.map(t => (
              <div key={t} style={{ padding: "16px 20px", borderLeft: "1px solid var(--line)" }}>
                <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                  <div style={{
                    width: 28, height: 28, borderRadius: "50%",
                    background: "var(--gold-deep)", color: "var(--ink-on-dark)",
                    display: "flex", alignItems: "center", justifyContent: "center",
                    fontFamily: "var(--font-display)", fontSize: "0.72rem",
                  }}>{t[0]}</div>
                  <span style={{ fontFamily: "var(--font-display)", fontSize: "0.95rem" }}>{t}</span>
                </div>
              </div>
            ))}
          </div>

          {/* grid */}
          <div style={{
            position: "relative",
            display: "grid", gridTemplateColumns: `80px repeat(3, 1fr)`,
          }}>
            {/* time column */}
            <div>
              {hours.map(h => (
                <div key={h} style={{ height: 60, padding: "6px 12px", borderBottom: "1px solid var(--line)" }}>
                  <span className="caption">{h}:00</span>
                </div>
              ))}
            </div>
            {therapists.map((t, ti) => (
              <div key={t} style={{
                position: "relative", borderLeft: "1px solid var(--line)",
              }}>
                {hours.map((h, hi) => (
                  <div key={h} style={{ height: 60, borderBottom: "1px solid var(--line)" }}/>
                ))}
                {/* booking blocks */}
                {bookings.filter(b => b[0] === ti).map((b, i) => {
                  const [, offset, length, title, status] = b;
                  const statusColor = status === "active" ? "var(--gold-deep)" : status === "completed" ? "var(--ink-3)" : "var(--ink)";
                  const bg = status === "active" ? "var(--bg-nude)" : status === "completed" ? "var(--bg-shell)" : "var(--bg)";
                  return (
                    <div key={i} style={{
                      position: "absolute",
                      top: offset * 60 + 4, height: length * 60 - 8, left: 8, right: 8,
                      background: bg,
                      borderLeft: `3px solid ${statusColor}`,
                      borderRadius: 4,
                      padding: "8px 12px",
                      fontFamily: "var(--font-display)", fontSize: "0.82rem",
                      opacity: status === "completed" ? 0.55 : 1,
                      cursor: "pointer",
                    }}>
                      <div style={{ fontSize: "0.74rem", color: statusColor, letterSpacing: "0.08em", textTransform: "uppercase" }}>
                        {String(Math.floor(9 + offset)).padStart(2, "0")}:{(offset % 1) * 60 === 0 ? "00" : "30"}
                      </div>
                      <div style={{ marginTop: 2 }}>{title}</div>
                    </div>
                  );
                })}
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

/* ------------------ CUSTOMERS ------------------ */
function AdminCustomers() {
  const customers = [
    { name: "Eloise Whitfield", email: "eloise.w@example.com", tier: "Atelier", visits: 24, ltv: 3260, last: "8 Mar" },
    { name: "Saskia Ramos",     email: "s.ramos@example.com", tier: "Atelier", visits: 18, ltv: 2450, last: "23 May" },
    { name: "Marcus Thane",     email: "marcus.t@example.com", tier: "Guest",   visits: 4,  ltv: 540,  last: "20 May" },
    { name: "Anika Patel",      email: "anika.p@example.com",  tier: "Atelier", visits: 31, ltv: 4180, last: "23 May" },
    { name: "Reuben Cole",      email: "r.cole@example.com",  tier: "Guest",   visits: 2,  ltv: 285,  last: "11 May" },
    { name: "Sophia Lin",       email: "s.lin@example.com",   tier: "Guest",   visits: 7,  ltv: 985,  last: "23 May" },
    { name: "James Kovac",      email: "j.kovac@example.com", tier: "Atelier", visits: 12, ltv: 1840, last: "23 May" },
    { name: "Lily Whitfield",   email: "lily.w@example.com",  tier: "Guest",   visits: 1,  ltv: 165,  last: "23 May" },
  ];
  return (
    <section style={{ padding: "32px 0 96px" }}>
      <div className="container-wide">
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-end", marginBottom: 24 }}>
          <div>
            <div className="eyebrow">Database</div>
            <h2 style={{ marginTop: 8 }}>Customers</h2>
          </div>
          <Button variant="primary" size="sm" icon="plus">Add customer</Button>
        </div>

        <div style={{
          background: "var(--bg-cream)", border: "1px solid var(--line)", borderRadius: 8,
          overflow: "hidden",
        }}>
          <div style={{
            padding: "14px 20px", display: "flex", gap: 12, borderBottom: "1px solid var(--line)",
            background: "var(--bg-shell)",
          }}>
            <div style={{
              flex: 1, display: "flex", alignItems: "center", gap: 8,
              padding: "8px 14px", background: "var(--bg-cream)", borderRadius: 999, border: "1px solid var(--line-strong)",
            }}>
              <Icon name="search" size={14} className="text-ink-3"/>
              <input placeholder="Search customers…" style={{
                background: "transparent", border: "none", outline: "none", flex: 1, fontSize: "0.9rem",
              }}/>
            </div>
          </div>
          <table style={{ width: "100%", borderCollapse: "collapse" }}>
            <thead><tr style={{ borderBottom: "1px solid var(--line)" }}>
              <Th>Customer</Th><Th>Tier</Th><Th>Visits</Th><Th>Lifetime value</Th><Th>Last visit</Th><Th></Th>
            </tr></thead>
            <tbody>
              {customers.map(c => (
                <tr key={c.email} style={{ borderTop: "1px solid var(--line)" }}>
                  <Td>
                    <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
                      <div style={{
                        width: 32, height: 32, borderRadius: "50%",
                        background: "var(--bg-nude)", color: "var(--ink)",
                        display: "flex", alignItems: "center", justifyContent: "center",
                        fontFamily: "var(--font-display)", fontSize: "0.78rem",
                      }}>{c.name.split(" ").map(p => p[0]).join("")}</div>
                      <div>
                        <div style={{ fontFamily: "var(--font-display)" }}>{c.name}</div>
                        <div className="caption">{c.email}</div>
                      </div>
                    </div>
                  </Td>
                  <Td>
                    <span className={c.tier === "Atelier" ? "chip chip-gold" : "chip chip-line"} style={{ fontSize: "0.66rem" }}>
                      {c.tier}
                    </span>
                  </Td>
                  <Td><span style={{ fontFamily: "var(--font-display)" }}>{c.visits}</span></Td>
                  <Td><span style={{ fontFamily: "var(--font-display)", color: "var(--gold-deep)" }}>£{c.ltv.toLocaleString()}</span></Td>
                  <Td><span className="caption">{c.last}</span></Td>
                  <Td style={{ textAlign: "right" }}>
                    <button style={{ padding: 6 }}><Icon name="dots" size={16}/></button>
                  </Td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </section>
  );
}

/* ------------------ REVENUE ------------------ */
function AdminRevenue() {
  // Simple inline chart data (7 days)
  const data = [820, 1140, 985, 1320, 1480, 1180, 985];
  const days = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];
  const max = Math.max(...data);

  return (
    <section style={{ padding: "32px 0 96px" }}>
      <div className="container-wide">
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-end", marginBottom: 24 }}>
          <div>
            <div className="eyebrow">May 2026 · MTD</div>
            <h2 style={{ marginTop: 8 }}>Revenue</h2>
          </div>
          <div style={{ display: "flex", gap: 4 }}>
            {["7D", "30D", "QTD", "YTD"].map((p, i) => (
              <button key={p} style={{
                padding: "8px 16px", borderRadius: 999,
                background: i === 0 ? "var(--ink)" : "transparent",
                color: i === 0 ? "var(--ink-on-dark)" : "var(--ink-2)",
                border: `1px solid ${i === 0 ? "var(--ink)" : "var(--line-strong)"}`,
                fontFamily: "var(--font-display)", fontSize: "0.72rem", letterSpacing: "0.14em", textTransform: "uppercase",
              }}>{p}</button>
            ))}
          </div>
        </div>

        {/* KPI */}
        <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 16, marginBottom: 32 }} className="admin-stats">
          <AdminStat label="This week" value="£7,910" delta="+18%"/>
          <AdminStat label="Avg per booking" value="£163" delta="+5%"/>
          <AdminStat label="Bookings" value="48" delta="+9"/>
          <AdminStat label="Membership MRR" value="£14,640" delta="+£480"/>
        </div>

        {/* Chart */}
        <div style={{ background: "var(--bg-cream)", border: "1px solid var(--line)", borderRadius: 8, padding: "32px 32px 16px" }}>
          <h3 style={{ marginBottom: 24, fontSize: "1.05rem" }}>Daily revenue</h3>
          <div style={{ display: "flex", alignItems: "flex-end", gap: 12, height: 220 }}>
            {data.map((v, i) => (
              <div key={i} style={{ flex: 1, display: "flex", flexDirection: "column", alignItems: "center", gap: 8 }}>
                <div style={{ position: "relative", flex: 1, width: "100%", display: "flex", alignItems: "flex-end" }}>
                  <div style={{
                    width: "100%", height: `${(v / max) * 100}%`,
                    background: i === data.length - 1 ? "var(--gold-deep)" : "var(--ink)",
                    borderRadius: "4px 4px 0 0",
                    position: "relative",
                  }}>
                    <span style={{
                      position: "absolute", top: -22, left: 0, right: 0,
                      textAlign: "center",
                      fontFamily: "var(--font-display)", fontSize: "0.7rem",
                      color: "var(--ink-2)",
                    }}>£{v}</span>
                  </div>
                </div>
                <span className="caption">{days[i]}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Breakdown */}
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16, marginTop: 24 }} className="rev-grid">
          <div style={{ background: "var(--bg-cream)", border: "1px solid var(--line)", borderRadius: 8, padding: 24 }}>
            <h3 style={{ fontSize: "1rem", marginBottom: 16 }}>By category</h3>
            {[
              ["Facials", 42, "var(--gold-deep)"],
              ["Massage", 31, "var(--ink)"],
              ["Body", 18, "var(--gold-soft)"],
              ["Specialist", 9, "var(--ink-3)"],
            ].map(([label, pct, color]) => (
              <div key={label} style={{ marginBottom: 14 }}>
                <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 6 }}>
                  <span style={{ fontFamily: "var(--font-display)", fontSize: "0.9rem" }}>{label}</span>
                  <span style={{ fontFamily: "var(--font-display)", fontSize: "0.9rem", color: "var(--ink-2)" }}>{pct}%</span>
                </div>
                <div style={{ height: 6, background: "var(--bg-shell)", borderRadius: 3, overflow: "hidden" }}>
                  <div style={{ width: `${pct}%`, height: "100%", background: color, transition: "width 600ms var(--ease)" }}/>
                </div>
              </div>
            ))}
          </div>
          <div style={{ background: "var(--bg-cream)", border: "1px solid var(--line)", borderRadius: 8, padding: 24 }}>
            <h3 style={{ fontSize: "1rem", marginBottom: 16 }}>Top treatments</h3>
            {[
              ["Chelsea Signature Facial", 18, 2970],
              ["Hot Stone Ritual", 12, 2340],
              ["London Deep Tissue", 11, 1485],
              ["Radiance Half Day", 4, 1700],
            ].map(([n, count, rev]) => (
              <div key={n} style={{
                display: "grid", gridTemplateColumns: "1fr auto auto", gap: 14, alignItems: "center",
                padding: "12px 0", borderTop: "1px solid var(--line)",
              }}>
                <span style={{ fontSize: "0.92rem" }}>{n}</span>
                <span className="caption">{count}×</span>
                <span style={{ fontFamily: "var(--font-display)", color: "var(--gold-deep)" }}>£{rev}</span>
              </div>
            ))}
          </div>
        </div>
        <style>{`
          @media (max-width: 880px) {
            .admin-stats { grid-template-columns: 1fr 1fr !important; }
            .rev-grid { grid-template-columns: 1fr !important; }
          }
        `}</style>
      </div>
    </section>
  );
}

window.AdminPage = AdminPage;
