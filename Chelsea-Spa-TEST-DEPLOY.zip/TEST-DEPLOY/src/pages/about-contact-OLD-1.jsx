/* =========================================================================
   ABOUT PAGE — Brand story, team, membership, certifications
   ========================================================================= */

function AboutPage() {
  const { navigate } = useRouter();
  return (
    <div>
      <Nav />

      {/* HERO */}
      <section style={{ paddingTop: 160, paddingBottom: 80, background: "var(--bg-cream)", borderBottom: "1px solid var(--line)" }}>
        <div className="container-narrow">
          <div className="eyebrow">Our story</div>
          <h1 style={{ marginTop: 14, maxWidth: "16ch" }}>
            A small room on Hollywood Road, eleven years on.
          </h1>
          <p className="body-lg" style={{ marginTop: 24, maxWidth: "56ch" }}>
            We opened in 2014 with one rule — nothing rushed. Two therapists, three treatments, one quiet
            room. Today we still do most things by hand, and our shortest appointment is sixty minutes long.
          </p>
        </div>
      </section>

      {/* IMAGE TRIPTYCH */}
      <section style={{ padding: "80px 0" }}>
        <div className="container-wide">
          <div style={{ display: "grid", gridTemplateColumns: "1.4fr 1fr 1fr", gap: 16 }} className="trip-grid">
            <Placeholder label="treatment room" height={460} />
            <Placeholder label="apothecary shelf" height={460} />
            <Placeholder label="reception" height={460} />
          </div>
        </div>
        <style>{`
          @media (max-width: 880px) { .trip-grid { grid-template-columns: 1fr !important; } }
        `}</style>
      </section>

      {/* MANIFESTO */}
      <section className="section-lg" style={{ background: "var(--bg-cream)" }}>
        <div className="container-narrow">
          <div className="eyebrow" style={{ marginBottom: 24 }}>What we believe</div>
          {[
          { n: "01", t: "Nothing rushed.", b: "Our shortest appointment is an hour, and our therapists never run consecutive bookings without a buffer. Time is the only luxury we cannot reproduce." },
          { n: "02", t: "Products that earn their place.", b: "Every product on our shelves is apothecary-grade and tested by the team first. If we wouldn't put it on ourselves, it doesn't reach our guests." },
          { n: "03", t: "A long conversation, first.", b: "Every ritual begins with a quiet ten minutes to learn what your skin has been doing and what your week has been like. We adjust accordingly, every time." },
          { n: "04", t: "Quietly looked after.", b: "Our therapists are paid above industry average, given six weeks of leave, and trained every quarter. Their well-being is the foundation of yours." }].
          map((item, i, arr) =>
          <div key={item.n} style={{
            display: "grid", gridTemplateColumns: "120px 1fr", gap: 32,
            padding: "32px 0",
            borderTop: "1px solid var(--line)",
            borderBottom: i === arr.length - 1 ? "1px solid var(--line)" : "none"
          }} className="manifesto-row">
              <div className="eyebrow" style={{ color: "var(--gold-deep)" }}>{item.n}</div>
              <div>
                <h3>{item.t}</h3>
                <p className="body-lg" style={{ marginTop: 12, maxWidth: "56ch" }}>{item.b}</p>
              </div>
            </div>
          )}
        </div>
        <style>{`
          @media (max-width: 580px) { .manifesto-row { grid-template-columns: 1fr !important; gap: 12px !important; } }
        `}</style>
      </section>

      {/* TEAM */}
      <section className="section-lg">
        <div className="container-wide">
          <div className="section-head">
            <div className="eyebrow">The team</div>
            <h2>Hands you'll come to know by name.</h2>
          </div>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 32 }} className="team-grid">
            {THERAPISTS.filter((t) => t.id !== "any").map((t) =>
            <div key={t.id}>
                <Placeholder label={t.name.split(" ")[0].toLowerCase()} height={360} />
                <div style={{ marginTop: 20 }}>
                  <h3 style={{ fontSize: "1.3rem" }}>{t.name}</h3>
                  <div className="caption" style={{ marginTop: 4 }}>{t.title} · {t.years} years</div>
                  <div style={{ display: "flex", gap: 6, marginTop: 12 }}>
                    {t.specialties.map((s) => <span key={s} className="chip chip-line">{s}</span>)}
                  </div>
                  <p className="body-sm" style={{ marginTop: 14 }}>
                    Trained at the London College of Beauty Therapy, with{" "}
                    {t.years > 10 ? "over a decade of " : "several years of "}practice across Mayfair and Notting Hill.
                  </p>
                </div>
              </div>
            )}
          </div>
        </div>
        <style>{`
          @media (max-width: 880px) { .team-grid { grid-template-columns: 1fr !important; } }
        `}</style>
      </section>

      {/* MEMBERSHIP (anchor) */}
      <section id="membership" className="section-lg" style={{ background: "var(--ink)", color: "var(--ink-on-dark)" }}>
        <div className="container-wide">
          <div className="section-head" style={{ marginBottom: 56 }}>
            <div className="eyebrow" style={{ color: "var(--gold-soft)" }}>The Atelier Circle</div>
            <h2 style={{ color: "var(--ink-on-dark)" }}>
              Three ways<br />to be <em className="serif-italic" style={{ color: "var(--gold)" }}>cared for</em>.
            </h2>
          </div>

          <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 16 }} className="tier-grid">
            {[
            { name: "Quiet", price: 120, sub: "1 ritual / month", popular: false, feats: ["One 60-min ritual every month", "10% off products", "14-day priority booking"] },
            { name: "Atelier", price: 240, sub: "2 rituals / month", popular: true, feats: ["Two 75-min rituals every month", "15% off products", "21-day priority booking", "2 guest passes / year", "Seasonal half-day included"] },
            { name: "Patron", price: 480, sub: "Unlimited rituals", popular: false, feats: ["Unlimited bookings", "20% off products", "30-day priority booking", "6 guest passes / year", "Private suite access", "Quarterly facialist consult"] }].
            map((tier) =>
            <div key={tier.name} style={{
              background: tier.popular ? "var(--gold-deep)" : "transparent",
              border: `1px solid ${tier.popular ? "var(--gold-deep)" : "rgba(246,241,232,0.16)"}`,
              color: tier.popular ? "var(--ink)" : "var(--ink-on-dark)",
              borderRadius: 8, padding: "40px 32px",
              position: "relative"
            }}>
                {tier.popular &&
              <span style={{
                position: "absolute", top: -10, left: "50%", transform: "translateX(-50%)",
                background: "var(--ink)", color: "var(--gold-soft)",
                padding: "5px 14px", borderRadius: 999,
                fontFamily: "var(--font-display)", fontSize: "0.65rem",
                letterSpacing: "0.2em", textTransform: "uppercase"
              }}>Most loved</span>
              }
                <h3 style={{ color: "inherit", fontSize: "1.5rem" }}>{tier.name}</h3>
                <div style={{
                fontFamily: "var(--font-display)", fontSize: "2.6rem", fontWeight: 300,
                marginTop: 12, lineHeight: 1, letterSpacing: "-0.03em"
              }}>
                  £{tier.price}<span style={{ fontSize: "0.9rem", letterSpacing: "0.1em", marginLeft: 6, opacity: 0.7 }}>/ mo</span>
                </div>
                <div className="caption" style={{
                color: tier.popular ? "rgba(42,38,34,0.7)" : "rgba(246,241,232,0.6)",
                marginTop: 8, marginBottom: 24
              }}>{tier.sub}</div>
                <div style={{ height: 1, background: tier.popular ? "rgba(42,38,34,0.2)" : "rgba(246,241,232,0.16)", marginBottom: 24 }} />
                <ul style={{ listStyle: "none", display: "flex", flexDirection: "column", gap: 12 }}>
                  {tier.feats.map((f) =>
                <li key={f} style={{ display: "flex", gap: 10, alignItems: "flex-start", fontSize: "0.93rem", lineHeight: 1.5 }}>
                      <Icon name="check" size={14} className={tier.popular ? "" : "text-gold"} />
                      <span style={{ color: tier.popular ? "var(--ink)" : "rgba(246,241,232,0.85)" }}>{f}</span>
                    </li>
                )}
                </ul>
                <button onClick={() => navigate("/booking")} style={{
                marginTop: 32, width: "100%", padding: "16px 24px",
                background: tier.popular ? "var(--ink)" : "transparent",
                color: tier.popular ? "var(--ink-on-dark)" : "var(--ink-on-dark)",
                border: tier.popular ? "1px solid var(--ink)" : "1px solid rgba(246,241,232,0.4)",
                borderRadius: 2,
                fontFamily: "var(--font-display)", fontSize: "0.78rem",
                letterSpacing: "0.18em", textTransform: "uppercase",
                cursor: "pointer",
                transition: "all 240ms var(--ease)"
              }}>Join {tier.name}</button>
              </div>
            )}
          </div>
        </div>
        <style>{`
          @media (max-width: 980px) { .tier-grid { grid-template-columns: 1fr !important; gap: 24px !important; } }
        `}</style>
      </section>

      {/* PRESS / CERTS */}
      <section className="section">
        <div className="container-narrow" style={{ textAlign: "center" }}>
          <div className="eyebrow" style={{ marginBottom: 32 }}>As featured in</div>
          <div style={{
            display: "grid", gridTemplateColumns: "repeat(5, 1fr)", gap: 32, alignItems: "center"
          }} className="press-grid">
            {["Condé Nast", "Vogue UK", "Tatler", "Monocle", "Wallpaper*"].map((p) =>
            <div key={p} style={{
              fontFamily: "var(--font-display)", fontSize: "1.05rem", letterSpacing: "0.1em",
              color: "var(--ink-3)", opacity: 0.7
            }}>{p}</div>
            )}
          </div>
        </div>
        <style>{`
          @media (max-width: 880px) { .press-grid { grid-template-columns: repeat(2, 1fr) !important; } }
        `}</style>
      </section>

      <Footer />
    </div>);

}

/* =========================================================================
   CONTACT PAGE
   ========================================================================= */

function ContactPage() {
  const toast = useToast();
  const [form, setForm] = useState({ name: "", email: "", subject: "General", message: "" });
  const [sent, setSent] = useState(false);

  const submit = (e) => {
    e.preventDefault();
    if (!form.name || !form.email || !form.message) {
      toast("Please complete all required fields.");
      return;
    }
    setSent(true);
    toast("Message sent — we'll reply by end of day.", "success");
  };

  return (
    <div>
      <Nav />

      <section style={{ paddingTop: 160, paddingBottom: 64, background: "var(--bg-cream)", borderBottom: "1px solid var(--line)" }}>
        <div className="container-narrow">
          <div className="eyebrow">Visit · Write · Call</div>
          <h1 style={{ marginTop: 12 }}>Find us<span style={{ color: "var(--gold-deep)" }}>.</span></h1>
        </div>
      </section>

      <section style={{ padding: "80px 0 120px" }}>
        <div className="container-wide" style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 80 }} className="contact-grid">

          {/* LEFT — info */}
          <div style={{ padding: "6px" }}>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 32, marginBottom: 40, padding: "21px", width: "520px", margin: "0px 0px 40px 20px" }} className="ci-grid">
              <ContactInfo icon="map" label="Visit"
              title="53 Hollywood Road"
              lines={["Chelsea, London SW10 9HX", "\n"]} />
              <ContactInfo icon="phone" label="Call"
              title="020 7351 4555"
              lines={["Reception · 9am – 8pm daily", "Bookings preferred online"]} />
              <ContactInfo icon="mail" label="Write"
              title="thechelseaspa@gmail.com"
              lines={["We reply within one business day."]} />
              <ContactInfo icon="clock" label="Hours"
              title="Open today · 09:00 – 20:00"
              lines={["Mon – Fri  09:00 – 20:00", "Sat – Sun  10:00 – 18:00"]} />
            </div>

            {/* Map placeholder */}
            <div style={{
              position: "relative",
              height: 320,
              background:
              "repeating-linear-gradient(0deg, var(--bg-shell) 0px, var(--bg-shell) 1px, transparent 1px, transparent 28px), repeating-linear-gradient(90deg, var(--bg-shell) 0px, var(--bg-shell) 1px, transparent 1px, transparent 28px), var(--bg-nude)",
              borderRadius: 8,
              border: "1px solid var(--line)",
              overflow: "hidden", borderWidth: "1px 0px", padding: "11px"
            }}>
              {/* "streets" */}
              <div style={{ position: "absolute", left: 0, right: 0, top: "62%", height: 12, background: "var(--bg-cream)", transform: "rotate(-2deg)" }} />
              <div style={{ position: "absolute", left: "30%", top: 0, bottom: 0, width: 8, background: "var(--bg-cream)" }} />
              {/* pin */}
              <div style={{
                position: "absolute", left: "30%", top: "62%", transform: "translate(-50%, -100%)"
              }}>
                <div style={{
                  background: "var(--ink)", color: "var(--gold-soft)",
                  borderRadius: 999,
                  fontFamily: "var(--font-display)", fontSize: "0.72rem",
                  letterSpacing: "0.16em", textTransform: "uppercase",
                  whiteSpace: "nowrap",
                  marginBottom: 4, padding: "1px"
                }}>The Chelsea Spa</div>
                <div style={{
                  width: 14, height: 14, borderRadius: "50%",
                  background: "var(--gold-deep)",
                  border: "3px solid var(--ink-on-dark)",
                  margin: "0 auto",
                  boxShadow: "0 4px 12px rgba(0,0,0,0.2)"
                }} />
              </div>
              <div style={{
                position: "absolute", bottom: 16, right: 16,
                padding: "6px 12px",
                background: "var(--bg-cream)", borderRadius: 4,
                fontFamily: "var(--font-mono)", fontSize: "0.7rem"
              }}>51.4866° N, 0.1689° W</div>
            </div>
          </div>

          {/* RIGHT — form */}
          <div style={{ padding: "0px", width: "475px" }}>
            <h3 style={{ marginBottom: 8 }}>Send us a note</h3>
            <p className="text-ink-2" style={{ marginBottom: 28 }}>
              For bookings, please use <a onClick={() => window.location.hash = "/booking"} style={{ color: "var(--gold-deep)", cursor: "pointer", textDecoration: "underline", borderStyle: "solid", borderWidth: "1px" }}>the booking page</a> — it's quicker.
            </p>

            {sent ?
            <div className="fade-up" style={{
              padding: 48, textAlign: "center",
              background: "var(--bg-cream)", border: "1px solid var(--gold-soft)", borderRadius: 8
            }}>
                <div style={{ display: "inline-flex", padding: 16, background: "var(--bg-nude)", borderRadius: "50%", marginBottom: 20 }}>
                  <Icon name="check" size={20} className="text-gold" />
                </div>
                <h3>Thank you, {form.name.split(" ")[0]}.</h3>
                <p style={{ marginTop: 8, color: "var(--ink-2)" }}>We've received your note and will reply by end of day.</p>
                <Button variant="ghost" style={{ marginTop: 24 }} onClick={() => {setSent(false);setForm({ name: "", email: "", subject: "General", message: "" });}}>
                  Send another
                </Button>
              </div> :

            <form onSubmit={submit} style={{
              background: "var(--bg-cream)", border: "1px solid var(--line)", borderRadius: 8,
              padding: 32
            }}>
                <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16, marginBottom: 16 }}>
                  <label>
                    <span className="label">Name</span>
                    <input className="input" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="Your name" />
                  </label>
                  <label>
                    <span className="label">Email</span>
                    <input className="input" type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} placeholder="you@example.com" />
                  </label>
                </div>
                <label style={{ display: "block", marginBottom: 16 }}>
                  <span className="label">Subject</span>
                  <select className="input" value={form.subject} onChange={(e) => setForm({ ...form, subject: e.target.value })}>
                    <option>General enquiry</option>
                    <option>Memberships</option>
                    <option>Gift cards</option>
                    <option>Press</option>
                    <option>Careers</option>
                  </select>
                </label>
                <label style={{ display: "block", marginBottom: 24 }}>
                  <span className="label">Message</span>
                  <textarea className="input" value={form.message} onChange={(e) => setForm({ ...form, message: e.target.value })}
                rows={6} placeholder="Tell us a little about what you're after…"
                style={{ resize: "vertical" }} />
                </label>
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", gap: 16, flexWrap: "wrap" }}>
                  <span className="caption">We typically reply within one business day.</span>
                  <Button variant="primary" type="submit" iconRight="arrow-right">Send note</Button>
                </div>
              </form>
            }
          </div>
        </div>
        <style>{`
          @media (max-width: 980px) {
            .contact-grid { grid-template-columns: 1fr !important; gap: 56px !important; }
          }
          @media (max-width: 580px) {
            .ci-grid { grid-template-columns: 1fr !important; }
          }
        `}</style>
      </section>

      <Footer />
    </div>);

}

function ContactInfo({ icon, label, title, lines }) {
  return (
    <div>
      <div style={{ display: "flex", alignItems: "center", gap: 10, color: "var(--gold-deep)" }}>
        <Icon name={icon} size={14} />
        <span className="eyebrow">{label}</span>
      </div>
      <div style={{ fontFamily: "var(--font-display)", fontSize: "1.2rem", marginTop: 12, marginBottom: 8, letterSpacing: "-0.01em" }}>{title}</div>
      {lines.map((l, i) =>
      <div key={i} className="body-sm text-ink-2">{l}</div>
      )}
    </div>);

}

window.AboutPage = AboutPage;
window.ContactPage = ContactPage;