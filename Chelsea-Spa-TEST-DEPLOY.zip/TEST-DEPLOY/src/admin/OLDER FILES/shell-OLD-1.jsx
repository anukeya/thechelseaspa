/* =========================================================================
   ADMIN SHELL — login, sidebar, topbar, secure role display, dark mode, routing
   ========================================================================= */

const ADMIN_NAV = [
  { group: "Workspace", items: [
    { id: "overview",  label: "Overview",     icon: "grid" },
    { id: "calendar",  label: "Calendar",     icon: "calendar" },
    { id: "bookings",  label: "Bookings",     icon: "clock" },
  ]},
  { group: "Manage", items: [
    { id: "customers", label: "Customers",    icon: "users" },
    { id: "staff",     label: "Staff & rota", icon: "user" },
    { id: "catalog",   label: "Catalog",      icon: "scissors" },
    { id: "inventory", label: "Inventory",    icon: "package" },
  ]},
  { group: "Business", items: [
    { id: "sales",         label: "Sales & payments", icon: "wallet" },
    { id: "marketing",     label: "Content (CMS)",    icon: "megaphone" },
    { id: "notifications", label: "Notifications",    icon: "bell" },
    { id: "settings",      label: "Settings",         icon: "settings" },
  ]},
];

const MODULE_MAP = {
  overview: ModuleOverview, calendar: ModuleCalendar, bookings: ModuleBookings,
  customers: ModuleCustomers, staff: ModuleStaff, catalog: ModuleCatalog,
  inventory: ModuleInventory, sales: ModuleSales, marketing: ModuleMarketing,
  notifications: ModuleNotifications, settings: ModuleSettings,
};

const MODULE_TITLE = {
  overview: "Overview", calendar: "Calendar", bookings: "Bookings", customers: "Customers",
  staff: "Staff & rota", catalog: "Catalog", inventory: "Inventory", sales: "Sales & payments",
  marketing: "Content", notifications: "Notifications", settings: "Settings",
};

// ==========================================================
// NORMALISE CHELSEA SPA ACCESS ROLES
//
// New system:
// super_admin
// admin
// practitioner
//
// The legacyRole support is temporary while we migrate
// old profile records.
// ==========================================================

function normalizeAccessRole(
  accessRole,
  legacyRole
) {

  const validRoles = [
    "super_admin",
    "admin",
    "practitioner"
  ];


  // New database role already exists.
  if (
    validRoles.includes(accessRole)
  ) {
    return accessRole;
  }


  // Temporary conversion for old profiles.
  const oldRoleMap = {
    super_admin: "super_admin",
    manager: "admin",
    receptionist: "practitioner",
    therapist: "practitioner"
  };


  return (
    oldRoleMap[legacyRole] ||
    "practitioner"
  );
}

function AdminApp() {
  return (
    <ToastProvider>
      <AdminShell/>
    </ToastProvider>
  );
}

function AdminShell() {
  const [authed, setAuthed] = useState(false);
  const [checkingSession, setCheckingSession] = useState(true);
  const [module, setModule] = useState("overview");
  // Start with the lowest permission level.
  // The real role is loaded from Supabase.
  const [role, setRole] = useState("practitioner");
  const [currentUser, setCurrentUser] = useState({
    name: "Staff",
    email: ""
  });
  const [dark, setDark] = useState(() => localStorage.getItem("cs-admin-dark") === "1");
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [search, setSearch] = useState("");

  useEffect(() => {
    let cancelled = false;

    async function restoreSupabaseSession() {
      try {
        const { data, error } = await window.supabaseClient.auth.getSession();
        if (error) throw error;

        const session = data.session;
        if (!session) return;

        const { data: profile, error: profileError } = await window.supabaseClient
          .from("profiles")
          .select("access_role, role, is_active, first_name, last_name, email")
          .eq("id", session.user.id)
          .single();

        if (profileError) throw profileError;
        if (!profile?.is_active || profile.role === "inactive") {
          await window.supabaseClient.auth.signOut();
          return;
        }

        // Convert either the new access_role
        // or an older legacy role.
        const resolvedRole =
          normalizeAccessRole(
            profile.access_role,
            profile.role
          );

        if (!cancelled) {
          const profileName = [
            profile.first_name,
            profile.last_name
          ]
            .filter(Boolean)
            .join(" ")
            .trim();

          setRole(resolvedRole);

          setCurrentUser({
            name:
              profileName ||
              session.user.email?.split("@")[0] ||
              "Staff",
            email:
              profile.email ||
              session.user.email ||
              ""
          });

          setAuthed(true);
        }
      } catch (error) {
        console.error("Could not restore admin session:", error);
      } finally {
        if (!cancelled) setCheckingSession(false);
      }
    }

    restoreSupabaseSession();
    return () => { cancelled = true; };
  }, []);

  useEffect(() => {
    document.documentElement.classList.toggle("admin-dark", dark);
    document.body.classList.toggle("admin-dark", dark);
    localStorage.setItem("cs-admin-dark", dark ? "1" : "0");
  }, [dark]);

  // ==========================================================
  // MODULES THIS ROLE MAY OPEN
  //
  // The fallback [] prevents AdminShell from crashing
  // if a bad/old role ever reaches the frontend.
  // ==========================================================

  const allowed = AD.PERMS?.[role] || [];
  // If current module not allowed for role, bounce to overview
  // If the current page is not permitted,
  // return the user to Overview.
useEffect(() => {

  if (!allowed.includes(module)) {
      setModule("overview");
    }
  }, [role, module]);

  const go = (m) => { setModule(m); setSidebarOpen(false); window.scrollTo({ top: 0 }); };

  if (checkingSession) {
    return (
      <div style={{ minHeight: "100vh", display: "grid", placeItems: "center", background: "var(--bg)" }}>
        <div className="caption">Checking secure session…</div>
      </div>
    );
  }

  if (!authed) {
    return (
      <AdminLogin
          onLogin={(loginUser) => {
            // AdminLogin has already resolved
            // the real Chelsea Spa access role.
            setRole(loginUser.role);
            setCurrentUser({
              name: loginUser.name,
              email: loginUser.email
            });
            setAuthed(true);
        }}
        dark={dark}
        setDark={setDark}
      />
    );
  }

  const Module = MODULE_MAP[module];

  return (
    <div className="admin-root">
      {/* SIDEBAR */}
      <aside className={`admin-sidebar ${sidebarOpen ? "open" : ""}`}>
        <div style={{ padding: "22px 22px 18px", borderBottom: "1px solid var(--line)", display: "flex", alignItems: "center", justifyContent: "space-between" }}>
          <Logo size={24}/>
          <button className="icon-btn mobile-only" style={{ width: 34, height: 34 }} onClick={() => setSidebarOpen(false)}><Icon name="x" size={18}/></button>
        </div>

        <div className="hide-scroll" style={{ flex: 1, overflowY: "auto", padding: "8px 14px 20px" }}>
          {ADMIN_NAV.map(grp => {
            const items = grp.items.filter(it => allowed.includes(it.id));
            if (!items.length) return null;
            return (
              <div key={grp.group}>
                <div className="nav-group-label">{grp.group}</div>
                <div style={{ display: "flex", flexDirection: "column", gap: 2 }}>
                  {items.map(it => (
                    <button key={it.id} className={`nav-item ${module === it.id ? "active" : ""}`} onClick={() => go(it.id)}>
                      <span className="nav-ic"><Icon name={it.icon} size={17}/></span>
                      {it.label}
                    </button>
                  ))}
                </div>
              </div>
            );
          })}
        </div>

        {/* sidebar footer */}
        <div style={{ padding: "14px", borderTop: "1px solid var(--line)" }}>
          <a href="index.html" className="nav-item" style={{ marginBottom: 2 }}>
            <span className="nav-ic"><Icon name="external" size={17}/></span>
            View website
          </a>
          <button className="nav-item" onClick={async () => {
            await window.supabaseClient.auth.signOut();
            setAuthed(false);
            setRole("practitioner");
            setCurrentUser({
              name: "Staff",
              email: ""
            });
          }}>
            <span className="nav-ic"><Icon name="logout" size={17}/></span>
            Sign out
          </button>
        </div>
      </aside>

      {/* scrim for mobile sidebar */}
      {sidebarOpen && <div onClick={() => setSidebarOpen(false)} style={{ position: "fixed", inset: 0, zIndex: 90, background: "rgba(20,16,12,0.4)" }} className="mobile-only"/>}

      {/* MAIN */}
      <div className="admin-main">
        <header className="admin-topbar">
          <button className="icon-btn mobile-only" onClick={() => setSidebarOpen(true)}><Icon name="menu" size={20}/></button>

          <SearchInput value={search} onChange={setSearch} placeholder="Search bookings, customers, treatments…" width={340}/>

          <div style={{ flex: 1 }}/>

          {/* Authenticated access role — read only in production */}
          <div
            style={{
              display: "flex",
              alignItems: "center",
              gap: 7,
              padding: "8px 11px",
              borderRadius: 8,
              border: "1px solid var(--line-strong)",
              background: "var(--bg)",
              color: "var(--ink-2)"
            }}
            title="Your access role"
          >
            <Icon name="shield" size={14}/>
            <span
              className="role-text"
              style={{
                fontFamily: "var(--font-display)",
                fontSize: "0.76rem",
                letterSpacing: "0.04em"
              }}
            >
              {AD.ROLES?.[role]?.label || "Staff"}
            </span>
          </div>

          {/* dark mode */}
          <IconBtn icon={dark ? "sun" : "moon"} title="Toggle theme" onClick={() => setDark(!dark)}/>

          {/* notifications */}
          <IconBtn icon="bell" title="Notifications" badge={3} onClick={() => go("notifications")}/>

          {/* authenticated user */}
          <div style={{ display: "flex", alignItems: "center", gap: 10, paddingLeft: 8, borderLeft: "1px solid var(--line)" }}>
            <Avatar name={currentUser.name} size={34} color="var(--gold-deep)"/>
            <div className="topbar-user" style={{ lineHeight: 1.2 }}>
              <div style={{ fontFamily: "var(--font-display)", fontSize: "0.82rem" }}>
                {currentUser.name}
              </div>
              <div className="caption" style={{ fontSize: "0.64rem" }}>
                {AD.ROLES?.[role]?.label || "Staff"}
              </div>
            </div>
          </div>
        </header>

        <main className="admin-content" key={module}>
          <Module go={go}/>
        </main>
      </div>

      <style>{`
        @media (max-width: 720px) { .topbar-user { display: none; } }
      `}</style>
    </div>
  );
}

/* ---- Login screen --------------------------------------------------- */
function AdminLogin({ onLogin, dark, setDark }) {
  const [mode, setMode] = useState("login"); // login | forgot
  const [email, setEmail] = useState("thechelseaspa@gmail.com");
  const [pw, setPw] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const submit = async (e) => {
    e.preventDefault();
    setError(null);
    setLoading(true);

    try {
      const { data, error: signInError } = await window.supabaseClient.auth
        .signInWithPassword({
          email: email.trim(),
          password: pw,
        });

      if (signInError) throw signInError;
      if (!data.user || !data.session) {
        throw new Error("Supabase did not create a login session.");
      }

      const {data: profile, error: profileError} =
        await window.supabaseClient
          .from("profiles")
          .select(`
            access_role,
            role,
            is_active,
            first_name,
            last_name,
            email`)
          .eq("id", data.user.id)
          .single();

      if (profileError) throw profileError;

      if (!profile?.is_active) {

        await window.supabaseClient
          .auth
          .signOut();

        throw new Error(
          "This staff account is not active. Ask a Super Admin to enable it."
        );
      }


      // Convert either new or legacy profile
      // into our current access-role system.
      const resolvedRole =
        normalizeAccessRole(
          profile.access_role,
          profile.role
        );
      const profileName = [
        profile.first_name,
        profile.last_name
      ]
        .filter(Boolean)
        .join(" ")
        .trim();

      onLogin({
        role: resolvedRole,
        name:
          profileName ||
          data.user.email?.split("@")[0] ||
          "Staff",
        email:
          profile.email ||
          data.user.email ||
          ""
      });
    } catch (err) {
      console.error("Supabase sign-in failed:", err);
      setError(err.message || "Sign in failed");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={{ minHeight: "100vh", display: "grid", gridTemplateColumns: "1fr 1fr", background: "var(--bg)" }} className="login-root">
      {/* left: brand panel */}
      <div style={{ background: "var(--ink)", color: "var(--ink-on-dark)", padding: "56px 64px", display: "flex", flexDirection: "column", justifyContent: "space-between", position: "relative", overflow: "hidden" }} className="login-brand">
        <Logo light size={26}/>
        <div style={{ position: "relative", zIndex: 2 }}>
          <div className="eyebrow" style={{ color: "var(--gold-soft)" }}>Staff console</div>
          <h1 style={{ color: "var(--ink-on-dark)", fontSize: "3rem", marginTop: 14, fontWeight: 300, lineHeight: 1.05 }}>
            Everything,<br/><em className="serif-italic" style={{ color: "var(--gold)" }}>quietly in order</em>.
          </h1>
          <p style={{ color: "rgba(246,241,232,0.7)", marginTop: 20, maxWidth: "42ch", lineHeight: 1.6 }}>
            Calendar, customers, catalogue and cash — one calm place to run The Chelsea Spa.
          </p>
        </div>
        <div style={{ position: "relative", zIndex: 2, display: "flex", gap: 28 }}>
          <div><div style={{ fontFamily: "var(--font-display)", fontSize: "1.6rem", color: "var(--gold-soft)" }}>1,284</div><div className="caption" style={{ color: "rgba(246,241,232,0.5)" }}>Customers</div></div>
          <div><div style={{ fontFamily: "var(--font-display)", fontSize: "1.6rem", color: "var(--gold-soft)" }}>£42.8k</div><div className="caption" style={{ color: "rgba(246,241,232,0.5)" }}>Revenue MTD</div></div>
          <div><div style={{ fontFamily: "var(--font-display)", fontSize: "1.6rem", color: "var(--gold-soft)" }}>4.9★</div><div className="caption" style={{ color: "rgba(246,241,232,0.5)" }}>Avg. rating</div></div>
        </div>
        <div style={{ position: "absolute", right: -80, bottom: -80, opacity: 0.08, zIndex: 1 }}><LogoMark size={420} color="#fff"/></div>
      </div>

      {/* right: form */}
      <div style={{ display: "flex", alignItems: "center", justifyContent: "center", padding: 40, position: "relative" }}>
        <button className="icon-btn" style={{ position: "absolute", top: 24, right: 24 }} onClick={() => setDark(!dark)}><Icon name={dark ? "sun" : "moon"} size={18}/></button>
        <div style={{ width: "100%", maxWidth: 380 }}>
          {mode === "login" ? (
            <form onSubmit={submit}>
              <h2 style={{ fontSize: "1.8rem" }}>Welcome back</h2>
              <p className="text-ink-2" style={{ marginTop: 8, marginBottom: 32 }}>Sign in to the staff console.</p>
              <div style={{ marginBottom: 16 }}>
                <div className="a-label">Email</div>
                <input className="a-input" value={email} onChange={e => setEmail(e.target.value)} type="email"/>
              </div>
              <div style={{ marginBottom: 12 }}>
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                  <span className="a-label">Password</span>
                  <button type="button" onClick={() => setMode("forgot")} className="caption" style={{ color: "var(--gold-deep)", textTransform: "uppercase", letterSpacing: "0.1em", marginBottom: 7 }}>Forgot?</button>
                </div>
                <input className="a-input" value={pw} onChange={e => setPw(e.target.value)} type="password" placeholder="••••••••"/>
              </div>
              <label style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 24, fontSize: "0.84rem", color: "var(--ink-2)", cursor: "pointer" }}>
                <input type="checkbox" defaultChecked style={{ accentColor: "var(--gold-deep)" }}/> Keep me signed in
              </label>
              <Button variant="primary" type="submit" size="lg" disabled={loading} style={{ width: "100%" }}>
                {loading ? "Signing in…" : "Sign in"}
              </Button>
              {error && (
                <div style={{ marginTop: 14, padding: "10px 14px", borderRadius: 6, background: "rgba(154,74,58,0.1)", border: "1px solid rgba(154,74,58,0.3)", color: "var(--danger)", fontSize: "0.84rem", display: "flex", gap: 8, alignItems: "center" }}>
                  <Icon name="alert" size={15}/> {error}
                </div>
              )}
              <div style={{ marginTop: 24, display: "flex", alignItems: "center", gap: 10, justifyContent: "center" }}>
                <Icon name="lock" size={13} className="text-ink-3"/>
                <span className="caption">Secured with Supabase Auth · RLS protected</span>
              </div>
            </form>
          ) : (
            <div>
              <h2 style={{ fontSize: "1.8rem" }}>Reset password</h2>
              <p className="text-ink-2" style={{ marginTop: 8, marginBottom: 32 }}>We'll email you a secure reset link.</p>
              <div style={{ marginBottom: 24 }}>
                <div className="a-label">Email</div>
                <input className="a-input" defaultValue={email} type="email"/>
              </div>
              <Button variant="primary" size="lg" onClick={() => setMode("login")} style={{ width: "100%" }}>Send reset link</Button>
              <button onClick={() => setMode("login")} className="caption" style={{ marginTop: 20, color: "var(--gold-deep)", textTransform: "uppercase", letterSpacing: "0.12em", width: "100%", textAlign: "center" }}>← Back to sign in</button>
            </div>
          )}
        </div>
      </div>

      <style>{`
        @media (max-width: 880px) {
          .login-root { grid-template-columns: 1fr !important; }
          .login-brand { display: none !important; }
        }
      `}</style>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById("admin-root")).render(<AdminApp/>);
