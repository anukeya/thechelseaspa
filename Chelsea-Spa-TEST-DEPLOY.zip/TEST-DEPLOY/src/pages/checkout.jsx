/* =========================================================================
   STEP 10D — STRIPE-HOSTED CHECKOUT

   This page never collects raw card data.
   It creates/reuses a Stripe Checkout Session through Supabase Edge
   Functions and redirects the customer to Stripe's hosted payment page.

   A Stripe success URL is NOT treated as proof of payment. After return,
   this page asks the server for the webhook-confirmed payment state.
   ========================================================================= */

function CheckoutPage() {
  const { navigate } = useRouter();
  const toast = useToast();

  const params =
    useMemo(
      () => readCheckoutReturnParams(),
      [window.location.hash]
    );

  // Stripe now returns using a normal query string BEFORE the hash.
  // This makes the success state survive any hash-router normalisation.
  function leaveCheckout(path) {
    const cleanTarget =
      `${window.location.pathname}#${path}`;

    window.location.assign(cleanTarget);
  }

  const [booking] =
    useState(() =>
      readSavedBookingHold()
    );

  const [payMode, setPayMode] =
    useState(() =>
      booking && Number(booking.deposit_due || 0) > 0
        ? "deposit"
        : "full"
    );

  const [processing, setProcessing] =
    useState(false);

  const [statusLoading, setStatusLoading] =
    useState(false);

  const [checkoutStatus, setCheckoutStatus] =
    useState(null);

  const [statusError, setStatusError] =
    useState("");



  useEffect(() => {
    if (
      params.success === "1" &&
      params.session_id
    ) {
      verifyPayment(
        params.session_id
      );
    }
  }, [
    params.success,
    params.session_id
  ]);


  async function verifyPayment(sessionId) {
    setStatusLoading(true);
    setStatusError("");

    // The webhook can arrive just after the browser redirect.
    // Poll briefly rather than falsely declaring success from the URL.
    for (let attempt = 0; attempt < 8; attempt += 1) {
      try {
        const result =
          await window.API.Payments
            .checkoutStatus(
              sessionId
            );

        setCheckoutStatus(result);

        if (
          result?.payment_status === "paid" ||
          result?.payment_status === "partial" ||
          result?.appointment_status === "confirmed"
        ) {
          const finalSnapshot =
            buildConfirmedBookingSnapshot(
              booking ||
              confirmedBooking,
              result
            );

          setConfirmedBooking(
            finalSnapshot
          );

          saveConfirmedBooking(
            finalSnapshot
          );

          setStatusLoading(false);

          // The Stripe webhook is the single source of truth for
          // payment confirmation and it triggers booking-notifications
          // server-side. The browser must not send a second notification.
          clearSavedBookingHold();
          return;
        }

        if (
          result?.payment_record_status === "failed" ||
          result?.appointment_status === "expired"
        ) {
          setStatusLoading(false);
          return;
        }

      } catch (err) {
        console.error(
          "Checkout verification failed:",
          err
        );

        if (attempt === 7) {
          setStatusError(
            err?.message ||
            "Payment status could not be checked."
          );
        }
      }

      await sleepCheckout(1250);
    }

    setStatusLoading(false);
  }


  async function onPay() {
    if (!booking) {
      toast(
        "Your booking hold is missing. Please start again."
      );
      return;
    }

    if (bookingHoldExpired(booking)) {
      toast(
        "Your appointment hold has expired. Please choose the time again."
      );
      return;
    }

    setProcessing(true);

    try {
      const result =
        await window.API.Payments
          .startCheckout({
            appointment_id:
              booking.appointment_id,

            reference:
              booking.reference,

            payment_type:
              payMode
          });

      if (result.session_id) {
        sessionStorage.setItem(
          "cs_checkout_session_id",
          result.session_id
        );
      }

      window.location.href =
        result.url;

    } catch (err) {
      console.error(
        "Payment could not be started:",
        err
      );

      toast(
        err?.message ||
        "Payment could not be started."
      );

      setProcessing(false);
    }
  }


  if (
    params.success === "1" &&
    params.session_id
  ) {
    return (
      <CheckoutResultPage
        loading={statusLoading}
        status={checkoutStatus}
        booking={
          booking ||
          confirmedBooking
        }
        error={statusError}
        onRetry={() =>
          verifyPayment(
            params.session_id
          )
        }
        onHome={() =>
          leaveCheckout("/")
        }
        onTreatments={() =>
          leaveCheckout("/treatments")
        }
      />
    );
  }


  if (params.cancelled === "1") {
    return (
      <div>
        <Nav />

        <section
          style={{
            padding: "180px 0 140px"
          }}
        >
          <div className="container-narrow">
            <CheckoutNotice
              icon="arrow-left"
              title="Payment was cancelled"
              body="Your appointment may still be held for a short time. You can return to payment while the hold is active, or choose a new appointment if it has expired."
            >
              <Button
                variant="primary"
                onClick={() =>
                  leaveCheckout("/checkout")
                }
              >
                Return to payment
              </Button>

              <Button
                variant="ghost"
                onClick={() =>
                  leaveCheckout("/booking")
                }
              >
                Choose another time
              </Button>
            </CheckoutNotice>
          </div>
        </section>

        <Footer />
      </div>
    );
  }


  if (!booking) {
    return (
      <div>
        <Nav />

        <section
          style={{
            padding: "180px 0 140px"
          }}
        >
          <div className="container-narrow">
            <CheckoutNotice
              icon="calendar"
              title="No booking is waiting for payment"
              body="Choose a treatment, appointment time and therapist first."
            >
              <Button
                variant="primary"
                onClick={() =>
                  leaveCheckout("/booking")
                }
              >
                Start booking
              </Button>
            </CheckoutNotice>
          </div>
        </section>

        <Footer />
      </div>
    );
  }


  const fullAmount =
    Number(booking.price || 0);

  const depositAmount =
    Number(
      booking.deposit_due || 0
    );

  const canPayDeposit =
    depositAmount > 0 &&
    depositAmount < fullAmount;

  const chargedNow =
    payMode === "deposit" && canPayDeposit
      ? depositAmount
      : fullAmount;

  const balance =
    Math.max(
      0,
      fullAmount - chargedNow
    );


  return (
    <div>
      <Nav />

      <section
        style={{
          padding: "150px 0 120px"
        }}
      >
        <div
          className="container-narrow checkout-grid"
          style={{
            display: "grid",
            gridTemplateColumns: "1fr 330px",
            gap: 44
          }}
        >
          <div>
            <button
              onClick={() =>
                navigate("/booking")
              }
              className="caption"
              style={{
                display: "inline-flex",
                alignItems: "center",
                gap: 6,
                marginBottom: 26,
                color: "var(--ink-2)"
              }}
            >
              <Icon
                name="arrow-left"
                size={14}
              />
              Back to booking
            </button>

            <div className="eyebrow">
              Secure payment
            </div>

            <h1
              style={{
                marginTop: 10,
                marginBottom: 14
              }}
            >
              Confirm your appointment
              <span
                style={{
                  color: "var(--gold-deep)"
                }}
              >
                .
              </span>
            </h1>

            <p
              className="body-lg text-ink-2"
              style={{
                maxWidth: "52ch",
                marginBottom: 32
              }}
            >
              Choose how much to pay today. The payment itself is completed securely on Stripe's hosted checkout page.
            </p>


            <CheckoutCard
              title="Payment amount"
              sub="The exact treatment price was calculated by the booking server for your selected therapist."
            >
              {canPayDeposit && (
                <CheckoutPayChoice
                  selected={payMode === "deposit"}
                  onClick={() =>
                    setPayMode("deposit")
                  }
                  title={`Pay deposit · £${depositAmount.toFixed(2)}`}
                  sub={`£${balance.toFixed(2)} remaining after the deposit.`}
                />
              )}

              <CheckoutPayChoice
                selected={payMode === "full" || !canPayDeposit}
                onClick={() =>
                  setPayMode("full")
                }
                title={`Pay in full · £${fullAmount.toFixed(2)}`}
                sub="Nothing left to pay for the treatment on the day."
              />
            </CheckoutCard>


            <CheckoutCard
              title="Secure Stripe Checkout"
              sub="Card details, Apple Pay, Google Pay and any other available payment methods are handled by Stripe — not by this website."
            >
              <div
                style={{
                  padding: "18px",
                  borderRadius: 6,
                  background: "var(--bg-nude)",
                  display: "flex",
                  gap: 12,
                  alignItems: "flex-start"
                }}
              >
                <Icon
                  name="shield"
                  size={18}
                  className="text-gold"
                />

                <div>
                  <div
                    style={{
                      fontFamily: "var(--font-display)",
                      fontSize: "0.94rem"
                    }}
                  >
                    Your card details never touch Chelsea Spa's website
                  </div>

                  <div
                    className="caption"
                    style={{
                      marginTop: 5,
                      lineHeight: 1.5
                    }}
                  >
                    After you press the button below, you will be redirected to Stripe to complete payment securely.
                  </div>
                </div>
              </div>
            </CheckoutCard>


            <div
              style={{
                display: "flex",
                gap: 10,
                alignItems: "center",
                marginTop: 20,
                color: "var(--ink-3)",
                fontSize: "0.82rem"
              }}
            >
              <Icon name="clock" size={14} />
              Initial appointment hold expires at {formatCheckoutDateTime(booking.hold_expires_at)}. Starting Stripe Checkout extends the hold to match the Stripe session.
            </div>


            <Button
              variant="primary"
              size="lg"
              onClick={onPay}
              disabled={processing}
              style={{
                width: "100%",
                marginTop: 22
              }}
            >
              {processing
                ? "Opening secure payment…"
                : `Pay £${chargedNow.toFixed(2)} securely with Stripe`}
            </Button>
          </div>


          <aside
            style={{
              position: "sticky",
              top: 120,
              alignSelf: "start",
              background: "var(--bg-cream)",
              border: "1px solid var(--line)",
              borderRadius: 8,
              padding: 26
            }}
          >
            <div
              className="eyebrow"
              style={{ marginBottom: 16 }}
            >
              Appointment summary
            </div>

            <CheckoutSummaryRow
              label="Reference"
              value={booking.reference}
            />

            <CheckoutSummaryRow
              label="Treatment"
              value={booking.treatment?.name}
            />

            <CheckoutSummaryRow
              label="Therapist"
              value={booking.therapist?.staff_name}
            />

            <CheckoutSummaryRow
              label="Date"
              value={formatCheckoutDate(booking.start_at)}
            />

            <CheckoutSummaryRow
              label="Time"
              value={formatCheckoutTime(booking.start_at)}
            />

            <CheckoutSummaryRow
              label="Customer"
              value={
                [
                  booking.customer?.first_name,
                  booking.customer?.last_name
                ]
                  .filter(Boolean)
                  .join(" ")
              }
            />

            <div className="divider" />

            <div
              style={{
                display: "flex",
                justifyContent: "space-between",
                marginTop: 16
              }}
            >
              <span
                style={{
                  fontFamily: "var(--font-display)"
                }}
              >
                Treatment price
              </span>

              <span
                style={{
                  fontFamily: "var(--font-display)",
                  color: "var(--gold-deep)",
                  fontSize: "1.15rem"
                }}
              >
                £{fullAmount.toFixed(2)}
              </span>
            </div>

            <div
              className="caption"
              style={{
                marginTop: 10,
                lineHeight: 1.5
              }}
            >
              The appointment is confirmed only after Stripe reports a successful payment to our server.
            </div>
          </aside>
        </div>

        <style>{`
          @media (max-width: 880px) {
            .checkout-grid {
              grid-template-columns: 1fr !important;
            }

            .checkout-grid > aside {
              position: relative !important;
              top: 0 !important;
              order: -1;
            }
          }
        `}</style>
      </section>

      <Footer />
    </div>
  );
}


function CheckoutResultPage({
  loading,
  status,
  booking,
  error,
  onRetry,
  onHome,
  onTreatments
}) {
  const confirmed =
    status?.appointment_status === "confirmed" &&
    ["paid", "partial"].includes(
      status?.payment_status
    );

  const failed =
    status?.payment_record_status === "failed" ||
    status?.appointment_status === "expired";

  const reference =
    status?.reference ||
    booking?.reference ||
    "—";

  const treatmentName =
    status?.service_name ||
    booking?.treatment?.name ||
    "—";

  const appointmentStart =
    status?.start_at ||
    booking?.start_at ||
    null;

  const therapistName =
    status?.staff_name ||
    status?.therapist_name ||
    booking?.therapist?.staff_name ||
    "—";

  const customerEmail =
    status?.customer_email ||
    booking?.customer?.email ||
    "";

  const customerPhone =
    status?.customer_phone ||
    booking?.customer?.phone ||
    "";

  return (
    <div>
      <Nav />

      <section
        style={{
          padding: "160px 0 130px"
        }}
      >
        <div className="container-narrow">
          {loading && (
            <CheckoutNotice
              icon="clock"
              title="Finalising your payment…"
              body="Stripe has returned you to Chelsea Spa. We are waiting for the secure payment confirmation from the Stripe webhook."
            />
          )}

          {!loading && confirmed && (
            <div
              style={{
                maxWidth: 720,
                margin: "0 auto",
                padding: "52px 42px",
                background: "var(--bg-cream)",
                border: "1px solid var(--line)",
                borderRadius: 10,
                boxShadow: "var(--shadow-2)"
              }}
            >
              <div
                style={{
                  textAlign: "center"
                }}
              >
                <div
                  style={{
                    width: 62,
                    height: 62,
                    margin: "0 auto 20px",
                    borderRadius: "50%",
                    display: "grid",
                    placeItems: "center",
                    background: "var(--bg-nude)",
                    color: "var(--gold-deep)"
                  }}
                >
                  <Icon
                    name="check"
                    size={28}
                  />
                </div>

                <div className="eyebrow">
                  Payment successful
                </div>

                <h1
                  style={{
                    marginTop: 10,
                    marginBottom: 12,
                    fontSize: "clamp(2rem, 5vw, 3.2rem)"
                  }}
                >
                  Booking Confirmed
                </h1>

                <p
                  className="body-lg text-ink-2"
                  style={{
                    maxWidth: "52ch",
                    margin: "0 auto"
                  }}
                >
                  Your appointment at The Chelsea Spa is confirmed.
                  {status?.payment_status === "partial"
                    ? " Your deposit has been received."
                    : " Your treatment has been paid in full."}
                </p>
              </div>


              <div
                style={{
                  margin: "32px 0 22px",
                  padding: "22px 20px",
                  textAlign: "center",
                  background: "var(--bg-nude)",
                  border: "1px solid var(--gold-soft)",
                  borderRadius: 8
                }}
              >
                <div
                  className="caption"
                  style={{
                    textTransform: "uppercase",
                    letterSpacing: "0.14em"
                  }}
                >
                  Booking Reference
                </div>

                <div
                  style={{
                    marginTop: 7,
                    fontFamily: "var(--font-display)",
                    fontSize: "1.8rem",
                    color: "var(--gold-deep)",
                    overflowWrap: "anywhere"
                  }}
                >
                  {reference}
                </div>
              </div>


              <div
                style={{
                  border: "1px solid var(--line)",
                  borderRadius: 8,
                  overflow: "hidden"
                }}
              >
                <CheckoutConfirmationRow
                  label="Treatment"
                  value={treatmentName}
                />

                <CheckoutConfirmationRow
                  label="Date"
                  value={
                    formatCheckoutDate(
                      appointmentStart
                    )
                  }
                />

                <CheckoutConfirmationRow
                  label="Time"
                  value={
                    formatCheckoutTime(
                      appointmentStart
                    )
                  }
                />

                <CheckoutConfirmationRow
                  label="Therapist"
                  value={therapistName}
                />

                <CheckoutConfirmationRow
                  label="Paid today"
                  value={
                    `£${Number(
                      status?.amount_paid || 0
                    ).toFixed(2)}`
                  }
                  last
                />
              </div>


              <div
                style={{
                  marginTop: 20,
                  padding: "15px 17px",
                  borderRadius: 8,
                  border: "1px solid var(--line)",
                  background: "var(--bg)"
                }}
              >
                <strong>
                  Confirmation email
                </strong>

                <div
                  className="caption"
                  style={{
                    marginTop: 4,
                    lineHeight: 1.5
                  }}
                >
                  A booking confirmation email is sent automatically
                  by our secure payment system
                  {customerEmail
                    ? (
                        <>
                          {" to "}
                          <strong>
                            {customerEmail}
                          </strong>
                        </>
                      )
                    : null}
                  {" "}after Stripe confirms your payment.
                </div>
              </div>


              {customerPhone && (
                <div
                  style={{
                    marginTop: 12,
                    padding: "14px 17px",
                    borderRadius: 8,
                    background: "var(--bg-nude)"
                  }}
                >
                  <div
                    style={{
                      display: "flex",
                      gap: 10,
                      alignItems: "flex-start"
                    }}
                  >
                    <Icon
                      name="message"
                      size={17}
                      className="text-gold"
                    />

                    <div>
                      <strong>
                        Appointment reminder
                      </strong>

                      <div
                        className="caption"
                        style={{
                          marginTop: 4,
                          lineHeight: 1.5
                        }}
                      >
                        We will send a text reminder to {customerPhone}
                        {" "}the day before your treatment between 9am and 7pm.
                      </div>
                    </div>
                  </div>
                </div>
              )}


              <div
                style={{
                  display: "flex",
                  justifyContent: "center",
                  marginTop: 28
                }}
              >
                <Button
                  variant="primary"
                  onClick={onHome}
                >
                  Return home
                </Button>
              </div>
            </div>
          )}

          {!loading && failed && (
            <CheckoutNotice
              icon="alert"
              title="Payment was not completed"
              body="The payment session failed or expired, so the appointment has not been confirmed. Please choose a new appointment if necessary."
            >
              <Button
                variant="primary"
                onClick={onTreatments}
              >
                Choose a treatment
              </Button>
            </CheckoutNotice>
          )}

          {!loading && !confirmed && !failed && (
            <CheckoutNotice
              icon="clock"
              title="Payment confirmation is still arriving"
              body={
                error ||
                "We have not received the final Stripe webhook confirmation yet. Do not pay again. You can retry this status check in a moment."
              }
            >
              <Button
                variant="primary"
                onClick={onRetry}
              >
                Check again
              </Button>

              <Button
                variant="ghost"
                onClick={onHome}
              >
                Return home
              </Button>
            </CheckoutNotice>
          )}
        </div>
      </section>

      <Footer />
    </div>
  );
}


function CheckoutConfirmationRow({
  label,
  value,
  last = false
}) {
  return (
    <div
      style={{
        display: "grid",
        gridTemplateColumns: "145px 1fr",
        gap: 18,
        padding: "14px 16px",
        borderBottom:
          last
            ? "none"
            : "1px solid var(--line)"
      }}
    >
      <div className="caption">
        {label}
      </div>

      <div
        style={{
          fontFamily: "var(--font-display)",
          textAlign: "right"
        }}
      >
        {value || "—"}
      </div>
    </div>
  );
}


function CheckoutNotice({
  icon,
  title,
  body,
  children
}) {
  return (
    <div
      style={{
        textAlign: "center",
        maxWidth: 660,
        margin: "0 auto",
        padding: "52px 40px",
        background: "var(--bg-cream)",
        border: "1px solid var(--line)",
        borderRadius: 8
      }}
    >
      <div
        style={{
          display: "inline-flex",
          padding: 18,
          borderRadius: "50%",
          background: "var(--bg-nude)",
          color: "var(--gold-deep)",
          marginBottom: 22
        }}
      >
        <Icon name={icon} size={24} />
      </div>

      <h2>{title}</h2>

      <p
        className="body-lg text-ink-2"
        style={{
          marginTop: 14,
          lineHeight: 1.6
        }}
      >
        {body}
      </p>

      {children && (
        <div
          style={{
            marginTop: 28,
            display: "flex",
            justifyContent: "center",
            gap: 10,
            flexWrap: "wrap"
          }}
        >
          {children}
        </div>
      )}
    </div>
  );
}


function CheckoutCard({
  title,
  sub,
  children
}) {
  return (
    <div
      style={{
        background: "var(--bg-cream)",
        border: "1px solid var(--line)",
        borderRadius: 8,
        padding: "24px 28px",
        marginBottom: 16
      }}
    >
      <h3 style={{ fontSize: "1.05rem" }}>
        {title}
      </h3>

      {sub && (
        <p
          className="caption"
          style={{
            marginTop: 6,
            marginBottom: 18,
            lineHeight: 1.5
          }}
        >
          {sub}
        </p>
      )}

      {children}
    </div>
  );
}


function CheckoutPayChoice({
  selected,
  onClick,
  title,
  sub
}) {
  return (
    <button
      onClick={onClick}
      style={{
        width: "100%",
        padding: "17px 18px",
        background:
          selected
            ? "var(--bg-nude)"
            : "var(--bg)",
        border:
          `1px solid ${
            selected
              ? "var(--gold-deep)"
              : "var(--line)"
          }`,
        borderRadius: 6,
        textAlign: "left",
        marginBottom: 9
      }}
    >
      <div
        style={{
          fontFamily: "var(--font-display)",
          fontSize: "0.94rem"
        }}
      >
        {title}
      </div>

      <div
        className="caption"
        style={{ marginTop: 6 }}
      >
        {sub}
      </div>
    </button>
  );
}


function CheckoutSummaryRow({
  label,
  value
}) {
  return (
    <div
      style={{
        padding: "10px 0",
        borderBottom: "1px solid var(--line)"
      }}
    >
      <div className="caption">
        {label}
      </div>

      <div
        style={{
          fontFamily: "var(--font-display)",
          fontSize: "0.9rem",
          marginTop: 3
        }}
      >
        {value || "—"}
      </div>
    </div>
  );
}


function readSavedBookingHold() {
  if (window.__booking?.appointment_id) {
    return window.__booking;
  }

  try {
    const raw =
      sessionStorage.getItem(
        "cs_booking_hold"
      );

    return raw
      ? JSON.parse(raw)
      : null;
  } catch {
    return null;
  }
}


function buildConfirmedBookingSnapshot(
  currentBooking,
  status
) {
  const base =
    currentBooking || {};

  return {
    appointment_id:
      status?.appointment_id ||
      base?.appointment_id ||
      null,

    reference:
      status?.reference ||
      base?.reference ||
      "",

    treatment:
      base?.treatment || {
        name:
          status?.service_name ||
          ""
      },

    therapist:
      base?.therapist || {
        staff_name:
          status?.staff_name ||
          status?.therapist_name ||
          ""
      },

    start_at:
      status?.start_at ||
      base?.start_at ||
      null,

    customer:
      base?.customer || {
        email:
          status?.customer_email ||
          "",
        phone:
          status?.customer_phone ||
          ""
      }
  };
}


function saveConfirmedBooking(
  booking
) {
  try {
    sessionStorage.setItem(
      "cs_last_confirmed_booking",
      JSON.stringify(
        booking || {}
      )
    );
  } catch {
    // Confirmation page can still render from live status.
  }
}


function readSavedConfirmedBooking() {
  try {
    const raw =
      sessionStorage.getItem(
        "cs_last_confirmed_booking"
      );

    return raw
      ? JSON.parse(raw)
      : null;
  } catch {
    return null;
  }
}


function clearSavedBookingHold() {
  sessionStorage.removeItem(
    "cs_booking_hold"
  );

  sessionStorage.removeItem(
    "cs_checkout_session_id"
  );

  window.__booking = null;
}


function readCheckoutReturnParams() {
  const hash =
    String(window.location.hash || "");

  // Preferred format. Everything after # remains entirely in the browser
  // and is never inspected by the web host's ModSecurity rules.
  const successMatch =
    hash.match(
      /^#\/checkout\/success\/(cs_[A-Za-z0-9_-]+)$/
    );

  if (successMatch) {
    return {
      success: "1",
      cancelled: "",
      session_id: successMatch[1]
    };
  }

  if (hash === "#/checkout/cancelled") {
    return {
      success: "",
      cancelled: "1",
      session_id: ""
    };
  }

  // Backward compatibility with the old hash-query return format.
  const queryIndex =
    hash.indexOf("?");

  if (queryIndex < 0) {
    return {};
  }

  const params =
    new URLSearchParams(
      hash.slice(queryIndex + 1)
    );

  return {
    success:
      params.get("success") || "",

    cancelled:
      params.get("cancelled") || "",

    session_id:
      params.get("session_id") || ""
  };
}


function bookingHoldExpired(booking) {
  if (!booking?.hold_expires_at) {
    return false;
  }

  return (
    new Date(
      booking.hold_expires_at
    ).getTime()
    <=
    Date.now()
  );
}


function formatCheckoutTime(value) {
  if (!value) {
    return "—";
  }

  return new Date(value)
    .toLocaleTimeString(
      "en-GB",
      {
        hour: "2-digit",
        minute: "2-digit"
      }
    );
}


function formatCheckoutDate(value) {
  if (!value) {
    return "—";
  }

  return new Date(value)
    .toLocaleDateString(
      "en-GB",
      {
        weekday: "short",
        day: "numeric",
        month: "short",
        year: "numeric"
      }
    );
}


function formatCheckoutDateTime(value) {
  if (!value) {
    return "—";
  }

  return new Date(value)
    .toLocaleString(
      "en-GB",
      {
        weekday: "short",
        day: "numeric",
        month: "short",
        year: "numeric",
        hour: "2-digit",
        minute: "2-digit"
      }
    );
}


function sleepCheckout(ms) {
  return new Promise(
    resolve =>
      setTimeout(resolve, ms)
  );
}


window.CheckoutPage = CheckoutPage;
