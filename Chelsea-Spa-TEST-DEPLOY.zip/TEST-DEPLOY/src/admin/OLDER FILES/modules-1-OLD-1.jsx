/* =========================================================================
   ADMIN MODULES (1/3) — Overview · Calendar · Bookings
   ========================================================================= */


/* =====================================================================
   SHARED DATE / CALENDAR HELPERS
   ===================================================================== */


(function ensureAdminDatePickerContrast() {
  if (typeof document === "undefined") {
    return;
  }

  if (document.getElementById("chelsea-admin-date-picker-contrast")) {
    return;
  }

  const style = document.createElement("style");
  style.id = "chelsea-admin-date-picker-contrast";
  style.textContent = `
    html.admin-dark input[type="date"],
    body.admin-dark input[type="date"] {
      color-scheme: dark;
    }

    html.admin-dark input[type="date"]::-webkit-calendar-picker-indicator,
    body.admin-dark input[type="date"]::-webkit-calendar-picker-indicator {
      filter: invert(1) brightness(1.9) contrast(1.25);
      opacity: 1 !important;
      cursor: pointer;
    }

    input[type="date"]::-webkit-calendar-picker-indicator {
      opacity: 0.92;
      cursor: pointer;
    }
  `;

  document.head.appendChild(style);
})();

function adminStartOfDay(date) {
  const d = new Date(date);
  d.setHours(0, 0, 0, 0);
  return d;
}


function adminAddDays(date, days) {
  const d = new Date(date);
  d.setDate(
    d.getDate() + days
  );
  return d;
}


function adminStartOfWeek(date) {
  const d =
    adminStartOfDay(date);

  const day =
    d.getDay();

  const diff =
    day === 0
      ? -6
      : 1 - day;

  return adminAddDays(
    d,
    diff
  );
}


function adminStartOfMonth(date) {
  const d = new Date(date);
  d.setDate(1);
  d.setHours(0, 0, 0, 0);
  return d;
}


function adminNextMonth(date) {
  const d =
    adminStartOfMonth(date);

  d.setMonth(
    d.getMonth() + 1
  );

  return d;
}


function adminDateKey(value) {
  const d = new Date(value);

  const year =
    d.getFullYear();

  const month =
    String(
      d.getMonth() + 1
    ).padStart(2, "0");

  const day =
    String(
      d.getDate()
    ).padStart(2, "0");

  return `${year}-${month}-${day}`;
}


function adminDateLabel(
  date,
  options
) {
  return new Date(date)
    .toLocaleDateString(
      "en-GB",
      options
    );
}


function adminTimeLabel(value) {
  if (!value) {
    return "—";
  }

  return new Date(value)
    .toLocaleTimeString(
      "en-GB",
      {
        hour: "2-digit",
        minute: "2-digit"
      }
    );
}



function adminBookingSourceLabel(booking) {
  const source =
    booking?.booking_source ||
    booking?.booking_source_label ||
    booking?.channel ||
    "legacy";

  const labels = {
    website: "Website",
    online: "Website",
    phone: "Phone",
    walk_in: "Walk-in",
    admin: "Admin / in person",
    admin_panel: "Admin / in person",
    treatwell: "Treatwell",
    legacy: "Legacy",
    other: "Other"
  };

  return labels[source] || String(source).replace(/_/g, " ");
}


function adminBookedByLabel(booking) {
  if (booking?.booked_by_name) {
    return booking.booked_by_name;
  }

  const source =
    booking?.booking_source ||
    booking?.booking_source_label ||
    booking?.channel;

  if (source === "website" || source === "online") {
    return "Online website";
  }

  if (source === "treatwell") {
    return "Treatwell";
  }

  if (source === "legacy") {
    return "Legacy record";
  }

  return "System";
}


function adminCalendarStatus(status) {
  const map = {
    pending_payment: {
      label: "Pending",
      color: "#9a7b4f",
      bg: "rgba(154,123,79,0.13)"
    },

    confirmed: {
      label: "Confirmed",
      color: "var(--gold-deep)",
      bg: "var(--bg-nude)"
    },

    checked_in: {
      label: "Checked in",
      color: "#6a82c4",
      bg: "rgba(106,130,196,0.14)"
    },

    completed: {
      label: "Completed",
      color: "var(--success)",
      bg: "rgba(107,122,94,0.15)"
    },

    cancelled: {
      label: "Cancelled",
      color: "var(--danger)",
      bg: "rgba(154,74,58,0.12)"
    },

    no_show: {
      label: "No show",
      color: "#9a4a3a",
      bg: "rgba(154,74,58,0.10)"
    },

    expired: {
      label: "Expired",
      color: "var(--ink-3)",
      bg: "var(--bg-shell)"
    }
  };

  return (
    map[status] || {
      label:
        String(status || "Unknown")
          .replace(/_/g, " "),

      color: "var(--ink-3)",
      bg: "var(--bg-shell)"
    }
  );
}


/* =====================================================================
   OVERVIEW — REAL OPERATIONAL DASHBOARD
   ===================================================================== */

function ModuleOverview({ go }) {
  const [bookings, setBookings] =
    useState([]);

  const [selected, setSelected] =
    useState(null);

  const [loading, setLoading] =
    useState(true);

  const [error, setError] =
    useState("");

  const toast =
    useToast();


  async function loadToday() {
    setLoading(true);
    setError("");

    try {
      const start =
        adminStartOfDay(
          new Date()
        );

      const end =
        adminAddDays(
          start,
          1
        );

      const rows =
        await window.API.Appointments
          .listAdmin({
            start:
              start.toISOString(),

            end:
              end.toISOString()
          });

      setBookings(
        (rows || [])
          .sort(
            (a, b) =>
              new Date(
                a.start_at
              ).getTime()
              -
              new Date(
                b.start_at
              ).getTime()
          )
      );
    } catch (err) {
      console.error(
        "Could not load dashboard:",
        err
      );

      setError(
        err?.message ||
        "Could not load today's bookings."
      );
    } finally {
      setLoading(false);
    }
  }


  useEffect(() => {
    loadToday();
  }, []);


  const activeBookings =
    bookings.filter(
      booking =>
        ![
          "cancelled",
          "expired"
        ].includes(
          booking.status
        )
    );


  const confirmedCount =
    bookings.filter(
      booking =>
        booking.status ===
        "confirmed"
    ).length;


  const pendingCount =
    bookings.filter(
      booking =>
        booking.status ===
        "pending_payment"
    ).length;


  const completedCount =
    bookings.filter(
      booking =>
        booking.status ===
        "completed"
    ).length;


  const bookedValue =
    activeBookings.reduce(
      (total, booking) =>
        total +
        Number(
          booking.price_snapshot ||
          0
        ),
      0
    );


  const todayLabel =
    adminDateLabel(
      new Date(),
      {
        weekday: "long",
        day: "numeric",
        month: "long",
        year: "numeric"
      }
    );


  async function handleChanged(updated) {
    setSelected(updated);

    setBookings(current =>
      current.map(row =>
        row.id === updated.id
          ? updated
          : row
      )
    );
  }


  return (
    <div>
      <PageHead
        eyebrow={todayLabel}
        title="Today's operations"
      >
        <Button
          variant="ghost"
          size="sm"
          icon="refresh"
          onClick={loadToday}
        >
          Refresh
        </Button>

        <Button
          variant="primary"
          size="sm"
          icon="plus"
          onClick={() =>
            go("bookings")
          }
        >
          New booking
        </Button>
      </PageHead>


      {error && (
        <Panel
          style={{
            marginBottom: 16
          }}
        >
          <EmptyBlock
            icon="alert"
            title="Dashboard could not be loaded"
            sub={error}
            action={
              <Button
                variant="primary"
                size="sm"
                onClick={loadToday}
              >
                Try again
              </Button>
            }
          />
        </Panel>
      )}


      <div
        style={{
          display: "grid",
          gridTemplateColumns:
            "repeat(4, 1fr)",
          gap: 16,
          marginBottom: 16
        }}
        className="kpi-row"
      >
        <AStat
          label="Bookings today"
          value={
            loading
              ? "—"
              : String(
                  bookings.length
                )
          }
          icon="calendar"
        />

        <AStat
          label="Confirmed"
          value={
            loading
              ? "—"
              : String(
                  confirmedCount
                )
          }
          icon="check"
        />

        <AStat
          label="Pending payment"
          value={
            loading
              ? "—"
              : String(
                  pendingCount
                )
          }
          icon="clock"
        />

        <AStat
          label="Booked value today"
          value={
            loading
              ? "—"
              : `£${bookedValue.toFixed(0)}`
          }
          icon="wallet"
        />
      </div>


      <div
        style={{
          display: "grid",
          gridTemplateColumns:
            "1.55fr 1fr",
          gap: 16
        }}
        className="ov-grid"
      >
        <Panel>
          <div
            style={{
              display: "flex",
              justifyContent:
                "space-between",
              alignItems: "center",
              marginBottom: 8
            }}
          >
            <div>
              <h3
                style={{
                  fontSize: "1.1rem"
                }}
              >
                Today's schedule
              </h3>

              <span className="caption">
                Live appointments from Supabase
              </span>
            </div>

            <button
              onClick={() =>
                go("calendar")
              }
              className="caption"
              style={{
                color:
                  "var(--gold-deep)",
                textTransform:
                  "uppercase",
                letterSpacing:
                  "0.14em"
              }}
            >
              Open calendar →
            </button>
          </div>


          {loading && (
            <div
              className="caption"
              style={{
                padding:
                  "22px 0"
              }}
            >
              Loading today's bookings…
            </div>
          )}


          {!loading &&
            bookings.length === 0 && (
              <EmptyBlock
                title="No bookings today"
                sub="New confirmed or pending appointments will appear here."
              />
            )}


          {!loading &&
            bookings
              .slice(0, 10)
              .map(booking => (
                <button
                  key={booking.id}
                  onClick={() =>
                    setSelected(
                      booking
                    )
                  }
                  style={{
                    width: "100%",
                    display: "grid",
                    gridTemplateColumns:
                      "58px 1fr auto",
                    gap: 14,
                    alignItems:
                      "center",
                    padding:
                      "12px 0",
                    borderTop:
                      "1px solid var(--line)",
                    textAlign:
                      "left",
                    color:
                      "inherit"
                  }}
                >
                  <span
                    style={{
                      fontFamily:
                        "var(--font-display)",
                      fontSize:
                        "0.92rem"
                    }}
                  >
                    {adminTimeLabel(
                      booking.start_at
                    )}
                  </span>

                  <div
                    style={{
                      display: "flex",
                      alignItems:
                        "center",
                      gap: 10,
                      minWidth: 0
                    }}
                  >
                    <Avatar
                      name={
                        booking.customer_name ||
                        "Customer"
                      }
                      size={28}
                      color={
                        booking.staff_colour ||
                        undefined
                      }
                    />

                    <div
                      style={{
                        minWidth: 0
                      }}
                    >
                      <div
                        style={{
                          fontFamily:
                            "var(--font-display)",
                          fontSize:
                            "0.88rem",
                          whiteSpace:
                            "nowrap",
                          overflow:
                            "hidden",
                          textOverflow:
                            "ellipsis"
                        }}
                      >
                        {booking.customer_name ||
                          "Unknown customer"}
                      </div>

                      <div
                        className="caption"
                        style={{
                          fontSize:
                            "0.68rem"
                        }}
                      >
                        {booking.service_name_snapshot ||
                          "Treatment"}
                        {" · "}
                        {booking.staff_name ||
                          "Unassigned"}
                      </div>
                    </div>
                  </div>

                  <RealBookingStatusPill
                    status={
                      booking.status
                    }
                  />
                </button>
              ))}
        </Panel>


        <Panel>
          <h3
            style={{
              fontSize: "1.1rem",
              marginBottom: 16
            }}
          >
            Today's status
          </h3>

          <DashboardCountRow
            label="Confirmed"
            value={confirmedCount}
          />

          <DashboardCountRow
            label="Completed"
            value={completedCount}
          />

          <DashboardCountRow
            label="Pending payment"
            value={pendingCount}
            attention={
              pendingCount > 0
            }
          />

          <DashboardCountRow
            label="Cancelled"
            value={
              bookings.filter(
                booking =>
                  booking.status ===
                  "cancelled"
              ).length
            }
          />

          <DashboardCountRow
            label="No-show"
            value={
              bookings.filter(
                booking =>
                  booking.status ===
                  "no_show"
              ).length
            }
          />

          <div
            className="caption"
            style={{
              marginTop: 18,
              lineHeight: 1.55
            }}
          >
            Revenue charts, retention and marketing analytics have been removed from this screen until they are connected to real payment and customer data.
          </div>
        </Panel>
      </div>


      <BookingDrawer
        booking={selected}
        onClose={() =>
          setSelected(null)
        }
        onChanged={
          handleChanged
        }
        toast={toast}
      />


      <style>{`
        @media (max-width: 1080px) {
          .kpi-row {
            grid-template-columns:
              1fr 1fr !important;
          }

          .ov-grid {
            grid-template-columns:
              1fr !important;
          }
        }
      `}</style>
    </div>
  );
}


function DashboardCountRow({
  label,
  value,
  attention
}) {
  return (
    <div
      style={{
        display: "flex",
        justifyContent:
          "space-between",
        alignItems: "center",
        gap: 12,
        padding: "12px 0",
        borderTop:
          "1px solid var(--line)"
      }}
    >
      <span
        style={{
          fontFamily:
            "var(--font-display)",
          fontSize: "0.86rem"
        }}
      >
        {label}
      </span>

      <span
        style={{
          fontFamily:
            "var(--font-display)",
          fontSize: "1rem",
          color:
            attention
              ? "var(--danger)"
              : "var(--ink)"
        }}
      >
        {value}
      </span>
    </div>
  );
}


/* =====================================================================
   CALENDAR — REAL DAY / WEEK / MONTH
   ===================================================================== */


function calendarStaffName(item) {
  if (!item) {
    return "Therapist";
  }

  return (
    item.full_name ||
    [
      item.first_name,
      item.last_name
    ]
      .filter(Boolean)
      .join(" ")
    ||
    "Therapist"
  );
}


function calendarShiftRowsForDay(
  shifts,
  day,
  staffId
) {
  const key =
    adminDateKey(day);

  return (shifts || [])
    .filter(shift => {
      if (
        staffId &&
        String(shift.staff_id) !==
          String(staffId)
      ) {
        return false;
      }

      return (
        shift.start_at &&
        adminDateKey(
          shift.start_at
        ) === key
      );
    })
    .sort(
      (a, b) =>
        new Date(
          a.start_at
        ).getTime()
        -
        new Date(
          b.start_at
        ).getTime()
    );
}


function calendarShiftLabel(
  shift
) {
  if (!shift) {
    return "No shift";
  }

  return (
    `${adminTimeLabel(
      shift.start_at
    )}–${adminTimeLabel(
      shift.end_at
    )}`
  );
}


/* =====================================================================
   CALENDAR — REAL DAY / WEEK / MONTH
   Admin/Super Admin: all therapists or one therapist
   Practitioner: own calendar only
   ===================================================================== */

function ModuleCalendar() {
  const [view, setView] =
    useState("day");

  const [cursor, setCursor] =
    useState(
      adminStartOfDay(
        new Date()
      )
    );

  const [staffFilter, setStaffFilter] =
    useState("all");

  const [bookings, setBookings] =
    useState([]);

  const [staff, setStaff] =
    useState([]);

  const [shifts, setShifts] =
    useState([]);

  const [calendarAccess, setCalendarAccess] =
    useState({
      ready: false,
      role: "practitioner",
      canSeeAll: false,
      ownStaffId: null
    });

  const [selected, setSelected] =
    useState(null);

  const [
    manualBookingOpen,
    setManualBookingOpen
  ] =
    useState(false);

  const [loading, setLoading] =
    useState(true);

  const [error, setError] =
    useState("");

  const toast =
    useToast();


  function rangeForView() {
    if (view === "week") {
      const start =
        adminStartOfWeek(
          cursor
        );

      return {
        start,
        end:
          adminAddDays(
            start,
            7
          )
      };
    }


    if (view === "month") {
      const start =
        adminStartOfMonth(
          cursor
        );

      return {
        start,
        end:
          adminNextMonth(
            start
          )
      };
    }


    const start =
      adminStartOfDay(
        cursor
      );

    return {
      start,
      end:
        adminAddDays(
          start,
          1
        )
    };
  }


  async function loadCalendarAccess() {
    try {
      const {
        data: sessionResult,
        error: sessionError
      } =
        await window.supabaseClient
          .auth
          .getSession();

      if (sessionError) {
        throw sessionError;
      }

      const session =
        sessionResult?.session;

      if (!session?.user?.id) {
        throw new Error(
          "Your secure staff session could not be found."
        );
      }


      const {
        data: profile,
        error: profileError
      } =
        await window.supabaseClient
          .from("profiles")
          .select(`
            access_role,
            role,
            is_active
          `)
          .eq(
            "id",
            session.user.id
          )
          .single();

      if (profileError) {
        throw profileError;
      }

      if (
        !profile ||
        profile.is_active === false
      ) {
        throw new Error(
          "This staff account is not active."
        );
      }


      let role =
        profile.access_role ||
        profile.role ||
        "practitioner";

      if (role === "manager") {
        role = "admin";
      }

      if (
        role === "receptionist" ||
        role === "therapist"
      ) {
        role = "practitioner";
      }


      const canSeeAll =
        role === "super_admin" ||
        role === "admin";


      if (canSeeAll) {
        setCalendarAccess({
          ready: true,
          role,
          canSeeAll: true,
          ownStaffId: null
        });

        return;
      }


      const {
        data: ownStaff,
        error: staffError
      } =
        await window.supabaseClient
          .from("staff_members")
          .select(`
            id,
            first_name,
            last_name,
            is_active,
            user_id
          `)
          .eq(
            "user_id",
            session.user.id
          )
          .eq(
            "is_active",
            true
          )
          .maybeSingle();


      if (staffError) {
        throw staffError;
      }


      if (!ownStaff?.id) {
        throw new Error(
          "Your login is not linked to an active therapist profile."
        );
      }


      setStaffFilter(
        ownStaff.id
      );

      setCalendarAccess({
        ready: true,
        role,
        canSeeAll: false,
        ownStaffId:
          ownStaff.id
      });

    } catch (err) {
      console.error(
        "Could not resolve calendar access:",
        err
      );

      setCalendarAccess({
        ready: true,
        role: "practitioner",
        canSeeAll: false,
        ownStaffId: null
      });

      setError(
        err?.message ||
        "Could not resolve your calendar access."
      );

      setLoading(false);
    }
  }


  async function loadCalendar() {
    if (!calendarAccess.ready) {
      return;
    }

    if (
      !calendarAccess.canSeeAll &&
      !calendarAccess.ownStaffId
    ) {
      return;
    }


    setLoading(true);
    setError("");

    try {
      const range =
        rangeForView();

      const [
        result,
        shiftRows
      ] =
        await Promise.all([
          window.API.Appointments
            .calendarRange(
              range.start.toISOString(),
              range.end.toISOString()
            ),

          window.API.Shifts.list({
            start:
              range.start.toISOString(),

            end:
              range.end.toISOString(),

            staff_id:
              calendarAccess.canSeeAll
                ? undefined
                : calendarAccess.ownStaffId
          })
        ]);


      const allStaff =
        (result.staff || [])
          .sort(
            (a, b) =>
              calendarStaffName(a)
                .localeCompare(
                  calendarStaffName(b)
                )
          );


      const visibleStaff =
        calendarAccess.canSeeAll
          ? allStaff
          : allStaff.filter(
              item =>
                String(item.id) ===
                String(
                  calendarAccess.ownStaffId
                )
            );


      const visibleBookings =
        (result.appointments || [])
          .filter(booking =>
            calendarAccess.canSeeAll
              ? true
              : String(
                  booking.staff_id
                ) ===
                String(
                  calendarAccess.ownStaffId
                )
          )
          .sort(
            (a, b) =>
              new Date(
                a.start_at
              ).getTime()
              -
              new Date(
                b.start_at
              ).getTime()
          );


      const visibleShifts =
        (shiftRows || [])
          .filter(shift =>
            calendarAccess.canSeeAll
              ? true
              : String(
                  shift.staff_id
                ) ===
                String(
                  calendarAccess.ownStaffId
                )
          )
          .sort(
            (a, b) =>
              new Date(
                a.start_at
              ).getTime()
              -
              new Date(
                b.start_at
              ).getTime()
          );


      setBookings(
        visibleBookings
      );

      setStaff(
        visibleStaff
      );

      setShifts(
        visibleShifts
      );


      if (
        !calendarAccess.canSeeAll
      ) {
        setStaffFilter(
          calendarAccess.ownStaffId
        );
      } else if (
        staffFilter !== "all" &&
        !visibleStaff.some(
          item =>
            String(item.id) ===
            String(staffFilter)
        )
      ) {
        setStaffFilter("all");
      }

    } catch (err) {
      console.error(
        "Could not load calendar:",
        err
      );

      setError(
        err?.message ||
        "Could not load calendar."
      );
    } finally {
      setLoading(false);
    }
  }


  useEffect(() => {
    loadCalendarAccess();
  }, []);


  useEffect(() => {
    loadCalendar();
  }, [
    calendarAccess.ready,
    calendarAccess.canSeeAll,
    calendarAccess.ownStaffId,
    view,
    adminDateKey(cursor)
  ]);


  function move(direction) {
    if (view === "month") {
      const next =
        new Date(cursor);

      next.setMonth(
        next.getMonth() +
        direction
      );

      setCursor(next);
      return;
    }


    setCursor(
      adminAddDays(
        cursor,
        view === "week"
          ? 7 * direction
          : direction
      )
    );
  }


  function goToday() {
    setCursor(
      adminStartOfDay(
        new Date()
      )
    );
  }


  function openDay(date) {
    setCursor(
      adminStartOfDay(
        date
      )
    );

    setView("day");
  }


  async function handleBookingChanged(
    updated
  ) {
    setSelected(updated);

    setBookings(current =>
      current.map(row =>
        row.id === updated.id
          ? updated
          : row
      )
    );
  }


  const filteredStaff =
    staffFilter === "all"
      ? staff
      : staff.filter(
          item =>
            String(item.id) ===
            String(staffFilter)
        );


  const filteredBookings =
    staffFilter === "all"
      ? bookings
      : bookings.filter(
          booking =>
            String(
              booking.staff_id
            ) ===
            String(staffFilter)
        );


  const filteredShifts =
    staffFilter === "all"
      ? shifts
      : shifts.filter(
          shift =>
            String(
              shift.staff_id
            ) ===
            String(staffFilter)
        );


  let heading;

  if (view === "month") {
    heading =
      adminDateLabel(
        cursor,
        {
          month: "long",
          year: "numeric"
        }
      );
  } else if (view === "week") {
    const start =
      adminStartOfWeek(
        cursor
      );

    const end =
      adminAddDays(
        start,
        6
      );

    heading =
      `${adminDateLabel(
        start,
        {
          day: "numeric",
          month: "short"
        }
      )} – ${adminDateLabel(
        end,
        {
          day: "numeric",
          month: "short",
          year: "numeric"
        }
      )}`;
  } else {
    heading =
      adminDateLabel(
        cursor,
        {
          weekday: "long",
          day: "numeric",
          month: "long",
          year: "numeric"
        }
      );
  }


  return (
    <div>
      <PageHead
        eyebrow={heading}
        title="Calendar"
      >
        <div
          style={{
            display: "flex",
            gap: 2,
            background:
              "var(--bg-nude)",
            borderRadius: 8,
            padding: 3
          }}
        >
          {[
            "day",
            "week",
            "month"
          ].map(item => (
            <button
              key={item}
              onClick={() =>
                setView(item)
              }
              style={{
                padding:
                  "7px 16px",
                borderRadius: 6,
                background:
                  view === item
                    ? "var(--bg-cream)"
                    : "transparent",
                color:
                  view === item
                    ? "var(--ink)"
                    : "var(--ink-3)",
                fontFamily:
                  "var(--font-display)",
                fontSize:
                  "0.74rem",
                letterSpacing:
                  "0.1em",
                textTransform:
                  "uppercase",
                boxShadow:
                  view === item
                    ? "var(--shadow-1)"
                    : "none"
              }}
            >
              {item}
            </button>
          ))}
        </div>

        <span
          style={{
            width: 1,
            height: 26,
            background:
              "var(--line)"
          }}
        />

        <IconBtn
          icon="chevron-up"
          title="Previous"
          onClick={() =>
            move(-1)
          }
        />

        <Button
          variant="ghost"
          size="sm"
          onClick={goToday}
        >
          Today
        </Button>

        <IconBtn
          icon="chevron-down"
          title="Next"
          onClick={() =>
            move(1)
          }
        />

        <Button
          variant="ghost"
          size="sm"
          icon="refresh"
          onClick={loadCalendar}
        >
          Refresh
        </Button>

        <Button
          variant="primary"
          size="sm"
          icon="plus"
          onClick={() =>
            setManualBookingOpen(
              true
            )
          }
        >
          New booking
        </Button>
      </PageHead>


      {staff.length > 0 && (
        <div
          style={{
            display: "flex",
            justifyContent:
              "space-between",
            alignItems:
              "center",
            gap: 12,
            marginBottom: 12,
            flexWrap: "wrap"
          }}
        >
          <div
            className="caption"
            style={{
              lineHeight: 1.5
            }}
          >
            {calendarAccess.canSeeAll
              ? (
                staffFilter === "all"
                  ? "Showing all therapists and their working shifts."
                  : "Showing one therapist across this calendar view."
              )
              : "Your account can only view your own shifts and appointments."
            }
          </div>

          <select
            className="a-input"
            value={staffFilter}
            disabled={
              !calendarAccess.canSeeAll
            }
            onChange={event =>
              setStaffFilter(
                event.target.value
              )
            }
            style={{
              width: "auto",
              minWidth: 230
            }}
          >
            {calendarAccess.canSeeAll && (
              <option value="all">
                All therapists
              </option>
            )}

            {staff.map(item => (
              <option
                key={item.id}
                value={item.id}
              >
                {calendarAccess.canSeeAll
                  ? calendarStaffName(item)
                  : `My calendar — ${calendarStaffName(item)}`
                }
              </option>
            ))}
          </select>
        </div>
      )}


      {loading && (
        <Panel>
          <div
            className="caption"
            style={{
              padding: 28,
              textAlign:
                "center"
            }}
          >
            Loading real calendar…
          </div>
        </Panel>
      )}


      {!loading &&
        error && (
          <Panel>
            <EmptyBlock
              icon="alert"
              title="Calendar could not be loaded"
              sub={error}
              action={
                <Button
                  variant="primary"
                  size="sm"
                  onClick={
                    loadCalendar
                  }
                >
                  Try again
                </Button>
              }
            />
          </Panel>
        )}


      {!loading &&
        !error &&
        view === "day" && (
          <RealCalendarDay
            date={cursor}
            bookings={
              filteredBookings
            }
            staff={
              filteredStaff
            }
            shifts={
              filteredShifts
            }
            onBooking={
              setSelected
            }
          />
        )}


      {!loading &&
        !error &&
        view === "week" && (
          <RealCalendarWeek
            cursor={cursor}
            bookings={
              filteredBookings
            }
            staff={
              filteredStaff
            }
            shifts={
              filteredShifts
            }
            onBooking={
              setSelected
            }
            onOpenDay={
              openDay
            }
          />
        )}


      {!loading &&
        !error &&
        view === "month" && (
          <RealCalendarMonth
            cursor={cursor}
            bookings={
              filteredBookings
            }
            staff={
              filteredStaff
            }
            shifts={
              filteredShifts
            }
            onOpenDay={
              openDay
            }
          />
        )}


      <ManualBookingDrawer
        open={manualBookingOpen}
        onClose={() =>
          setManualBookingOpen(
            false
          )
        }
        toast={toast}
        onCreated={async booking => {
          setManualBookingOpen(
            false
          );

          await loadCalendar();

          setSelected(
            booking
          );
        }}
      />


      <BookingDrawer
        booking={selected}
        onClose={() =>
          setSelected(null)
        }
        onChanged={
          handleBookingChanged
        }
        toast={toast}
      />
    </div>
  );
}


function RealCalendarDay({
  date,
  bookings,
  staff,
  shifts,
  onBooking
}) {
  const shownStaff =
    staff || [];


  if (
    shownStaff.length === 0
  ) {
    return (
      <Panel>
        <EmptyBlock
          title="No active therapists"
          sub="No therapist is available in this calendar view."
        />
      </Panel>
    );
  }


  const eventTimes =
    bookings
      .filter(
        booking =>
          booking.start_at &&
          booking.end_at
      );


  const dayShifts =
    calendarShiftRowsForDay(
      shifts,
      date
    );


  let openHour = 9;
  let closeHour = 20;


  dayShifts.forEach(
    shift => {
      const start =
        new Date(
          shift.start_at
        );

      const end =
        new Date(
          shift.end_at
        );

      openHour =
        Math.min(
          openHour,
          start.getHours()
        );

      closeHour =
        Math.max(
          closeHour,
          end.getHours() +
          (
            end.getMinutes() > 0
              ? 1
              : 0
          )
        );
    }
  );


  eventTimes.forEach(
    booking => {
      const start =
        new Date(
          booking.start_at
        );

      const end =
        new Date(
          booking.blocked_end_at ||
          booking.end_at
        );

      openHour =
        Math.min(
          openHour,
          start.getHours()
        );

      closeHour =
        Math.max(
          closeHour,
          end.getHours() +
          (
            end.getMinutes() > 0
              ? 1
              : 0
          )
        );
    }
  );


  openHour =
    Math.max(
      0,
      openHour
    );

  closeHour =
    Math.min(
      24,
      closeHour
    );


  const hours =
    Array.from(
      {
        length:
          Math.max(
            1,
            closeHour -
            openHour
          )
      },
      (_, index) =>
        openHour + index
    );


  const ROW = 64;


  return (
    <Panel
      pad={false}
      style={{
        overflow:
          "hidden"
      }}
    >
      <div
        style={{
          overflowX: "auto"
        }}
      >
        <div
          style={{
            minWidth:
              Math.max(
                760,
                70 +
                shownStaff.length *
                190
              )
          }}
        >
          <div
            style={{
              display: "grid",
              gridTemplateColumns:
                `70px repeat(${shownStaff.length}, minmax(190px, 1fr))`,
              borderBottom:
                "1px solid var(--line)",
              background:
                "var(--bg-nude)"
            }}
          >
            <div
              style={{
                padding:
                  "14px 12px"
              }}
            >
              <span className="caption">
                Time
              </span>
            </div>

            {shownStaff.map(
              item => {
                const ownShifts =
                  calendarShiftRowsForDay(
                    shifts,
                    date,
                    item.id
                  );

                return (
                  <div
                    key={item.id}
                    style={{
                      padding:
                        "12px 16px",
                      borderLeft:
                        "1px solid var(--line)",
                      display: "flex",
                      alignItems:
                        "center",
                      gap: 10
                    }}
                  >
                    <Avatar
                      name={
                        calendarStaffName(
                          item
                        )
                      }
                      size={28}
                      color={
                        item.colour ||
                        undefined
                      }
                    />

                    <div
                      style={{
                        minWidth: 0
                      }}
                    >
                      <div
                        style={{
                          fontFamily:
                            "var(--font-display)",
                          fontSize:
                            "0.84rem",
                          whiteSpace:
                            "nowrap"
                        }}
                      >
                        {calendarStaffName(
                          item
                        )}
                      </div>

                      <div
                        className="caption"
                        style={{
                          fontSize:
                            "0.64rem"
                        }}
                      >
                        {ownShifts.length
                          ? ownShifts
                              .map(
                                calendarShiftLabel
                              )
                              .join(", ")
                          : "No shift"
                        }
                      </div>
                    </div>
                  </div>
                );
              }
            )}
          </div>


          <div
            style={{
              position:
                "relative",
              display: "grid",
              gridTemplateColumns:
                `70px repeat(${shownStaff.length}, minmax(190px, 1fr))`
            }}
          >
            <div>
              {hours.map(hour => (
                <div
                  key={hour}
                  style={{
                    height: ROW,
                    padding:
                      "5px 12px",
                    borderBottom:
                      "1px solid var(--line)"
                  }}
                >
                  <span
                    className="caption"
                    style={{
                      fontSize:
                        "0.66rem"
                    }}
                  >
                    {String(
                      hour
                    ).padStart(
                      2,
                      "0"
                    )}:00
                  </span>
                </div>
              ))}
            </div>


            {shownStaff.map(
              staffMember => (
                <div
                  key={
                    staffMember.id
                  }
                  style={{
                    position:
                      "relative",
                    borderLeft:
                      "1px solid var(--line)"
                  }}
                >
                  {hours.map(
                    hour => (
                      <div
                        key={hour}
                        style={{
                          height: ROW,
                          borderBottom:
                            "1px solid var(--line)"
                        }}
                      />
                    )
                  )}


                  {bookings
                    .filter(
                      booking =>
                        String(
                          booking.staff_id
                        ) ===
                        String(
                          staffMember.id
                        )
                    )
                    .map(
                      booking => {
                        const start =
                          new Date(
                            booking.start_at
                          );

                        const blockedEnd =
                          new Date(
                            booking.blocked_end_at ||
                            booking.end_at
                          );

                        const startMinutes =
                          (
                            start.getHours()
                            -
                            openHour
                          )
                          *
                          60
                          +
                          start.getMinutes();

                        const durationMinutes =
                          Math.max(
                            15,
                            (
                              blockedEnd.getTime()
                              -
                              start.getTime()
                            )
                            /
                            60000
                          );

                        const top =
                          startMinutes
                          /
                          60
                          *
                          ROW
                          +
                          3;

                        const height =
                          Math.max(
                            34,
                            durationMinutes
                            /
                            60
                            *
                            ROW
                            -
                            6
                          );

                        const status =
                          adminCalendarStatus(
                            booking.status
                          );

                        return (
                          <button
                            key={
                              booking.id
                            }
                            title={
                              `${booking.customer_name || "Customer"} · ${booking.service_name_snapshot || "Treatment"}`
                            }
                            onClick={() =>
                              onBooking(
                                booking
                              )
                            }
                            style={{
                              position:
                                "absolute",
                              top,
                              height,
                              left: 6,
                              right: 6,
                              background:
                                status.bg,
                              borderLeft:
                                `3px solid ${status.color}`,
                              borderRadius:
                                5,
                              padding:
                                "7px 10px",
                              cursor:
                                "pointer",
                              overflow:
                                "hidden",
                              textAlign:
                                "left",
                              color:
                                "var(--ink)"
                            }}
                          >
                            <div
                              style={{
                                fontFamily:
                                  "var(--font-display)",
                                fontSize:
                                  "0.68rem",
                                color:
                                  status.color,
                                letterSpacing:
                                  "0.04em"
                              }}
                            >
                              {adminTimeLabel(
                                booking.start_at
                              )}
                            </div>

                            <div
                              style={{
                                fontFamily:
                                  "var(--font-display)",
                                fontSize:
                                  "0.8rem",
                                marginTop: 1,
                                whiteSpace:
                                  "nowrap",
                                overflow:
                                  "hidden",
                                textOverflow:
                                  "ellipsis"
                              }}
                            >
                              {booking.customer_name ||
                                "Customer"}
                            </div>

                            <div
                              className="caption"
                              style={{
                                fontSize:
                                  "0.64rem",
                                whiteSpace:
                                  "nowrap",
                                overflow:
                                  "hidden",
                                textOverflow:
                                  "ellipsis"
                              }}
                            >
                              {booking.service_name_snapshot ||
                                "Treatment"}
                            </div>
                          </button>
                        );
                      }
                    )}
                </div>
              )
            )}
          </div>
        </div>
      </div>


      <CalendarLegend />
    </Panel>
  );
}


function RealCalendarWeek({
  cursor,
  bookings,
  staff,
  shifts,
  onBooking,
  onOpenDay
}) {
  const start =
    adminStartOfWeek(
      cursor
    );

  const days =
    Array.from(
      { length: 7 },
      (_, index) =>
        adminAddDays(
          start,
          index
        )
    );


  return (
    <Panel
      pad={false}
      style={{
        overflow:
          "hidden"
      }}
    >
      <div
        style={{
          overflowX: "auto"
        }}
      >
        <div
          style={{
            minWidth: 1050,
            display: "grid",
            gridTemplateColumns:
              "repeat(7, minmax(145px, 1fr))"
          }}
        >
          {days.map(day => {
            const key =
              adminDateKey(
                day
              );

            const rows =
              bookings.filter(
                booking =>
                  adminDateKey(
                    booking.start_at
                  ) === key
              );

            const shiftRows =
              calendarShiftRowsForDay(
                shifts,
                day
              );

            return (
              <div
                key={key}
                style={{
                  minHeight: 560,
                  borderRight:
                    "1px solid var(--line)"
                }}
              >
                <button
                  onClick={() =>
                    onOpenDay(
                      day
                    )
                  }
                  style={{
                    width: "100%",
                    padding:
                      "12px 10px",
                    background:
                      adminDateKey(
                        new Date()
                      ) === key
                        ? "var(--bg-nude)"
                        : "transparent",
                    borderBottom:
                      "1px solid var(--line)",
                    textAlign:
                      "center"
                  }}
                >
                  <div
                    style={{
                      fontFamily:
                        "var(--font-display)",
                      fontSize:
                        "0.82rem"
                    }}
                  >
                    {adminDateLabel(
                      day,
                      {
                        weekday:
                          "short",
                        day:
                          "numeric"
                      }
                    )}
                  </div>

                  <div
                    className="caption"
                    style={{
                      fontSize:
                        "0.64rem"
                    }}
                  >
                    {rows.length} booking
                    {rows.length === 1
                      ? ""
                      : "s"}
                  </div>
                </button>


                <div
                  style={{
                    padding:
                      "8px 8px 4px"
                  }}
                >
                  <div
                    className="caption"
                    style={{
                      fontSize:
                        "0.61rem",
                      textTransform:
                        "uppercase",
                      letterSpacing:
                        "0.08em",
                      marginBottom: 5
                    }}
                  >
                    Working
                  </div>

                  {shiftRows.length > 0 ? (
                    <div
                      style={{
                        display: "flex",
                        flexDirection:
                          "column",
                        gap: 4
                      }}
                    >
                      {shiftRows
                        .slice(0, 4)
                        .map(shift => {
                          const person =
                            staff.find(
                              item =>
                                String(
                                  item.id
                                ) ===
                                String(
                                  shift.staff_id
                                )
                            );

                          return (
                            <div
                              key={
                                shift.id
                              }
                              style={{
                                padding:
                                  "5px 7px",
                                borderRadius:
                                  5,
                                background:
                                  "var(--bg-shell)",
                                fontSize:
                                  "0.62rem"
                              }}
                            >
                              <strong>
                                {calendarStaffName(
                                  person ||
                                  shift.staff_members
                                )}
                              </strong>
                              {" "}
                              {calendarShiftLabel(
                                shift
                              )}
                            </div>
                          );
                        })}

                      {shiftRows.length > 4 && (
                        <div
                          className="caption"
                          style={{
                            fontSize:
                              "0.59rem"
                          }}
                        >
                          +{shiftRows.length - 4} more shift
                          {shiftRows.length - 4 === 1
                            ? ""
                            : "s"}
                        </div>
                      )}
                    </div>
                  ) : (
                    <div
                      className="caption"
                      style={{
                        fontSize:
                          "0.61rem",
                        paddingBottom: 5
                      }}
                    >
                      No shift
                    </div>
                  )}
                </div>


                <div
                  style={{
                    padding: 8,
                    display:
                      "flex",
                    flexDirection:
                      "column",
                    gap: 7,
                    borderTop:
                      "1px solid var(--line)"
                  }}
                >
                  {rows.map(
                    booking => {
                      const status =
                        adminCalendarStatus(
                          booking.status
                        );

                      return (
                        <button
                          key={
                            booking.id
                          }
                          onClick={() =>
                            onBooking(
                              booking
                            )
                          }
                          style={{
                            padding:
                              "8px 9px",
                            borderRadius:
                              6,
                            background:
                              status.bg,
                            borderLeft:
                              `3px solid ${status.color}`,
                            textAlign:
                              "left"
                          }}
                        >
                          <div
                            style={{
                              fontFamily:
                                "var(--font-display)",
                              fontSize:
                                "0.68rem",
                              color:
                                status.color
                            }}
                          >
                            {adminTimeLabel(
                              booking.start_at
                            )}
                          </div>

                          <div
                            style={{
                              fontFamily:
                                "var(--font-display)",
                              fontSize:
                                "0.76rem",
                              whiteSpace:
                                "nowrap",
                              overflow:
                                "hidden",
                              textOverflow:
                                "ellipsis"
                            }}
                          >
                            {booking.customer_name ||
                              "Customer"}
                          </div>

                          <div
                            className="caption"
                            style={{
                              fontSize:
                                "0.62rem",
                              whiteSpace:
                                "nowrap",
                              overflow:
                                "hidden",
                              textOverflow:
                                "ellipsis"
                            }}
                          >
                            {booking.staff_name ||
                              "Unassigned"}
                            {" · "}
                            {booking.service_name_snapshot ||
                              "Treatment"}
                          </div>
                        </button>
                      );
                    }
                  )}

                  {rows.length === 0 && (
                    <div
                      className="caption"
                      style={{
                        padding:
                          "12px 4px",
                        textAlign:
                          "center"
                      }}
                    >
                      No bookings
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      <CalendarLegend />
    </Panel>
  );
}


function RealCalendarMonth({
  cursor,
  bookings,
  staff,
  shifts,
  onOpenDay
}) {
  const monthStart =
    adminStartOfMonth(
      cursor
    );

  const nextMonth =
    adminNextMonth(
      cursor
    );

  const mondayIndex =
    (
      monthStart.getDay() +
      6
    )
    %
    7;

  const gridStart =
    adminAddDays(
      monthStart,
      -mondayIndex
    );

  const cells =
    Array.from(
      { length: 42 },
      (_, index) =>
        adminAddDays(
          gridStart,
          index
        )
    );


  return (
    <Panel
      pad={false}
      style={{
        overflow:
          "hidden"
      }}
    >
      <div
        style={{
          display: "grid",
          gridTemplateColumns:
            "repeat(7, 1fr)",
          background:
            "var(--bg-nude)",
          borderBottom:
            "1px solid var(--line)"
        }}
      >
        {[
          "Mon",
          "Tue",
          "Wed",
          "Thu",
          "Fri",
          "Sat",
          "Sun"
        ].map(day => (
          <div
            key={day}
            style={{
              padding: 12,
              textAlign:
                "center"
            }}
          >
            <span className="caption">
              {day}
            </span>
          </div>
        ))}
      </div>


      <div
        style={{
          display: "grid",
          gridTemplateColumns:
            "repeat(7, 1fr)"
        }}
      >
        {cells.map(day => {
          const key =
            adminDateKey(
              day
            );

          const rows =
            bookings.filter(
              booking =>
                adminDateKey(
                  booking.start_at
                ) === key
            );

          const shiftRows =
            calendarShiftRowsForDay(
              shifts,
              day
            );

          const inMonth =
            day >= monthStart &&
            day < nextMonth;

          const isToday =
            adminDateKey(
              new Date()
            ) === key;

          return (
            <button
              key={key}
              onClick={() =>
                onOpenDay(
                  day
                )
              }
              style={{
                minHeight: 138,
                padding:
                  "8px 9px",
                borderRight:
                  "1px solid var(--line)",
                borderBottom:
                  "1px solid var(--line)",
                background:
                  isToday
                    ? "var(--bg-nude)"
                    : "transparent",
                textAlign:
                  "left",
                opacity:
                  inMonth
                    ? 1
                    : 0.45,
                overflow:
                  "hidden"
              }}
            >
              <div
                style={{
                  display: "flex",
                  justifyContent:
                    "space-between",
                  alignItems:
                    "center",
                  gap: 6
                }}
              >
                <div
                  style={{
                    fontFamily:
                      "var(--font-display)",
                    fontSize:
                      "0.84rem",
                    color:
                      isToday
                        ? "var(--gold-deep)"
                        : "var(--ink-2)"
                  }}
                >
                  {day.getDate()}
                </div>

                {rows.length > 0 && (
                  <span
                    className="caption"
                    style={{
                      fontSize:
                        "0.58rem"
                    }}
                  >
                    {rows.length} booking
                    {rows.length === 1
                      ? ""
                      : "s"}
                  </span>
                )}
              </div>


              {shiftRows.length > 0 && (
                <div
                  style={{
                    marginTop: 6,
                    display:
                      "flex",
                    flexDirection:
                      "column",
                    gap: 3
                  }}
                >
                  {shiftRows
                    .slice(0, 2)
                    .map(shift => {
                      const person =
                        staff.find(
                          item =>
                            String(
                              item.id
                            ) ===
                            String(
                              shift.staff_id
                            )
                        );

                      return (
                        <div
                          key={
                            shift.id
                          }
                          style={{
                            background:
                              "var(--bg-shell)",
                            borderRadius: 3,
                            padding:
                              "3px 5px",
                            fontSize:
                              "0.57rem",
                            whiteSpace:
                              "nowrap",
                            overflow:
                              "hidden",
                            textOverflow:
                              "ellipsis"
                          }}
                        >
                          {calendarStaffName(
                            person ||
                            shift.staff_members
                          )}
                          {" "}
                          {calendarShiftLabel(
                            shift
                          )}
                        </div>
                      );
                    })}

                  {shiftRows.length > 2 && (
                    <div
                      className="caption"
                      style={{
                        fontSize:
                          "0.55rem"
                      }}
                    >
                      +{shiftRows.length - 2} more working
                    </div>
                  )}
                </div>
              )}


              {rows.length > 0 && (
                <div
                  style={{
                    marginTop: 6,
                    display:
                      "flex",
                    flexDirection:
                      "column",
                    gap: 3
                  }}
                >
                  {rows
                    .slice(0, 2)
                    .map(
                      booking => (
                        <div
                          key={
                            booking.id
                          }
                          className="caption"
                          style={{
                            fontSize:
                              "0.59rem",
                            whiteSpace:
                              "nowrap",
                            overflow:
                              "hidden",
                            textOverflow:
                              "ellipsis"
                          }}
                        >
                          {adminTimeLabel(
                            booking.start_at
                          )}
                          {" · "}
                          {booking.staff_name ||
                            "Unassigned"}
                          {" · "}
                          {booking.service_name_snapshot ||
                            "Treatment"}
                        </div>
                      )
                    )}

                  {rows.length > 2 && (
                    <div
                      className="caption"
                      style={{
                        fontSize:
                          "0.56rem"
                      }}
                    >
                      +{rows.length - 2} more booking
                      {rows.length - 2 === 1
                        ? ""
                        : "s"}
                    </div>
                  )}
                </div>
              )}
            </button>
          );
        })}
      </div>

      <CalendarLegend />
    </Panel>
  );
}


function CalendarLegend() {
  const statuses = [
    "pending_payment",
    "confirmed",
    "checked_in",
    "completed",
    "cancelled",
    "no_show"
  ];

  return (
    <div
      style={{
        padding:
          "12px 16px",
        borderTop:
          "1px solid var(--line)",
        display:
          "flex",
        gap: 16,
        flexWrap:
          "wrap"
      }}
    >
      {statuses.map(key => {
        const item =
          adminCalendarStatus(
            key
          );

        return (
          <span
            key={key}
            style={{
              display: "flex",
              alignItems:
                "center",
              gap: 6,
              fontSize:
                "0.74rem",
              color:
                "var(--ink-2)"
            }}
          >
            <span
              style={{
                width: 9,
                height: 9,
                borderRadius: 2,
                background:
                  item.color
              }}
            />

            {item.label}
          </span>
        );
      })}
    </div>
  );
}


/* =====================================================================
   BOOKINGS — list + drawer
   ===================================================================== */
function ModuleBookings() {
  const [filter, setFilter] = useState("all");
  const [search, setSearch] = useState("");
  const [bookings, setBookings] = useState([]);
  const [selected, setSelected] = useState(null);
  const [manualBookingOpen, setManualBookingOpen] = useState(false);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const toast = useToast();

  async function loadBookings() {
    setLoading(true);
    setError("");

    try {
      if (
        !window.API ||
        !window.API.Appointments ||
        !window.API.Appointments.listAdmin
      ) {
        throw new Error(
          "Appointments API is not available."
        );
      }

      const rows =
        await window.API.Appointments.listAdmin();

      setBookings(
        Array.isArray(rows)
          ? rows
          : []
      );
    } catch (err) {
      console.error(
        "Could not load appointments:",
        err
      );

      setError(
        err?.message ||
        "Could not load bookings."
      );
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    loadBookings();
  }, []);

  function matchesTab(booking) {
    if (filter === "all") {
      return true;
    }

    if (filter === "pending") {
      return booking.status === "pending_payment";
    }

    return booking.status === filter;
  }

  function matchesSearch(booking) {
    const q =
      String(search || "")
        .trim()
        .toLowerCase();

    if (!q) {
      return true;
    }

    const haystack = [
      booking.reference,
      booking.id,
      booking.customer_name,
      booking.customer_email,
      booking.customer_phone,
      booking.service_name_snapshot,
      booking.staff_name,
      adminBookingSourceLabel(booking),
      adminBookedByLabel(booking),
      booking.status
    ]
      .filter(Boolean)
      .join(" ")
      .toLowerCase();

    return haystack.includes(q);
  }

  const filtered =
    bookings.filter(
      booking =>
        matchesTab(booking) &&
        matchesSearch(booking)
    );

  function countStatus(status) {
    if (status === "pending") {
      return bookings.filter(
        booking =>
          booking.status === "pending_payment"
      ).length;
    }

    return bookings.filter(
      booking =>
        booking.status === status
    ).length;
  }

  const tabs = [
    {
      id: "all",
      label: "All",
      count: bookings.length
    },
    {
      id: "pending",
      label: "Pending",
      count: countStatus("pending")
    },
    {
      id: "confirmed",
      label: "Confirmed",
      count: countStatus("confirmed")
    },
    {
      id: "completed",
      label: "Completed",
      count: countStatus("completed")
    },
    {
      id: "cancelled",
      label: "Cancelled",
      count: countStatus("cancelled")
    }
  ];

  function bookingDate(iso) {
    if (!iso) {
      return "—";
    }

    return new Date(iso)
      .toLocaleDateString(
        "en-GB",
        {
          day: "numeric",
          month: "short",
          year: "numeric"
        }
      );
  }

  function bookingTime(iso) {
    if (!iso) {
      return "—";
    }

    return new Date(iso)
      .toLocaleTimeString(
        "en-GB",
        {
          hour: "2-digit",
          minute: "2-digit"
        }
      );
  }

  function displayReference(booking) {
    if (booking.reference) {
      return booking.reference;
    }

    return String(
      booking.id || ""
    ).slice(0, 8);
  }

  async function handleBookingChanged(updated) {
    setSelected(updated);

    setBookings(current =>
      current.map(row =>
        row.id === updated.id
          ? updated
          : row
      )
    );
  }

  return (
    <div>
      <PageHead
        eyebrow="Reservations"
        title="Bookings"
      >
        <Button
          variant="ghost"
          size="sm"
          icon="refresh"
          onClick={loadBookings}
        >
          Refresh
        </Button>

        <Button
          variant="primary"
          size="sm"
          icon="plus"
          onClick={() =>
            setManualBookingOpen(true)
          }
        >
          New booking
        </Button>
      </PageHead>

      <div
        style={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
          gap: 16,
          marginBottom: 18,
          flexWrap: "wrap"
        }}
      >
        <Tabs
          tabs={tabs}
          active={filter}
          onChange={setFilter}
        />

        <SearchInput
          value={search}
          onChange={setSearch}
          placeholder="Search bookings…"
        />
      </div>

      {loading && (
        <Panel>
          <div
            style={{
              padding: 28,
              textAlign: "center"
            }}
          >
            <div
              style={{
                fontFamily: "var(--font-display)",
                marginBottom: 6
              }}
            >
              Loading bookings…
            </div>

            <div className="caption">
              Reading real appointments from Supabase.
            </div>
          </div>
        </Panel>
      )}

      {!loading && error && (
        <Panel>
          <EmptyBlock
            icon="alert"
            title="Bookings could not be loaded"
            sub={error}
            action={
              <Button
                variant="primary"
                size="sm"
                onClick={loadBookings}
              >
                Try again
              </Button>
            }
          />
        </Panel>
      )}

      {!loading && !error && (
        <Panel
          pad={false}
          style={{ overflow: "hidden" }}
        >
          <div
            style={{ overflowX: "auto" }}
            className="hide-scroll"
          >
            <table className="atable">
              <thead>
                <tr>
                  <th>Ref</th>
                  <th>Customer</th>
                  <th>Treatment</th>
                  <th>Therapist</th>
                  <th>Date / time</th>
                  <th>Source</th>
                  <th>Booked by</th>
                  <th>Amount</th>
                  <th>Status</th>
                  <th></th>
                </tr>
              </thead>

              <tbody>
                {filtered.map(booking => (
                  <tr
                    key={booking.id}
                    onClick={() =>
                      setSelected(booking)
                    }
                    style={{
                      cursor: "pointer"
                    }}
                  >
                    <td
                      style={{
                        fontFamily: "var(--font-mono)",
                        fontSize: "0.78rem",
                        color: "var(--ink-3)"
                      }}
                    >
                      {displayReference(booking)}
                    </td>

                    <td>
                      <div
                        style={{
                          display: "flex",
                          alignItems: "center",
                          gap: 10
                        }}
                      >
                        <Avatar
                          name={
                            booking.customer_name ||
                            "Customer"
                          }
                          size={28}
                          color={
                            booking.staff_colour ||
                            undefined
                          }
                        />

                        <div>
                          <div
                            style={{
                              fontFamily:
                                "var(--font-display)"
                            }}
                          >
                            {booking.customer_name ||
                              "Unknown customer"}
                          </div>

                          {booking.customer_phone && (
                            <div
                              className="caption"
                              style={{
                                fontSize: "0.66rem"
                              }}
                            >
                              {booking.customer_phone}
                            </div>
                          )}
                        </div>
                      </div>
                    </td>

                    <td>
                      {booking.service_name_snapshot ||
                        "Treatment"}
                    </td>

                    <td>
                      {booking.staff_name ||
                        "Unassigned"}
                    </td>

                    <td>
                      <div
                        style={{
                          fontFamily:
                            "var(--font-display)",
                          fontSize: "0.84rem"
                        }}
                      >
                        {bookingDate(
                          booking.start_at
                        )}
                      </div>

                      <div
                        className="caption"
                        style={{
                          fontSize: "0.68rem"
                        }}
                      >
                        {bookingTime(
                          booking.start_at
                        )}

                        {booking.duration_minutes
                          ? ` · ${booking.duration_minutes}m`
                          : ""}
                      </div>
                    </td>

                    <td>
                      <span className="caption">
                        {adminBookingSourceLabel(booking)}
                      </span>
                    </td>

                    <td>
                      <span className="caption">
                        {adminBookedByLabel(booking)}
                      </span>
                    </td>

                    <td
                      style={{
                        fontFamily:
                          "var(--font-display)",
                        color: "var(--gold-deep)"
                      }}
                    >
                      £{
                        Number(
                          booking.price_snapshot || 0
                        ).toFixed(2)
                      }
                    </td>

                    <td>
                      <RealBookingStatusPill
                        status={booking.status}
                      />
                    </td>

                    <td>
                      <button
                        className="icon-btn"
                        onClick={event => {
                          event.stopPropagation();
                          setSelected(booking);
                        }}
                      >
                        <Icon
                          name="chevron-right"
                          size={16}
                        />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {filtered.length === 0 && (
            <div style={{ padding: 40 }}>
              <EmptyBlock
                title={
                  bookings.length
                    ? "No bookings match"
                    : "No bookings yet"
                }
                sub={
                  bookings.length
                    ? "Try a different filter or search."
                    : "Real Supabase appointments will appear here."
                }
              />
            </div>
          )}
        </Panel>
      )}

      <ManualBookingDrawer
        open={manualBookingOpen}
        onClose={() =>
          setManualBookingOpen(false)
        }
        toast={toast}
        onCreated={async booking => {
          setManualBookingOpen(false);
          await loadBookings();
          setSelected(booking);
        }}
      />

      <BookingDrawer
        booking={selected}
        onClose={() =>
          setSelected(null)
        }
        onChanged={handleBookingChanged}
        toast={toast}
      />
    </div>
  );
}



function ManualBookingDrawer({
  open,
  onClose,
  onCreated,
  toast
}) {
  const EMPTY_FORM = {
    first_name: "",
    last_name: "",
    email: "",
    phone: "",
    service_id: "",
    date: "",
    start_at: "",
    staff_id: "",
    channel: "admin",
    customer_notes: "",
    internal_notes: ""
  };

  const [form, setForm] =
    useState(EMPTY_FORM);

  const [services, setServices] =
    useState([]);

  const [times, setTimes] =
    useState([]);

  const [staff, setStaff] =
    useState([]);

  const [loadingServices, setLoadingServices] =
    useState(false);

  const [loadingTimes, setLoadingTimes] =
    useState(false);

  const [loadingStaff, setLoadingStaff] =
    useState(false);

  const [saving, setSaving] =
    useState(false);

  // When a booking has been created successfully, the same
  // drawer changes into a proper confirmation screen instead
  // of disappearing after a small toast.
  const [confirmation, setConfirmation] =
    useState(null);


  useEffect(() => {
    if (!open) {
      return;
    }

    setForm(EMPTY_FORM);
    setTimes([]);
    setStaff([]);
    setConfirmation(null);
    loadServices();
  }, [open]);


  async function loadServices() {
    setLoadingServices(true);

    try {
      const rows =
        await window.API.Services.list();

      setServices(
        (rows || [])
          .filter(service =>
            service.is_active
          )
      );
    } catch (err) {
      console.error(
        "Could not load treatments:",
        err
      );

      toast(
        err?.message ||
        "Could not load treatments."
      );
    } finally {
      setLoadingServices(false);
    }
  }


  function setField(name, value) {
    setForm(current =>
      Object.assign(
        {},
        current,
        {
          [name]: value
        }
      )
    );
  }


  async function loadTimes(
    serviceId,
    date
  ) {
    setTimes([]);
    setStaff([]);

    setField(
      "start_at",
      ""
    );

    setField(
      "staff_id",
      ""
    );


    if (
      !serviceId ||
      !date
    ) {
      return;
    }


    setLoadingTimes(true);


    try {
      const rows =
        await window.API.Appointments
          .availableTimes(
            serviceId,
            date
          );


      setTimes(
        rows || []
      );
    } catch (err) {
      console.error(
        "Could not load available times:",
        err
      );

      toast(
        err?.message ||
        "Could not load available times."
      );
    } finally {
      setLoadingTimes(false);
    }
  }


  async function loadStaff(
    serviceId,
    startAt
  ) {
    setStaff([]);

    setField(
      "staff_id",
      ""
    );


    if (
      !serviceId ||
      !startAt
    ) {
      return;
    }


    setLoadingStaff(true);


    try {
      const rows =
        await window.API.Appointments
          .availableStaff(
            serviceId,
            startAt
          );


      setStaff(
        rows || []
      );
    } catch (err) {
      console.error(
        "Could not load available therapists:",
        err
      );

      toast(
        err?.message ||
        "Could not load available therapists."
      );
    } finally {
      setLoadingStaff(false);
    }
  }


  function formatTime(iso) {
    if (!iso) {
      return "";
    }

    return new Date(iso)
      .toLocaleTimeString(
        "en-GB",
        {
          hour: "2-digit",
          minute: "2-digit"
        }
      );
  }


  function formatDate(iso) {
    if (!iso) {
      return "—";
    }

    return new Date(iso)
      .toLocaleDateString(
        "en-GB",
        {
          weekday: "long",
          day: "numeric",
          month: "long",
          year: "numeric"
        }
      );
  }


  function selectedStaff() {
    return staff.find(
      item =>
        String(item.staff_id) ===
        String(form.staff_id)
    );
  }


  async function finishConfirmation() {
    const booking =
      confirmation;

    setConfirmation(null);

    if (booking) {
      await onCreated(
        booking
      );
      return;
    }

    onClose();
  }


  async function saveBooking() {
    if (!form.first_name.trim()) {
      toast(
        "Enter the customer's first name."
      );

      return;
    }


    if (
      !form.email.trim() &&
      !form.phone.trim()
    ) {
      toast(
        "Enter the customer's email or phone."
      );

      return;
    }


    if (!form.service_id) {
      toast(
        "Select a treatment."
      );

      return;
    }


    if (!form.date) {
      toast(
        "Select a date."
      );

      return;
    }


    if (!form.start_at) {
      toast(
        "Select an available time."
      );

      return;
    }


    if (!form.staff_id) {
      toast(
        "Select a therapist."
      );

      return;
    }


    setSaving(true);


    try {
      const booking =
        await window.API.Appointments
          .createAdmin({
            service_id:
              form.service_id,

            staff_id:
              form.staff_id,

            start_at:
              form.start_at,

            first_name:
              form.first_name.trim(),

            last_name:
              form.last_name.trim(),

            email:
              form.email.trim(),

            phone:
              form.phone.trim(),

            customer_notes:
              form.customer_notes.trim(),

            internal_notes:
              form.internal_notes.trim(),

            channel:
              form.channel
          });


      // Keep the drawer open and show the customer-facing
      // confirmation details, including the booking reference.
      setConfirmation(
        booking
      );

    } catch (err) {
      console.error(
        "Could not create booking:",
        err
      );

      toast(
        err?.message ||
        "Could not create booking."
      );
    } finally {
      setSaving(false);
    }
  }


  const chosenStaff =
    selectedStaff();


  const notification =
    confirmation?._notification ||
    null;

  const confirmationEmail =
    confirmation?.customer_email ||
    form.email ||
    "";

  const displayReference =
    confirmation?.reference ||
    (
      confirmation?.id
        ? String(
            confirmation.id
          ).slice(0, 8)
        : "—"
    );


  return (
    <Drawer
      open={open}
      onClose={
        saving
          ? undefined
          : confirmation
            ? finishConfirmation
            : onClose
      }
      subtitle={
        confirmation
          ? "Appointment saved successfully"
          : "Phone · walk-in · admin booking"
      }
      title={
        confirmation
          ? "Booking Confirmed"
          : "New booking"
      }
      footer={
        confirmation
          ? (
              <Button
                variant="primary"
                size="sm"
                onClick={finishConfirmation}
              >
                View booking
              </Button>
            )
          : (
              <>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={onClose}
                  disabled={saving}
                >
                  Cancel
                </Button>

                <Button
                  variant="primary"
                  size="sm"
                  onClick={saveBooking}
                  disabled={saving}
                >
                  {saving
                    ? "Creating…"
                    : "Create booking"}
                </Button>
              </>
            )
      }
    >
      {confirmation ? (
        <div>
          <div
            style={{
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              width: 56,
              height: 56,
              borderRadius: "50%",
              margin: "4px auto 14px",
              background:
                "rgba(107,122,94,0.16)",
              color:
                "var(--success)",
              fontSize: "1.7rem",
              fontFamily:
                "var(--font-display)"
            }}
            aria-hidden="true"
          >
            ✓
          </div>

          <div
            style={{
              textAlign: "center",
              marginBottom: 22
            }}
          >
            <div
              className="caption"
              style={{
                textTransform: "uppercase",
                letterSpacing: "0.14em"
              }}
            >
              Booking reference
            </div>

            <div
              style={{
                marginTop: 6,
                fontFamily:
                  "var(--font-display)",
                fontSize: "1.55rem",
                color:
                  "var(--gold-deep)",
                overflowWrap:
                  "anywhere"
              }}
            >
              {displayReference}
            </div>
          </div>

          <div
            style={{
              border:
                "1px solid var(--line)",
              borderRadius: 9,
              overflow: "hidden",
              marginBottom: 16
            }}
          >
            {[
              [
                "Customer",
                confirmation.customer_name ||
                  [
                    form.first_name,
                    form.last_name
                  ]
                    .filter(Boolean)
                    .join(" ")
              ],
              [
                "Treatment",
                confirmation.service_name_snapshot ||
                  "Treatment"
              ],
              [
                "Therapist",
                confirmation.staff_name ||
                  chosenStaff?.staff_name ||
                  "Therapist"
              ],
              [
                "Date",
                formatDate(
                  confirmation.start_at
                )
              ],
              [
                "Time",
                `${formatTime(
                  confirmation.start_at
                )}–${formatTime(
                  confirmation.end_at
                )}`
              ],
              [
                "Booking source",
                adminBookingSourceLabel(
                  confirmation
                )
              ]
            ].map(
              ([label, value]) => (
                <div
                  key={label}
                  style={{
                    display: "grid",
                    gridTemplateColumns:
                      "132px 1fr",
                    gap: 14,
                    padding:
                      "11px 13px",
                    borderBottom:
                      "1px solid var(--line)"
                  }}
                >
                  <div className="caption">
                    {label}
                  </div>

                  <div
                    style={{
                      fontFamily:
                        "var(--font-display)",
                      fontSize:
                        "0.84rem"
                    }}
                  >
                    {value || "—"}
                  </div>
                </div>
              )
            )}
          </div>

          {confirmationEmail &&
            notification?.sent === true && (
            <div
              style={{
                padding:
                  "12px 14px",
                borderRadius: 8,
                background:
                  "rgba(107,122,94,0.12)",
                border:
                  "1px solid rgba(107,122,94,0.28)",
                color:
                  "var(--success)",
                lineHeight: 1.5
              }}
            >
              <strong>
                Confirmation email sent
              </strong>

              <div
                style={{
                  marginTop: 3,
                  fontSize:
                    "0.82rem"
                }}
              >
                A booking confirmation email has been sent to{" "}
                <strong>
                  {confirmationEmail}
                </strong>.
              </div>
            </div>
          )}

          {confirmationEmail &&
            notification &&
            notification.sent !== true && (
            <div
              style={{
                padding:
                  "12px 14px",
                borderRadius: 8,
                background:
                  "rgba(184,137,73,0.12)",
                border:
                  "1px solid rgba(184,137,73,0.30)",
                color:
                  "var(--ink)",
                lineHeight: 1.5
              }}
            >
              <strong>
                Booking confirmed — email needs attention
              </strong>

              <div
                className="caption"
                style={{
                  marginTop: 4
                }}
              >
                The appointment is safely booked, but the confirmation email
                could not be verified as sent.
                {notification.error
                  ? ` ${notification.error}`
                  : ""}
              </div>
            </div>
          )}

          {!confirmationEmail && (
            <div
              style={{
                padding:
                  "12px 14px",
                borderRadius: 8,
                background:
                  "var(--bg-nude)",
                border:
                  "1px solid var(--line)",
                lineHeight: 1.5
              }}
            >
              <strong>
                Booking confirmed
              </strong>

              <div
                className="caption"
                style={{
                  marginTop: 4
                }}
              >
                No customer email address was supplied, so a customer
                confirmation email could not be sent.
              </div>
            </div>
          )}
        </div>
      ) : (
        <>
          <div className="a-label">
            Customer
          </div>

          <div
            style={{
              display: "grid",
              gridTemplateColumns:
                "1fr 1fr",
              gap: 12
            }}
          >
            <input
              className="a-input"
              placeholder="First name *"
              value={form.first_name}
              onChange={event =>
                setField(
                  "first_name",
                  event.target.value
                )
              }
            />

            <input
              className="a-input"
              placeholder="Last name"
              value={form.last_name}
              onChange={event =>
                setField(
                  "last_name",
                  event.target.value
                )
              }
            />

            <input
              className="a-input"
              type="email"
              placeholder="Email"
              value={form.email}
              onChange={event =>
                setField(
                  "email",
                  event.target.value
                )
              }
            />

            <input
              className="a-input"
              placeholder="Phone"
              value={form.phone}
              onChange={event =>
                setField(
                  "phone",
                  event.target.value
                )
              }
            />
          </div>


          <div
            className="a-divider"
            style={{
              margin: "20px 0"
            }}
          />


          <div className="a-label">
            Treatment
          </div>

          <select
            className="a-input"
            value={form.service_id}
            disabled={loadingServices}
            onChange={event => {
              const serviceId =
                event.target.value;

              setField(
                "service_id",
                serviceId
              );

              loadTimes(
                serviceId,
                form.date
              );
            }}
          >
            <option value="">
              {loadingServices
                ? "Loading treatments…"
                : "Select treatment"}
            </option>

            {services.map(service => (
              <option
                key={service.id}
                value={service.id}
              >
                {service.name}
              </option>
            ))}
          </select>


          <div
            style={{
              display: "grid",
              gridTemplateColumns:
                "1fr 1fr",
              gap: 12,
              marginTop: 12
            }}
          >
            <input
              className="a-input"
              type="date"
              value={form.date}
              onChange={event => {
                const date =
                  event.target.value;

                setField(
                  "date",
                  date
                );

                loadTimes(
                  form.service_id,
                  date
                );
              }}
            />

            <select
              className="a-input"
              value={form.start_at}
              disabled={
                !form.service_id ||
                !form.date ||
                loadingTimes
              }
              onChange={event => {
                const startAt =
                  event.target.value;

                setField(
                  "start_at",
                  startAt
                );

                loadStaff(
                  form.service_id,
                  startAt
                );
              }}
            >
              <option value="">
                {loadingTimes
                  ? "Checking times…"
                  : "Select time"}
              </option>

              {times.map(item => (
                <option
                  key={item.start_at}
                  value={item.start_at}
                >
                  {formatTime(
                    item.start_at
                  )}
                </option>
              ))}
            </select>
          </div>


          {!loadingTimes &&
            form.service_id &&
            form.date &&
            times.length === 0 && (
              <div
                className="caption"
                style={{
                  marginTop: 8
                }}
              >
                No available slots for this treatment on this date.
              </div>
            )}


          <div
            className="a-divider"
            style={{
              margin: "20px 0"
            }}
          />


          <div className="a-label">
            Therapist
          </div>

          <select
            className="a-input"
            value={form.staff_id}
            disabled={
              !form.start_at ||
              loadingStaff
            }
            onChange={event =>
              setField(
                "staff_id",
                event.target.value
              )
            }
          >
            <option value="">
              {loadingStaff
                ? "Checking therapists…"
                : "Select therapist"}
            </option>

            {staff.map(item => (
              <option
                key={item.staff_id}
                value={item.staff_id}
              >
                {item.staff_name}
                {" — £"}
                {Number(
                  item.price || 0
                ).toFixed(2)}
              </option>
            ))}
          </select>


          {chosenStaff && (
            <div
              style={{
                marginTop: 10,
                padding: "12px 14px",
                background: "var(--bg-nude)",
                borderRadius: 8
              }}
            >
              <div
                style={{
                  fontFamily:
                    "var(--font-display)",
                  marginBottom: 4
                }}
              >
                Exact booking price:
                {" £"}
                {Number(
                  chosenStaff.price || 0
                ).toFixed(2)}
              </div>

              <div className="caption">
                Treatment ends at{" "}
                {formatTime(
                  chosenStaff.end_at
                )}
              </div>
            </div>
          )}


          <div
            className="a-divider"
            style={{
              margin: "20px 0"
            }}
          />


          <div className="a-label">
            Booking source
          </div>

          <select
            className="a-input"
            value={form.channel}
            onChange={event =>
              setField(
                "channel",
                event.target.value
              )
            }
          >
            <option value="admin">
              Admin / in person
            </option>

            <option value="phone">
              Phone
            </option>

            <option value="walk_in">
              Walk-in
            </option>
          </select>


          <div
            className="a-divider"
            style={{
              margin: "20px 0"
            }}
          />


          <div className="a-label">
            Customer note
          </div>

          <textarea
            className="a-input"
            rows={3}
            placeholder="Customer request or booking note…"
            value={form.customer_notes}
            onChange={event =>
              setField(
                "customer_notes",
                event.target.value
              )
            }
            style={{
              resize: "vertical"
            }}
          />


          <div
            className="a-label"
            style={{
              marginTop: 16
            }}
          >
            Internal note
          </div>

          <textarea
            className="a-input"
            rows={3}
            placeholder="Private note for staff…"
            value={form.internal_notes}
            onChange={event =>
              setField(
                "internal_notes",
                event.target.value
              )
            }
            style={{
              resize: "vertical"
            }}
          />
        </>
      )}
    </Drawer>
  );
}


function RealBookingStatusPill({
  status
}) {
  const meta = {
    pending_payment: {
      label: "Pending",
      color: "var(--ink-2)",
      bg: "var(--bg-shell)"
    },

    confirmed: {
      label: "Confirmed",
      color: "var(--gold-deep)",
      bg: "var(--bg-nude)"
    },

    checked_in: {
      label: "Checked in",
      color: "#6a82c4",
      bg: "rgba(106,130,196,0.14)"
    },

    completed: {
      label: "Completed",
      color: "var(--success)",
      bg: "rgba(107,122,94,0.16)"
    },

    cancelled: {
      label: "Cancelled",
      color: "var(--danger)",
      bg: "rgba(154,74,58,0.14)"
    },

    no_show: {
      label: "No show",
      color: "#9a4a3a",
      bg: "rgba(154,74,58,0.10)"
    },

    expired: {
      label: "Expired",
      color: "var(--ink-3)",
      bg: "var(--bg-shell)"
    }
  };

  const item =
    meta[status] || {
      label:
        String(status || "Unknown")
          .replace(/_/g, " "),
      color: "var(--ink-3)",
      bg: "var(--bg-shell)"
    };

  return (
    <span
      style={{
        display: "inline-flex",
        alignItems: "center",
        padding: "5px 9px",
        borderRadius: 999,
        background: item.bg,
        color: item.color,
        fontFamily: "var(--font-display)",
        fontSize: "0.66rem",
        letterSpacing: "0.08em",
        textTransform: "uppercase",
        whiteSpace: "nowrap"
      }}
    >
      {item.label}
    </span>
  );
}


function BookingDrawer({
  booking,
  onClose,
  onChanged,
  toast
}) {
  const [notes, setNotes] =
    useState("");

  const [savingNotes, setSavingNotes] =
    useState(false);

  const [changingStatus, setChangingStatus] =
    useState(false);


  useEffect(() => {
    setNotes(
      booking?.internal_notes || ""
    );
  }, [
    booking?.id,
    booking?.internal_notes
  ]);


  if (!booking) {
    return null;
  }


  const transitions = {
    pending_payment: [
      {
        status: "confirmed",
        label: "Confirm booking",
        variant: "primary"
      },
      {
        status: "cancelled",
        label: "Cancel",
        variant: "ghost"
      }
    ],

    confirmed: [
      {
        status: "checked_in",
        label: "Check in",
        variant: "primary"
      },
      {
        status: "no_show",
        label: "No show",
        variant: "ghost"
      },
      {
        status: "cancelled",
        label: "Cancel",
        variant: "ghost"
      }
    ],

    checked_in: [
      {
        status: "completed",
        label: "Complete",
        variant: "primary"
      },
      {
        status: "no_show",
        label: "No show",
        variant: "ghost"
      }
    ],

    completed: [],
    cancelled: [],
    no_show: [],
    expired: []
  };


  const availableTransitions =
    transitions[booking.status] || [];


  function formatDateTime(iso) {
    if (!iso) {
      return "—";
    }

    return new Date(iso)
      .toLocaleString(
        "en-GB",
        {
          day: "numeric",
          month: "short",
          year: "numeric",
          hour: "2-digit",
          minute: "2-digit"
        }
      );
  }


  async function changeStatus(nextStatus) {
    if (
      !window.API?.Appointments?.updateStatus
    ) {
      toast(
        "Install the Step 10C3 api.jsx first."
      );

      return;
    }


    if (
      nextStatus === "cancelled" &&
      !window.confirm(
        "Cancel this booking?"
      )
    ) {
      return;
    }


    setChangingStatus(true);


    try {
      const updated =
        await window.API.Appointments
          .updateStatus(
            booking.id,
            nextStatus
          );


      await onChanged(updated);


      toast(
        `Booking status changed to ${
          String(nextStatus)
            .replace(/_/g, " ")
        }`,
        "success"
      );
    } catch (err) {
      console.error(
        "Could not update booking status:",
        err
      );

      toast(
        err?.message ||
        "Could not update booking status."
      );
    } finally {
      setChangingStatus(false);
    }
  }


  async function saveNotes() {
    if (
      !window.API?.Appointments
        ?.updateInternalNotes
    ) {
      toast(
        "Install the Step 10C3 api.jsx first."
      );

      return;
    }


    setSavingNotes(true);


    try {
      const updated =
        await window.API.Appointments
          .updateInternalNotes(
            booking.id,
            notes
          );


      await onChanged(updated);


      toast(
        "Internal note saved.",
        "success"
      );
    } catch (err) {
      console.error(
        "Could not save internal note:",
        err
      );

      toast(
        err?.message ||
        "Could not save internal note."
      );
    } finally {
      setSavingNotes(false);
    }
  }


  return (
    <Drawer
      open={!!booking}
      onClose={onClose}
      subtitle={
        `Booking ${
          booking.reference ||
          String(booking.id).slice(0, 8)
        }`
      }
      title={
        booking.customer_name ||
        "Booking details"
      }
      footer={
        <>
          <Button
            variant="ghost"
            size="sm"
            onClick={onClose}
          >
            Close
          </Button>

          <Button
            variant="primary"
            size="sm"
            onClick={saveNotes}
            disabled={savingNotes}
          >
            {savingNotes
              ? "Saving…"
              : "Save note"}
          </Button>
        </>
      }
    >
      <div
        style={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
          gap: 12,
          marginBottom: 22
        }}
      >
        <RealBookingStatusPill
          status={booking.status}
        />

        <span className="caption">
          {adminBookingSourceLabel(booking)}
        </span>
      </div>


      <div className="a-label">
        Booking
      </div>

      <div
        style={{
          display: "grid",
          gridTemplateColumns:
            "1fr 1fr",
          gap: 16,
          marginBottom: 8
        }}
      >
        <DRow
          label="Treatment"
          value={
            booking.service_name_snapshot ||
            "—"
          }
        />

        <DRow
          label="Therapist"
          value={
            booking.staff_name ||
            "Unassigned"
          }
        />

        <DRow
          label="Starts"
          value={
            formatDateTime(
              booking.start_at
            )
          }
        />

        <DRow
          label="Duration"
          value={
            booking.duration_minutes
              ? `${booking.duration_minutes} min`
              : "—"
          }
        />

        <DRow
          label="Room"
          value={
            booking.room || "—"
          }
        />

        <DRow
          label="Booking source"
          value={
            adminBookingSourceLabel(booking)
          }
        />

        <DRow
          label="Booked by"
          value={
            adminBookedByLabel(booking)
          }
        />
      </div>


      <div
        className="a-divider"
        style={{
          margin: "20px 0"
        }}
      />


      <div className="a-label">
        Customer
      </div>

      <div
        style={{
          display: "grid",
          gridTemplateColumns:
            "1fr 1fr",
          gap: 16
        }}
      >
        <DRow
          label="Name"
          value={
            booking.customer_name ||
            "—"
          }
        />

        <DRow
          label="Phone"
          value={
            booking.customer_phone ||
            "—"
          }
        />

        <DRow
          label="Email"
          value={
            booking.customer_email ||
            "—"
          }
        />
      </div>


      <div
        className="a-divider"
        style={{
          margin: "20px 0"
        }}
      />


      <div className="a-label">
        Payment
      </div>

      <div
        style={{
          display: "grid",
          gridTemplateColumns:
            "1fr 1fr",
          gap: 16
        }}
      >
        <DRow
          label="Treatment price"
          value={
            `£${Number(
              booking.price_snapshot || 0
            ).toFixed(2)}`
          }
        />

        <DRow
          label="Deposit due"
          value={
            `£${Number(
              booking.deposit_due || 0
            ).toFixed(2)}`
          }
        />

        <DRow
          label="Amount paid"
          value={
            `£${Number(
              booking.amount_paid || 0
            ).toFixed(2)}`
          }
        />

        <DRow
          label="Payment status"
          value={
            booking.payment_status ||
            "—"
          }
        />
      </div>


      {booking.customer_notes && (
        <>
          <div
            className="a-divider"
            style={{
              margin: "20px 0"
            }}
          />

          <div className="a-label">
            Customer note
          </div>

          <div
            style={{
              padding: "12px 14px",
              background:
                "var(--bg-nude)",
              borderRadius: 8,
              fontSize: "0.86rem"
            }}
          >
            {booking.customer_notes}
          </div>
        </>
      )}


      <div
        className="a-divider"
        style={{
          margin: "20px 0"
        }}
      />


      <div className="a-label">
        Internal note
      </div>

      <textarea
        className="a-input"
        rows={4}
        value={notes}
        onChange={event =>
          setNotes(
            event.target.value
          )
        }
        placeholder="Private note for the Chelsea Spa team…"
        style={{
          resize: "vertical"
        }}
      />


      <div
        className="a-divider"
        style={{
          margin: "20px 0"
        }}
      />


      <div className="a-label">
        Change status
      </div>

      {availableTransitions.length > 0 ? (
        <div
          style={{
            display: "flex",
            gap: 8,
            flexWrap: "wrap"
          }}
        >
          {availableTransitions.map(
            action => (
              <Button
                key={action.status}
                variant={action.variant}
                size="sm"
                disabled={
                  changingStatus
                }
                onClick={() =>
                  changeStatus(
                    action.status
                  )
                }
              >
                {changingStatus
                  ? "Updating…"
                  : action.label}
              </Button>
            )
          )}
        </div>
      ) : (
        <div className="caption">
          No further status action is available for this booking.
        </div>
      )}
    </Drawer>
  );
}



function DRow({ label, value }) {
  return (
    <div>
      <div className="caption">{label}</div>
      <div style={{ fontFamily: "var(--font-display)", fontSize: "0.92rem", marginTop: 3 }}>{value}</div>
    </div>
  );
}

function fmtShort(iso) {
  const d = new Date(iso);
  return d.toLocaleDateString("en-GB", { day: "numeric", month: "short" });
}

Object.assign(window, { ModuleOverview, ModuleCalendar, ModuleBookings });
