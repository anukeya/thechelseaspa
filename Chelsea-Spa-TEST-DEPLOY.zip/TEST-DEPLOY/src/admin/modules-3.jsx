/* =========================================================================
   ADMIN MODULES (3/3) — Sales · Inventory · Marketing/CMS · Notifications · Settings
   ========================================================================= */

/* =====================================================================
   SALES & PAYMENTS
   ===================================================================== */
function csMoney(value) {
  return new Intl.NumberFormat(
    "en-GB",
    {
      style: "currency",
      currency: "GBP"
    }
  ).format(Number(value || 0));
}

function csDateTime(value) {
  if (!value) return "—";

  const date =
    new Date(value);

  if (Number.isNaN(date.getTime())) {
    return "—";
  }

  return date.toLocaleString(
    "en-GB",
    {
      day: "2-digit",
      month: "short",
      year: "numeric",
      hour: "2-digit",
      minute: "2-digit"
    }
  );
}

function csFinanceRange(range) {
  const now = new Date();
  const end = null;

  if (range === "all") {
    return {
      from: null,
      to: end
    };
  }

  if (range === "mtd") {
    const from =
      new Date(
        now.getFullYear(),
        now.getMonth(),
        1
      );

    return {
      from: from.toISOString(),
      to: end
    };
  }

  const days =
    range === "90d"
      ? 90
      : 30;

  const from =
    new Date(
      now.getTime()
      -
      days * 24 * 60 * 60 * 1000
    );

  return {
    from: from.toISOString(),
    to: end
  };
}

function csProviderLabel(provider) {
  const value =
    String(provider || "")
      .toLowerCase();

  if (value === "stripe") {
    return "Stripe";
  }

  if (value === "treatwell") {
    return "Treatwell prepaid";
  }

  if (value === "legacy_woocommerce") {
    return "Legacy WooCommerce";
  }

  return provider || "Other";
}

function csPaymentPill(status) {
  const value =
    String(status || "")
      .toLowerCase();

  if (
    value === "paid" ||
    value === "succeeded"
  ) {
    return (
      <Pill
        color="var(--success)"
        bg="rgba(107,122,94,0.16)"
        dot
      >
        Paid
      </Pill>
    );
  }

  if (value === "partial") {
    return (
      <Pill
        color="var(--gold-deep)"
        bg="var(--bg-nude)"
        dot
      >
        Partial
      </Pill>
    );
  }

  if (value === "refunded") {
    return (
      <Pill
        color="var(--danger)"
        bg="rgba(154,74,58,0.14)"
        dot
      >
        Refunded
      </Pill>
    );
  }

  if (value === "failed") {
    return (
      <Pill
        color="var(--danger)"
        bg="rgba(154,74,58,0.14)"
        dot
      >
        Failed
      </Pill>
    );
  }

  return (
    <Pill
      color="var(--ink-3)"
      bg="var(--bg-shell)"
      dot
    >
      {status || "Unknown"}
    </Pill>
  );
}

function csDownloadCsv(filename, rows) {
  const safeRows =
    Array.isArray(rows)
      ? rows
      : [];

  if (!safeRows.length) {
    throw new Error(
      "There is no data to export."
    );
  }

  const headers =
    Object.keys(safeRows[0]);

  const escapeCell = value => {
    const text =
      value === null ||
      value === undefined
        ? ""
        : String(value);

    return `"${text.replace(/"/g, '""')}"`;
  };

  const csv = [
    headers.map(escapeCell).join(","),
    ...safeRows.map(
      row =>
        headers
          .map(
            key =>
              escapeCell(row[key])
          )
          .join(",")
    )
  ].join("\n");

  const blob =
    new Blob(
      [csv],
      {
        type:
          "text/csv;charset=utf-8"
      }
    );

  const url =
    URL.createObjectURL(blob);

  const link =
    document.createElement("a");

  link.href = url;
  link.download = filename;

  document.body.appendChild(link);
  link.click();
  link.remove();

  URL.revokeObjectURL(url);
}


/* =====================================================================
   SALES & PAYMENTS — REAL SUPABASE DATA
   ===================================================================== */
function ModuleSales() {
  const [tab, setTab] =
    useState("overview");

  const [range, setRange] =
    useState("30d");

  const [ledger, setLedger] =
    useState([]);

  const [loading, setLoading] =
    useState(true);

  const [error, setError] =
    useState("");

  const toast =
    useToast();


  const load =
    useCallback(
      async () => {
        try {
          setLoading(true);
          setError("");

          const windowRange =
            csFinanceRange(range);

          const rows =
            await window.API
              .AdminFinance
              .ledger(windowRange);

          setLedger(rows || []);
        } catch (err) {
          console.error(
            "Sales ledger loading failed:",
            err
          );

          setError(
            err?.message ||
            "Sales data could not be loaded."
          );
        } finally {
          setLoading(false);
        }
      },
      [range]
    );


  useEffect(() => {
    load();
  }, [load]);


  const exportReport = () => {
    try {
      csDownloadCsv(
        `chelsea-spa-sales-${range}.csv`,
        ledger.map(row => ({
          date:
            csDateTime(
              row.transaction_at
            ),
          provider:
            csProviderLabel(
              row.provider
            ),
          status:
            row.status,
          amount:
            Number(row.amount || 0)
              .toFixed(2),
          currency:
            row.currency || "GBP",
          booking_reference:
            row.booking_reference || "",
          booking_source:
            row.booking_source || "",
          treatment:
            row.service_name || "",
          customer:
            row.customer_name || "",
          payment_type:
            row.payment_type || ""
        }))
      );
    } catch (err) {
      toast(
        err?.message ||
        "Report could not be exported."
      );
    }
  };


  return (
    <div>
      <PageHead
        eyebrow="Finance"
        title="Sales & payments"
      >
        <Button
          variant="ghost"
          size="sm"
          icon="refresh"
          onClick={load}
        >
          Refresh
        </Button>

        <Button
          variant="ghost"
          size="sm"
          icon="download"
          onClick={exportReport}
          disabled={!ledger.length}
        >
          Report
        </Button>
      </PageHead>

      <div
        style={{
          display: "flex",
          justifyContent:
            "space-between",
          alignItems: "center",
          gap: 14,
          marginBottom: 20,
          flexWrap: "wrap"
        }}
      >
        <Tabs
          active={tab}
          onChange={setTab}
          tabs={[
            {
              id: "overview",
              label: "Overview"
            },
            {
              id: "transactions",
              label: "Transactions",
              count: ledger.length
            }
          ]}
        />

        <Tabs
          active={range}
          onChange={setRange}
          tabs={[
            {
              id: "30d",
              label: "30 days"
            },
            {
              id: "90d",
              label: "90 days"
            },
            {
              id: "mtd",
              label: "MTD"
            },
            {
              id: "all",
              label: "All"
            }
          ]}
        />
      </div>

      {error && (
        <Panel>
          <div
            style={{
              color: "var(--danger)",
              marginBottom: 12
            }}
          >
            {error}
          </div>

          <Button
            variant="primary"
            size="sm"
            onClick={load}
          >
            Try again
          </Button>
        </Panel>
      )}

      {!error &&
       tab === "overview" && (
        <SalesOverview
          rows={ledger}
          loading={loading}
        />
      )}

      {!error &&
       tab === "transactions" && (
        <SalesTransactions
          rows={ledger}
          loading={loading}
        />
      )}
    </div>
  );
}


function SalesOverview({
  rows,
  loading
}) {
  if (loading) {
    return (
      <Panel>
        <div className="caption">
          Loading real payment data…
        </div>
      </Panel>
    );
  }

  const paidRows =
    rows.filter(
      row =>
        ["paid", "partial", "succeeded"]
          .includes(
            String(
              row.status || ""
            ).toLowerCase()
          )
    );

  const total =
    paidRows.reduce(
      (sum, row) =>
        sum + Number(row.amount || 0),
      0
    );

  const average =
    paidRows.length
      ? total / paidRows.length
      : 0;

  const stripe =
    paidRows
      .filter(
        row =>
          row.provider === "stripe"
      )
      .reduce(
        (sum, row) =>
          sum + Number(row.amount || 0),
        0
      );

  const treatwell =
    paidRows
      .filter(
        row =>
          row.provider === "treatwell"
      )
      .reduce(
        (sum, row) =>
          sum + Number(row.amount || 0),
        0
      );

  const legacy =
    paidRows
      .filter(
        row =>
          row.provider ===
          "legacy_woocommerce"
      )
      .reduce(
        (sum, row) =>
          sum + Number(row.amount || 0),
        0
      );

  const daily = {};

  paidRows.forEach(row => {
    const date =
      new Date(
        row.transaction_at
      );

    if (
      Number.isNaN(
        date.getTime()
      )
    ) {
      return;
    }

    const key =
      date
        .toISOString()
        .slice(0, 10);

    daily[key] =
      (daily[key] || 0)
      +
      Number(row.amount || 0);
  });

  const trend =
    Object.keys(daily)
      .sort()
      .map(
        key =>
          Number(
            daily[key]
              .toFixed(2)
          )
      );

  const sourceRows = [
    {
      label: "Stripe",
      amount: stripe
    },
    {
      label: "Treatwell prepaid",
      amount: treatwell
    },
    {
      label: "Legacy WooCommerce",
      amount: legacy
    }
  ].filter(
    row => row.amount > 0
  );

  const maxSource =
    Math.max(
      1,
      ...sourceRows.map(
        row => row.amount
      )
    );

  return (
    <div>
      <div
        style={{
          display: "grid",
          gridTemplateColumns:
            "repeat(4,1fr)",
          gap: 16,
          marginBottom: 16
        }}
        className="kpi-row"
      >
        <AStat
          label="Recorded revenue"
          value={csMoney(total)}
          icon="wallet"
        />

        <AStat
          label="Transactions"
          value={paidRows.length}
          icon="credit-card"
        />

        <AStat
          label="Avg. transaction"
          value={csMoney(average)}
          icon="trending"
        />

        <AStat
          label="Treatwell prepaid"
          value={csMoney(treatwell)}
          icon="calendar"
        />
      </div>

      <div
        style={{
          display: "grid",
          gridTemplateColumns:
            "1.6fr 1fr",
          gap: 16
        }}
        className="ov-grid"
      >
        <Panel>
          <h3
            style={{
              fontSize: "1.05rem",
              marginBottom: 16
            }}
          >
            Revenue trend
          </h3>

          {trend.length ? (
            <LineChart
              data={trend}
              height={210}
            />
          ) : (
            <div
              className="caption"
              style={{
                padding: "70px 0",
                textAlign: "center"
              }}
            >
              No recorded paid transactions
              in this period.
            </div>
          )}
        </Panel>

        <Panel>
          <h3
            style={{
              fontSize: "1.05rem",
              marginBottom: 16
            }}
          >
            Revenue source
          </h3>

          {!sourceRows.length && (
            <div className="caption">
              No revenue in this period.
            </div>
          )}

          {sourceRows.map(row => {
            const pct =
              Math.round(
                row.amount /
                maxSource *
                100
              );

            return (
              <div
                key={row.label}
                style={{
                  marginBottom: 18
                }}
              >
                <div
                  style={{
                    display: "flex",
                    justifyContent:
                      "space-between",
                    gap: 12,
                    marginBottom: 7
                  }}
                >
                  <span
                    style={{
                      fontFamily:
                        "var(--font-display)",
                      fontSize: "0.86rem"
                    }}
                  >
                    {row.label}
                  </span>

                  <span
                    className="caption"
                  >
                    {csMoney(row.amount)}
                  </span>
                </div>

                <ProgressBar
                  pct={pct}
                  height={6}
                />
              </div>
            );
          })}

          <div
            className="a-divider"
            style={{
              margin: "20px 0"
            }}
          />

          <div
            className="caption"
            style={{
              lineHeight: 1.6
            }}
          >
            Stripe and legacy payments are
            read from the real payments
            ledger. Treatwell prepaid
            bookings are read from linked
            Treatwell appointments and are
            kept separate from Stripe.
          </div>
        </Panel>
      </div>
    </div>
  );
}


function SalesTransactions({
  rows,
  loading
}) {
  if (loading) {
    return (
      <Panel>
        <div className="caption">
          Loading transactions…
        </div>
      </Panel>
    );
  }

  if (!rows.length) {
    return (
      <Panel>
        <div className="caption">
          No transactions found for this
          period.
        </div>
      </Panel>
    );
  }

  return (
    <Panel
      pad={false}
      style={{
        overflow: "hidden"
      }}
    >
      <div
        style={{
          overflowX: "auto"
        }}
      >
        <table className="atable">
          <thead>
            <tr>
              <th>Date</th>
              <th>Booking</th>
              <th>Customer</th>
              <th>Treatment</th>
              <th>Source</th>
              <th>Amount</th>
              <th>Status</th>
            </tr>
          </thead>

          <tbody>
            {rows.map(row => (
              <tr key={row.ledger_id}>
                <td>
                  <span className="caption">
                    {csDateTime(
                      row.transaction_at
                    )}
                  </span>
                </td>

                <td>
                  <div
                    style={{
                      fontFamily:
                        "var(--font-mono)",
                      fontSize: "0.75rem"
                    }}
                  >
                    {row.booking_reference ||
                     "Legacy order"}
                  </div>

                  {row.booking_source && (
                    <div
                      className="caption"
                      style={{
                        marginTop: 3
                      }}
                    >
                      {row.booking_source}
                    </div>
                  )}
                </td>

                <td
                  style={{
                    fontFamily:
                      "var(--font-display)",
                    fontSize: "0.86rem"
                  }}
                >
                  {row.customer_name || "—"}
                </td>

                <td>
                  {row.service_name || "—"}
                </td>

                <td>
                  <span className="caption">
                    {csProviderLabel(
                      row.provider
                    )}
                  </span>
                </td>

                <td
                  style={{
                    fontFamily:
                      "var(--font-display)",
                    color:
                      "var(--gold-deep)"
                  }}
                >
                  {csMoney(row.amount)}
                </td>

                <td>
                  {csPaymentPill(
                    row.status
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </Panel>
  );
}


/* =====================================================================
   INVENTORY — REAL PRODUCTS, STOCK, SUPPLIERS + EXISTING RESOURCES
   ===================================================================== */
function ModuleInventory() {
  const [tab, setTab] =
    useState("stock");

  const [products, setProducts] =
    useState([]);

  const [suppliers, setSuppliers] =
    useState([]);

  const [movements, setMovements] =
    useState([]);

  const [loading, setLoading] =
    useState(true);

  const [error, setError] =
    useState("");

  const [adjusting, setAdjusting] =
    useState(null);

  const [supplierEditor, setSupplierEditor] =
    useState(null);

  const toast =
    useToast();


  const load =
    useCallback(async () => {
      try {
        setLoading(true);
        setError("");

        const [
          productRows,
          supplierRows,
          movementRows
        ] = await Promise.all([
          window.API
            .InventoryAdmin
            .products(),

          window.API
            .InventoryAdmin
            .Suppliers
            .list(),

          window.API
            .InventoryAdmin
            .movements(150)
        ]);

        setProducts(productRows || []);
        setSuppliers(supplierRows || []);
        setMovements(movementRows || []);
      } catch (err) {
        console.error(
          "Inventory loading failed:",
          err
        );

        setError(
          err?.message ||
          "Inventory could not be loaded."
        );
      } finally {
        setLoading(false);
      }
    }, []);


  useEffect(() => {
    load();
  }, [load]);


  const tracked =
    products.filter(
      product =>
        product.track_inventory &&
        product.is_active
    );

  const low =
    tracked.filter(
      product =>
        Number(
          product.stock_quantity || 0
        )
        <=
        Number(
          product.reorder_level || 0
        )
    );

  const stockValue =
    tracked.reduce(
      (sum, product) =>
        sum
        +
        Number(
          product.stock_quantity || 0
        )
        *
        Number(
          product.sale_price ??
          product.price ??
          0
        ),
      0
    );


  const exportStock = () => {
    try {
      csDownloadCsv(
        "chelsea-spa-stock.csv",
        products.map(
          product => ({
            sku: product.sku || "",
            product: product.name,
            stock:
              product.stock_quantity,
            reorder_level:
              product.reorder_level,
            tracked:
              product.track_inventory
                ? "yes"
                : "no",
            supplier:
              product.supplier_name ||
              "",
            price:
              Number(
                product.price || 0
              ).toFixed(2),
            active:
              product.is_active
                ? "yes"
                : "no"
          })
        )
      );
    } catch (err) {
      toast(
        err?.message ||
        "Stock report could not be exported."
      );
    }
  };


  return (
    <div>
      <PageHead
        eyebrow="Stock & supply"
        title="Inventory"
      >
        <Button
          variant="ghost"
          size="sm"
          icon="refresh"
          onClick={load}
        >
          Refresh
        </Button>

        <Button
          variant="ghost"
          size="sm"
          icon="download"
          onClick={exportStock}
          disabled={!products.length}
        >
          Stock report
        </Button>
      </PageHead>

      <div
        style={{
          marginBottom: 20
        }}
      >
        <Tabs
          active={tab}
          onChange={setTab}
          tabs={[
            {
              id: "stock",
              label: "Stock",
              count: tracked.length
            },
            {
              id: "suppliers",
              label: "Suppliers",
              count:
                suppliers.filter(
                  s => s.is_active
                ).length
            },
            {
              id: "history",
              label: "Stock history"
            },
            {
              id: "resources",
              label:
                "Resources & Equipment"
            }
          ]}
        />
      </div>

      {error && (
        <Panel>
          <div
            style={{
              color: "var(--danger)",
              marginBottom: 12
            }}
          >
            {error}
          </div>

          <Button
            variant="primary"
            size="sm"
            onClick={load}
          >
            Try again
          </Button>
        </Panel>
      )}

      {!error &&
       tab === "stock" && (
        <InventoryStockPanel
          products={products}
          tracked={tracked}
          low={low}
          stockValue={stockValue}
          loading={loading}
          onAdjust={setAdjusting}
        />
      )}

      {!error &&
       tab === "suppliers" && (
        <InventorySuppliersPanel
          suppliers={suppliers}
          products={products}
          loading={loading}
          onEdit={setSupplierEditor}
          onAdd={() =>
            setSupplierEditor({
              id: null,
              name: "",
              contact_name: "",
              email: "",
              phone: "",
              lead_time_days: "",
              notes: "",
              is_active: true
            })
          }
        />
      )}

      {!error &&
       tab === "history" && (
        <InventoryHistoryPanel
          rows={movements}
          loading={loading}
        />
      )}

      {!error &&
       tab === "resources" && (
        <ResourcesPanel toast={toast} />
      )}

      {adjusting && (
        <StockAdjustmentPanel
          product={adjusting}
          onClose={() =>
            setAdjusting(null)
          }
          onSaved={async () => {
            setAdjusting(null);
            await load();
          }}
          toast={toast}
        />
      )}

      {supplierEditor && (
        <SupplierEditorPanel
          supplier={supplierEditor}
          onClose={() =>
            setSupplierEditor(null)
          }
          onSaved={async () => {
            setSupplierEditor(null);
            await load();
          }}
          toast={toast}
        />
      )}
    </div>
  );
}


function InventoryStockPanel({
  products,
  tracked,
  low,
  stockValue,
  loading,
  onAdjust
}) {
  if (loading) {
    return (
      <Panel>
        <div className="caption">
          Loading stock…
        </div>
      </Panel>
    );
  }

  return (
    <div>
      <div
        style={{
          display: "grid",
          gridTemplateColumns:
            "repeat(4,1fr)",
          gap: 16,
          marginBottom: 16
        }}
        className="kpi-row"
      >
        <AStat
          label="SKUs tracked"
          value={tracked.length}
          icon="package"
        />

        <AStat
          label="Low / out"
          value={low.length}
          icon="alert"
        />

        <AStat
          label="Retail stock value"
          value={csMoney(stockValue)}
          icon="wallet"
        />

        <AStat
          label="Products"
          value={products.length}
          icon="grid"
        />
      </div>

      {low.length > 0 && (
        <Panel
          style={{
            marginBottom: 16,
            borderColor:
              "var(--gold-soft)",
            background:
              "var(--bg-nude)"
          }}
        >
          <div
            style={{
              display: "flex",
              gap: 12,
              alignItems:
                "flex-start"
            }}
          >
            <Icon
              name="alert"
              size={18}
              className="text-gold"
            />

            <div>
              <div
                style={{
                  fontFamily:
                    "var(--font-display)"
                }}
              >
                {low.length} product
                {low.length === 1
                  ? ""
                  : "s"} need attention
              </div>

              <div
                className="caption"
                style={{
                  marginTop: 4
                }}
              >
                {low
                  .map(
                    product =>
                      `${product.name} (${product.stock_quantity})`
                  )
                  .join(" · ")}
              </div>
            </div>
          </div>
        </Panel>
      )}

      <Panel
        pad={false}
        style={{
          overflow: "hidden"
        }}
      >
        <div
          style={{
            overflowX: "auto"
          }}
        >
          <table className="atable">
            <thead>
              <tr>
                <th>Product</th>
                <th>Stock</th>
                <th>Reorder at</th>
                <th>Status</th>
                <th>Supplier</th>
                <th>Value</th>
                <th></th>
              </tr>
            </thead>

            <tbody>
              {products.map(product => {
                const stock =
                  Number(
                    product
                      .stock_quantity || 0
                  );

                const reorder =
                  Number(
                    product
                      .reorder_level || 0
                  );

                const isTracked =
                  product.track_inventory;

                const isLow =
                  isTracked &&
                  stock <= reorder;

                const isOut =
                  isTracked &&
                  stock === 0;

                return (
                  <tr key={product.id}>
                    <td>
                      <div
                        style={{
                          fontFamily:
                            "var(--font-display)",
                          fontSize:
                            "0.9rem"
                        }}
                      >
                        {product.name}
                      </div>

                      <div
                        className="caption"
                        style={{
                          marginTop: 3
                        }}
                      >
                        {product.sku ||
                         "No SKU"}
                        {!product.is_active
                          ? " · Inactive"
                          : ""}
                      </div>
                    </td>

                    <td
                      style={{
                        fontFamily:
                          "var(--font-display)"
                      }}
                    >
                      {stock}
                    </td>

                    <td>
                      <span className="caption">
                        {isTracked
                          ? reorder
                          : "Not tracked"}
                      </span>
                    </td>

                    <td>
                      {!isTracked ? (
                        <Pill
                          color="var(--ink-3)"
                          bg="var(--bg-shell)"
                        >
                          Not tracked
                        </Pill>
                      ) : isOut ? (
                        <Pill
                          color="var(--danger)"
                          bg="rgba(154,74,58,0.14)"
                          dot
                        >
                          Out
                        </Pill>
                      ) : isLow ? (
                        <Pill
                          color="var(--gold-deep)"
                          bg="var(--bg-nude)"
                          dot
                        >
                          Low
                        </Pill>
                      ) : (
                        <Pill
                          color="var(--success)"
                          bg="rgba(107,122,94,0.16)"
                          dot
                        >
                          In stock
                        </Pill>
                      )}
                    </td>

                    <td>
                      <span className="caption">
                        {product
                          .supplier_name ||
                         "—"}
                      </span>
                    </td>

                    <td>
                      {csMoney(
                        stock
                        *
                        Number(
                          product
                            .sale_price ??
                          product
                            .price ??
                          0
                        )
                      )}
                    </td>

                    <td>
                      {isTracked && (
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() =>
                            onAdjust(product)
                          }
                        >
                          Adjust
                        </Button>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </Panel>
    </div>
  );
}


function StockAdjustmentPanel({
  product,
  onClose,
  onSaved,
  toast
}) {
  const [delta, setDelta] =
    useState("");

  const [reason, setReason] =
    useState("manual_adjustment");

  const [note, setNote] =
    useState("");

  const [saving, setSaving] =
    useState(false);

  const save = async () => {
    const quantityDelta =
      Number(delta);

    if (
      !Number.isInteger(
        quantityDelta
      )
      ||
      quantityDelta === 0
    ) {
      toast(
        "Enter a whole-number stock change, for example 5 or -2."
      );
      return;
    }

    try {
      setSaving(true);

      await window.API
        .InventoryAdmin
        .adjustStock({
          productId: product.id,
          quantityDelta,
          reason,
          note
        });

      toast(
        "Stock updated",
        "success"
      );

      await onSaved();
    } catch (err) {
      toast(
        err?.message ||
        "Stock could not be updated."
      );
    } finally {
      setSaving(false);
    }
  };

  const future =
    Number(
      product.stock_quantity || 0
    )
    +
    (Number(delta) || 0);

  return (
    <div
      style={{
        position: "fixed",
        inset: 0,
        zIndex: 210,
        background:
          "rgba(20,16,12,0.38)",
        display: "grid",
        placeItems: "center",
        padding: 20
      }}
      onMouseDown={onClose}
    >
      <div
        style={{
          width: "min(520px, 100%)"
        }}
        onMouseDown={e =>
          e.stopPropagation()
        }
      >
      <Panel
        style={{
          width: "100%",
          boxShadow:
            "var(--shadow-3)"
        }}
      >
        <div
          style={{
            display: "flex",
            justifyContent:
              "space-between",
            gap: 16,
            marginBottom: 20
          }}
        >
          <div>
            <div className="eyebrow">
              Stock adjustment
            </div>
            <h3
              style={{
                marginTop: 6
              }}
            >
              {product.name}
            </h3>
          </div>

          <button
            className="icon-btn"
            onClick={onClose}
          >
            <Icon
              name="x"
              size={16}
            />
          </button>
        </div>

        <div
          style={{
            display: "grid",
            gap: 14
          }}
        >
          <div>
            <div className="a-label">
              Current stock
            </div>
            <div
              style={{
                fontFamily:
                  "var(--font-display)",
                fontSize: "1.4rem",
                marginTop: 5
              }}
            >
              {product.stock_quantity}
            </div>
          </div>

          <div>
            <div className="a-label">
              Change
            </div>
            <input
              className="a-input"
              type="number"
              step="1"
              value={delta}
              onChange={e =>
                setDelta(
                  e.target.value
                )
              }
              placeholder="+5 or -2"
            />
          </div>

          <div>
            <div className="a-label">
              Reason
            </div>
            <select
              className="a-input"
              value={reason}
              onChange={e =>
                setReason(
                  e.target.value
                )
              }
            >
              <option value="manual_adjustment">
                Manual adjustment
              </option>
              <option value="purchase">
                Stock received
              </option>
              <option value="sale">
                Sale / usage
              </option>
              <option value="return">
                Return
              </option>
              <option value="damage">
                Damaged / lost
              </option>
              <option value="correction">
                Correction
              </option>
            </select>
          </div>

          <div>
            <div className="a-label">
              Note
            </div>
            <textarea
              className="a-input"
              rows={3}
              value={note}
              onChange={e =>
                setNote(
                  e.target.value
                )
              }
              placeholder="Optional note"
              style={{
                resize: "vertical"
              }}
            />
          </div>

          <div
            className="caption"
            style={{
              padding: 12,
              background:
                "var(--bg-nude)",
              borderRadius: 6
            }}
          >
            New stock will be{" "}
            <strong>{future}</strong>.
            Negative stock is blocked by
            the database.
          </div>

          <div
            style={{
              display: "flex",
              justifyContent:
                "flex-end",
              gap: 10
            }}
          >
            <Button
              variant="ghost"
              onClick={onClose}
              disabled={saving}
            >
              Cancel
            </Button>

            <Button
              variant="primary"
              onClick={save}
              disabled={saving}
            >
              {saving
                ? "Saving…"
                : "Save adjustment"}
            </Button>
          </div>
        </div>
      </Panel>
      </div>
    </div>
  );
}


function InventorySuppliersPanel({
  suppliers,
  products,
  loading,
  onEdit,
  onAdd
}) {
  if (loading) {
    return (
      <Panel>
        <div className="caption">
          Loading suppliers…
        </div>
      </Panel>
    );
  }

  return (
    <div>
      <div
        style={{
          display: "flex",
          justifyContent: "flex-end",
          marginBottom: 14
        }}
      >
        <Button
          variant="primary"
          size="sm"
          icon="plus"
          onClick={onAdd}
        >
          Add supplier
        </Button>
      </div>

      <Panel
        pad={false}
        style={{
          overflow: "hidden"
        }}
      >
        <table className="atable">
          <thead>
            <tr>
              <th>Supplier</th>
              <th>Contact</th>
              <th>Lead time</th>
              <th>Products</th>
              <th>Status</th>
              <th></th>
            </tr>
          </thead>

          <tbody>
            {!suppliers.length && (
              <tr>
                <td
                  colSpan={6}
                  className="caption"
                  style={{
                    padding: 24
                  }}
                >
                  No suppliers yet.
                </td>
              </tr>
            )}

            {suppliers.map(
              supplier => {
                const productCount =
                  products.filter(
                    product =>
                      String(
                        product
                          .supplier_name ||
                        ""
                      ).trim()
                      ===
                      supplier.name
                  ).length;

                return (
                  <tr key={supplier.id}>
                    <td
                      style={{
                        fontFamily:
                          "var(--font-display)"
                      }}
                    >
                      {supplier.name}
                    </td>

                    <td>
                      <div>
                        {supplier
                          .contact_name ||
                         "—"}
                      </div>
                      <div className="caption">
                        {supplier.email ||
                         supplier.phone ||
                         ""}
                      </div>
                    </td>

                    <td>
                      <span className="caption">
                        {supplier
                          .lead_time_days !=
                         null
                          ? `${supplier.lead_time_days} days`
                          : "—"}
                      </span>
                    </td>

                    <td>{productCount}</td>

                    <td>
                      {supplier
                        .is_active ? (
                        <Pill
                          color="var(--success)"
                          bg="rgba(107,122,94,0.16)"
                          dot
                        >
                          Active
                        </Pill>
                      ) : (
                        <Pill
                          color="var(--ink-3)"
                          bg="var(--bg-shell)"
                        >
                          Inactive
                        </Pill>
                      )}
                    </td>

                    <td>
                      <button
                        className="icon-btn"
                        onClick={() =>
                          onEdit(
                            supplier
                          )
                        }
                        title="Edit supplier"
                      >
                        <Icon
                          name="edit"
                          size={15}
                        />
                      </button>
                    </td>
                  </tr>
                );
              }
            )}
          </tbody>
        </table>
      </Panel>
    </div>
  );
}


function SupplierEditorPanel({
  supplier,
  onClose,
  onSaved,
  toast
}) {
  const [form, setForm] =
    useState({
      ...supplier,
      lead_time_days:
        supplier
          .lead_time_days ??
        ""
    });

  const [saving, setSaving] =
    useState(false);

  const change =
    (key, value) =>
      setForm(
        current => ({
          ...current,
          [key]: value
        })
      );

  const save = async () => {
    if (
      !String(
        form.name || ""
      ).trim()
    ) {
      toast(
        "Supplier name is required."
      );
      return;
    }

    try {
      setSaving(true);

      const payload = {
        name:
          String(
            form.name || ""
          ).trim(),
        contact_name:
          String(
            form.contact_name || ""
          ).trim() || null,
        email:
          String(
            form.email || ""
          ).trim() || null,
        phone:
          String(
            form.phone || ""
          ).trim() || null,
        lead_time_days:
          form.lead_time_days === ""
            ? null
            : Math.max(
                0,
                Number(
                  form.lead_time_days
                ) || 0
              ),
        notes:
          String(
            form.notes || ""
          ).trim() || null,
        is_active:
          form.is_active !== false
      };

      if (form.id) {
        await window.API
          .InventoryAdmin
          .Suppliers
          .update(
            form.id,
            payload
          );
      } else {
        await window.API
          .InventoryAdmin
          .Suppliers
          .create(payload);
      }

      toast(
        "Supplier saved",
        "success"
      );

      await onSaved();
    } catch (err) {
      toast(
        err?.message ||
        "Supplier could not be saved."
      );
    } finally {
      setSaving(false);
    }
  };

  return (
    <div
      style={{
        position: "fixed",
        inset: 0,
        zIndex: 210,
        background:
          "rgba(20,16,12,0.38)",
        display: "grid",
        placeItems: "center",
        padding: 20
      }}
      onMouseDown={onClose}
    >
      <div
        style={{
          width: "min(620px,100%)"
        }}
        onMouseDown={e =>
          e.stopPropagation()
        }
      >
      <Panel
        style={{
          width: "100%"
        }}
      >
        <div
          style={{
            display: "flex",
            justifyContent:
              "space-between",
            alignItems: "center",
            marginBottom: 20
          }}
        >
          <h3>
            {form.id
              ? "Edit supplier"
              : "Add supplier"}
          </h3>

          <button
            className="icon-btn"
            onClick={onClose}
          >
            <Icon
              name="x"
              size={16}
            />
          </button>
        </div>

        <div
          style={{
            display: "grid",
            gridTemplateColumns:
              "1fr 1fr",
            gap: 14
          }}
          className="ov-grid"
        >
          <div>
            <div className="a-label">
              Supplier name
            </div>
            <input
              className="a-input"
              value={form.name || ""}
              onChange={e =>
                change(
                  "name",
                  e.target.value
                )
              }
            />
          </div>

          <div>
            <div className="a-label">
              Contact name
            </div>
            <input
              className="a-input"
              value={
                form.contact_name ||
                ""
              }
              onChange={e =>
                change(
                  "contact_name",
                  e.target.value
                )
              }
            />
          </div>

          <div>
            <div className="a-label">
              Email
            </div>
            <input
              className="a-input"
              type="email"
              value={form.email || ""}
              onChange={e =>
                change(
                  "email",
                  e.target.value
                )
              }
            />
          </div>

          <div>
            <div className="a-label">
              Phone
            </div>
            <input
              className="a-input"
              value={form.phone || ""}
              onChange={e =>
                change(
                  "phone",
                  e.target.value
                )
              }
            />
          </div>

          <div>
            <div className="a-label">
              Lead time (days)
            </div>
            <input
              className="a-input"
              type="number"
              min="0"
              value={
                form.lead_time_days
              }
              onChange={e =>
                change(
                  "lead_time_days",
                  e.target.value
                )
              }
            />
          </div>

          <div
            style={{
              display: "flex",
              alignItems: "end",
              paddingBottom: 4
            }}
          >
            <label
              style={{
                display: "flex",
                alignItems: "center",
                gap: 10
              }}
            >
              <Toggle
                checked={
                  form.is_active !==
                  false
                }
                onChange={value =>
                  change(
                    "is_active",
                    value
                  )
                }
                size={38}
              />
              <span
                style={{
                  fontFamily:
                    "var(--font-display)",
                  fontSize: "0.86rem"
                }}
              >
                Active supplier
              </span>
            </label>
          </div>

          <div
            style={{
              gridColumn: "1 / -1"
            }}
          >
            <div className="a-label">
              Notes
            </div>
            <textarea
              className="a-input"
              rows={3}
              value={form.notes || ""}
              onChange={e =>
                change(
                  "notes",
                  e.target.value
                )
              }
              style={{
                resize: "vertical"
              }}
            />
          </div>
        </div>

        <div
          style={{
            display: "flex",
            justifyContent:
              "flex-end",
            gap: 10,
            marginTop: 20
          }}
        >
          <Button
            variant="ghost"
            onClick={onClose}
            disabled={saving}
          >
            Cancel
          </Button>

          <Button
            variant="primary"
            onClick={save}
            disabled={saving}
          >
            {saving
              ? "Saving…"
              : "Save supplier"}
          </Button>
        </div>
      </Panel>
      </div>
    </div>
  );
}


function InventoryHistoryPanel({
  rows,
  loading
}) {
  if (loading) {
    return (
      <Panel>
        <div className="caption">
          Loading stock history…
        </div>
      </Panel>
    );
  }

  return (
    <Panel
      pad={false}
      style={{
        overflow: "hidden"
      }}
    >
      <table className="atable">
        <thead>
          <tr>
            <th>Date</th>
            <th>Product</th>
            <th>Change</th>
            <th>Reason</th>
            <th>Balance</th>
            <th>Note</th>
          </tr>
        </thead>

        <tbody>
          {!rows.length && (
            <tr>
              <td
                colSpan={6}
                className="caption"
                style={{
                  padding: 24
                }}
              >
                No stock adjustments have
                been recorded yet.
              </td>
            </tr>
          )}

          {rows.map(row => (
            <tr key={row.id}>
              <td>
                <span className="caption">
                  {csDateTime(
                    row.created_at
                  )}
                </span>
              </td>

              <td
                style={{
                  fontFamily:
                    "var(--font-display)"
                }}
              >
                {row.products?.name ||
                 "Product"}
              </td>

              <td
                style={{
                  fontFamily:
                    "var(--font-display)",
                  color:
                    row.quantity_delta > 0
                      ? "var(--success)"
                      : "var(--danger)"
                }}
              >
                {row.quantity_delta > 0
                  ? "+"
                  : ""}
                {row.quantity_delta}
              </td>

              <td>
                {String(
                  row.reason || ""
                ).replace(/_/g, " ")}
              </td>

              <td>{row.balance_after}</td>

              <td>
                <span className="caption">
                  {row.note || "—"}
                </span>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </Panel>
  );
}


function ResourcesPanel({ toast }) {
  const [resources, setResources] = useState([]);
  const [units, setUnits] = useState([]);
  const [services, setServices] = useState([]);
  const [requirements, setRequirements] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [resourceEditor, setResourceEditor] = useState(false);
  const [unitEditor, setUnitEditor] = useState(null);
  const [requirementEditor, setRequirementEditor] = useState(null);
  const [statusSavingUnit, setStatusSavingUnit] = useState(null);
  const [locations, setLocations] = useState([]);

  const loadResources = useCallback(async () => {
    try {
      setLoading(true);
      setError("");

      const [
        { data: resourceRows, error: resourceError },
        { data: unitRows, error: unitError },
        { data: locationRows, error: locationError },
        { data: serviceRows, error: serviceError },
        { data: requirementRows, error: requirementError }
      ] = await Promise.all([

        window.supabaseClient
          .from("resources")
          .select("*")
          .order("name"),

        window.supabaseClient
          .from("resource_units")
          .select("*")
          .order("name"),

        window.supabaseClient
          .from("locations")
          .select("id, name, is_active")
          .eq("is_active", true)
          .order("name"),

        window.supabaseClient
          .from("services")
          .select("id, name, location_id, is_active")
          .eq("is_active", true)
          .order("name"),

        window.supabaseClient
          .from("service_resource_requirements")
          .select("service_id, resource_id, quantity_required")
      ]);

      if (resourceError) throw resourceError;
      if (unitError) throw unitError;
      if (locationError) throw locationError;
      if (serviceError) throw serviceError;
      if (requirementError) throw requirementError;

      setResources(resourceRows || []);
      setUnits(unitRows || []);
      setLocations(locationRows || []);
      setServices(serviceRows || []);
      setRequirements(requirementRows || []);

    } catch (err) {
      console.error("Resource loading failed:", err);

      setError(
        err.message ||
        "Resources could not be loaded."
      );

    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadResources();
  }, [loadResources]);


  const updateUnitStatus =
    async (unit, status) => {

      try {

        setStatusSavingUnit(unit.id);

        const {
          error
        } =
          await window.supabaseClient
            .from("resource_units")
            .update({
              status: status
            })
            .eq("id", unit.id)
            .select("id")
            .single();

        if (error) {
          throw error;
        }

        toast(
          `${unit.name} status updated`,
          "success"
        );

        await loadResources();

      } catch (error) {

        console.error(
          "Resource unit status update failed:",
          error
        );

        toast(
          error.message ||
          "Unit status could not be updated."
        );

      } finally {

        setStatusSavingUnit(null);

      }

    };


  if (loading) {
    return (
      <Panel>
        <div className="caption">
          Loading resources…
        </div>
      </Panel>
    );
  }


  if (error) {
    return (
      <Panel>
        <div
          style={{
            color: "var(--danger)",
            marginBottom: 12
          }}
        >
          {error}
        </div>

        <Button
          variant="primary"
          size="sm"
          onClick={loadResources}
        >
          Try Again
        </Button>
      </Panel>
    );
  }


  return (
    <div>

      <div
        style={{
          display: "flex",
          justifyContent: "flex-end",
          marginBottom: 16
        }}
      >
        <Button
          variant="primary"
          size="sm"
          icon="plus"
          onClick={() =>
            setResourceEditor(true)
          }
        >
          Add Resource
        </Button>
      </div>


      {resources.length === 0 ? (

        <Panel>
          <EmptyBlock
            title="No resources yet"
            sub="Add machines, treatment rooms, beds or other booking resources."
          />
        </Panel>

      ) : (

        <div
          style={{
            display: "grid",
            gap: 16
          }}
        >

          {resources.map((resource) => {

            const resourceUnits =
              units.filter(
                unit =>
                  unit.resource_id === resource.id
              );

            const activeCount =
              resourceUnits.filter(
                unit =>
                  unit.status === "active"
              ).length;

            return (

              <Panel key={resource.id}>

                <div
                  style={{
                    display: "flex",
                    justifyContent: "space-between",
                    gap: 16,
                    alignItems: "flex-start",
                    flexWrap: "wrap"
                  }}
                >

                  <div>
                    <h3>
                      {resource.name}
                    </h3>

                    <div className="caption">
                      {resource.resource_type}
                      {" · "}
                      {activeCount} active unit
                      {activeCount === 1 ? "" : "s"}
                      {" · "}
                      {resourceUnits.length} total
                    </div>
                  </div>


                  <div
                    style={{
                      display: "flex",
                      alignItems: "center",
                      gap: 8,
                      flexWrap: "wrap"
                    }}
                  >

                    <Pill
                      color={
                        resource.is_active
                          ? "var(--success)"
                          : "var(--danger)"
                      }
                      bg={
                        resource.is_active
                          ? "rgba(107,122,94,0.16)"
                          : "rgba(154,74,58,0.14)"
                      }
                      dot
                    >
                      {resource.is_active
                        ? "Active"
                        : "Inactive"}
                    </Pill>


                    <Button
                      variant="ghost"
                      size="sm"
                      icon="plus"
                      onClick={() =>
                        setUnitEditor({
                          resource: resource
                        })
                      }
                    >
                      Add Unit
                    </Button>

                  </div>

                </div>


                <div
                  style={{
                    marginTop: 16
                  }}
                >

                  {resourceUnits.length === 0 && (

                    <div
                      className="caption"
                      style={{
                        padding: "12px 0",
                        borderTop:
                          "1px solid var(--line)"
                      }}
                    >
                      No physical units added yet.
                    </div>

                  )}


                  {resourceUnits.map(unit => (

                    <div
                      key={unit.id}
                      style={{
                        display: "flex",
                        justifyContent: "space-between",
                        alignItems: "center",
                        gap: 14,
                        padding: "10px 0",
                        borderTop:
                          "1px solid var(--line)"
                      }}
                    >

                      <div style={{ flex: 1 }}>

                        <div
                          style={{
                            fontFamily:
                              "var(--font-display)"
                          }}
                        >
                          {unit.name}
                        </div>

                        {unit.notes && (
                          <div
                            className="caption"
                            style={{
                              marginTop: 2
                            }}
                          >
                            {unit.notes}
                          </div>
                        )}

                      </div>


                      <select
                        className="a-input"
                        value={unit.status}
                        disabled={
                          statusSavingUnit === unit.id
                        }
                        onChange={(event) =>
                          updateUnitStatus(
                            unit,
                            event.target.value
                          )
                        }
                        style={{
                          width: 170,
                          paddingTop: 7,
                          paddingBottom: 7
                        }}
                      >
                        <option value="active">
                          Active
                        </option>

                        <option value="maintenance">
                          Maintenance
                        </option>

                        <option value="out_of_order">
                          Out of order
                        </option>

                        <option value="retired">
                          Retired
                        </option>
                      </select>

                    </div>

                  ))}

                </div>

              </Panel>

            );

          })}

        </div>

      )}


      <Panel
        pad={false}
        style={{
          overflow: "hidden",
          marginTop: 20
        }}
      >

        <div
          style={{
            padding: "16px 20px",
            borderBottom:
              "1px solid var(--line)"
          }}
        >

          <h3>
            Treatment Resource Requirements
          </h3>

          <div
            className="caption"
            style={{
              marginTop: 4
            }}
          >
            Choose which machines, rooms or beds
            each treatment needs before it can be booked.
          </div>

        </div>


        {services.length === 0 ? (

          <div
            className="caption"
            style={{
              padding: 20
            }}
          >
            No active treatments found.
          </div>

        ) : (

          services.map((service) => {

            const serviceRequirements =
              requirements.filter(
                item =>
                  item.service_id === service.id
              );

            const requirementText =
              serviceRequirements
                .map((item) => {

                  const resource =
                    resources.find(
                      row =>
                        row.id === item.resource_id
                    );

                  if (!resource) {
                    return null;
                  }

                  return (
                    `${resource.name} × ${item.quantity_required}`
                  );

                })
                .filter(Boolean)
                .join(" · ");

            return (

              <div
                key={service.id}
                style={{
                  display: "flex",
                  justifyContent: "space-between",
                  alignItems: "center",
                  gap: 16,
                  padding: "14px 20px",
                  borderBottom:
                    "1px solid var(--line)"
                }}
              >

                <div style={{ flex: 1 }}>

                  <div
                    style={{
                      fontFamily:
                        "var(--font-display)"
                    }}
                  >
                    {service.name}
                  </div>

                  <div
                    className="caption"
                    style={{
                      marginTop: 3
                    }}
                  >
                    {requirementText ||
                      "No resource requirement"}
                  </div>

                </div>


                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() =>
                    setRequirementEditor({
                      service: service
                    })
                  }
                >
                  Manage
                </Button>

              </div>

            );

          })

        )}

      </Panel>


      <ResourceDrawer
        open={resourceEditor}
        locations={locations}

        onClose={() =>
          setResourceEditor(false)
        }

        onSaved={async () => {
          setResourceEditor(false);
          await loadResources();
        }}

        toast={toast}
      />


      <ResourceUnitDrawer
        editor={unitEditor}

        onClose={() =>
          setUnitEditor(null)
        }

        onSaved={async () => {
          setUnitEditor(null);
          await loadResources();
        }}

        toast={toast}
      />


      <ServiceResourceDrawer
        editor={requirementEditor}
        resources={resources}
        requirements={requirements}

        onClose={() =>
          setRequirementEditor(null)
        }

        onSaved={async () => {
          setRequirementEditor(null);
          await loadResources();
        }}

        toast={toast}
      />

    </div>
  );
}


function ResourceDrawer({
  open,
  locations,
  onClose,
  onSaved,
  toast
}) {

  const [name, setName] = useState("");
  const [type, setType] = useState("equipment");
  const [locationId, setLocationId] = useState("");
  const [saving, setSaving] = useState(false);
  const [formError, setFormError] = useState("");


  useEffect(() => {

    if (!open) return;

    setName("");
    setType("equipment");

    setLocationId(
      locations?.[0]?.id || ""
    );

    setFormError("");

  }, [open, locations]);


  if (!open) {
    return null;
  }


  const save = async () => {

    const cleanName =
      name.trim();

    if (!cleanName) {
      setFormError(
        "Enter a resource name."
      );
      return;
    }


    if (!locationId) {
      setFormError(
        "Select a location."
      );
      return;
    }


    try {

      setSaving(true);
      setFormError("");


      const {
        error
      } =
        await window.supabaseClient
          .from("resources")
          .insert({
            location_id: locationId,
            name: cleanName,
            resource_type: type,
            is_active: true
          });


      if (error) {
        throw error;
      }


      toast(
        "Resource added",
        "success"
      );

      await onSaved();


    } catch (error) {

      console.error(
        "Resource creation failed:",
        error
      );


      if (error?.code === "23505") {

        setFormError(
          "A resource with this name already exists at this location."
        );

      } else {

        setFormError(
          error.message ||
          "Resource could not be added."
        );

      }


    } finally {

      setSaving(false);

    }

  };


  return (

    <Drawer
      open={true}

      onClose={
        saving
          ? () => {}
          : onClose
      }

      title="Add Resource"

      subtitle=
        "Machine, room, bed or other booking resource"

      footer={
        <>

          <Button
            variant="ghost"
            size="sm"
            onClick={onClose}
            disabled={saving}
          >
            Cancel
          </Button>

          <Button
            variant="primary"
            size="sm"
            onClick={save}
            disabled={saving}
          >
            {saving
              ? "Saving…"
              : "Add Resource"}
          </Button>

        </>
      }
    >

      {formError && (

        <div
          style={{
            padding: 12,
            marginBottom: 16,
            borderRadius: 7,
            color: "var(--danger)",
            background:
              "rgba(154,74,58,0.10)"
          }}
        >
          {formError}
        </div>

      )}


      <TherapistField label="Resource name">

        <input
          className="a-input"
          value={name}
          onChange={(event) =>
            setName(
              event.target.value
            )
          }
          placeholder=
            "e.g. HydraFacial Machine"
        />

      </TherapistField>


      <TherapistField label="Type">

        <select
          className="a-input"
          value={type}
          onChange={(event) =>
            setType(
              event.target.value
            )
          }
        >

          <option value="equipment">
            Equipment / Machine
          </option>

          <option value="room">
            Treatment Room
          </option>

          <option value="bed">
            Treatment Bed
          </option>

          <option value="other">
            Other
          </option>

        </select>

      </TherapistField>


      <TherapistField label="Location">

        <select
          className="a-input"
          value={locationId}
          onChange={(event) =>
            setLocationId(
              event.target.value
            )
          }
        >

          {locations.map(
            (location) => (

              <option
                key={location.id}
                value={location.id}
              >
                {location.name}
              </option>

            )
          )}

        </select>

      </TherapistField>


      <div
        style={{
          padding: 13,
          borderRadius: 8,
          background: "var(--bg-nude)"
        }}
      >

        <div className="caption">

          This creates the resource type only.
          Physical machines or rooms are added
          as individual units.

        </div>

      </div>

    </Drawer>

  );

}


function ResourceUnitDrawer({
  editor,
  onClose,
  onSaved,
  toast
}) {

  const [name, setName] = useState("");
  const [status, setStatus] = useState("active");
  const [notes, setNotes] = useState("");
  const [saving, setSaving] = useState(false);
  const [formError, setFormError] = useState("");


  useEffect(() => {

    if (!editor) {
      return;
    }

    setName("");
    setStatus("active");
    setNotes("");
    setFormError("");
    setSaving(false);

  }, [editor]);


  if (!editor) {
    return null;
  }


  const resource =
    editor.resource;


  const save =
    async () => {

      const cleanName =
        name.trim();

      if (!cleanName) {

        setFormError(
          "Enter a unit name."
        );

        return;
      }


      try {

        setSaving(true);
        setFormError("");


        const {
          error
        } =
          await window.supabaseClient
            .from("resource_units")
            .insert({
              resource_id: resource.id,
              name: cleanName,
              status: status,
              notes:
                notes.trim() || null
            });


        if (error) {
          throw error;
        }


        toast(
          "Resource unit added",
          "success"
        );


        await onSaved();


      } catch (error) {

        console.error(
          "Resource unit creation failed:",
          error
        );


        if (error?.code === "23505") {

          setFormError(
            "A unit with this name already exists for this resource."
          );

        } else {

          setFormError(
            error.message ||
            "Resource unit could not be added."
          );

        }


      } finally {

        setSaving(false);

      }

    };


  return (

    <Drawer
      open={true}

      onClose={
        saving
          ? () => {}
          : onClose
      }

      title="Add Unit"

      subtitle={
        resource?.name ||
        "Physical resource"
      }

      footer={
        <>

          <Button
            variant="ghost"
            size="sm"
            onClick={onClose}
            disabled={saving}
          >
            Cancel
          </Button>

          <Button
            variant="primary"
            size="sm"
            onClick={save}
            disabled={saving}
          >
            {saving
              ? "Saving…"
              : "Add Unit"}
          </Button>

        </>
      }
    >

      {formError && (

        <div
          style={{
            padding: 12,
            marginBottom: 16,
            borderRadius: 7,
            color: "var(--danger)",
            background:
              "rgba(154,74,58,0.10)"
          }}
        >
          {formError}
        </div>

      )}


      <TherapistField label="Unit name">

        <input
          className="a-input"

          value={name}

          onChange={(event) =>
            setName(
              event.target.value
            )
          }

          placeholder=
            "e.g. HF-01"
        />

      </TherapistField>


      <TherapistField label="Status">

        <select
          className="a-input"

          value={status}

          onChange={(event) =>
            setStatus(
              event.target.value
            )
          }
        >

          <option value="active">
            Active
          </option>

          <option value="maintenance">
            Maintenance
          </option>

          <option value="out_of_order">
            Out of order
          </option>

          <option value="retired">
            Retired
          </option>

        </select>

      </TherapistField>


      <TherapistField label="Notes">

        <textarea
          className="a-input"
          rows={3}

          value={notes}

          onChange={(event) =>
            setNotes(
              event.target.value
            )
          }

          placeholder=
            "Serial number, maintenance note, room details, etc."

          style={{
            resize: "vertical"
          }}
        />

      </TherapistField>


      <div
        style={{
          padding: 13,
          borderRadius: 8,
          background: "var(--bg-nude)"
        }}
      >

        <div className="caption">
          Use Retired instead of deleting an old unit.
          This preserves historical booking records.
        </div>

      </div>

    </Drawer>

  );

}


function ServiceResourceDrawer({
  editor,
  resources,
  requirements,
  onClose,
  onSaved,
  toast
}) {

  const [selected, setSelected] = useState({});
  const [saving, setSaving] = useState(false);
  const [formError, setFormError] = useState("");


  useEffect(() => {

    if (!editor?.service) {
      return;
    }


    const nextSelected = {};


    requirements
      .filter(
        row =>
          row.service_id === editor.service.id
      )
      .forEach((row) => {

        nextSelected[row.resource_id] =
          String(
            row.quantity_required || 1
          );

      });


    setSelected(nextSelected);
    setSaving(false);
    setFormError("");

  }, [editor, requirements]);


  if (!editor?.service) {
    return null;
  }


  const service =
    editor.service;


  const eligibleResources =
    resources.filter(
      resource =>
        resource.location_id ===
        service.location_id
    );


  const toggleResource =
    (resourceId) => {

      setSelected(
        current => {

          const next = {
            ...current
          };


          if (
            Object.prototype
              .hasOwnProperty
              .call(next, resourceId)
          ) {

            delete next[resourceId];

          } else {

            next[resourceId] = "1";

          }


          return next;

        }
      );

    };


  const changeQuantity =
    (resourceId, value) => {

      setSelected(
        current => ({
          ...current,
          [resourceId]: value
        })
      );

    };


  const save =
    async () => {

      setFormError("");


      const payload = [];


      for (
        const [resourceId, quantityValue]
        of Object.entries(selected)
      ) {

        const quantity =
          Number(quantityValue);


        if (
          !Number.isInteger(quantity) ||
          quantity < 1
        ) {

          setFormError(
            "Every selected resource needs a quantity of at least 1."
          );

          return;
        }


        payload.push({
          resource_id: resourceId,
          quantity_required: quantity
        });

      }


      try {

        setSaving(true);


        const {
          error
        } =
          await window.supabaseClient
            .rpc(
              "set_service_resource_requirements",
              {
                p_service_id: service.id,
                p_requirements: payload
              }
            );


        if (error) {
          throw error;
        }


        toast(
          "Treatment resources updated",
          "success"
        );


        await onSaved();


      } catch (error) {

        console.error(
          "Treatment resource save failed:",
          error
        );


        setFormError(
          error.message ||
          "Treatment resources could not be saved."
        );


      } finally {

        setSaving(false);

      }

    };


  return (

    <Drawer
      open={true}

      onClose={
        saving
          ? () => {}
          : onClose
      }

      title="Treatment Resources"

      subtitle={
        service.name
      }

      footer={
        <>

          <Button
            variant="ghost"
            size="sm"
            onClick={onClose}
            disabled={saving}
          >
            Cancel
          </Button>

          <Button
            variant="primary"
            size="sm"
            onClick={save}
            disabled={saving}
          >
            {saving
              ? "Saving…"
              : "Save Requirements"}
          </Button>

        </>
      }
    >

      {formError && (

        <div
          style={{
            padding: 12,
            marginBottom: 16,
            borderRadius: 7,
            color: "var(--danger)",
            background:
              "rgba(154,74,58,0.10)"
          }}
        >
          {formError}
        </div>

      )}


      <div
        className="caption"
        style={{
          marginBottom: 16
        }}
      >
        Select every physical resource this
        treatment must have available at the
        same time as the therapist.
      </div>


      {eligibleResources.length === 0 ? (

        <div
          className="caption"
          style={{
            padding: 16,
            border:
              "1px solid var(--line)",
            borderRadius: 8
          }}
        >
          No resources exist for this treatment's location.
        </div>

      ) : (

        eligibleResources.map(
          resource => {

            const isSelected =
              Object.prototype
                .hasOwnProperty
                .call(
                  selected,
                  resource.id
                );


            return (

              <div
                key={resource.id}

                style={{
                  display: "grid",
                  gridTemplateColumns:
                    "1fr 100px",
                  gap: 14,
                  alignItems: "center",
                  padding: "12px 0",
                  borderBottom:
                    "1px solid var(--line)"
                }}
              >

                <label
                  style={{
                    display: "flex",
                    gap: 10,
                    alignItems: "center",
                    cursor: "pointer"
                  }}
                >

                  <input
                    type="checkbox"

                    checked={isSelected}

                    onChange={() =>
                      toggleResource(
                        resource.id
                      )
                    }
                  />


                  <div>

                    <div
                      style={{
                        fontFamily:
                          "var(--font-display)"
                      }}
                    >
                      {resource.name}
                    </div>


                    <div
                      className="caption"
                      style={{
                        marginTop: 2
                      }}
                    >
                      {resource.resource_type}

                      {!resource.is_active
                        ? " · Inactive"
                        : ""}
                    </div>

                  </div>

                </label>


                <input
                  className="a-input"
                  type="number"
                  min="1"
                  step="1"

                  disabled={
                    !isSelected
                  }

                  value={
                    isSelected
                      ? selected[resource.id]
                      : ""
                  }

                  onChange={(event) =>
                    changeQuantity(
                      resource.id,
                      event.target.value
                    )
                  }

                  placeholder="Qty"
                />

              </div>

            );

          }
        )

      )}


      <div
        style={{
          marginTop: 18,
          padding: 13,
          borderRadius: 8,
          background: "var(--bg-nude)"
        }}
      >

        <div className="caption">
          Example: HydraFacial can require
          HydraFacial Machine × 1 and Treatment Room × 1.
          Booking availability will then require both
          resources to be free.
        </div>

      </div>

    </Drawer>

  );

}



/* =====================================================================
   MARKETING & CMS — REAL SUPABASE CMS + SEO
   ===================================================================== */
function ModuleMarketing() {
  const [tab, setTab] =
    useState("content");

  const toast =
    useToast();

  const viewSite = () => {
    const url =
      window.location.origin
      +
      window.location.pathname
        .replace(
          /admin\.html.*$/i,
          ""
        )
      +
      "#/";

    window.open(
      url,
      "_blank",
      "noopener,noreferrer"
    );
  };

  return (
    <div>
      <PageHead
        eyebrow="Website & marketing"
        title="Content (CMS)"
      >
        <Button
          variant="ghost"
          size="sm"
          icon="globe"
          onClick={viewSite}
        >
          View site
        </Button>
      </PageHead>

      <div
        style={{
          marginBottom: 20
        }}
      >
        <Tabs
          active={tab}
          onChange={setTab}
          tabs={[
            {
              id: "content",
              label: "Pages & sections"
            },
            {
              id: "media",
              label: "Media library"
            },
            {
              id: "faq",
              label: "FAQ"
            },
            {
              id: "testimonials",
              label: "Testimonials"
            },
            {
              id: "seo",
              label: "SEO"
            }
          ]}
        />
      </div>

      {tab === "content" && (
        <CMSContent toast={toast} />
      )}

      {tab === "media" && (
        <CMSMedia toast={toast} />
      )}

      {tab === "faq" && (
        <CMSFaq toast={toast} />
      )}

      {tab === "testimonials" && (
        <CMSTestimonials toast={toast} />
      )}

      {tab === "seo" && (
        <CMSSeo toast={toast} />
      )}
    </div>
  );
}


function CMSContent({ toast }) {
  const [sections, setSections] =
    useState([]);

  const [selected, setSelected] =
    useState(null);

  const [loading, setLoading] =
    useState(true);

  const [saving, setSaving] =
    useState(false);

  const [error, setError] =
    useState("");


  const load =
    useCallback(async () => {
      try {
        setLoading(true);
        setError("");

        const rows =
          await window.API
            .SiteAdmin
            .sections();

        setSections(rows || []);

        setSelected(
          current => {
            if (!current) {
              return rows?.[0]
                ? { ...rows[0] }
                : null;
            }

            const fresh =
              (rows || [])
                .find(
                  row =>
                    row.id ===
                    current.id
                );

            return fresh
              ? { ...fresh }
              : current;
          }
        );
      } catch (err) {
        setError(
          err?.message ||
          "Website content could not be loaded."
        );
      } finally {
        setLoading(false);
      }
    }, []);


  useEffect(() => {
    load();
  }, [load]);



  const save = async () => {
    if (!selected) return;

    try {
      setSaving(true);

      const saved =
        await window.API
          .SiteAdmin
          .saveSection(
            selected
          );

      toast(
        "Website section saved",
        "success"
      );

      setSelected(
        { ...saved }
      );

      await load();
    } catch (err) {
      toast(
        err?.message ||
        "Section could not be saved."
      );
    } finally {
      setSaving(false);
    }
  };



  if (error) {
    return (
      <Panel>
        <div
          style={{
            color: "var(--danger)",
            marginBottom: 12
          }}
        >
          {error}
        </div>

        <Button
          variant="primary"
          size="sm"
          onClick={load}
        >
          Try again
        </Button>
      </Panel>
    );
  }


  return (
    <div
      style={{
        display: "grid",
        gridTemplateColumns:
          "0.9fr 1.3fr",
        gap: 16
      }}
      className="ov-grid"
    >
      <Panel
        pad={false}
        style={{
          overflow: "hidden"
        }}
      >
        <div
          style={{
            padding: "14px 18px",
            borderBottom:
              "1px solid var(--line)",
            display: "flex",
            justifyContent:
              "space-between",
            alignItems: "center"
          }}
        >
          <h3
            style={{
              fontSize: "1rem"
            }}
          >
            Website sections
          </h3>

          <span className="caption">
            Live sections
          </span>
        </div>

        {loading && (
          <div
            className="caption"
            style={{
              padding: 20
            }}
          >
            Loading…
          </div>
        )}

        {!loading &&
         !sections.length && (
          <div
            className="caption"
            style={{
              padding: 20
            }}
          >
            No CMS sections yet.
          </div>
        )}

        {!loading &&
         sections.map(section => (
          <button
            key={section.id}
            onClick={() =>
              setSelected(
                { ...section }
              )
            }
            style={{
              display: "block",
              width: "100%",
              textAlign: "left",
              padding: "13px 18px",
              border: 0,
              borderBottom:
                "1px solid var(--line)",
              background:
                selected?.id ===
                section.id
                  ? "var(--bg-nude)"
                  : "transparent",
              cursor: "pointer"
            }}
          >
            <div
              style={{
                fontFamily:
                  "var(--font-display)",
                fontSize: "0.87rem"
              }}
            >
              {section.label}
            </div>

            <div
              className="caption"
              style={{
                marginTop: 3
              }}
            >
              {section.page_key}
              {" · "}
              {section.section_key}
              {" · "}
              {section.is_published
                ? "Published"
                : "Hidden"}
            </div>
          </button>
        ))}
      </Panel>

      <Panel>
        {!selected ? (
          <div className="caption">
            Choose a section to edit.
          </div>
        ) : (
          <div
            style={{
              display: "grid",
              gap: 14
            }}
          >
            <div
              style={{
                display: "grid",
                gridTemplateColumns:
                  "1fr 1fr",
                gap: 12
              }}
              className="ov-grid"
            >
              <div>
                <div className="a-label">
                  Page
                </div>
                <select
                  className="a-input"
                  value={
                    selected.page_key ||
                    ""
                  }
                  onChange={e =>
                    setSelected({
                      ...selected,
                      page_key:
                        e.target.value
                    })
                  }
                >
                  <option value="home">
                    Homepage
                  </option>
                  <option value="about">
                    About
                  </option>
                  <option value="contact">
                    Contact
                  </option>
                  <option value="treatments">
                    Treatments
                  </option>
                  <option value="shop">
                    Shop
                  </option>
                  <option value="booking">
                    Booking
                  </option>
                </select>
              </div>

              <div>
                <div className="a-label">
                  Section key
                </div>
                <input
                  className="a-input"
                  value={
                    selected
                      .section_key ||
                    ""
                  }
                  disabled={
                    Boolean(
                      selected.id
                    )
                  }
                  onChange={e =>
                    setSelected({
                      ...selected,
                      section_key:
                        e.target.value
                    })
                  }
                  placeholder="hero_heading"
                />
              </div>
            </div>

            <div>
              <div className="a-label">
                Admin label
              </div>
              <input
                className="a-input"
                value={
                  selected.label || ""
                }
                onChange={e =>
                  setSelected({
                    ...selected,
                    label:
                      e.target.value
                  })
                }
              />
            </div>

            <div>
              <div className="a-label">
                Content
              </div>
              <textarea
                className="a-input"
                rows={7}
                value={
                  selected
                    .content_text ??
                  ""
                }
                onChange={e =>
                  setSelected({
                    ...selected,
                    content_text:
                      e.target.value
                  })
                }
                style={{
                  resize: "vertical"
                }}
              />
            </div>

            <div
              style={{
                display: "flex",
                justifyContent:
                  "space-between",
                alignItems: "center",
                gap: 14,
                flexWrap: "wrap"
              }}
            >
              <label
                style={{
                  display: "flex",
                  gap: 10,
                  alignItems: "center"
                }}
              >
                <Toggle
                  checked={
                    selected
                      .is_published !==
                    false
                  }
                  onChange={value =>
                    setSelected({
                      ...selected,
                      is_published:
                        value
                    })
                  }
                  size={38}
                />
                <span
                  style={{
                    fontFamily:
                      "var(--font-display)",
                    fontSize:
                      "0.85rem"
                  }}
                >
                  Published
                </span>
              </label>

              <div
                style={{
                  display: "flex",
                  gap: 10
                }}
              >

                <Button
                  variant="primary"
                  size="sm"
                  onClick={save}
                  disabled={saving}
                >
                  {saving
                    ? "Saving…"
                    : "Save section"}
                </Button>
              </div>
            </div>
          </div>
        )}
      </Panel>
    </div>
  );
}


function CMSMedia({ toast }) {
  const [items, setItems] =
    useState([]);

  const [loading, setLoading] =
    useState(true);

  const [uploading, setUploading] =
    useState(false);

  const inputRef =
    useRef(null);


  const load =
    useCallback(async () => {
      try {
        setLoading(true);

        const rows =
          await window.API
            .SiteAdmin
            .media();

        setItems(rows || []);
      } catch (err) {
        toast(
          err?.message ||
          "Media could not be loaded."
        );
      } finally {
        setLoading(false);
      }
    }, [toast]);


  useEffect(() => {
    load();
  }, [load]);


  const upload =
    async event => {
      const file =
        event.target.files?.[0];

      event.target.value = "";

      if (!file) return;

      try {
        setUploading(true);

        await window.API
          .SiteAdmin
          .uploadMedia(file);

        toast(
          "Media uploaded",
          "success"
        );

        await load();
      } catch (err) {
        toast(
          err?.message ||
          "Media upload failed."
        );
      } finally {
        setUploading(false);
      }
    };


  const remove =
    async item => {
      if (
        !window.confirm(
          "Delete this media file?"
        )
      ) {
        return;
      }

      try {
        await window.API
          .SiteAdmin
          .deleteMedia(item);

        toast(
          "Media deleted",
          "success"
        );

        await load();
      } catch (err) {
        toast(
          err?.message ||
          "Media could not be deleted."
        );
      }
    };


  const copy =
    async url => {
      try {
        await navigator.clipboard
          .writeText(url);

        toast(
          "Media URL copied",
          "success"
        );
      } catch {
        toast(
          "Copy failed. Open the media and copy its URL."
        );
      }
    };


  return (
    <Panel>
      <div
        style={{
          display: "flex",
          justifyContent:
            "space-between",
          alignItems: "center",
          gap: 14,
          marginBottom: 16
        }}
      >
        <div>
          <h3
            style={{
              fontSize: "1.05rem"
            }}
          >
            Media library
          </h3>

          <div
            className="caption"
            style={{
              marginTop: 4
            }}
          >
            Stored in the Supabase
            cms-media bucket.
          </div>
        </div>

        <div>
          <input
            ref={inputRef}
            type="file"
            accept="image/*,video/mp4,application/pdf"
            onChange={upload}
            style={{
              display: "none"
            }}
          />

          <Button
            variant="primary"
            size="sm"
            icon="plus"
            onClick={() =>
              inputRef.current?.click()
            }
            disabled={uploading}
          >
            {uploading
              ? "Uploading…"
              : "Upload"}
          </Button>
        </div>
      </div>

      {loading && (
        <div className="caption">
          Loading media…
        </div>
      )}

      {!loading &&
       !items.length && (
        <div
          className="caption"
          style={{
            padding: "36px 0"
          }}
        >
          No media uploaded yet.
        </div>
      )}

      <div
        style={{
          display: "grid",
          gridTemplateColumns:
            "repeat(auto-fill,minmax(180px,1fr))",
          gap: 14
        }}
      >
        {items.map(item => (
          <div
            key={item.id}
            style={{
              border:
                "1px solid var(--line)",
              borderRadius: 8,
              overflow: "hidden"
            }}
          >
            <div
              style={{
                height: 140,
                background:
                  "var(--bg-shell)",
                display: "grid",
                placeItems: "center",
                overflow: "hidden"
              }}
            >
              {item.media_type ===
               "image" ? (
                <img
                  src={item.public_url}
                  alt={
                    item.alt_text ||
                    item.label ||
                    ""
                  }
                  style={{
                    width: "100%",
                    height: "100%",
                    objectFit: "cover"
                  }}
                />
              ) : item.media_type ===
                "video" ? (
                <video
                  src={item.public_url}
                  muted
                  controls
                  style={{
                    width: "100%",
                    height: "100%",
                    objectFit: "cover"
                  }}
                />
              ) : (
                <Icon
                  name="file-text"
                  size={30}
                />
              )}
            </div>

            <div
              style={{
                padding: 12
              }}
            >
              <div
                style={{
                  fontFamily:
                    "var(--font-display)",
                  fontSize: "0.84rem",
                  overflow: "hidden",
                  textOverflow:
                    "ellipsis",
                  whiteSpace: "nowrap"
                }}
              >
                {item.label ||
                 item.storage_path}
              </div>

              <div
                style={{
                  display: "flex",
                  gap: 6,
                  marginTop: 10
                }}
              >
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() =>
                    copy(
                      item.public_url
                    )
                  }
                >
                  Copy URL
                </Button>

                <button
                  className="icon-btn"
                  onClick={() =>
                    remove(item)
                  }
                  title="Delete"
                >
                  <Icon
                    name="trash"
                    size={14}
                  />
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </Panel>
  );
}


function CMSFaq({ toast }) {
  return (
    <SimpleCmsCollection
      type="faq"
      load={() =>
        window.API
          .SiteAdmin
          .faqs()
      }
      createBlank={() => ({
        id: null,
        question: "",
        answer: "",
        sort_order: 100,
        is_published: true
      })}
      title="Frequently asked questions"
      renderTitle={item =>
        item.question ||
        "New FAQ"
      }
      renderEditor={(
        item,
        setItem
      ) => (
        <>
          <div>
            <div className="a-label">
              Question
            </div>
            <input
              className="a-input"
              value={
                item.question || ""
              }
              onChange={e =>
                setItem({
                  ...item,
                  question:
                    e.target.value
                })
              }
            />
          </div>

          <div>
            <div className="a-label">
              Answer
            </div>
            <textarea
              className="a-input"
              rows={5}
              value={
                item.answer || ""
              }
              onChange={e =>
                setItem({
                  ...item,
                  answer:
                    e.target.value
                })
              }
              style={{
                resize: "vertical"
              }}
            />
          </div>
        </>
      )}
      save={item =>
        window.API
          .SiteAdmin
          .saveFaq(item)
      }
      remove={id =>
        window.API
          .SiteAdmin
          .deleteFaq(id)
      }
      toast={toast}
    />
  );
}


function CMSTestimonials({ toast }) {
  return (
    <SimpleCmsCollection
      type="testimonial"
      load={() =>
        window.API
          .SiteAdmin
          .testimonials()
      }
      createBlank={() => ({
        id: null,
        quote: "",
        author: "",
        author_meta: "",
        rating: 5,
        sort_order: 100,
        is_published: true
      })}
      title="Testimonials"
      renderTitle={item =>
        item.author ||
        "New testimonial"
      }
      renderEditor={(
        item,
        setItem
      ) => (
        <>
          <div>
            <div className="a-label">
              Quote
            </div>
            <textarea
              className="a-input"
              rows={5}
              value={
                item.quote || ""
              }
              onChange={e =>
                setItem({
                  ...item,
                  quote:
                    e.target.value
                })
              }
              style={{
                resize: "vertical"
              }}
            />
          </div>

          <div
            style={{
              display: "grid",
              gridTemplateColumns:
                "1fr 1fr",
              gap: 12
            }}
            className="ov-grid"
          >
            <div>
              <div className="a-label">
                Author
              </div>
              <input
                className="a-input"
                value={
                  item.author || ""
                }
                onChange={e =>
                  setItem({
                    ...item,
                    author:
                      e.target.value
                  })
                }
              />
            </div>

            <div>
              <div className="a-label">
                Author note
              </div>
              <input
                className="a-input"
                value={
                  item.author_meta ||
                  ""
                }
                onChange={e =>
                  setItem({
                    ...item,
                    author_meta:
                      e.target.value
                  })
                }
                placeholder="Member · 3 years"
              />
            </div>
          </div>

          <div>
            <div className="a-label">
              Rating
            </div>
            <select
              className="a-input"
              value={item.rating || 5}
              onChange={e =>
                setItem({
                  ...item,
                  rating:
                    Number(
                      e.target.value
                    )
                })
              }
            >
              {[5,4,3,2,1].map(
                rating => (
                  <option
                    key={rating}
                    value={rating}
                  >
                    {rating} stars
                  </option>
                )
              )}
            </select>
          </div>
        </>
      )}
      save={item =>
        window.API
          .SiteAdmin
          .saveTestimonial(item)
      }
      remove={id =>
        window.API
          .SiteAdmin
          .deleteTestimonial(id)
      }
      toast={toast}
    />
  );
}


function SimpleCmsCollection({
  type,
  load,
  createBlank,
  title,
  renderTitle,
  renderEditor,
  save,
  remove,
  toast
}) {
  const [items, setItems] =
    useState([]);

  const [selected, setSelected] =
    useState(null);

  const [loading, setLoading] =
    useState(true);

  const [saving, setSaving] =
    useState(false);


  const reload =
    async () => {
      try {
        setLoading(true);

        const rows =
          await load();

        setItems(rows || []);
      } catch (err) {
        toast(
          err?.message ||
          `${title} could not be loaded.`
        );
      } finally {
        setLoading(false);
      }
    };


  useEffect(() => {
    reload();
  }, []);


  const saveCurrent = async () => {
    if (!selected) return;

    try {
      setSaving(true);

      const result =
        await save(selected);

      setSelected(
        result
          ? { ...result }
          : null
      );

      toast(
        `${type} saved`,
        "success"
      );

      await reload();
    } catch (err) {
      toast(
        err?.message ||
        `${type} could not be saved.`
      );
    } finally {
      setSaving(false);
    }
  };


  const removeCurrent =
    async () => {
      if (
        !selected?.id ||
        !window.confirm(
          `Delete this ${type}?`
        )
      ) {
        return;
      }

      try {
        await remove(
          selected.id
        );

        setSelected(null);

        toast(
          `${type} deleted`,
          "success"
        );

        await reload();
      } catch (err) {
        toast(
          err?.message ||
          `${type} could not be deleted.`
        );
      }
    };


  return (
    <div
      style={{
        display: "grid",
        gridTemplateColumns:
          "0.8fr 1.2fr",
        gap: 16
      }}
      className="ov-grid"
    >
      <Panel
        pad={false}
        style={{
          overflow: "hidden"
        }}
      >
        <div
          style={{
            padding: "14px 18px",
            borderBottom:
              "1px solid var(--line)",
            display: "flex",
            justifyContent:
              "space-between",
            alignItems: "center"
          }}
        >
          <h3
            style={{
              fontSize: "1rem"
            }}
          >
            {title}
          </h3>

          <Button
            variant="ghost"
            size="sm"
            icon="plus"
            onClick={() =>
              setSelected(
                createBlank()
              )
            }
          >
            Add
          </Button>
        </div>

        {loading && (
          <div
            className="caption"
            style={{
              padding: 20
            }}
          >
            Loading…
          </div>
        )}

        {!loading &&
         items.map(item => (
          <button
            key={item.id}
            onClick={() =>
              setSelected(
                { ...item }
              )
            }
            style={{
              width: "100%",
              border: 0,
              borderBottom:
                "1px solid var(--line)",
              padding: "13px 18px",
              textAlign: "left",
              background:
                selected?.id ===
                item.id
                  ? "var(--bg-nude)"
                  : "transparent",
              cursor: "pointer"
            }}
          >
            <div
              style={{
                fontFamily:
                  "var(--font-display)",
                fontSize: "0.87rem"
              }}
            >
              {renderTitle(item)}
            </div>

            <div
              className="caption"
              style={{
                marginTop: 3
              }}
            >
              {item.is_published
                ? "Published"
                : "Hidden"}
            </div>
          </button>
        ))}
      </Panel>

      <Panel>
        {!selected ? (
          <div className="caption">
            Choose an item to edit.
          </div>
        ) : (
          <div
            style={{
              display: "grid",
              gap: 14
            }}
          >
            {renderEditor(
              selected,
              setSelected
            )}

            <label
              style={{
                display: "flex",
                gap: 10,
                alignItems: "center"
              }}
            >
              <Toggle
                checked={
                  selected
                    .is_published !==
                  false
                }
                onChange={value =>
                  setSelected({
                    ...selected,
                    is_published:
                      value
                  })
                }
                size={38}
              />

              <span
                style={{
                  fontFamily:
                    "var(--font-display)",
                  fontSize: "0.85rem"
                }}
              >
                Published
              </span>
            </label>

            <div
              style={{
                display: "flex",
                justifyContent:
                  "flex-end",
                gap: 10
              }}
            >
              {selected.id && (
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={
                    removeCurrent
                  }
                  disabled={saving}
                >
                  Delete
                </Button>
              )}

              <Button
                variant="primary"
                size="sm"
                onClick={
                  saveCurrent
                }
                disabled={saving}
              >
                {saving
                  ? "Saving…"
                  : "Save"}
              </Button>
            </div>
          </div>
        )}
      </Panel>
    </div>
  );
}


function CMSSeo({ toast }) {
  const [pages, setPages] =
    useState([]);

  const [loading, setLoading] =
    useState(true);

  const [savingId, setSavingId] =
    useState(null);


  const load =
    useCallback(async () => {
      try {
        setLoading(true);

        const rows =
          await window.API
            .SiteAdmin
            .seoPages();

        setPages(rows || []);
      } catch (err) {
        toast(
          err?.message ||
          "SEO settings could not be loaded."
        );
      } finally {
        setLoading(false);
      }
    }, [toast]);


  useEffect(() => {
    load();
  }, [load]);


  const change =
    (id, key, value) => {
      setPages(
        current =>
          current.map(
            page =>
              page.id === id
                ? {
                    ...page,
                    [key]: value
                  }
                : page
          )
      );
    };


  const save =
    async page => {
      try {
        setSavingId(page.id);

        await window.API
          .SiteAdmin
          .saveSeo(page);

        toast(
          `${page.page_name} SEO saved`,
          "success"
        );

        await load();
      } catch (err) {
        toast(
          err?.message ||
          "SEO settings could not be saved."
        );
      } finally {
        setSavingId(null);
      }
    };


  if (loading) {
    return (
      <Panel>
        <div className="caption">
          Loading SEO settings…
        </div>
      </Panel>
    );
  }


  return (
    <div
      style={{
        display: "grid",
        gap: 16
      }}
    >
      <Panel>
        <div
          style={{
            display: "flex",
            gap: 12,
            alignItems:
              "flex-start"
          }}
        >
          <Icon
            name="globe"
            size={18}
            className="text-gold"
          />

          <div>
            <div
              style={{
                fontFamily:
                  "var(--font-display)"
              }}
            >
              Live metadata
            </div>

            <div
              className="caption"
              style={{
                marginTop: 4,
                lineHeight: 1.6
              }}
            >
              These values are loaded by
              the public React site and
              update the document title,
              meta description, Open Graph
              tags and robots directive.
              The current website uses
              hash routing, so canonical
              paths remain hash-based until
              the final routing/deployment
              optimisation.
            </div>
          </div>
        </div>
      </Panel>

      {pages.map(page => (
        <Panel key={page.id}>
          <div
            style={{
              display: "flex",
              justifyContent:
                "space-between",
              alignItems: "center",
              gap: 14,
              marginBottom: 16
            }}
          >
            <div>
              <div className="eyebrow">
                {page.page_name}
              </div>

              <div
                className="caption"
                style={{
                  marginTop: 4
                }}
              >
                {page.page_key}
              </div>
            </div>

            <Button
              variant="primary"
              size="sm"
              onClick={() =>
                save(page)
              }
              disabled={
                savingId ===
                page.id
              }
            >
              {savingId === page.id
                ? "Saving…"
                : "Save SEO"}
            </Button>
          </div>

          <div
            style={{
              display: "grid",
              gap: 12
            }}
          >
            <div>
              <div className="a-label">
                Meta title
                {" · "}
                {String(
                  page.meta_title ||
                  ""
                ).length}
                /60
              </div>
              <input
                className="a-input"
                value={
                  page.meta_title ||
                  ""
                }
                onChange={e =>
                  change(
                    page.id,
                    "meta_title",
                    e.target.value
                  )
                }
              />
            </div>

            <div>
              <div className="a-label">
                Meta description
                {" · "}
                {String(
                  page
                    .meta_description ||
                  ""
                ).length}
                /160
              </div>
              <textarea
                className="a-input"
                rows={3}
                value={
                  page
                    .meta_description ||
                  ""
                }
                onChange={e =>
                  change(
                    page.id,
                    "meta_description",
                    e.target.value
                  )
                }
                style={{
                  resize: "vertical"
                }}
              />
            </div>

            <div
              style={{
                display: "grid",
                gridTemplateColumns:
                  "1fr 1fr",
                gap: 12
              }}
              className="ov-grid"
            >
              <div>
                <div className="a-label">
                  Canonical path
                </div>
                <input
                  className="a-input"
                  value={
                    page
                      .canonical_path ||
                    ""
                  }
                  onChange={e =>
                    change(
                      page.id,
                      "canonical_path",
                      e.target.value
                    )
                  }
                  placeholder="#/about"
                />
              </div>

              <div>
                <div className="a-label">
                  OG image URL
                </div>
                <input
                  className="a-input"
                  value={
                    page
                      .og_image_url ||
                    ""
                  }
                  onChange={e =>
                    change(
                      page.id,
                      "og_image_url",
                      e.target.value
                    )
                  }
                />
              </div>
            </div>

            <label
              style={{
                display: "flex",
                gap: 10,
                alignItems: "center"
              }}
            >
              <Toggle
                checked={
                  page.noindex === true
                }
                onChange={value =>
                  change(
                    page.id,
                    "noindex",
                    value
                  )
                }
                size={38}
              />
              <span
                style={{
                  fontFamily:
                    "var(--font-display)",
                  fontSize: "0.85rem"
                }}
              >
                No-index this page
              </span>
            </label>
          </div>
        </Panel>
      ))}
    </div>
  );
}



/* =====================================================================
   NOTIFICATIONS
   ===================================================================== */
function ModuleNotifications() {
  const toast = useToast();
  const [channels, setChannels] = useState({ email: true, sms: true, whatsapp: true, push: false });
  return (
    <div>
      <PageHead eyebrow="Communications" title="Notifications"/>
      <div style={{ display: "grid", gridTemplateColumns: "1.4fr 1fr", gap: 16 }} className="ov-grid">
        <Panel pad={false} style={{ overflow: "hidden" }}>
          <div style={{ padding: "16px 20px", borderBottom: "1px solid var(--line)" }}><h3 style={{ fontSize: "1.05rem" }}>Recent activity</h3></div>
          {AD.NOTIFS.map((n, i) => (
            <div key={i} style={{ display: "flex", gap: 14, padding: "14px 20px", borderBottom: i < AD.NOTIFS.length-1 ? "1px solid var(--line)" : "none", alignItems: "flex-start" }}>
              <span style={{ color: n.type === "alert" ? "var(--gold-deep)" : "var(--ink-3)", marginTop: 2 }}><Icon name={n.icon} size={16}/></span>
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: "0.88rem" }}>{n.text}</div>
                <div className="caption" style={{ fontSize: "0.68rem", marginTop: 2 }}>{n.time}</div>
              </div>
              <span className="chip chip-line" style={{ fontSize: "0.6rem" }}>{n.channel}</span>
            </div>
          ))}
        </Panel>
        <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
          <Panel>
            <h3 style={{ fontSize: "1.05rem", marginBottom: 14 }}>Channels</h3>
            {[["email","Email","mail"],["sms","SMS reminders","message"],["whatsapp","WhatsApp","message"],["push","Push notifications","bell"]].map(([k, label, icon]) => (
              <div key={k} style={{ display: "flex", alignItems: "center", justifyContent: "space-between", padding: "11px 0", borderTop: "1px solid var(--line)" }}>
                <span style={{ display: "flex", alignItems: "center", gap: 10, fontFamily: "var(--font-display)", fontSize: "0.88rem" }}><Icon name={icon} size={15} className="text-ink-3"/>{label}</span>
                <Toggle checked={channels[k]} onChange={v => { setChannels({...channels, [k]: v}); toast(label + (v ? " enabled" : " disabled")); }} size={38}/>
              </div>
            ))}
          </Panel>
          <Panel>
            <h3 style={{ fontSize: "1.05rem", marginBottom: 12 }}>Calendar sync</h3>
            <SyncRow icon="calendar" label="Google Calendar" connected/>
            <SyncRow icon="calendar" label="Outlook" connected={false} toast={toast}/>
          </Panel>
        </div>
      </div>
    </div>
  );
}

function SyncRow({ icon, label, connected, toast }) {
  return (
    <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", padding: "11px 0", borderTop: "1px solid var(--line)" }}>
      <span style={{ display: "flex", alignItems: "center", gap: 10, fontFamily: "var(--font-display)", fontSize: "0.88rem" }}><Icon name={icon} size={15} className="text-ink-3"/>{label}</span>
      {connected ? <Pill color="var(--success)" bg="rgba(107,122,94,0.16)" dot>Connected</Pill> : <Button variant="ghost" size="sm" onClick={() => toast && toast("Connecting…")}>Connect</Button>}
    </div>
  );
}


/* =====================================================================
   SETTINGS — REAL BUSINESS DETAILS, ACCESS, SYSTEM + AUDIT
   ===================================================================== */
function ModuleSettings() {
  const [tab, setTab] =
    useState("business");

  const toast =
    useToast();

  return (
    <div>
      <PageHead
        eyebrow="Configuration"
        title="Settings"
      />

      <div
        style={{
          marginBottom: 20
        }}
      >
        <Tabs
          active={tab}
          onChange={setTab}
          tabs={[
            {
              id: "business",
              label:
                "Business & website"
            },
            {
              id: "access",
              label:
                "Roles & access"
            },
            {
              id: "system",
              label:
                "System limits"
            },
            {
              id: "audit",
              label: "Audit log"
            }
          ]}
        />
      </div>

      {tab === "business" && (
        <BusinessSettingsPanel
          toast={toast}
        />
      )}

      {tab === "access" && (
        <RolesPanel />
      )}

      {tab === "system" && (
        <SystemSettingsPanel
          toast={toast}
        />
      )}

      {tab === "audit" && (
        <AuditPanel />
      )}
    </div>
  );
}


function BusinessSettingsPanel({
  toast
}) {
  const [location, setLocation] =
    useState(null);

  const [
    publicSettings,
    setPublicSettings
  ] = useState(null);

  const [loading, setLoading] =
    useState(true);

  const [saving, setSaving] =
    useState(false);


  const load =
    useCallback(async () => {
      try {
        setLoading(true);

        const [
          locationRow,
          publicRow
        ] = await Promise.all([
          window.API
            .SiteAdmin
            .location(),

          window.API
            .SiteAdmin
            .publicSettings()
        ]);

        setLocation({
          ...locationRow
        });

        setPublicSettings({
          ...publicRow,
          opening_hours: {
            mon_fri:
              publicRow
                ?.opening_hours
                ?.mon_fri ||
              "09:00 – 20:00",
            sat_sun:
              publicRow
                ?.opening_hours
                ?.sat_sun ||
              "10:00 – 18:00"
          }
        });
      } catch (err) {
        toast(
          err?.message ||
          "Settings could not be loaded."
        );
      } finally {
        setLoading(false);
      }
    }, [toast]);


  useEffect(() => {
    load();
  }, [load]);


  const save = async () => {
    if (
      !location ||
      !publicSettings
    ) {
      return;
    }

    try {
      setSaving(true);

      await window.API
        .SiteAdmin
        .updateLocation(
          location
        );

      await window.API
        .SiteAdmin
        .updatePublicSettings(
          publicSettings
        );

      toast(
        "Business settings saved",
        "success"
      );

      await load();
    } catch (err) {
      toast(
        err?.message ||
        "Business settings could not be saved."
      );
    } finally {
      setSaving(false);
    }
  };


  if (
    loading ||
    !location ||
    !publicSettings
  ) {
    return (
      <Panel>
        <div className="caption">
          Loading business settings…
        </div>
      </Panel>
    );
  }


  const setLoc =
    (key, value) =>
      setLocation({
        ...location,
        [key]: value
      });

  const setPublic =
    (key, value) =>
      setPublicSettings({
        ...publicSettings,
        [key]: value
      });

  const setHours =
    (key, value) =>
      setPublicSettings({
        ...publicSettings,
        opening_hours: {
          ...publicSettings
            .opening_hours,
          [key]: value
        }
      });


  return (
    <div
      style={{
        display: "grid",
        gap: 16
      }}
    >
      <Panel>
        <div
          style={{
            display: "flex",
            justifyContent:
              "space-between",
            alignItems: "center",
            marginBottom: 18
          }}
        >
          <div>
            <h3
              style={{
                fontSize: "1.05rem"
              }}
            >
              Business details
            </h3>

            <div
              className="caption"
              style={{
                marginTop: 4
              }}
            >
              These details are stored in
              the real locations table.
            </div>
          </div>

          <Button
            variant="primary"
            size="sm"
            onClick={save}
            disabled={saving}
          >
            {saving
              ? "Saving…"
              : "Save settings"}
          </Button>
        </div>

        <div
          style={{
            display: "grid",
            gridTemplateColumns:
              "1fr 1fr",
            gap: 14
          }}
          className="ov-grid"
        >
          <SettingInput
            label="Business name"
            value={location.name || ""}
            onChange={value =>
              setLoc(
                "name",
                value
              )
            }
          />

          <SettingInput
            label="Phone"
            value={location.phone || ""}
            onChange={value =>
              setLoc(
                "phone",
                value
              )
            }
          />

          <SettingInput
            label="Email"
            value={location.email || ""}
            onChange={value =>
              setLoc(
                "email",
                value
              )
            }
          />

          <SettingInput
            label="Address line 1"
            value={
              location
                .address_line_1 ||
              ""
            }
            onChange={value =>
              setLoc(
                "address_line_1",
                value
              )
            }
          />

          <SettingInput
            label="Address line 2"
            value={
              location
                .address_line_2 ||
              ""
            }
            onChange={value =>
              setLoc(
                "address_line_2",
                value
              )
            }
          />

          <SettingInput
            label="City"
            value={location.city || ""}
            onChange={value =>
              setLoc(
                "city",
                value
              )
            }
          />

          <SettingInput
            label="Postcode"
            value={
              location.postcode || ""
            }
            onChange={value =>
              setLoc(
                "postcode",
                value
              )
            }
          />

          <SettingInput
            label="Timezone"
            value={
              location.timezone ||
              "Europe/London"
            }
            onChange={value =>
              setLoc(
                "timezone",
                value
              )
            }
          />
        </div>
      </Panel>

      <Panel>
        <h3
          style={{
            fontSize: "1.05rem",
            marginBottom: 18
          }}
        >
          Public website details
        </h3>

        <div
          style={{
            display: "grid",
            gridTemplateColumns:
              "1fr 1fr",
            gap: 14
          }}
          className="ov-grid"
        >
          <SettingInput
            label="Mon–Fri opening hours"
            value={
              publicSettings
                .opening_hours
                .mon_fri || ""
            }
            onChange={value =>
              setHours(
                "mon_fri",
                value
              )
            }
          />

          <SettingInput
            label="Sat–Sun opening hours"
            value={
              publicSettings
                .opening_hours
                .sat_sun || ""
            }
            onChange={value =>
              setHours(
                "sat_sun",
                value
              )
            }
          />

          <SettingInput
            label="Instagram URL"
            value={
              publicSettings
                .instagram_url ||
              ""
            }
            onChange={value =>
              setPublic(
                "instagram_url",
                value
              )
            }
          />

          <SettingInput
            label="Facebook URL"
            value={
              publicSettings
                .facebook_url ||
              ""
            }
            onChange={value =>
              setPublic(
                "facebook_url",
                value
              )
            }
          />

          <SettingInput
            label="External booking URL (optional)"
            value={
              publicSettings
                .booking_url ||
              ""
            }
            onChange={value =>
              setPublic(
                "booking_url",
                value
              )
            }
          />

          <div
            style={{
              gridColumn: "1 / -1"
            }}
          >
            <div className="a-label">
              Footer tagline
            </div>

            <textarea
              className="a-input"
              rows={3}
              value={
                publicSettings
                  .footer_tagline ||
                ""
              }
              onChange={e =>
                setPublic(
                  "footer_tagline",
                  e.target.value
                )
              }
              style={{
                resize: "vertical"
              }}
            />
          </div>
        </div>
      </Panel>
    </div>
  );
}


function SettingInput({
  label,
  value,
  onChange,
  type = "text"
}) {
  return (
    <div>
      <div className="a-label">
        {label}
      </div>

      <input
        className="a-input"
        type={type}
        value={value}
        onChange={e =>
          onChange(
            e.target.value
          )
        }
      />
    </div>
  );
}


function RolesPanel() {
  const [counts, setCounts] =
    useState({});

  const [loading, setLoading] =
    useState(true);

  const [error, setError] =
    useState("");


  useEffect(() => {
    let cancelled = false;

    (async () => {
      try {
        const result =
          await window.API
            .SiteAdmin
            .roleSummary();

        if (!cancelled) {
          setCounts(
            result || {}
          );
        }
      } catch (err) {
        if (!cancelled) {
          setError(
            err?.message ||
            "Role summary could not be loaded."
          );
        }
      } finally {
        if (!cancelled) {
          setLoading(false);
        }
      }
    })();

    return () => {
      cancelled = true;
    };
  }, []);


  const roles = [
    {
      code: "super_admin",
      name: "Super Admin",
      access:
        "Full system access, including protected limits and role administration."
    },
    {
      code: "admin",
      name: "Admin / Manager",
      access:
        "Day-to-day management: bookings, CRM, catalog, inventory, finance, CMS and SEO."
    },
    {
      code: "skin_specialist",
      name: "Skin Specialist",
      access:
        "Own operational access with restricted management actions."
    },
    {
      code: "senior_therapist",
      name: "Senior Therapist",
      access:
        "Own operational access with restricted management actions."
    },
    {
      code: "practitioner",
      name: "Practitioner",
      access:
        "Own appointments and permitted staff functions only."
    }
  ];


  return (
    <div
      style={{
        display: "grid",
        gap: 12
      }}
    >
      <Panel>
        <div
          style={{
            display: "flex",
            gap: 12,
            alignItems:
              "flex-start"
          }}
        >
          <Icon
            name="shield"
            size={18}
            className="text-gold"
          />

          <div>
            <div
              style={{
                fontFamily:
                  "var(--font-display)"
              }}
            >
              Live role summary
            </div>

            <div
              className="caption"
              style={{
                marginTop: 4
              }}
            >
              Account role editing remains
              in the Staff / user-management
              workflow. This page shows the
              active access model rather than
              a fake permission matrix.
            </div>
          </div>
        </div>
      </Panel>

      {loading && (
        <Panel>
          <div className="caption">
            Loading roles…
          </div>
        </Panel>
      )}

      {error && (
        <Panel>
          <div
            style={{
              color: "var(--danger)"
            }}
          >
            {error}
          </div>
        </Panel>
      )}

      {!loading &&
       !error &&
       roles.map(role => (
        <Panel key={role.code}>
          <div
            style={{
              display: "flex",
              justifyContent:
                "space-between",
              gap: 20,
              alignItems:
                "flex-start"
            }}
          >
            <div>
              <h3
                style={{
                  fontSize: "1rem"
                }}
              >
                {role.name}
              </h3>

              <div
                className="caption"
                style={{
                  marginTop: 5,
                  lineHeight: 1.6
                }}
              >
                {role.access}
              </div>
            </div>

            <Pill
              color="var(--gold-deep)"
              bg="var(--bg-nude)"
            >
              {counts[role.code] || 0}
              {" "}
              active
            </Pill>
          </div>
        </Panel>
      ))}
    </div>
  );
}


function SystemSettingsPanel({
  toast
}) {
  const [settings, setSettings] =
    useState(null);

  const [role, setRole] =
    useState("");

  const [limit, setLimit] =
    useState("");

  const [saving, setSaving] =
    useState(false);

  const [loading, setLoading] =
    useState(true);


  const load =
    useCallback(async () => {
      try {
        setLoading(true);

        const [
          settingsRow,
          authResult
        ] = await Promise.all([
          window.API
            .SiteAdmin
            .businessSettings(),

          window.supabaseClient
            .auth
            .getUser()
        ]);

        const user =
          authResult?.data?.user;

        let currentRole = "";

        if (user?.id) {
          const {
            data,
            error
          } =
            await window
              .supabaseClient
              .from("profiles")
              .select(
                "access_role, role"
              )
              .eq("id", user.id)
              .single();

          if (error) {
            throw error;
          }

          currentRole =
            data?.access_role ||
            data?.role ||
            "";
        }

        setSettings(
          settingsRow
        );

        setLimit(
          String(
            settingsRow
              ?.max_active_staff ??
            ""
          )
        );

        setRole(currentRole);
      } catch (err) {
        toast(
          err?.message ||
          "System settings could not be loaded."
        );
      } finally {
        setLoading(false);
      }
    }, [toast]);


  useEffect(() => {
    load();
  }, [load]);


  const save = async () => {
    try {
      setSaving(true);

      const result =
        await window.API
          .SiteAdmin
          .setStaffLimit(
            Number(limit)
          );

      setSettings(result);

      toast(
        "Staff limit updated",
        "success"
      );
    } catch (err) {
      toast(
        err?.message ||
        "Staff limit could not be updated."
      );
    } finally {
      setSaving(false);
    }
  };


  if (loading) {
    return (
      <Panel>
        <div className="caption">
          Loading system settings…
        </div>
      </Panel>
    );
  }


  const isSuperAdmin =
    role === "super_admin";


  return (
    <div
      style={{
        display: "grid",
        gap: 16
      }}
    >
      <Panel>
        <div
          style={{
            display: "flex",
            gap: 12,
            alignItems:
              "flex-start"
          }}
        >
          <Icon
            name="lock"
            size={18}
            className="text-gold"
          />

          <div>
            <div
              style={{
                fontFamily:
                  "var(--font-display)"
              }}
            >
              Protected configuration
            </div>

            <div
              className="caption"
              style={{
                marginTop: 4,
                lineHeight: 1.6
              }}
            >
              Secrets, database keys,
              Stripe secrets, Gmail
              credentials and Treatwell
              ingest secrets are never
              exposed in this browser
              settings page.
            </div>
          </div>
        </div>
      </Panel>

      <Panel>
        <h3
          style={{
            fontSize: "1.05rem",
            marginBottom: 16
          }}
        >
          Active staff limit
        </h3>

        <div
          style={{
            display: "grid",
            gridTemplateColumns:
              "1fr auto",
            gap: 12,
            alignItems: "end",
            maxWidth: 500
          }}
        >
          <div>
            <div className="a-label">
              Maximum active staff
            </div>

            <input
              className="a-input"
              type="number"
              min="1"
              max="500"
              value={limit}
              disabled={!isSuperAdmin}
              onChange={e =>
                setLimit(
                  e.target.value
                )
              }
            />
          </div>

          <Button
            variant="primary"
            onClick={save}
            disabled={
              !isSuperAdmin ||
              saving
            }
          >
            {saving
              ? "Saving…"
              : "Save"}
          </Button>
        </div>

        <div
          className="caption"
          style={{
            marginTop: 10
          }}
        >
          Current database value:{" "}
          {settings
            ?.max_active_staff ??
           "—"}.
          {" "}
          Only Super Admin can change
          this value.
        </div>
      </Panel>
    </div>
  );
}


function AuditPanel() {
  const [rows, setRows] =
    useState([]);

  const [loading, setLoading] =
    useState(true);

  const [error, setError] =
    useState("");


  const load =
    useCallback(async () => {
      try {
        setLoading(true);
        setError("");

        const data =
          await window.API
            .SiteAdmin
            .audit(150);

        setRows(data || []);
      } catch (err) {
        setError(
          err?.message ||
          "Audit log could not be loaded."
        );
      } finally {
        setLoading(false);
      }
    }, []);


  useEffect(() => {
    load();
  }, [load]);


  if (loading) {
    return (
      <Panel>
        <div className="caption">
          Loading audit log…
        </div>
      </Panel>
    );
  }


  if (error) {
    return (
      <Panel>
        <div
          style={{
            color: "var(--danger)",
            marginBottom: 12
          }}
        >
          {error}
        </div>

        <Button
          variant="primary"
          size="sm"
          onClick={load}
        >
          Try again
        </Button>
      </Panel>
    );
  }


  return (
    <Panel
      pad={false}
      style={{
        overflow: "hidden"
      }}
    >
      <table className="atable">
        <thead>
          <tr>
            <th>Time</th>
            <th>Action</th>
            <th>Entity</th>
            <th>Details</th>
          </tr>
        </thead>

        <tbody>
          {!rows.length && (
            <tr>
              <td
                colSpan={4}
                className="caption"
                style={{
                  padding: 24
                }}
              >
                No 10I2C admin changes have
                been logged yet.
              </td>
            </tr>
          )}

          {rows.map(row => (
            <tr key={row.id}>
              <td>
                <span className="caption">
                  {csDateTime(
                    row.created_at
                  )}
                </span>
              </td>

              <td
                style={{
                  fontFamily:
                    "var(--font-display)"
                }}
              >
                {String(
                  row.action || ""
                ).replace(/_/g, " ")}
              </td>

              <td>
                <span className="caption">
                  {row.entity_type}
                  {row.entity_id
                    ? ` · ${row.entity_id}`
                    : ""}
                </span>
              </td>

              <td>
                <span
                  className="caption"
                  style={{
                    fontFamily:
                      "var(--font-mono)",
                    fontSize: "0.68rem"
                  }}
                >
                  {JSON.stringify(
                    row.details || {}
                  )}
                </span>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </Panel>
  );
}



Object.assign(window, { ModuleSales, ModuleInventory, ModuleMarketing, ModuleNotifications, ModuleSettings });
