/* =========================================================================
   STEP 10D — REAL PUBLIC BOOKING FLOW

   Treatment → Date → Time → Therapist + exact price → Customer details

   All availability, role pricing, cleanup buffer and resource checks come
   from Supabase. No random/mock availability remains.
   ========================================================================= */

function BookingPage() {
  const { navigate } = useRouter();
  const toast = useToast();

  const requestedTreatmentId = useMemo(() => {
    const match =
      window.location.hash.match(
        /[?&]t=([^&]+)/
      );

    return match
      ? decodeURIComponent(match[1])
      : "";
  }, []);

  const [services, setServices] =
    useState([]);

  const [servicesLoading, setServicesLoading] =
    useState(true);

  const [servicesError, setServicesError] =
    useState("");

  const [treatment, setTreatment] =
    useState(null);

  const [date, setDate] =
    useState("");

  const [times, setTimes] =
    useState([]);

  const [timesLoading, setTimesLoading] =
    useState(false);

  const [time, setTime] =
    useState("");

  const [staff, setStaff] =
    useState([]);

  const [staffLoading, setStaffLoading] =
    useState(false);

  const [therapist, setTherapist] =
    useState(null);

  const [details, setDetails] =
    useState({
      first: "",
      last: "",
      email: "",
      phone: "",
      notes: ""
    });

  const [creatingHold, setCreatingHold] =
    useState(false);

  const [activeStep, setActiveStep] =
    useState(1);


  useEffect(() => {
    loadServices();
  }, []);


  useEffect(() => {
    if (
      !requestedTreatmentId ||
      !services.length ||
      treatment
    ) {
      return;
    }

    const match =
      services.find(
        service =>
          String(service.id) ===
          String(requestedTreatmentId)
      );

    if (match) {
      chooseTreatment(match);
    }
  }, [
    services,
    requestedTreatmentId
  ]);


  async function loadServices() {
    setServicesLoading(true);
    setServicesError("");

    try {
      if (!window.API?.Services?.listBookable) {
        throw new Error(
          "Public booking API is not installed."
        );
      }

      const rows =
        await window.API.Services.listBookable();

      setServices(rows || []);
    } catch (err) {
      console.error(
        "Could not load treatments:",
        err
      );

      setServicesError(
        err?.message ||
        "Treatments could not be loaded."
      );
    } finally {
      setServicesLoading(false);
    }
  }


  function resetAfterTreatment() {
    setDate("");
    setTimes([]);
    setTime("");
    setStaff([]);
    setTherapist(null);
  }


  function chooseTreatment(service) {
    setTreatment(service);
    resetAfterTreatment();
    setActiveStep(2);
  }


  async function chooseDate(nextDate) {
    setDate(nextDate);
    setTimes([]);
    setTime("");
    setStaff([]);
    setTherapist(null);

    if (!nextDate || !treatment?.id) {
      return;
    }

    setTimesLoading(true);

    try {
      const rows =
        await window.API.Appointments
          .availableTimes(
            treatment.id,
            nextDate
          );

      setTimes(rows || []);
      setActiveStep(3);
    } catch (err) {
      console.error(
        "Could not load available times:",
        err
      );

      toast(
        err?.message ||
        "Available times could not be loaded."
      );
    } finally {
      setTimesLoading(false);
    }
  }


  async function chooseTime(startAt) {
    setTime(startAt);
    setStaff([]);
    setTherapist(null);

    if (!startAt || !treatment?.id) {
      return;
    }

    setStaffLoading(true);

    try {
      const rows =
        await window.API.Appointments
          .availableStaff(
            treatment.id,
            startAt
          );

      setStaff(rows || []);
      setActiveStep(4);
    } catch (err) {
      console.error(
        "Could not load therapists:",
        err
      );

      toast(
        err?.message ||
        "Available therapists could not be loaded."
      );
    } finally {
      setStaffLoading(false);
    }
  }


  function chooseTherapist(member) {
    setTherapist(member);
    setActiveStep(5);
  }


  const detailsValid =
    details.first.trim() &&
    details.last.trim() &&
    isLikelyEmail(details.email) &&
    details.phone.trim();


  const stepsDone = [
    !!treatment,
    !!date,
    !!time,
    !!therapist,
    !!detailsValid
  ];


  async function goToCheckout() {
    if (!stepsDone.every(Boolean)) {
      toast(
        "Complete all booking details first."
      );
      return;
    }

    setCreatingHold(true);

    try {
      const hold =
        await window.API.Appointments
          .createHold({
            service_id:
              treatment.id,

            staff_id:
              therapist.staff_id,

            start_at:
              time,

            first_name:
              details.first.trim(),

            last_name:
              details.last.trim(),

            email:
              details.email.trim(),

            phone:
              details.phone.trim(),

            customer_notes:
              details.notes.trim()
          });


      const trustedBooking = {
        appointment_id:
          hold.appointment_id,

        reference:
          hold.reference,

        customer_id:
          hold.customer_id,

        treatment: {
          id: treatment.id,
          name: treatment.name,
          category_name:
            treatment.category_name,
          duration_minutes:
            treatment.duration_minutes
        },

        therapist: {
          staff_id:
            therapist.staff_id,
          staff_name:
            therapist.staff_name,
          service_role:
            therapist.service_role
        },

        start_at: time,
        end_at: hold.end_at,
        blocked_end_at:
          hold.blocked_end_at,

        price:
          Number(hold.price || 0),

        deposit_due:
          Number(
            hold.deposit_due || 0
          ),

        hold_expires_at:
          hold.hold_expires_at,

        customer: {
          first_name:
            details.first.trim(),
          last_name:
            details.last.trim(),
          email:
            details.email.trim(),
          phone:
            details.phone.trim()
        }
      };


      sessionStorage.setItem(
        "cs_booking_hold",
        JSON.stringify(
          trustedBooking
        )
      );

      window.__booking =
        trustedBooking;

      navigate("/checkout");

    } catch (err) {
      console.error(
        "Could not create booking hold:",
        err
      );

      toast(
        err?.message ||
        "That appointment could not be reserved. Please choose another time."
      );

      // Availability may have changed between selection and hold.
      if (treatment?.id && date) {
        await chooseDate(date);
      }
    } finally {
      setCreatingHold(false);
    }
  }


  return (
    <div style={{ background: "var(--bg)" }}>
      <Nav />

      <section
        style={{
          paddingTop: 140,
          paddingBottom: 24
        }}
      >
        <div className="container-narrow">
          <button
            onClick={() =>
              navigate("/treatments")
            }
            className="caption"
            style={{
              display: "inline-flex",
              alignItems: "center",
              gap: 6,
              marginBottom: 32,
              color: "var(--ink-2)"
            }}
          >
            <Icon
              name="arrow-left"
              size={14}
            />
            Back to treatments
          </button>

          <div className="eyebrow">
            Book your treatment
          </div>

          <h1
            style={{
              marginTop: 12,
              marginBottom: 16
            }}
          >
            Choose a time that works
            {" "}
            <em
              className="serif-italic"
              style={{
                color: "var(--gold-deep)"
              }}
            >
              for you.
            </em>
          </h1>

          <p
            className="body-lg text-ink-2"
            style={{ maxWidth: "58ch" }}
          >
            Availability is checked live against therapist rotas, existing bookings and any equipment required for your treatment. Your exact price is shown before payment.
          </p>
        </div>
      </section>


      <section style={{ paddingBottom: 120 }}>
        <div
          className="container-narrow booking-grid"
          style={{
            display: "grid",
            gridTemplateColumns: "1fr 320px",
            gap: 48
          }}
        >
          <div>
            <BookingStep
              n={1}
              title="Choose your treatment"
              done={stepsDone[0]}
              open={activeStep === 1}
              summary={
                treatment
                  ? `${treatment.name} · from £${Number(
                      treatment.display_price || 0
                    ).toFixed(2)}`
                  : null
              }
              onEdit={() =>
                setActiveStep(1)
              }
            >
              <LiveTreatmentPicker
                services={services}
                loading={servicesLoading}
                error={servicesError}
                selected={treatment}
                onSelect={chooseTreatment}
                onRetry={loadServices}
              />
            </BookingStep>


            <BookingStep
              n={2}
              title="Choose a date"
              done={stepsDone[1]}
              open={activeStep === 2}
              locked={!treatment}
              summary={
                date
                  ? formatBookingDate(date)
                  : null
              }
              onEdit={() =>
                setActiveStep(2)
              }
            >
              <BookingDatePicker
                value={date}
                onChange={chooseDate}
                loading={timesLoading}
              />
            </BookingStep>


            <BookingStep
              n={3}
              title="Choose a time"
              done={stepsDone[2]}
              open={activeStep === 3}
              locked={!date}
              summary={
                time
                  ? formatBookingTime(time)
                  : null
              }
              onEdit={() =>
                setActiveStep(3)
              }
            >
              <LiveTimePicker
                times={times}
                loading={timesLoading}
                selected={time}
                onSelect={chooseTime}
              />
            </BookingStep>


            <BookingStep
              n={4}
              title="Choose your therapist"
              done={stepsDone[3]}
              open={activeStep === 4}
              locked={!time}
              summary={
                therapist
                  ? `${therapist.staff_name} · £${Number(
                      therapist.price || 0
                    ).toFixed(2)}`
                  : null
              }
              onEdit={() =>
                setActiveStep(4)
              }
            >
              <LiveTherapistPicker
                staff={staff}
                loading={staffLoading}
                selected={therapist}
                onSelect={chooseTherapist}
              />
            </BookingStep>


            <BookingStep
              n={5}
              title="Your details"
              done={stepsDone[4]}
              open={activeStep === 5}
              locked={!therapist}
              summary={
                stepsDone[4]
                  ? `${details.first} ${details.last} · ${details.email}`
                  : null
              }
              onEdit={() =>
                setActiveStep(5)
              }
            >
              <LiveBookingDetailsForm
                details={details}
                setDetails={setDetails}
              />

              <div
                style={{
                  marginTop: 28,
                  display: "flex",
                  justifyContent: "flex-end"
                }}
              >
                <Button
                  variant="primary"
                  size="lg"
                  iconRight="arrow-right"
                  disabled={
                    !stepsDone.every(Boolean) ||
                    creatingHold
                  }
                  onClick={goToCheckout}
                >
                  {creatingHold
                    ? "Reserving your appointment…"
                    : "Continue to payment"}
                </Button>
              </div>
            </BookingStep>
          </div>


          <LiveBookingSummary
            treatment={treatment}
            date={date}
            time={time}
            therapist={therapist}
          />
        </div>

        <style>{`
          @media (max-width: 880px) {
            .booking-grid {
              grid-template-columns: 1fr !important;
            }

            .booking-summary-side {
              display: none !important;
            }
          }
        `}</style>
      </section>

      <Footer />
    </div>
  );
}


function BookingStep({
  n,
  title,
  done,
  open,
  locked,
  summary,
  onEdit,
  children
}) {
  const collapsed =
    !open && !!summary;

  return (
    <div
      style={{
        border: "1px solid var(--line)",
        borderRadius: 8,
        background: "var(--bg-cream)",
        marginBottom: 16,
        overflow: "hidden",
        opacity: locked ? 0.55 : 1,
        borderColor:
          open
            ? "var(--gold-soft)"
            : "var(--line)",
        boxShadow:
          open
            ? "var(--shadow-2)"
            : "none"
      }}
    >
      <div
        style={{
          padding:
            collapsed
              ? "20px 28px"
              : "24px 28px 12px",
          display: "flex",
          alignItems: "center",
          gap: 16
        }}
      >
        <div
          style={{
            width: 32,
            height: 32,
            borderRadius: "50%",
            background:
              done
                ? "var(--gold-deep)"
                : open
                  ? "var(--ink)"
                  : "var(--bg-nude)",
            color:
              done || open
                ? "var(--ink-on-dark)"
                : "var(--ink-2)",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            fontFamily: "var(--font-display)",
            fontSize: "0.85rem",
            flexShrink: 0
          }}
        >
          {done
            ? <Icon name="check" size={14} />
            : n}
        </div>

        <div style={{ flex: 1 }}>
          <h3 style={{ fontSize: "1.08rem" }}>
            {title}
          </h3>

          {collapsed && (
            <div
              className="caption"
              style={{ marginTop: 4 }}
            >
              {summary}
            </div>
          )}
        </div>

        {collapsed && !locked && (
          <button
            onClick={onEdit}
            className="caption"
            style={{
              color: "var(--gold-deep)",
              textTransform: "uppercase",
              letterSpacing: "0.14em",
              fontSize: "0.7rem"
            }}
          >
            Edit
          </button>
        )}
      </div>

      {open && !locked && (
        <div
          className="fade-in"
          style={{
            padding: "12px 28px 28px"
          }}
        >
          {children}
        </div>
      )}
    </div>
  );
}


function LiveTreatmentPicker({
  services,
  loading,
  error,
  selected,
  onSelect,
  onRetry
}) {
  const [search, setSearch] =
    useState("");

  const q =
    search.trim().toLowerCase();

  const list =
    q
      ? services.filter(service =>
          [
            service.name,
            service.category_name
          ]
            .filter(Boolean)
            .join(" ")
            .toLowerCase()
            .includes(q)
        )
      : services;


  if (loading) {
    return (
      <BookingInfoBox>
        Loading live treatments…
      </BookingInfoBox>
    );
  }


  if (error) {
    return (
      <BookingInfoBox>
        <div>{error}</div>
        <div style={{ marginTop: 12 }}>
          <Button
            variant="ghost"
            size="sm"
            onClick={onRetry}
          >
            Try again
          </Button>
        </div>
      </BookingInfoBox>
    );
  }


  if (!services.length) {
    return (
      <BookingInfoBox>
        No treatments are currently enabled for online booking. Please call the spa to book.
      </BookingInfoBox>
    );
  }


  return (
    <div>
      <div
        style={{
          display: "flex",
          alignItems: "center",
          gap: 10,
          border: "1px solid var(--line-strong)",
          borderRadius: 6,
          padding: "10px 12px",
          marginBottom: 14
        }}
      >
        <Icon name="search" size={14} />

        <input
          value={search}
          onChange={event =>
            setSearch(event.target.value)
          }
          placeholder="Search treatment…"
          style={{
            flex: 1,
            border: "none",
            outline: "none",
            background: "transparent"
          }}
        />
      </div>

      <div style={{ display: "grid", gap: 8 }}>
        {list.map(service => {
          const isSelected =
            selected?.id === service.id;

          return (
            <button
              key={service.id}
              onClick={() =>
                onSelect(service)
              }
              style={{
                display: "grid",
                gridTemplateColumns: "1fr auto",
                alignItems: "center",
                gap: 16,
                padding: "15px 18px",
                background:
                  isSelected
                    ? "var(--bg-nude)"
                    : "transparent",
                border:
                  `1px solid ${
                    isSelected
                      ? "var(--gold-deep)"
                      : "var(--line)"
                  }`,
                borderRadius: 6,
                textAlign: "left"
              }}
            >
              <div>
                <div
                  style={{
                    fontFamily: "var(--font-display)",
                    fontSize: "0.96rem"
                  }}
                >
                  {service.name}
                </div>

                <div
                  className="caption"
                  style={{ marginTop: 4 }}
                >
                  {service.category_name}
                  {" · "}
                  {service.duration_minutes} min
                </div>
              </div>

              <div
                style={{
                  fontFamily: "var(--font-display)",
                  color: "var(--gold-deep)",
                  whiteSpace: "nowrap"
                }}
              >
                From £
                {Number(
                  service.display_price || 0
                ).toFixed(2)}
              </div>
            </button>
          );
        })}
      </div>
    </div>
  );
}


function BookingDatePicker({
  value,
  onChange,
  loading
}) {
  const today =
    bookingDateInputValue(
      new Date()
    );

  const maxDateObj =
    new Date();

  maxDateObj.setMonth(
    maxDateObj.getMonth() + 6
  );

  const max =
    bookingDateInputValue(
      maxDateObj
    );

  return (
    <div>
      <label
        className="caption"
        style={{
          display: "block",
          marginBottom: 8
        }}
      >
        Appointment date
      </label>

      <input
        className="input"
        type="date"
        min={today}
        max={max}
        value={value}
        onChange={event =>
          onChange(event.target.value)
        }
      />

      {loading && (
        <div
          className="caption"
          style={{ marginTop: 10 }}
        >
          Checking live availability…
        </div>
      )}
    </div>
  );
}


function LiveTimePicker({
  times,
  loading,
  selected,
  onSelect
}) {
  if (loading) {
    return (
      <BookingInfoBox>
        Checking live availability…
      </BookingInfoBox>
    );
  }

  if (!times.length) {
    return (
      <BookingInfoBox>
        No appointment times are available on this date. Choose another date.
      </BookingInfoBox>
    );
  }

  return (
    <div
      style={{
        display: "grid",
        gridTemplateColumns: "repeat(4, 1fr)",
        gap: 8
      }}
    >
      {times.map(item => {
        const startAt =
          typeof item === "string"
            ? item
            : item.start_at;

        const isSelected =
          String(selected) ===
          String(startAt);

        return (
          <button
            key={startAt}
            onClick={() =>
              onSelect(startAt)
            }
            style={{
              padding: "11px 8px",
              borderRadius: 5,
              border:
                `1px solid ${
                  isSelected
                    ? "var(--gold-deep)"
                    : "var(--line)"
                }`,
              background:
                isSelected
                  ? "var(--bg-nude)"
                  : "transparent",
              fontFamily: "var(--font-display)",
              fontSize: "0.84rem"
            }}
          >
            {formatBookingTime(startAt)}
          </button>
        );
      })}

      <style>{`
        @media (max-width: 620px) {
          .booking-grid button {
            min-height: 42px;
          }
        }
      `}</style>
    </div>
  );
}


function LiveTherapistPicker({
  staff,
  loading,
  selected,
  onSelect
}) {
  if (loading) {
    return (
      <BookingInfoBox>
        Checking which therapists are available…
      </BookingInfoBox>
    );
  }

  if (!staff.length) {
    return (
      <BookingInfoBox>
        That time has just become unavailable. Please go back and choose another time.
      </BookingInfoBox>
    );
  }

  return (
    <div
      style={{
        display: "grid",
        gridTemplateColumns: "1fr 1fr",
        gap: 10
      }}
    >
      {staff.map(member => {
        const isSelected =
          selected?.staff_id ===
          member.staff_id;

        return (
          <button
            key={member.staff_id}
            onClick={() =>
              onSelect(member)
            }
            style={{
              padding: "18px",
              background:
                isSelected
                  ? "var(--bg-nude)"
                  : "var(--bg)",
              border:
                `1px solid ${
                  isSelected
                    ? "var(--gold-deep)"
                    : "var(--line)"
                }`,
              borderRadius: 6,
              textAlign: "left"
            }}
          >
            <div
              style={{
                display: "flex",
                alignItems: "center",
                gap: 12
              }}
            >
              <PublicTherapistAvatar
                name={member.staff_name}
              />

              <div>
                <div
                  style={{
                    fontFamily: "var(--font-display)",
                    fontSize: "0.94rem"
                  }}
                >
                  {member.staff_name}
                </div>

                <div
                  className="caption"
                  style={{ marginTop: 3 }}
                >
                  {friendlyRole(
                    member.service_role
                  )}
                </div>
              </div>
            </div>

            <div
              style={{
                marginTop: 14,
                paddingTop: 12,
                borderTop: "1px solid var(--line)",
                display: "flex",
                justifyContent: "space-between",
                alignItems: "center"
              }}
            >
              <span className="caption">
                Exact price
              </span>

              <span
                style={{
                  fontFamily: "var(--font-display)",
                  color: "var(--gold-deep)",
                  fontSize: "1rem"
                }}
              >
                £
                {Number(
                  member.price || 0
                ).toFixed(2)}
              </span>
            </div>
          </button>
        );
      })}
    </div>
  );
}


function PublicTherapistAvatar({ name }) {
  const initials = String(name || "T")
    .split(/\s+/)
    .filter(Boolean)
    .slice(0, 2)
    .map(part => part[0])
    .join("")
    .toUpperCase();

  return (
    <span
      style={{
        width: 34,
        height: 34,
        borderRadius: "50%",
        background: "var(--bg-nude)",
        border: "1px solid var(--line)",
        display: "inline-flex",
        alignItems: "center",
        justifyContent: "center",
        flexShrink: 0,
        fontFamily: "var(--font-display)",
        fontSize: "0.72rem",
        color: "var(--gold-deep)"
      }}
    >
      {initials || "T"}
    </span>
  );
}


function LiveBookingDetailsForm({
  details,
  setDetails
}) {
  function change(field, value) {
    setDetails(current => ({
      ...current,
      [field]: value
    }));
  }

  return (
    <div
      style={{
        display: "grid",
        gridTemplateColumns: "1fr 1fr",
        gap: 14
      }}
    >
      <BookingField label="First name *">
        <input
          className="input"
          autoComplete="given-name"
          value={details.first}
          onChange={event =>
            change(
              "first",
              event.target.value
            )
          }
        />
      </BookingField>

      <BookingField label="Last name *">
        <input
          className="input"
          autoComplete="family-name"
          value={details.last}
          onChange={event =>
            change(
              "last",
              event.target.value
            )
          }
        />
      </BookingField>

      <BookingField label="Email *">
        <input
          className="input"
          type="email"
          autoComplete="email"
          value={details.email}
          onChange={event =>
            change(
              "email",
              event.target.value
            )
          }
        />
      </BookingField>

      <BookingField label="Mobile phone *">
        <input
          className="input"
          type="tel"
          autoComplete="tel"
          value={details.phone}
          onChange={event =>
            change(
              "phone",
              event.target.value
            )
          }
        />
      </BookingField>

      <div style={{ gridColumn: "1 / -1" }}>
        <BookingField label="Anything we should know?">
          <textarea
            className="input"
            rows={4}
            value={details.notes}
            onChange={event =>
              change(
                "notes",
                event.target.value
              )
            }
            placeholder="Pressure preference, accessibility request, pregnancy information or anything else relevant to your visit."
            style={{ resize: "vertical" }}
          />
        </BookingField>
      </div>

      <div
        className="caption"
        style={{
          gridColumn: "1 / -1",
          lineHeight: 1.55
        }}
      >
        Email and mobile are required for transactional booking confirmations and appointment updates. They are not automatically used for marketing.
      </div>
    </div>
  );
}


function BookingField({
  label,
  children
}) {
  return (
    <label style={{ display: "block" }}>
      <span
        className="caption"
        style={{
          display: "block",
          marginBottom: 7
        }}
      >
        {label}
      </span>
      {children}
    </label>
  );
}


function LiveBookingSummary({
  treatment,
  date,
  time,
  therapist
}) {
  return (
    <aside
      className="booking-summary-side"
      style={{
        position: "sticky",
        top: 120,
        alignSelf: "start",
        padding: 26,
        background: "var(--bg-cream)",
        border: "1px solid var(--line)",
        borderRadius: 8
      }}
    >
      <div
        className="eyebrow"
        style={{ marginBottom: 18 }}
      >
        Your appointment
      </div>

      <SummaryLine
        label="Treatment"
        value={treatment?.name || "—"}
      />

      <SummaryLine
        label="Date"
        value={
          date
            ? formatBookingDate(date)
            : "—"
        }
      />

      <SummaryLine
        label="Time"
        value={
          time
            ? formatBookingTime(time)
            : "—"
        }
      />

      <SummaryLine
        label="Therapist"
        value={
          therapist?.staff_name || "—"
        }
      />

      <div className="divider" />

      <div
        style={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "baseline",
          marginTop: 16
        }}
      >
        <span className="caption">
          Exact price
        </span>

        <span
          style={{
            fontFamily: "var(--font-display)",
            color: "var(--gold-deep)",
            fontSize: "1.4rem"
          }}
        >
          {therapist
            ? `£${Number(
                therapist.price || 0
              ).toFixed(2)}`
            : "—"}
        </span>
      </div>

      <div
        className="caption"
        style={{
          marginTop: 14,
          lineHeight: 1.5
        }}
      >
        Your appointment is rechecked once more before the payment hold is created.
      </div>
    </aside>
  );
}


function SummaryLine({
  label,
  value
}) {
  return (
    <div
      style={{
        padding: "11px 0",
        borderBottom: "1px solid var(--line)"
      }}
    >
      <div className="caption">
        {label}
      </div>

      <div
        style={{
          fontFamily: "var(--font-display)",
          fontSize: "0.9rem",
          marginTop: 3
        }}
      >
        {value}
      </div>
    </div>
  );
}


function BookingInfoBox({ children }) {
  return (
    <div
      style={{
        padding: "18px",
        border: "1px solid var(--line)",
        borderRadius: 6,
        background: "var(--bg-nude)",
        color: "var(--ink-2)",
        lineHeight: 1.55
      }}
    >
      {children}
    </div>
  );
}


function isLikelyEmail(value) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/
    .test(
      String(value || "").trim()
    );
}


function bookingDateInputValue(date) {
  const d = new Date(date);

  const year =
    d.getFullYear();

  const month =
    String(
      d.getMonth() + 1
    ).padStart(2, "0");

  const day =
    String(
      d.getDate()
    ).padStart(2, "0");

  return `${year}-${month}-${day}`;
}


function formatBookingDate(value) {
  if (!value) {
    return "—";
  }

  const date =
    /^\d{4}-\d{2}-\d{2}$/.test(value)
      ? new Date(`${value}T12:00:00`)
      : new Date(value);

  return date.toLocaleDateString(
    "en-GB",
    {
      weekday: "short",
      day: "numeric",
      month: "short",
      year: "numeric"
    }
  );
}


function formatBookingTime(value) {
  if (!value) {
    return "—";
  }

  return new Date(value)
    .toLocaleTimeString(
      "en-GB",
      {
        hour: "2-digit",
        minute: "2-digit"
      }
    );
}


function friendlyRole(role) {
  const map = {
    skin_specialist: "Skin Specialist",
    senior_therapist: "Senior Therapist",
    therapist: "Therapist"
  };

  return map[role] || "Therapist";
}


window.BookingPage = BookingPage;
