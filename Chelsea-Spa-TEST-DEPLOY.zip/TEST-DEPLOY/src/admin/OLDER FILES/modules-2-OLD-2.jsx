/* =========================================================================
   ADMIN MODULES (2/3) — Customers (CRM) · Staff & Rota · Catalog
   ========================================================================= */

/* =====================================================================
   CUSTOMERS — CRM with profile drawer
   ===================================================================== */

function ModuleCustomers() {

  /* =====================================================================
     CUSTOMERS — REAL SUPABASE CRM
     Server-side pagination + server-side search
     ===================================================================== */

  const [customers, setCustomers] =
    useState([]);

  const [customersLoading, setCustomersLoading] =
    useState(true);

  const [customersError, setCustomersError] =
    useState("");

  // Text currently visible inside the search box.
  const [search, setSearch] =
    useState("");

  // Search value actually sent to Supabase.
  // This updates only after the user stops typing briefly.
  const [debouncedSearch, setDebouncedSearch] =
    useState("");

  // Customer currently opened in the profile drawer.
  const [selected, setSelected] =
    useState(null);

  // --------------------------------------------------------
  // SERVER-SIDE PAGINATION
  // --------------------------------------------------------

  const [page, setPage] =
    useState(1);

  const PAGE_SIZE = 50;

  const [resultTotal, setResultTotal] =
    useState(0);

  const [totalPages, setTotalPages] =
    useState(1);

  // --------------------------------------------------------
  // GLOBAL CUSTOMER STATISTICS
  // --------------------------------------------------------

  const [customerStats, setCustomerStats] =
    useState({
      total: 0,
      marketing: 0,
      sms: 0,
      loyalty: 0
    });

  const [customerStatsLoading, setCustomerStatsLoading] =
    useState(true);

  // --------------------------------------------------------
  // ADD / EDIT CUSTOMER DRAWER
  // --------------------------------------------------------

  // null = closed
  // { mode: "create", customer: null }
  // { mode: "edit", customer: existingCustomer }
  const [customerEditor, setCustomerEditor] =
    useState(null);

  const toast = useToast();


  // --------------------------------------------------------
  // LOAD ONE PAGE OF CUSTOMERS
  // --------------------------------------------------------

  const loadCustomers =
    async (
      targetPage = page,
      searchText = debouncedSearch
    ) => {

      try {

        setCustomersLoading(true);
        setCustomersError("");

        if (!window.API?.Customers?.listPage) {
          throw new Error(
            "Paginated Customers API is unavailable. Check src/services/api.jsx."
          );
        }

        const result =
          await window.API.Customers.listPage({
            page: targetPage,
            pageSize: PAGE_SIZE,
            search: searchText
          });

        setCustomers(
          Array.isArray(result?.customers)
            ? result.customers
            : []
        );

        setResultTotal(
          Number(result?.total || 0)
        );

        setTotalPages(
          Math.max(
            1,
            Number(result?.totalPages || 1)
          )
        );

      } catch (error) {

        console.error(
          "Customer list failed:",
          error
        );

        setCustomers([]);
        setCustomersError(
          error.message ||
          "Customers could not be loaded."
        );

      } finally {

        setCustomersLoading(false);

      }

    };


  // --------------------------------------------------------
  // LOAD GLOBAL CUSTOMER STATISTICS
  // --------------------------------------------------------

  const loadCustomerStats =
    async () => {

      try {

        setCustomerStatsLoading(true);

        if (!window.API?.Customers?.stats) {
          throw new Error(
            "Customer statistics API is unavailable. Check src/services/api.jsx."
          );
        }

        const result =
          await window.API.Customers.stats();

        setCustomerStats({
          total:
            Number(result?.total || 0),
          marketing:
            Number(result?.marketing || 0),
          sms:
            Number(result?.sms || 0),
          loyalty:
            Number(result?.loyalty || 0)
        });

      } catch (error) {

        console.error(
          "Customer statistics failed:",
          error
        );

      } finally {

        setCustomerStatsLoading(false);

      }

    };


  // Load dashboard totals once when the module opens.
  useEffect(() => {
    loadCustomerStats();
  }, []);


  // --------------------------------------------------------
  // SEARCH DEBOUNCE
  //
  // Wait 350ms after the user stops typing before sending
  // the search to Supabase. This avoids one request for every
  // single keystroke. A new search always starts on Page 1.
  // --------------------------------------------------------

  useEffect(() => {

    const timer =
      window.setTimeout(() => {

        setPage(1);
        setDebouncedSearch(
          search.trim()
        );

      }, 350);


    return () => {
      window.clearTimeout(timer);
    };

  }, [search]);


  // Load only the current page from Supabase.
  // This runs immediately when paging, but only after the
  // debounce delay when the search text changes.
  useEffect(() => {

    loadCustomers(
      page,
      debouncedSearch
    );

  }, [page, debouncedSearch]);


  // --------------------------------------------------------
  // GLOBAL KPI VALUES
  // --------------------------------------------------------

  const marketingPercentage =
    customerStats.total > 0
      ? Math.round(
          (
            customerStats.marketing /
            customerStats.total
          ) * 100
        )
      : 0;


  // --------------------------------------------------------
  // PAGINATION DISPLAY VALUES
  // --------------------------------------------------------

  const showingFrom =
    resultTotal === 0
      ? 0
      : ((page - 1) * PAGE_SIZE) + 1;

  const showingTo =
    Math.min(
      page * PAGE_SIZE,
      resultTotal
    );


  // --------------------------------------------------------
  // EXPORT CUSTOMER CSV
  // --------------------------------------------------------

  const exportCustomers =
    async () => {

      try {

        const rows =
          await window.API.Customers.export();

        if (
          !Array.isArray(rows) ||
          !rows.length
        ) {

          toast(
            "There are no customers to export."
          );

          return;
        }

        const headers = [
          "First Name",
          "Last Name",
          "Email",
          "Phone",
          "Date of Birth",
          "Allergies",
          "Loyalty Points",
          "Marketing Consent",
          "SMS Consent",
          "Created"
        ];

        const escapeCsv =
          (value) => {

            const text =
              value === null ||
              value === undefined
                ? ""
                : String(value);

            return (
              '"' +
              text.replace(/"/g, '""') +
              '"'
            );
          };

        const csvRows = [
          headers.map(escapeCsv).join(","),

          ...rows.map(
            (customer) => [
              customer.first_name,
              customer.last_name,
              customer.email,
              customer.phone,
              customer.date_of_birth,
              customer.allergies,
              customer.loyalty_points,
              customer.marketing_consent
                ? "Yes"
                : "No",
              customer.sms_consent
                ? "Yes"
                : "No",
              customer.created_at
            ]
              .map(escapeCsv)
              .join(",")
          )
        ];

        const csv =
          csvRows.join("\n");

        const blob =
          new Blob(
            [csv],
            {
              type:
                "text/csv;charset=utf-8;"
            }
          );

        const url =
          URL.createObjectURL(blob);

        const link =
          document.createElement("a");

        link.href = url;
        link.download =
          `chelsea-spa-customers-${
            new Date()
              .toISOString()
              .slice(0, 10)
          }.csv`;

        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        URL.revokeObjectURL(url);

        toast(
          "Customer CSV exported.",
          "success"
        );

      } catch (error) {

        console.error(
          "Customer export failed:",
          error
        );

        toast(
          error.message ||
          "Customer export failed."
        );

      }

    };


  // --------------------------------------------------------
  // CUSTOMER SAVED
  // --------------------------------------------------------

  const handleCustomerSaved =
    async (savedCustomer) => {

      setCustomerEditor(null);

      // If the currently opened profile was edited,
      // refresh the customer object in that drawer too.
      if (
        selected &&
        savedCustomer?.id === selected.id
      ) {
        setSelected(savedCustomer);
      }

      // Refresh both the visible page and dashboard totals.
      await Promise.all([
        loadCustomers(
          page,
          debouncedSearch
        ),
        loadCustomerStats()
      ]);

    };


  // --------------------------------------------------------
  // DISPLAY
  // --------------------------------------------------------

  return (

    <div>

      <PageHead
        eyebrow="Database"
        title="Customers"
      >

        <Button
          variant="ghost"
          size="sm"
          icon="download"
          onClick={exportCustomers}
        >
          Export CSV
        </Button>

        <Button
          variant="primary"
          size="sm"
          icon="plus"
          onClick={() =>
            setCustomerEditor({
              mode: "create",
              customer: null
            })
          }
        >
          Add Customer
        </Button>

      </PageHead>


      {/* ====================================================
          CUSTOMER KPIs — GLOBAL DATABASE TOTALS
         ==================================================== */}

      <div
        style={{
          display: "grid",
          gridTemplateColumns:
            "repeat(4,1fr)",
          gap: 16,
          marginBottom: 20
        }}
        className="kpi-row"
      >

        <AStat
          label="Total customers"
          value={
            customerStatsLoading
              ? "—"
              : customerStats.total
          }
          icon="users"
        />

        <AStat
          label="Email marketing"
          value={
            customerStatsLoading
              ? "—"
              : `${marketingPercentage}%`
          }
          icon="mail"
        />

        <AStat
          label="SMS consent"
          value={
            customerStatsLoading
              ? "—"
              : customerStats.sms
          }
          icon="message"
        />

        <AStat
          label="Loyalty members"
          value={
            customerStatsLoading
              ? "—"
              : customerStats.loyalty
          }
          icon="award"
        />

      </div>


      {/* ====================================================
          SEARCH
         ==================================================== */}

      <div
        style={{
          display: "flex",
          justifyContent: "flex-end",
          alignItems: "center",
          marginBottom: 18
        }}
      >

        <SearchInput
          value={search}
          onChange={(value) => {

            // Update the box immediately.
            // Supabase search waits 350ms via debouncedSearch.
            setSearch(value);

          }}
          placeholder=
            "Search name, email or phone…"
          width={320}
        />

      </div>


      {/* ====================================================
          LOADING
         ==================================================== */}

      {customersLoading && (

        <Panel>
          <SkeletonRows rows={6}/>
        </Panel>

      )}


      {/* ====================================================
          ERROR
         ==================================================== */}

      {!customersLoading &&
        customersError && (

          <Panel>

            <EmptyBlock
              icon="alert"
              title=
                "Customers could not be loaded"
              sub={customersError}
              action={
                <Button
                  variant="primary"
                  size="sm"
                  onClick={() =>
                    loadCustomers(
                      page,
                      debouncedSearch
                    )
                  }
                >
                  Try Again
                </Button>
              }
            />

          </Panel>

        )}


      {/* ====================================================
          CUSTOMER TABLE
         ==================================================== */}

      {!customersLoading &&
        !customersError && (

          <Panel
            pad={false}
            style={{
              overflow: "hidden"
            }}
          >

            <div
              style={{
                overflowX: "auto"
              }}
              className="hide-scroll"
            >

              <table className="atable">

                <thead>
                  <tr>
                    <th>Customer</th>
                    <th>Phone</th>
                    <th>Allergies</th>
                    <th>Loyalty</th>
                    <th>Marketing</th>
                    <th>Added to CRM</th>
                    <th></th>
                  </tr>
                </thead>

                <tbody>

                  {customers.map(
                    (customer) => {

                      const fullName = [
                        customer.first_name,
                        customer.last_name
                      ]
                        .filter(Boolean)
                        .join(" ");

                      return (

                        <tr
                          key={customer.id}
                          onClick={() =>
                            setSelected(customer)
                          }
                          style={{
                            cursor: "pointer"
                          }}
                        >

                          {/* CUSTOMER */}
                          <td>
                            <div
                              style={{
                                display: "flex",
                                alignItems:
                                  "center",
                                gap: 12
                              }}
                            >

                              <Avatar
                                name={
                                  fullName ||
                                  "Customer"
                                }
                                size={34}
                              />

                              <div>
                                <div
                                  style={{
                                    fontFamily:
                                      "var(--font-display)"
                                  }}
                                >
                                  {fullName || "Customer"}
                                </div>

                                <div
                                  className="caption"
                                  style={{
                                    fontSize:
                                      "0.7rem"
                                  }}
                                >
                                  {customer.email ||
                                    "No email"}
                                </div>
                              </div>

                            </div>
                          </td>

                          {/* PHONE */}
                          <td>
                            {customer.phone ||
                              <span className="caption">
                                —
                              </span>}
                          </td>

                          {/* ALLERGIES */}
                          <td>
                            {customer.allergies
                              ? (
                                  <Pill
                                    color="var(--danger)"
                                    bg=
                                      "rgba(154,74,58,0.12)"
                                  >
                                    Allergy
                                  </Pill>
                                )
                              : (
                                  <span className="caption">
                                    None recorded
                                  </span>
                                )}
                          </td>

                          {/* LOYALTY */}
                          <td
                            style={{
                              fontFamily:
                                "var(--font-display)"
                            }}
                          >
                            {Number(
                              customer.loyalty_points ||
                              0
                            )}

                            <span className="caption">
                              {" "}pts
                            </span>
                          </td>

                          {/* MARKETING */}
                          <td>
                            {customer.marketing_consent
                              ? (
                                  <Pill
                                    color=
                                      "var(--success)"
                                    bg=
                                      "rgba(107,122,94,0.16)"
                                    dot
                                  >
                                    Opted in
                                  </Pill>
                                )
                              : (
                                  <span className="caption">
                                    No
                                  </span>
                                )}
                          </td>

                          {/* CREATED */}
                          <td>
                            <span className="caption">
                              {customer.created_at
                                ? new Date(
                                    customer.created_at
                                  ).toLocaleDateString(
                                    "en-GB"
                                  )
                                : "—"}
                            </span>
                          </td>

                          <td>
                            <Icon
                              name="chevron-right"
                              size={16}
                              className=
                                "text-ink-3"
                            />
                          </td>

                        </tr>

                      );

                    }
                  )}

                </tbody>

              </table>

            </div>


            {/* EMPTY RESULT */}

            {customers.length === 0 && (

              <div
                style={{
                  padding: 40
                }}
              >
                <EmptyBlock
                  title=
                    "No customers found"
                  sub=
                    "Try a different name, email or phone number."
                />
              </div>

            )}


            {/* ====================================================
                CUSTOMER PAGINATION
               ==================================================== */}

            <div
              style={{
                display: "flex",
                justifyContent:
                  "space-between",
                alignItems:
                  "center",
                gap: 16,
                flexWrap: "wrap",
                padding: "14px 20px",
                borderTop:
                  "1px solid var(--line)"
              }}
            >

              <div className="caption">

                {resultTotal === 0
                  ? "No customers found"
                  : (
                      <>
                        Showing{" "}
                        <strong>
                          {showingFrom}
                        </strong>
                        {"–"}
                        <strong>
                          {showingTo}
                        </strong>
                        {" of "}
                        <strong>
                          {resultTotal}
                        </strong>
                        {search
                          ? " matching customers"
                          : " customers"}
                      </>
                    )}

              </div>


              {resultTotal > 0 && (

                <div
                  style={{
                    display: "flex",
                    alignItems: "center",
                    gap: 10
                  }}
                >

                  <Button
                    variant="ghost"
                    size="sm"
                    disabled={
                      page <= 1 ||
                      customersLoading
                    }
                    onClick={() =>
                      setPage(
                        (current) =>
                          Math.max(
                            1,
                            current - 1
                          )
                      )
                    }
                  >
                    Previous
                  </Button>

                  <div
                    className="caption"
                    style={{
                      minWidth: 100,
                      textAlign: "center"
                    }}
                  >
                    Page{" "}
                    <strong>{page}</strong>
                    {" of "}
                    <strong>{totalPages}</strong>
                  </div>

                  <Button
                    variant="ghost"
                    size="sm"
                    disabled={
                      page >= totalPages ||
                      customersLoading
                    }
                    onClick={() =>
                      setPage(
                        (current) =>
                          Math.min(
                            totalPages,
                            current + 1
                          )
                      )
                    }
                  >
                    Next
                  </Button>

                </div>

              )}

            </div>

          </Panel>

        )}


      {/* ====================================================
          CUSTOMER PROFILE DRAWER
         ==================================================== */}

      <CustomerDrawer
        customer={selected}
        onClose={() =>
          setSelected(null)
        }
        onEdit={(customer) =>
          setCustomerEditor({
            mode: "edit",
            customer
          })
        }
        toast={toast}
      />


      <CustomerEditorDrawer
        editor={customerEditor}
        onClose={() =>
          setCustomerEditor(null)
        }
        onSaved={handleCustomerSaved}
        toast={toast}
      />

    </div>

  );

}


/* =====================================================================
   CUSTOMER PROFILE DRAWER
   Real Supabase customer data.
   Booking/order/payment history comes later.
   ===================================================================== */

function CustomerDrawer({
  customer,
  onClose,
  onEdit,
  toast
}) {

  // --------------------------------------------------------
  // LIVE CUSTOMER SUMMARY
  // --------------------------------------------------------

  const [summary, setSummary] = useState(null);

  const [
    summaryLoading,
    setSummaryLoading
  ] = useState(false);

  const [
    summaryError,
    setSummaryError
  ] = useState("");

  // --------------------------------------------------------
  // CUSTOMER APPOINTMENT HISTORY
  // --------------------------------------------------------

  const [
    appointmentHistory,
    setAppointmentHistory
  ] =
    useState([]);


  const [
    historyLoading,
    setHistoryLoading
  ] =
    useState(false);


  const [
    historyError,
    setHistoryError
  ] =
    useState("");

  // --------------------------------------------------------
  // LOAD CUSTOMER SUMMARY
  // --------------------------------------------------------

  useEffect(() => {

    // No customer selected.
    if (!customer?.id) {

      setSummary(null);
      setSummaryError("");

      return;
    }


    let cancelled =
      false;


    async function loadSummary() {

      try {

        setSummaryLoading(true);
        setSummaryError("");


        const result =
          await window.API
            .Customers
            .summary(
              customer.id
            );


        if (!cancelled) {

          setSummary(
            result
          );

        }


      } catch (error) {

        console.error(
          "Customer summary failed:",
          error
        );


        if (!cancelled) {

          setSummaryError(
            error.message ||
            "Customer summary could not be loaded."
          );

        }


      } finally {

        if (!cancelled) {

          setSummaryLoading(
            false
          );

        }

      }

    }


    loadSummary();


    return () => {

      cancelled =
        true;

    };

  }, [customer?.id]);

  // --------------------------------------------------------
  // LOAD CUSTOMER APPOINTMENT HISTORY
  // --------------------------------------------------------

  useEffect(() => {

    if (!customer?.id) {

      setAppointmentHistory([]);
      setHistoryError("");

      return;
    }


    let cancelled =
      false;


    async function loadHistory() {

      try {

        setHistoryLoading(true);
        setHistoryError("");


        const result =
          await window.API
            .Customers
            .history(
              customer.id
            );


        if (!cancelled) {

          setAppointmentHistory(
            result || []
          );

        }


      } catch (error) {

        console.error(
          "Customer history failed:",
          error
        );


        if (!cancelled) {

          setHistoryError(
            error.message ||
            "Customer history could not be loaded."
          );

        }


      } finally {

        if (!cancelled) {

          setHistoryLoading(false);

        }

      }

    }


    loadHistory();


    return () => {

      cancelled = true;

    };

  }, [customer?.id]);

  // --------------------------------------------------------
  // NOTHING SELECTED
  // --------------------------------------------------------

  if (!customer) {
    return null;
  }

  const c =
    customer;


  const fullName = [

    c.first_name,
    c.last_name

  ]
    .filter(Boolean)
    .join(" ");


  // Legacy Amelia customers were imported into the new CRM,
  // so their current created_at is the migration date rather than
  // their genuine first visit to Chelsea Spa. Do not present that
  // migration timestamp as a false "customer since" date.
  const isLegacyCustomer =
    String(c.legacy_id || "")
      .startsWith("amelia:");

  const customerSince =
    c.created_at
      ? new Date(
          c.created_at
        ).toLocaleDateString(
          "en-GB",
          {
            day: "2-digit",
            month: "short",
            year: "numeric"
          }
        )
      : "Unknown";

  const customerSubtitle =
    isLegacyCustomer
      ? "Legacy Chelsea Spa customer"
      : `Customer since ${customerSince}`;


  const dateOfBirth =
    c.date_of_birth

      ? new Date(
          `${c.date_of_birth}T00:00:00`
        ).toLocaleDateString(
          "en-GB"
        )

      : "—";

  // --------------------------------------------------------
  // SUMMARY DISPLAY VALUES
  // --------------------------------------------------------

  const formatBookingDate =
    (value) => {

      if (!value) {
        return "—";
      }


      return new Date(
        value
      ).toLocaleDateString(
        "en-GB",
        {
          day: "2-digit",
          month: "short",
          year: "numeric"
        }
      );

    };


  const lastVisitText =
    summary?.last_visit

      ? formatBookingDate(
          summary.last_visit.start_at
        )

      : "No visits yet";


  const nextBookingText =
    summary?.next_appointment

      ? formatBookingDate(
          summary
            .next_appointment
            .start_at
        )

      : "None";


  const treatmentValue =
    Number(
      summary?.treatment_value || 0
    );

    // --------------------------------------------------------
    // SPLIT UPCOMING AND APPOINTMENT HISTORY
    // --------------------------------------------------------

    const now =
      Date.now();


    const inactiveStatuses =
      [
        "completed",
        "cancelled",
        "no_show",
        "expired"
      ];


    const upcomingAppointments =
      appointmentHistory

        .filter(
          appointment => {

            const start =
              new Date(
                appointment.start_at
              ).getTime();


            return (
              start >= now &&
              !inactiveStatuses.includes(
                appointment.status
              )
            );

          }
        )

        .sort(
          (a, b) =>
            new Date(a.start_at) -
            new Date(b.start_at)
        );


    const previousAppointments =
      appointmentHistory

        .filter(
          appointment =>
            !upcomingAppointments.some(
              upcoming =>
                upcoming.id ===
                appointment.id
            )
        )

        .sort(
          (a, b) =>
            new Date(b.start_at) -
            new Date(a.start_at)
        );

  return (

    <Drawer
      open={true}

      onClose={onClose}

      subtitle={customerSubtitle}

      title={
        fullName ||
        "Customer"
      }

      footer={
        <>

          <Button
            variant="ghost"
            size="sm"
            icon="edit"

            onClick={() =>
              onEdit(customer)
            }
          >
            Edit
          </Button>


          <Button
            variant="primary"
            size="sm"
            icon="plus"

            onClick={() =>
              toast(
                "Create booking comes later."
              )
            }
          >
            Book
          </Button>

        </>
      }
    >

      {/* ====================================================
          CUSTOMER HEADER
         ==================================================== */}

      <div
        style={{
          display: "flex",
          alignItems: "center",
          gap: 16,
          marginBottom: 22
        }}
      >

        <Avatar
          name={
            fullName ||
            "Customer"
          }
          size={56}
        />


        <div>

          <div
            style={{
              display: "flex",
              gap: 6,
              flexWrap: "wrap",
              marginBottom: 7
            }}
          >

            {c.marketing_consent && (

              <span
                className=
                  "chip chip-line"
              >
                Email marketing
              </span>

            )}


            {c.sms_consent && (

              <span
                className=
                  "chip chip-line"
              >
                SMS
              </span>

            )}


            {c.allergies && (

              <span
                className=
                  "chip chip-gold"

                style={{
                  color:
                    "var(--danger)"
                }}
              >
                Allergy warning
              </span>

            )}

          </div>


          <div className="caption">

            Loyalty:
            {" "}
            {Number(
              c.loyalty_points || 0
            )}
            {" points"}

          </div>

        </div>

      </div>
          
      {/* ====================================================
          LIVE CUSTOMER SUMMARY
        ==================================================== */}

      <div
        style={{
          display: "grid",
          gridTemplateColumns:
            "1fr 1fr",
          gap: 10,
          marginBottom: 24
        }}
      >

        <MiniStat
          label="Completed visits"
          value={
            summaryLoading
              ? "—"
              : summary
                ?.completed_visits ?? 0
          }
        />


        <MiniStat
          label="Treatment value"
          value={
            summaryLoading
              ? "—"
              : `£${treatmentValue.toFixed(2)}`
          }
        />


        <MiniStat
          label="Last visit"
          value={
            summaryLoading
              ? "—"
              : lastVisitText
          }
        />


        <MiniStat
          label="Next booking"
          value={
            summaryLoading
              ? "—"
              : nextBookingText
          }
        />

      </div>

      {summaryError && (

        <div
          style={{
            marginBottom: 20,
            padding: 12,
            borderRadius: 8,
            color:
              "var(--danger)",
            background:
              "rgba(154,74,58,0.10)"
          }}
        >
          {summaryError}
        </div>
      )}


      {!summaryLoading &&
        summary?.last_visit && (

          <div
            style={{
              marginBottom: 20,
              padding: 14,
              border:
                "1px solid var(--line)",
              borderRadius: 8
            }}
          >

            <div
              className="a-label"
              style={{
                marginBottom: 8
              }}
            >
              Last treatment
            </div>

            <div
              style={{
                fontFamily:
                  "var(--font-display)",
                marginBottom: 4
              }}
            >
              {summary
                .last_visit
                .service_name_snapshot ||
                "Treatment"}
            </div>


            <div className="caption">

              {formatBookingDate(
                summary
                  .last_visit
                  .start_at
              )}

              {summary
                .last_visit
                .therapist
                ?.full_name
                ? (
                    <>
                      {" · "}
                      {
                        summary
                          .last_visit
                          .therapist
                          .full_name
                      }
                    </>
                  )
                : null}

            </div>

          </div>
      )}

      {!summaryLoading &&
        summary?.next_appointment && (

          <div
            style={{
              marginBottom: 20,
              padding: 14,
              borderRadius: 8,
              background:
                "var(--bg-nude)"
            }}
          >

            <div
              className="a-label"
              style={{
                marginBottom: 8
              }}
            >
              Next appointment
            </div>


            <div
              style={{
                fontFamily:
                  "var(--font-display)",
                marginBottom: 4
              }}
            >
              {summary
                .next_appointment
                .service_name_snapshot ||
                "Treatment"}
            </div>


            <div className="caption">

              {new Date(
                summary
                  .next_appointment
                  .start_at
              ).toLocaleString(
                "en-GB",
                {
                  day: "2-digit",
                  month: "short",
                  year: "numeric",
                  hour: "2-digit",
                  minute: "2-digit"
                }
              )}

              {summary
                .next_appointment
                .therapist
                ?.full_name
                ? (
                    <>
                      {" · "}
                      {
                        summary
                          .next_appointment
                          .therapist
                          .full_name
                      }
                    </>
                  )
                : null}

            </div>

          </div>

      )}
      

      {/* ====================================================
          CONTACT
         ==================================================== */}

      <div className="a-label">
        Contact
      </div>


      <div
        style={{
          display: "grid",
          gridTemplateColumns:
            "1fr 1fr",
          gap: 12,
          marginBottom: 20
        }}
      >

        <DRow
          label="Email"
          value={
            c.email || "—"
          }
        />


        <DRow
          label="Phone"
          value={
            c.phone || "—"
          }
        />


        <DRow
          label="Date of birth"
          value={dateOfBirth}
        />


        <DRow
          label="Loyalty"
          value={
            `${Number(
              c.loyalty_points || 0
            )} pts`
          }
        />

      </div>


      {/* ====================================================
          ALLERGIES
         ==================================================== */}

      <div className="a-label">
        Allergies / medical notes
      </div>


      <div
        style={{
          padding: "12px 14px",
          background:
            c.allergies
              ? "rgba(154,74,58,0.10)"
              : "var(--bg-nude)",
          borderRadius: 8,
          marginBottom: 20,
          lineHeight: 1.55
        }}
      >

        {c.allergies ||
          "No allergies recorded."}

      </div>


      {/* ====================================================
          INTERNAL NOTES
         ==================================================== */}

      <div className="a-label">
        Customer notes
      </div>


      <div
        style={{
          padding: "12px 14px",
          background:
            "var(--bg-nude)",
          borderRadius: 8,
          marginBottom: 20,
          lineHeight: 1.55
        }}
      >

        {c.notes ||
          "No notes yet."}

      </div>


      {/* ====================================================
          MARKETING
         ==================================================== */}

      <div className="a-label">
        Consent
      </div>


      <div
        style={{
          display: "grid",
          gridTemplateColumns:
            "1fr 1fr",
          gap: 12,
          marginBottom: 22
        }}
      >

        <DRow
          label="Email marketing"
          value={
            c.marketing_consent
              ? "Yes"
              : "No"
          }
        />


        <DRow
          label="SMS"
          value={
            c.sms_consent
              ? "Yes"
              : "No"
          }
        />

      </div>


      <div
        className="a-divider"
        style={{
          margin:
            "4px 0 20px"
        }}
      />


      {/* ====================================================
          HISTORY PLACEHOLDER
         ==================================================== */}

      <div className="a-label">
        Customer history
      </div>


      <div
        style={{
          padding: "18px",
          border:
            "1px solid var(--line)",
          borderRadius: 8
        }}
      >

        <div
          style={{
            fontFamily:
              "var(--font-display)",
            marginBottom: 5
          }}
        >
          Treatment & purchase history
        </div>


        {/* ====================================================
            CUSTOMER APPOINTMENT HISTORY
          ==================================================== */}

        <div
          style={{
            marginTop: 26
          }}
        >

          <div
            className="a-label"
            style={{
              marginBottom: 12
            }}
          >
            Treatment & Appointment History
          </div>


          {/* ERROR */}

          {historyError && (

            <div
              style={{
                padding: 12,
                marginBottom: 14,
                borderRadius: 8,

                color:
                  "var(--danger)",

                background:
                  "rgba(154,74,58,0.10)"
              }}
            >
              {historyError}
            </div>

          )}


          {/* LOADING */}

          {historyLoading && (

            <div
              className="caption"
              style={{
                padding: "18px 0"
              }}
            >
              Loading customer history…
            </div>

          )}


          {/* NO APPOINTMENTS */}

          {!historyLoading &&
          !historyError &&
          appointmentHistory.length === 0 && (

            <div
              style={{
                padding: 18,
                border:
                  "1px solid var(--line)",
                borderRadius: 8
              }}
            >

              <div
                style={{
                  fontFamily:
                    "var(--font-display)",
                  marginBottom: 4
                }}
              >
                No appointments yet
              </div>

              <div className="caption">
                This customer does not yet have
                any appointment history in the
                Chelsea Spa booking database.
              </div>

            </div>

          )}


          {/* UPCOMING */}

          {!historyLoading &&
          upcomingAppointments.length > 0 && (

            <div
              style={{
                marginBottom: 24
              }}
            >

              <div
                style={{
                  fontFamily:
                    "var(--font-display)",
                  fontSize: "0.95rem",
                  marginBottom: 10
                }}
              >
                Upcoming
              </div>


              {upcomingAppointments.map(
                appointment => (

                  <CustomerHistoryItem
                    key={
                      appointment.id
                    }

                    appointment={
                      appointment
                    }
                  />

                )
              )}

            </div>

          )}


          {/* PREVIOUS / COMPLETED / CANCELLED */}

          {!historyLoading &&
          previousAppointments.length > 0 && (

            <div>

              <div
                style={{
                  fontFamily:
                    "var(--font-display)",
                  fontSize: "0.95rem",
                  marginBottom: 10
                }}
              >
                Appointment History
              </div>


              {previousAppointments.map(
                appointment => (

                  <CustomerHistoryItem
                    key={
                      appointment.id
                    }

                    appointment={
                      appointment
                    }
                  />

                )
              )}

            </div>

          )}


          <div
            className="a-divider"
            style={{
              margin: "22px 0"
            }}
          />

          <div
            className="a-label"
            style={{
              marginBottom: 12
            }}
          >
            Purchases & Payments
          </div>

          <CustomerPurchases
            customerId={c.id}
          />

        </div>

      </div>

    </Drawer>

  );

}

/* =========================================================
   ADD / EDIT CUSTOMER
   ========================================================= */


const EMPTY_CUSTOMER_FORM = {

  first_name: "",
  last_name: "",

  email: "",
  phone: "",

  date_of_birth: "",

  allergies: "",
  notes: "",

  loyalty_points: "0",

  marketing_consent: false,
  sms_consent: false

};

/* =========================================================
   CUSTOMER APPOINTMENT HISTORY ITEM
   ========================================================= */

function CustomerHistoryItem({
  appointment
}) {

  if (!appointment) {
    return null;
  }


  // --------------------------------------------------------
  // STATUS
  // --------------------------------------------------------

  const statusLabels = {

    pending_payment:
      "Pending payment",

    confirmed:
      "Confirmed",

    checked_in:
      "Checked in",

    completed:
      "Completed",

    cancelled:
      "Cancelled",

    no_show:
      "No show",

    expired:
      "Expired"

  };


  const status =
    statusLabels[
      appointment.status
    ] ||
    appointment.status ||
    "Unknown";


  // --------------------------------------------------------
  // DATE
  // --------------------------------------------------------

  const appointmentDate =
    appointment.start_at

      ? new Date(
          appointment.start_at
        )

      : null;


  const dateText =
    appointmentDate

      ? appointmentDate
          .toLocaleDateString(
            "en-GB",
            {
              weekday: "short",
              day: "2-digit",
              month: "short",
              year: "numeric"
            }
          )

      : "Date unavailable";


  const timeText =
    appointmentDate

      ? appointmentDate
          .toLocaleTimeString(
            "en-GB",
            {
              hour: "2-digit",
              minute: "2-digit"
            }
          )

      : "";


  const price =
    Number(
      appointment.price_snapshot || 0
    );


  const therapistName =
    appointment
      .therapist
      ?.full_name ||
    "Therapist not recorded";


  // --------------------------------------------------------
  // UI
  // --------------------------------------------------------

  return (

    <div
      style={{
        padding: 14,
        marginBottom: 9,

        border:
          "1px solid var(--line)",

        borderRadius: 8
      }}
    >

      {/* TOP ROW */}

      <div
        style={{
          display: "flex",
          justifyContent:
            "space-between",
          alignItems:
            "flex-start",
          gap: 12
        }}
      >

        <div>

          <div
            style={{
              fontFamily:
                "var(--font-display)",
              marginBottom: 4
            }}
          >
            {
              appointment
                .service_name_snapshot ||
              "Treatment"
            }
          </div>


          <div className="caption">

            {dateText}

            {timeText
              ? ` · ${timeText}`
              : ""}

          </div>

        </div>


        <div
          style={{
            textAlign: "right"
          }}
        >

          <div
            style={{
              fontFamily:
                "var(--font-display)",
              marginBottom: 3
            }}
          >
            £{price.toFixed(2)}
          </div>


          <div className="caption">
            {status}
          </div>

        </div>

      </div>


      {/* THERAPIST */}

      <div
        className="caption"
        style={{
          marginTop: 9
        }}
      >
        Therapist: {therapistName}
      </div>


      {/* CUSTOMER NOTES */}

      {appointment.customer_notes && (

        <div
          style={{
            marginTop: 10,
            paddingTop: 10,
            borderTop:
              "1px solid var(--line)"
          }}
        >

          <div className="caption">
            Customer note
          </div>

          <div
            style={{
              fontSize:
                "0.84rem",
              marginTop: 3
            }}
          >
            {
              appointment
                .customer_notes
            }
          </div>

        </div>

      )}


      {/* INTERNAL NOTES */}

      {appointment.internal_notes && (

        <div
          style={{
            marginTop: 8
          }}
        >

          <div className="caption">
            Internal note
          </div>

          <div
            style={{
              fontSize:
                "0.84rem",
              marginTop: 3
            }}
          >
            {
              appointment
                .internal_notes
            }
          </div>

        </div>

      )}

    </div>

  );

}

function CustomerPurchases({ customerId }) {

  const [state, setState] =
    useState({
      loading: true,
      error: "",
      rows: []
    });


  useEffect(() => {

    let active = true;

    window.API.Customers
      .purchaseHistory(customerId)

      .then((rows) => {
        if (active) {
          setState({
            loading: false,
            error: "",
            rows
          });
        }
      })

      .catch((error) => {
        if (active) {
          setState({
            loading: false,
            error:
              error.message ||
              "Purchase history unavailable.",
            rows: []
          });
        }
      });


    return () => {
      active = false;
    };

  }, [customerId]);


  if (state.loading) {
    return (
      <div className="caption">
        Loading purchases…
      </div>
    );
  }


  if (state.error) {
    return (
      <div
        className="caption"
        style={{
          color: "var(--danger)"
        }}
      >
        {state.error}
      </div>
    );
  }


  if (!state.rows.length) {
    return (
      <div className="caption">
        No purchases recorded yet.
      </div>
    );
  }


  return (

    <div>

      {state.rows.map((order) => {

        const payment =
          order.payments?.[0];

        return (

          <div
            key={order.id}
            style={{
              padding: 14,
              marginBottom: 10,
              border:
                "1px solid var(--line)",
              borderRadius: 8
            }}
          >

            <div
              style={{
                display: "flex",
                justifyContent:
                  "space-between"
              }}
            >

              <strong>
                {order.reference ||
                  "Order"}
              </strong>

              <strong>
                £{Number(
                  order.total || 0
                ).toFixed(2)}
              </strong>

            </div>


            <div
              className="caption"
              style={{
                marginTop: 4
              }}
            >
              {new Date(
                order.created_at
              ).toLocaleDateString(
                "en-GB"
              )}

              {" · "}

              {payment?.status ||
                order.status}
            </div>


            {order.order_items?.map(
              (item) => (

                <div
                  key={item.id}
                  className="caption"
                  style={{
                    marginTop: 8
                  }}
                >
                  {item.product_name_snapshot}
                  {" × "}
                  {item.quantity}
                  {" · £"}
                  {Number(
                    item.line_total || 0
                  ).toFixed(2)}
                </div>

              )
            )}

          </div>

        );

      })}

    </div>

  );

}


// Convert a Supabase customer row into editable form values.
function customerToForm(customer) {

  if (!customer) {
    return {
      ...EMPTY_CUSTOMER_FORM
    };
  }


  return {

    first_name:
      customer.first_name || "",

    last_name:
      customer.last_name || "",

    email:
      customer.email || "",

    phone:
      customer.phone || "",

    date_of_birth:
      customer.date_of_birth || "",

    allergies:
      customer.allergies || "",

    notes:
      customer.notes || "",

    loyalty_points:
      String(
        customer.loyalty_points || 0
      ),

    marketing_consent:
      customer.marketing_consent === true,

    sms_consent:
      customer.sms_consent === true

  };
}

function CustomerEditorDrawer({
  editor,
  onClose,
  onSaved,
  toast
}) {

  // --------------------------------------------------------
  // FORM STATE
  // --------------------------------------------------------

  const [form, setForm] =
    useState({
      ...EMPTY_CUSTOMER_FORM
    });


  const [saving, setSaving] =
    useState(false);


  const [formError, setFormError] =
    useState("");


  // --------------------------------------------------------
  // LOAD CREATE / EDIT VALUES
  // --------------------------------------------------------

  useEffect(() => {

    if (editor) {

      setForm(
        customerToForm(
          editor.customer
        )
      );

      setFormError("");
      setSaving(false);
      setTreatmentsExpanded(false);
      setTreatmentSearch("");
      setExpandedTreatmentCategories({});

    }

  }, [editor]);


  if (!editor) {
    return null;
  }


  const isEditing =
    editor.mode === "edit";


  // --------------------------------------------------------
  // CHANGE ONE FIELD
  // --------------------------------------------------------

  const change =
    (field, value) => {

      setForm(
        (current) => ({
          ...current,
          [field]: value
        })
      );

    };


  // --------------------------------------------------------
  // BASIC EMAIL VALIDATION
  // --------------------------------------------------------

  const emailLooksValid =
    (email) => {

      if (!email) {
        return true;
      }

      return /^[^\s@]+@[^\s@]+\.[^\s@]+$/
        .test(email);

    };


  // --------------------------------------------------------
  // SAVE CUSTOMER
  // --------------------------------------------------------

  const saveCustomer =
    async () => {

      setFormError("");


      const firstName =
        form.first_name.trim();

      const lastName =
        form.last_name.trim();

      const email =
        form.email.trim();

      const phone =
        form.phone.trim();


      // --------------------------------------------
      // REQUIRED FIELDS
      // --------------------------------------------

      if (!firstName) {

        setFormError(
          "Enter the customer's first name."
        );

        return;
      }


      if (!lastName) {

        setFormError(
          "Enter the customer's last name."
        );

        return;
      }


      // Email is optional in the CRM,
      // but if entered it must be valid.
      if (
        email &&
        !emailLooksValid(email)
      ) {

        setFormError(
          "Enter a valid email address."
        );

        return;
      }


      // Loyalty cannot be negative.
      const loyaltyPoints =
        Number(
          form.loyalty_points || 0
        );


      if (
        Number.isNaN(loyaltyPoints) ||
        loyaltyPoints < 0
      ) {

        setFormError(
          "Loyalty points cannot be negative."
        );

        return;
      }


      // --------------------------------------------
      // DATA SENT TO SUPABASE
      // --------------------------------------------

      const payload = {

        first_name:
          firstName,

        last_name:
          lastName,

        email:
          email || null,

        phone:
          phone || null,

        date_of_birth:
          form.date_of_birth || null,

        allergies:
          form.allergies.trim()
            || null,

        notes:
          form.notes.trim()
            || null,

        loyalty_points:
          loyaltyPoints,

        marketing_consent:
          form.marketing_consent,

        sms_consent:
          form.sms_consent

      };


      try {

        setSaving(true);


        let savedCustomer;


        if (isEditing) {

          savedCustomer =
            await window.API
              .Customers
              .update(
                editor.customer.id,
                payload
              );


          toast(
            "Customer updated",
            "success"
          );


        } else {

          savedCustomer =
            await window.API
              .Customers
              .create(payload);


          toast(
            "Customer added",
            "success"
          );

        }


        await onSaved(
          savedCustomer
        );


      } catch (error) {

        console.error(
          "Customer save failed:",
          error
        );


        // ------------------------------------------
        // DUPLICATE EMAIL
        //
        // customers_email_unique prevents the same
        // email existing twice for Chelsea Spa.
        // PostgreSQL duplicate key code = 23505.
        // ------------------------------------------

        if (
          error?.code === "23505"
        ) {

          setFormError(
            "A customer with this email address already exists."
          );


        } else {

          setFormError(
            error.message ||
            "The customer could not be saved."
          );

        }


      } finally {

        setSaving(false);

      }

    };


  // --------------------------------------------------------
  // FORM
  // --------------------------------------------------------

  return (

    <Drawer
      open={true}

      onClose={
        saving
          ? () => {}
          : onClose
      }

      title={
        isEditing
          ? "Edit Customer"
          : "Add Customer"
      }

      subtitle={
        isEditing

          ? [
              editor.customer.first_name,
              editor.customer.last_name
            ]
              .filter(Boolean)
              .join(" ")

          : "Create a customer record"
      }

      footer={
        <>

          <Button
            variant="ghost"
            size="sm"

            onClick={onClose}

            disabled={saving}
          >
            Cancel
          </Button>


          <Button
            variant="primary"
            size="sm"

            onClick={saveCustomer}

            disabled={saving}
          >

            {saving
              ? "Saving…"
              : isEditing
                ? "Save Changes"
                : "Add Customer"}

          </Button>

        </>
      }
    >

      {/* ==================================================
          FORM ERROR
         ================================================== */}

      {formError && (

        <div
          style={{
            marginBottom: 18,
            padding: "11px 13px",
            borderRadius: 7,

            color:
              "var(--danger)",

            background:
              "rgba(154,74,58,0.1)",

            border:
              "1px solid rgba(154,74,58,0.3)",

            fontSize:
              "0.84rem"
          }}
        >
          {formError}
        </div>

      )}


      {/* ==================================================
          NAME
         ================================================== */}

      <CustomerField
        label="First name"
        required
      >

        <input
          className="a-input"

          value={
            form.first_name
          }

          onChange={(event) =>
            change(
              "first_name",
              event.target.value
            )
          }

          placeholder="First name"
        />

      </CustomerField>


      <CustomerField
        label="Last name"
        required
      >

        <input
          className="a-input"

          value={
            form.last_name
          }

          onChange={(event) =>
            change(
              "last_name",
              event.target.value
            )
          }

          placeholder="Last name"
        />

      </CustomerField>


      {/* ==================================================
          CONTACT
         ================================================== */}

      <CustomerField
        label="Email"
      >

        <input
          className="a-input"
          type="email"

          value={
            form.email
          }

          onChange={(event) =>
            change(
              "email",
              event.target.value
            )
          }

          placeholder="customer@example.com"
        />

      </CustomerField>


      <CustomerField
        label="Phone"
      >

        <input
          className="a-input"
          type="tel"

          value={
            form.phone
          }

          onChange={(event) =>
            change(
              "phone",
              event.target.value
            )
          }

          placeholder="07..."
        />

      </CustomerField>


      <div
        className="caption"
        style={{
          marginTop: -8,
          marginBottom: 18
        }}
      >
        A confirmed booking will eventually
        require both a valid phone number and
        email because the customer receives
        SMS and email confirmation.
      </div>


      {/* ==================================================
          DATE OF BIRTH
         ================================================== */}

      <CustomerField
        label="Date of birth"
      >

        <input
          className="a-input"
          type="date"

          value={
            form.date_of_birth
          }

          onChange={(event) =>
            change(
              "date_of_birth",
              event.target.value
            )
          }
        />

      </CustomerField>


      {/* ==================================================
          ALLERGIES
         ================================================== */}

      <CustomerField
        label="Allergies / medical information"
      >

        <textarea
          className="a-input"
          rows={3}

          value={
            form.allergies
          }

          onChange={(event) =>
            change(
              "allergies",
              event.target.value
            )
          }

          placeholder=
            "Record relevant allergies or treatment warnings"

          style={{
            resize: "vertical"
          }}
        />

      </CustomerField>


      {/* ==================================================
          INTERNAL NOTES
         ================================================== */}

      <CustomerField
        label="Internal customer notes"
      >

        <textarea
          className="a-input"
          rows={4}

          value={
            form.notes
          }

          onChange={(event) =>
            change(
              "notes",
              event.target.value
            )
          }

          placeholder=
            "Internal notes visible to authorised staff"

          style={{
            resize: "vertical"
          }}
        />

      </CustomerField>


      {/* ==================================================
          LOYALTY
         ================================================== */}

      <CustomerField
        label="Loyalty points"
      >

        <input
          className="a-input"
          type="number"

          min="0"
          step="1"

          value={
            form.loyalty_points
          }

          onChange={(event) =>
            change(
              "loyalty_points",
              event.target.value
            )
          }
        />

      </CustomerField>


      {/* ==================================================
          CONSENT
         ================================================== */}

      <div
        className="a-label"
        style={{
          marginTop: 22,
          marginBottom: 10
        }}
      >
        Marketing consent
      </div>


      <label
        style={{
          display: "flex",
          alignItems: "center",
          gap: 10,
          padding: "11px 0",
          borderBottom:
            "1px solid var(--line)"
        }}
      >

        <input
          type="checkbox"

          checked={
            form.marketing_consent
          }

          onChange={(event) =>
            change(
              "marketing_consent",
              event.target.checked
            )
          }
        />


        <div>

          <div
            style={{
              fontFamily:
                "var(--font-display)"
            }}
          >
            Email marketing
          </div>

          <div className="caption">
            Customer has agreed to receive
            marketing emails.
          </div>

        </div>

      </label>


      <label
        style={{
          display: "flex",
          alignItems: "center",
          gap: 10,
          padding: "11px 0"
        }}
      >

        <input
          type="checkbox"

          checked={
            form.sms_consent
          }

          onChange={(event) =>
            change(
              "sms_consent",
              event.target.checked
            )
          }
        />


        <div>

          <div
            style={{
              fontFamily:
                "var(--font-display)"
            }}
          >
            SMS marketing
          </div>

          <div className="caption">
            Customer has agreed to receive
            promotional SMS messages.
          </div>

        </div>

      </label>


      <div
        style={{
          marginTop: 18,
          padding: 13,
          borderRadius: 8,
          background:
            "var(--bg-nude)"
        }}
      >

        <div className="caption">
          Booking confirmations are transactional
          messages and are separate from marketing
          consent. Marketing consent must not be
          automatically enabled when a booking is made.
        </div>

      </div>

    </Drawer>

  );

}

function CustomerField({
  label,
  required,
  children
}) {

  return (

    <div
      style={{
        marginBottom: 16
      }}
    >

      <div
        className="a-label"
        style={{
          marginBottom: 7
        }}
      >

        {label}

        {required && (
          <span
            style={{
              color:
                "var(--danger)",
              marginLeft: 3
            }}
          >
            *
          </span>
        )}

      </div>


      {children}

    </div>

  );

}

/*==================== END OF CUSTOMER RELATED SECTION ================== */



function MiniStat({ label, value }) {
  return (
    <div style={{ padding: "14px 16px", background: "var(--bg-cream)", border: "1px solid var(--line)", borderRadius: 8, textAlign: "center" }}>
      <div style={{ fontFamily: "var(--font-display)", fontSize: "1.3rem", letterSpacing: "-0.02em" }}>{value}</div>
      <div className="caption" style={{ fontSize: "0.66rem", marginTop: 2 }}>{label}</div>
    </div>
  );
}

/* =====================================================================
   STAFF & ROTA
   ===================================================================== */

   /*Newly Updated on 6th Aug 2026 by Sarkar */
function ModuleStaff() {
  // Start on Team while testing the Supabase connection.
  const [tab, setTab] = useState("team");

  // Real staff records loaded from Supabase.
  const [staff, setStaff] = useState([]);

  // Loading and error states for the page.
  const [staffLoading, setStaffLoading] = useState(true);
  const [staffError, setStaffError] = useState("");

  const toast = useToast();


  // ======================================================
  // LEAVE / SICKNESS / AVAILABILITY STATE
  // ======================================================

  // Real leave records loaded from Supabase.
  const [leaveRecords, setLeaveRecords] =
    useState([]);

  // Shows loading state.
  const [leaveLoading, setLeaveLoading] =
    useState(false);

  // Stores loading error.
  const [leaveError, setLeaveError] =
    useState("");

  // Controls Add/Edit Leave drawer.
  //
  // null = closed
  // { mode: "create", record: null }
  // { mode: "edit", record: existingRecord }
  const [leaveEditor, setLeaveEditor] =
    useState(null);


  // ======================================================
  // ONE-OFF EXTRA HOURS STATE — STEP 10G5D3
  // ======================================================

  const [extraHours, setExtraHours] =
    useState([]);

  const [extraHoursLoading, setExtraHoursLoading] =
    useState(false);

  const [extraHoursError, setExtraHoursError] =
    useState("");

  // null = closed
  // { mode: "create", record: null }
  // { mode: "edit", record: existingRecord }
  const [extraHoursEditor, setExtraHoursEditor] =
    useState(null);


  // ======================================================
  // WEEKLY ROTA STATE
  // ======================================================



  // Real shifts loaded from Supabase.
  const [shifts, setShifts] = useState([]);

  // Loading indicator for the rota.
  const [shiftsLoading, setShiftsLoading] =
    useState(false);

  // Stores any rota loading error.
  const [shiftsError, setShiftsError] =
    useState("");

  // Controls the Add/Edit Shift drawer.
  //
  // null = closed
  // { mode: "create", shift: null } = new shift
  // { mode: "edit", shift: existingShift } = edit shift
  const [shiftEditor, setShiftEditor] =
    useState(null);

  // Treatments available for therapist assignment.
  const [services, setServices] = useState([]);

  // Shows whether treatments are being loaded.
  const [servicesLoading, setServicesLoading] =
    useState(false);

  // Stores any treatment-loading error.
  const [servicesError, setServicesError] =
    useState("");

    // Controls whether the Add/Edit Therapist drawer is open.
  const [staffEditor, setStaffEditor] = useState(null);

      // Example values:
      // null
      // { mode: "create", member: null }
      // { mode: "edit", member: existingStaff }

  // Load treatments from Supabase.
  const loadServices = useCallback(async () => {
      try {
        setServicesLoading(true);
        setServicesError("");

        // Check that api.jsx loaded successfully.
        if (!window.API?.Services) {
          throw new Error(
            "Services API is unavailable."
          );
        }

        // Request all active treatments.
        const result =
          await window.API.Services.list();

        // Store the treatments in React state.
        setServices(
          Array.isArray(result) ? result : []
        );
      } catch (error) {
        console.error(
          "Treatment loading failed:",
          error
        );

        setServicesError(
          error.message ||
          "Treatments could not be loaded."
        );
      } finally {
        setServicesLoading(false);
      }
    }, []);
  // ======================================================
  // SERVICE ROLE PRICING STATE
  // ======================================================

  // Pricing rows from Supabase.
  const [
    rolePricing,
    setRolePricing
  ] = useState([]);



  // Loading indicator.
  const [
    rolePricingLoading,
    setRolePricingLoading
  ] = useState(false);



  // Error while loading pricing.
  const [
    rolePricingError,
    setRolePricingError
  ] = useState("");



  // Current logged-in person's access role.
  //
  // Example:
  // super_admin
  // admin
  // practitioner
  const [
    currentAccessRole,
    setCurrentAccessRole
  ] = useState(null);



  // Only these two roles may manage pricing.
  const canManageRolePricing =
    currentAccessRole === "super_admin" ||
    currentAccessRole === "admin";

  const canManageRota =
    currentAccessRole === "super_admin" ||
    currentAccessRole === "admin";


  // Load treatments when the Staff module opens.
    useEffect(() => {
      loadServices();
    }, [loadServices]);

  // Load all staff members from Supabase.
  const loadStaff = useCallback(async () => {
    try {
      setStaffLoading(true);
      setStaffError("");

      // Stop early when api.jsx did not load.
      if (!window.API || !window.API.Staff) {
        throw new Error(
          "Staff API is unavailable. Check src/services/api.jsx."
        );
      }

      const result = await window.API.Staff.list();

      // Staff.list() should return an array.
      setStaff(Array.isArray(result) ? result : []);
    } catch (error) {
      console.error("Staff loading failed:", error);

      setStaffError(
        error.message || "Staff members could not be loaded."
      );
    } finally {
      setStaffLoading(false);
    }
  }, []);

  // Load staff when this module first opens.
  useEffect(() => {
    loadStaff();
  }, [loadStaff]);


  // Business's configured maximum staff number.
  const [staffLimit, setStaffLimit] = useState(50);

  // Number of currently ACTIVE staff.
  const activeStaffCount = staff.filter(
    (member) => member.is_active
  ).length;

  // Load the configured maximum staff count.
  useEffect(() => {

    async function loadStaffLimit() {
      try {

        const settings =
          await window.API.Settings.get();

        setStaffLimit(
          settings.max_active_staff
        );

      } catch (error) {

        console.error(
          "Could not load staff limit:",
          error
        );

      }
    }

    loadStaffLimit();

  }, []);

  // Runs after adding or editing a therapist.
  const handleStaffSaved = async () => {
    // Close the Add/Edit Therapist drawer.
    setStaffEditor(null);

    // Reload therapists from Supabase
    // so the Team page immediately shows the changes.
    await loadStaff();
  };


  // Temporary button action.
  // We connect the real form in Step 7C.
    const handleMainButton = () => {

      // TEAM TAB
      if (tab === "team") {
        setStaffEditor({
          mode: "create",
          member: null
        });

        return;
      }


      // ROTA TAB
      if (tab === "rota") {
        if (!canManageRota) {
          toast("Only Admin or Super Admin can change the recurring rota.");
          return;
        }

        setShiftEditor({
          mode: "create",
          member: null
        });

        return;
      }


      // LEAVE TAB
      if (tab === "leave") {
        setLeaveEditor({
          mode: "create",
          record: null
        });

        return;
      }
    };

// ======================================================
// LOAD REAL SHIFTS FROM SUPABASE
// ======================================================

const loadShifts = useCallback(async () => {
  try {
    setShiftsLoading(true);
    setShiftsError("");

    if (!window.API?.WeeklyRota) {
      throw new Error(
        "Recurring Weekly Rota API is unavailable. Replace api.jsx with the Step 10G bundled version."
      );
    }

    const today =
      new Date().toISOString().slice(0, 10);

    const result =
      await window.API.WeeklyRota.listForDate(today);

    setShifts(
      Array.isArray(result)
        ? result
        : []
    );

  } catch (error) {
    console.error(
      "Recurring rota loading failed:",
      error
    );

    setShiftsError(
      error.message ||
      "The recurring rota could not be loaded."
    );

  } finally {
    setShiftsLoading(false);
  }
}, []);

useEffect(() => {
  loadShifts();
}, [loadShifts]);


// ======================================================
// LOAD ONE-OFF EXTRA HOURS FROM SUPABASE — STEP 10G5D3
// ======================================================

const loadExtraHours =
  useCallback(async () => {

    try {

      setExtraHoursLoading(true);
      setExtraHoursError("");

      if (!window.API?.ExtraHours) {
        throw new Error(
          "Extra Hours API is unavailable. Replace api.jsx with the Step 10G5D3 version."
        );
      }

      const result =
        await window.API.ExtraHours.list();

      setExtraHours(
        Array.isArray(result)
          ? result
          : []
      );

    } catch (error) {

      console.error(
        "Extra Hours loading failed:",
        error
      );

      setExtraHoursError(
        error.message ||
        "Extra Hours could not be loaded."
      );

    } finally {

      setExtraHoursLoading(false);
    }

  }, []);


useEffect(() => {

  if (
    tab === "rota" &&
    canManageRota
  ) {
    loadExtraHours();
  }

}, [
  tab,
  canManageRota,
  loadExtraHours
]);


  // ======================================================
  // LOAD LEAVE / SICKNESS FROM SUPABASE
  // ======================================================

  const loadLeaveRecords =
    useCallback(async () => {

      try {
        // Start loading.
        setLeaveLoading(true);

        // Clear old error.
        setLeaveError("");

        // Make sure api.jsx loaded.
        if (!window.API?.Leave) {
          throw new Error(
            "Leave API is unavailable."
          );
        }

        // Load all records.
        const result =
          await window.API.Leave.list();

        // Store result safely.
        setLeaveRecords(
          Array.isArray(result)
            ? result
            : []
        );

      } catch (error) {

        console.error(
          "Leave loading failed:",
          error
        );

        setLeaveError(
          error.message ||
          "Leave records could not be loaded."
        );

      } finally {

        setLeaveLoading(false);
      }
    }, []);

  useEffect(() => {
    loadLeaveRecords();
  }, [loadLeaveRecords]);

  // ======================================================
  // LOAD CURRENT USER'S REAL ACCESS ROLE
  // ======================================================

  useEffect(() => {

    async function loadCurrentAccessRole() {

      try {

        // Ask Supabase for the role of
        // the currently logged-in user.
        const {
          data,
          error
        } =
          await window.supabaseClient
            .rpc("current_access_role");


        if (error) {
          throw error;
        }


        // Example:
        // super_admin
        // admin
        // practitioner
        setCurrentAccessRole(data);


      } catch (error) {

        console.error(
          "Could not load access role:",
          error
        );

        setCurrentAccessRole(null);
      }
    }


    loadCurrentAccessRole();

  }, []);


  // ======================================================
// LOAD SERVICE ROLE PRICING
// ======================================================

const loadRolePricing =
  useCallback(async () => {

    try {

      // Start loading.
      setRolePricingLoading(true);

      // Clear old errors.
      setRolePricingError("");


      // Make sure api.jsx loaded successfully.
      if (
        !window.API?.ServiceRolePricing
      ) {
        throw new Error(
          "Service Role Pricing API is unavailable."
        );
      }


      // Load pricing from Supabase.
      const result =
        await window.API
          .ServiceRolePricing
          .list();


      // Always store an array.
      setRolePricing(
        Array.isArray(result)
          ? result
          : []
      );


    } catch (error) {

      console.error(
        "Role pricing loading failed:",
        error
      );


      setRolePricingError(
        error.message ||
        "Role pricing could not be loaded."
      );


    } finally {

      setRolePricingLoading(false);
    }

  }, []);

  // Load pricing only when the Role Pricing
  // tab is opened by Admin/Super Admin.
  useEffect(() => {

    if (
      tab === "role-pricing" &&
      canManageRolePricing
    ) {

      loadRolePricing();
    }

  }, [
    tab,
    canManageRolePricing,
    loadRolePricing
  ]);



  return (
    <div>
      <PageHead eyebrow="Team" title="Staff & rota">
         {/* Role Pricing does not need an Add button. */}
        {tab !== "role-pricing" &&
          (tab !== "rota" || canManageRota) && (

          <Button
            variant="primary"
            size="sm"
            icon="plus"

            disabled={
              tab === "team" &&
              activeStaffCount >= staffLimit
            }

            onClick={handleMainButton}
          >

            {tab === "team"
              ? (
                  activeStaffCount >= staffLimit
                    ? "Staff Limit Reached"
                    : "Add Therapist"
                )
              : tab === "rota"
                ? "Set Weekly Rota"
                : "Add Leave"}

          </Button>

        )}
      </PageHead>

      {/* Show current staff usage inside the visible page */}
      <div
        className="caption"
        style={{ marginBottom: 12 }}
      >
        {activeStaffCount} of {staffLimit} active staff
      </div>

      <div style={{ marginBottom: 20 }}>
        <Tabs
          active={tab}
          onChange={setTab}
          tabs={[
            {
              id: "team",
              label: "Team",
              count: staff.length
            },

            {
              id: "rota",
              label: "Weekly rota"
            },

            {
              id: "leave",
              label: "Leave & availability"
            },

            // Only Admin and Super Admin can see this tab.
            ...(canManageRolePricing
              ? [
                  {
                    id: "role-pricing",
                    label: "Role Pricing"
                  }
                ]
              : [])
          ]}
        />
      </div>

      {tab === "team" && (
        <TeamGrid
          staff={staff}
          loading={staffLoading}
          error={staffError}
          onReload={loadStaff}
          toast={toast}

          onEdit={(member) => {
            setStaffEditor({
              mode: "edit",
              member: member
            });
          }}
        />
      )}

      {/* Keep the old demonstration versions temporarily. */}
      {tab === "rota" && (
        <>
          <RotaPlanner
            staff={staff}
            shifts={shifts}
            loading={shiftsLoading}
            error={shiftsError}
            onReload={loadShifts}
            canManage={canManageRota}
            onEditStaff={(member) => {
              setShiftEditor({
                mode: "edit",
                member: member
              });
            }}
            toast={toast}
          />

          {canManageRota && (
            <div style={{ marginTop: 18 }}>
              <ExtraHoursPanel
                staff={staff}
                records={extraHours}
                loading={extraHoursLoading}
                error={extraHoursError}
                onReload={loadExtraHours}
                onAdd={() => {
                  setExtraHoursEditor({
                    mode: "create",
                    record: null
                  });
                }}
                onEdit={(record) => {
                  setExtraHoursEditor({
                    mode: "edit",
                    record
                  });
                }}
              />
            </div>
          )}
        </>
      )}

      {/* ADD/EDIT Leave Record */}
      {tab === "leave" && (
        <LeavePanel
          // Real therapists from Supabase.
          staff={staff}

          // Real leave/sickness records.
          records={leaveRecords}

          // Loading/error states.
          loading={leaveLoading}
          error={leaveError}

          // Reload records.
          onReload={loadLeaveRecords}

          // Open Edit drawer.
          onEdit={(record) => {
            setLeaveEditor({
              mode: "edit",
              record: record
            });
          }}

          // Approve a request.
          onApprove={async (record) => {
            try {
              await window.API.Leave.approve(
                record.id
              );

              toast(
                "Leave approved",
                "success"
              );

              await loadLeaveRecords();

            } catch (error) {
              console.error(error);

              toast(
                error.message ||
                "Leave could not be approved."
              );
            }
          }}

          // Decline a request.
          onDecline={async (record) => {
            try {
              await window.API.Leave.decline(
                record.id
              );

              toast(
                "Leave declined",
                "success"
              );

              await loadLeaveRecords();

            } catch (error) {
              console.error(error);

              toast(
                error.message ||
                "Leave could not be declined."
              );
            }
          }}

          toast={toast}
        />
      )}

      {/* =====================================================
          SERVICE ROLE PRICING
        ===================================================== */}

      {tab === "role-pricing" &&
        canManageRolePricing && (
          <RolePricingPanel
            settings={rolePricing}

            loading={rolePricingLoading}

            error={rolePricingError}

            onReload={loadRolePricing}

            toast={toast}
          />
      )}

      {/* Add/Edit Therapist Form/drawer */}
      <TherapistDrawer
        editor={staffEditor}

        onClose={() => setStaffEditor(null)}

        onSaved={handleStaffSaved}

        services={services}

        servicesLoading={servicesLoading}
        servicesError={servicesError}

        toast={toast}
      />

      {/* Step 10G — recurring weekly rota editor */}
      <WeeklyRotaDrawer
        editor={shiftEditor}
        staff={staff}
        onClose={() => setShiftEditor(null)}
        onSaved={async () => {
          setShiftEditor(null);
          await loadShifts();
        }}
        toast={toast}
      />

      {/* Step 10G5D3 — one-off Extra Hours editor */}
      <ExtraHoursDrawer
        editor={extraHoursEditor}
        staff={staff}
        onClose={() =>
          setExtraHoursEditor(null)
        }
        onSaved={async () => {
          setExtraHoursEditor(null);
          await loadExtraHours();
        }}
        onDelete={async (record) => {

          const confirmed =
            window.confirm(
              "Delete this Extra Hours record?"
            );

          if (!confirmed) {
            return;
          }

          try {

            await window.API.ExtraHours.remove(
              record.id
            );

            toast(
              "Extra Hours deleted",
              "success"
            );

            setExtraHoursEditor(null);

            await loadExtraHours();

          } catch (error) {

            console.error(
              "Extra Hours deletion failed:",
              error
            );

            toast(
              error.message ||
              "Extra Hours could not be deleted."
            );
          }
        }}
        toast={toast}
      />

      {/* Add/Edit leave, sickness or blocked time */}
      <LeaveDrawer
        editor={leaveEditor}

        staff={staff}

        // Close drawer.
        onClose={() =>
          setLeaveEditor(null)
        }

        // After save:
        // close drawer and reload.
        onSaved={async () => {

          setLeaveEditor(null);

          await loadLeaveRecords();
        }}

        // Delete leave record.
        onDelete={async (record) => {

          const confirmed =
            window.confirm(
              "Delete this leave record?"
            );

          if (!confirmed) {
            return;
          }

          try {

            await window.API.Leave.remove(
              record.id
            );

            toast(
              "Leave record deleted",
              "success"
            );

            setLeaveEditor(null);

            await loadLeaveRecords();

          } catch (error) {

            console.error(
              "Leave deletion failed:",
              error
            );

            toast(
              error.message ||
              "Leave record could not be deleted."
            );
          }
        }}

        toast={toast}
      />  

    </div>
  );
}

/* =========================================================
   REAL WEEKLY ROTA
   ========================================================= */

function RotaPlanner({
  staff,
  shifts,
  loading,
  error,
  onReload,
  canManage,
  onEditStaff
}) {
  const days = [
    [1, "Mon"],
    [2, "Tue"],
    [3, "Wed"],
    [4, "Thu"],
    [5, "Fri"],
    [6, "Sat"],
    [7, "Sun"]
  ];

  const formatTime = value =>
    value
      ? String(value).slice(0, 5)
      : "—";

  if (loading) {
    return (
      <Panel>
        <div className="caption">
          Loading recurring weekly rota…
        </div>
      </Panel>
    );
  }

  if (error) {
    return (
      <Panel>
        <div
          style={{
            color: "var(--danger)",
            marginBottom: 12
          }}
        >
          {error}
        </div>

        <Button
          variant="primary"
          size="sm"
          onClick={onReload}
        >
          Try Again
        </Button>
      </Panel>
    );
  }

  if (!staff.length) {
    return (
      <Panel>
        <div className="caption">
          Add a therapist before creating a rota.
        </div>
      </Panel>
    );
  }

  return (
    <Panel pad={false}>
      <div
        style={{
          padding: "16px 20px",
          borderBottom: "1px solid var(--line)",
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          gap: 16,
          flexWrap: "wrap"
        }}
      >
        <div>
          <h3>Recurring Weekly Rota</h3>

          <div
            className="caption"
            style={{ marginTop: 4 }}
          >
            Set the normal Monday-Sunday pattern once. It continues every week until Admin changes it.
          </div>
        </div>

        {!canManage && (
          <span
            className="chip chip-line"
            style={{ fontSize: "0.66rem" }}
          >
            View only
          </span>
        )}
      </div>

      <div style={{ overflowX: "auto" }}>
        <div style={{ minWidth: 1060 }}>
          <div
            style={{
              display: "grid",
              gridTemplateColumns: "190px repeat(7, 1fr) 92px",
              background: "var(--bg-nude)",
              borderBottom: "1px solid var(--line)"
            }}
          >
            <div style={{ padding: 12 }}>
              <span className="caption">Therapist</span>
            </div>

            {days.map(([, label]) => (
              <div
                key={label}
                style={{
                  padding: 12,
                  textAlign: "center",
                  borderLeft: "1px solid var(--line)"
                }}
              >
                <span className="caption">{label}</span>
              </div>
            ))}

            <div style={{ padding: 12 }} />
          </div>

          {staff.map(member => {
            const name =
              [member.first_name, member.last_name]
                .filter(Boolean)
                .join(" ") ||
              "Therapist";

            const memberRows =
              (shifts || []).filter(row =>
                String(row.staff_id) === String(member.id)
              );

            const effectiveFrom =
              memberRows[0]?.effective_from || null;

            return (
              <div
                key={member.id}
                style={{
                  display: "grid",
                  gridTemplateColumns: "190px repeat(7, 1fr) 92px",
                  borderBottom: "1px solid var(--line)",
                  minHeight: 78
                }}
              >
                <div
                  style={{
                    padding: "13px 14px",
                    display: "flex",
                    alignItems: "center",
                    gap: 10
                  }}
                >
                  <Avatar
                    name={name}
                    size={32}
                    color={member.colour}
                  />

                  <div style={{ minWidth: 0 }}>
                    <div
                      style={{
                        fontFamily: "var(--font-display)",
                        fontSize: "0.82rem",
                        whiteSpace: "nowrap",
                        overflow: "hidden",
                        textOverflow: "ellipsis"
                      }}
                    >
                      {name}
                    </div>

                    <div
                      className="caption"
                      style={{ fontSize: "0.62rem" }}
                    >
                      {effectiveFrom
                        ? `From ${new Date(`${effectiveFrom}T12:00:00`).toLocaleDateString("en-GB", { day: "numeric", month: "short", year: "numeric" })}`
                        : "No recurring rota"}
                    </div>
                  </div>
                </div>

                {days.map(([weekday]) => {
                  const row =
                    memberRows.find(item =>
                      Number(item.weekday) === weekday
                    );

                  const working =
                    row?.is_working === true;

                  return (
                    <div
                      key={weekday}
                      style={{
                        borderLeft: "1px solid var(--line)",
                        padding: "12px 8px",
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "center",
                        textAlign: "center",
                        background: working
                          ? "rgba(184,137,73,0.08)"
                          : "transparent"
                      }}
                    >
                      {working ? (
                        <div>
                          <div
                            style={{
                              fontFamily: "var(--font-display)",
                              fontSize: "0.75rem"
                            }}
                          >
                            {formatTime(row.start_time)}–{formatTime(row.end_time)}
                          </div>

                          {Number(row.break_minutes || 0) > 0 && (
                            <div
                              className="caption"
                              style={{ fontSize: "0.58rem", marginTop: 2 }}
                            >
                              {row.break_minutes}m break
                            </div>
                          )}
                        </div>
                      ) : (
                        <span
                          className="caption"
                          style={{ fontSize: "0.64rem" }}
                        >
                          Off
                        </span>
                      )}
                    </div>
                  );
                })}

                <div
                  style={{
                    padding: 10,
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center"
                  }}
                >
                  {canManage && (
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => onEditStaff(member)}
                    >
                      Edit
                    </Button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      <div
        style={{
          padding: "12px 16px",
          borderTop: "1px solid var(--line)"
        }}
        className="caption"
      >
        One-off leave, sickness and temporary exceptions remain separate under Leave & availability.
      </div>
    </Panel>
  );
}


const EMPTY_WEEKLY_ROTA_DAYS = [
  { weekday: 1, label: "Monday", is_working: true, start_time: "09:00", end_time: "17:00", break_minutes: 30 },
  { weekday: 2, label: "Tuesday", is_working: true, start_time: "09:00", end_time: "17:00", break_minutes: 30 },
  { weekday: 3, label: "Wednesday", is_working: true, start_time: "09:00", end_time: "17:00", break_minutes: 30 },
  { weekday: 4, label: "Thursday", is_working: true, start_time: "09:00", end_time: "17:00", break_minutes: 30 },
  { weekday: 5, label: "Friday", is_working: true, start_time: "09:00", end_time: "17:00", break_minutes: 30 },
  { weekday: 6, label: "Saturday", is_working: false, start_time: "09:00", end_time: "17:00", break_minutes: 0 },
  { weekday: 7, label: "Sunday", is_working: false, start_time: "09:00", end_time: "17:00", break_minutes: 0 }
];



/* =========================================================
   ONE-OFF EXTRA HOURS — STEP 10G5D3
   ========================================================= */

function ExtraHoursPanel({
  staff,
  records,
  loading,
  error,
  onReload,
  onAdd,
  onEdit
}) {

  const therapistName = (record) => {

    const linked =
      record.staff_members;

    if (linked) {
      return [
        linked.first_name,
        linked.last_name
      ]
        .filter(Boolean)
        .join(" ") ||
        "Therapist";
    }

    const member =
      (staff || []).find(
        person =>
          String(person.id) ===
          String(record.staff_id)
      );

    return member
      ? [
          member.first_name,
          member.last_name
        ]
          .filter(Boolean)
          .join(" ")
      : "Therapist";
  };


  const formatDate = value => {

    if (!value) {
      return "—";
    }

    return new Date(
      `${value}T12:00:00`
    ).toLocaleDateString(
      "en-GB",
      {
        weekday: "short",
        day: "numeric",
        month: "short",
        year: "numeric"
      }
    );
  };


  const formatTime = value =>
    value
      ? String(value).slice(0, 5)
      : "—";


  return (
    <Panel pad={false}>

      <div
        style={{
          padding: "16px 20px",
          borderBottom:
            "1px solid var(--line)",
          display: "flex",
          alignItems: "center",
          justifyContent:
            "space-between",
          gap: 14,
          flexWrap: "wrap"
        }}
      >
        <div>
          <h3>
            One-off Extra Hours
          </h3>

          <div
            className="caption"
            style={{ marginTop: 4 }}
          >
            Extend a therapist's availability for one specific date without changing their permanent weekly rota.
          </div>
        </div>

        <Button
          variant="primary"
          size="sm"
          icon="plus"
          onClick={onAdd}
        >
          Add Extra Hours
        </Button>
      </div>


      {loading && (
        <div
          className="caption"
          style={{ padding: 20 }}
        >
          Loading Extra Hours…
        </div>
      )}


      {!loading && error && (
        <div style={{ padding: 20 }}>
          <div
            style={{
              color: "var(--danger)",
              marginBottom: 12
            }}
          >
            {error}
          </div>

          <Button
            variant="ghost"
            size="sm"
            onClick={onReload}
          >
            Try Again
          </Button>
        </div>
      )}


      {!loading &&
        !error &&
        records.length === 0 && (
          <div style={{ padding: 24 }}>
            <div
              style={{
                fontFamily:
                  "var(--font-display)",
                marginBottom: 5
              }}
            >
              No Extra Hours set
            </div>

            <div className="caption">
              Use this only for one-off extensions, such as working until 20:00 on a day that normally ends at 17:00.
            </div>
          </div>
        )}


      {!loading &&
        !error &&
        records.length > 0 && (
          <div>

            {records.map(record => {

              const name =
                therapistName(record);

              const member =
                (staff || []).find(
                  person =>
                    String(person.id) ===
                    String(record.staff_id)
                );

              return (
                <div
                  key={record.id}
                  style={{
                    display: "flex",
                    alignItems: "center",
                    gap: 14,
                    padding: "15px 20px",
                    borderBottom:
                      "1px solid var(--line)"
                  }}
                >

                  <Avatar
                    name={name}
                    size={36}
                    color={
                      record.staff_members?.colour ||
                      member?.colour
                    }
                  />

                  <div
                    style={{
                      flex: 1,
                      minWidth: 0
                    }}
                  >
                    <div
                      style={{
                        fontFamily:
                          "var(--font-display)"
                      }}
                    >
                      {name}
                    </div>

                    <div
                      className="caption"
                      style={{ marginTop: 2 }}
                    >
                      {formatDate(
                        record.work_date
                      )}
                      {" · "}
                      {formatTime(
                        record.start_time
                      )}
                      {" – "}
                      {formatTime(
                        record.end_time
                      )}
                    </div>

                    {record.notes && (
                      <div
                        className="caption"
                        style={{ marginTop: 3 }}
                      >
                        {record.notes}
                      </div>
                    )}
                  </div>

                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() =>
                      onEdit(record)
                    }
                  >
                    Edit
                  </Button>

                </div>
              );
            })}

          </div>
        )}

    </Panel>
  );
}


const EMPTY_EXTRA_HOURS_FORM = {
  staff_id: "",
  work_date: "",
  start_time: "17:00",
  end_time: "20:00",
  notes: ""
};


function ExtraHoursDrawer({
  editor,
  staff,
  onClose,
  onSaved,
  onDelete,
  toast
}) {

  const [form, setForm] =
    useState({
      ...EMPTY_EXTRA_HOURS_FORM
    });

  const [saving, setSaving] =
    useState(false);

  const [formError, setFormError] =
    useState("");


  useEffect(() => {

    if (!editor) {
      return;
    }

    if (
      editor.mode === "edit" &&
      editor.record
    ) {

      setForm({
        staff_id:
          editor.record.staff_id ||
          "",

        work_date:
          editor.record.work_date ||
          "",

        start_time:
          String(
            editor.record.start_time ||
            "17:00"
          ).slice(0, 5),

        end_time:
          String(
            editor.record.end_time ||
            "20:00"
          ).slice(0, 5),

        notes:
          editor.record.notes ||
          ""
      });

    } else {

      const tomorrow =
        new Date();

      tomorrow.setDate(
        tomorrow.getDate() + 1
      );

      const localDate =
        tomorrow.getFullYear()
        + "-"
        + String(
          tomorrow.getMonth() + 1
        ).padStart(2, "0")
        + "-"
        + String(
          tomorrow.getDate()
        ).padStart(2, "0");

      setForm({
        ...EMPTY_EXTRA_HOURS_FORM,

        staff_id:
          (staff || []).find(
            member =>
              member.is_active
          )?.id || "",

        work_date:
          localDate
      });
    }

    setSaving(false);
    setFormError("");

  }, [editor, staff]);


  if (!editor) {
    return null;
  }


  const isEditing =
    editor.mode === "edit";


  const change = (
    field,
    value
  ) => {

    setForm(current => ({
      ...current,
      [field]: value
    }));
  };


  const save = async () => {

    setFormError("");

    if (!form.staff_id) {
      setFormError(
        "Select a therapist."
      );
      return;
    }

    if (!form.work_date) {
      setFormError(
        "Select the date."
      );
      return;
    }

    if (
      !form.start_time ||
      !form.end_time
    ) {
      setFormError(
        "Enter the Extra Hours start and finish times."
      );
      return;
    }

    if (
      form.end_time <=
      form.start_time
    ) {
      setFormError(
        "Finish time must be after start time."
      );
      return;
    }

    const payload = {
      staff_id:
        form.staff_id,

      work_date:
        form.work_date,

      start_time:
        form.start_time,

      end_time:
        form.end_time,

      notes:
        form.notes
    };


    try {

      setSaving(true);

      if (isEditing) {

        await window.API
          .ExtraHours
          .update(
            editor.record.id,
            payload
          );

        toast(
          "Extra Hours updated",
          "success"
        );

      } else {

        await window.API
          .ExtraHours
          .create(
            payload
          );

        toast(
          "Extra Hours added",
          "success"
        );
      }

      await onSaved();

    } catch (error) {

      console.error(
        "Extra Hours save failed:",
        error
      );

      setFormError(
        error.message ||
        "Extra Hours could not be saved."
      );

    } finally {

      setSaving(false);
    }
  };


  return (
    <Drawer
      open={true}

      onClose={
        saving
          ? () => {}
          : onClose
      }

      title={
        isEditing
          ? "Edit Extra Hours"
          : "Add Extra Hours"
      }

      subtitle=
        "One-off rota extension"

      footer={
        <>

          {isEditing && (
            <Button
              variant="ghost"
              size="sm"
              disabled={saving}
              onClick={() =>
                onDelete(
                  editor.record
                )
              }
            >
              Delete
            </Button>
          )}

          <Button
            variant="ghost"
            size="sm"
            disabled={saving}
            onClick={onClose}
          >
            Cancel
          </Button>

          <Button
            variant="primary"
            size="sm"
            disabled={saving}
            onClick={save}
          >
            {saving
              ? "Saving…"
              : isEditing
                ? "Save Changes"
                : "Add Extra Hours"}
          </Button>

        </>
      }
    >

      {formError && (
        <div
          style={{
            padding: 12,
            marginBottom: 16,
            color: "var(--danger)",
            background:
              "rgba(154,74,58,0.10)",
            borderRadius: 7
          }}
        >
          {formError}
        </div>
      )}


      <TherapistField
        label="Therapist"
      >
        <select
          className="a-input"
          value={form.staff_id}
          onChange={event =>
            change(
              "staff_id",
              event.target.value
            )
          }
        >
          <option value="">
            Select therapist
          </option>

          {(staff || [])
            .filter(
              member =>
                member.is_active
            )
            .map(member => {

              const name =
                [
                  member.first_name,
                  member.last_name
                ]
                  .filter(Boolean)
                  .join(" ");

              return (
                <option
                  key={member.id}
                  value={member.id}
                >
                  {name}
                </option>
              );
            })}
        </select>
      </TherapistField>


      <TherapistField
        label="Specific date"
      >
        <input
          className="a-input"
          type="date"
          value={form.work_date}
          onChange={event =>
            change(
              "work_date",
              event.target.value
            )
          }
        />
      </TherapistField>


      <div
        style={{
          display: "grid",
          gridTemplateColumns:
            "1fr 1fr",
          gap: 12
        }}
      >

        <TherapistField
          label="Extra from"
        >
          <input
            className="a-input"
            type="time"
            value={form.start_time}
            onChange={event =>
              change(
                "start_time",
                event.target.value
              )
            }
          />
        </TherapistField>


        <TherapistField
          label="Extra until"
        >
          <input
            className="a-input"
            type="time"
            value={form.end_time}
            onChange={event =>
              change(
                "end_time",
                event.target.value
              )
            }
          />
        </TherapistField>

      </div>


      <TherapistField
        label="Reason / note"
      >
        <textarea
          className="a-input"
          rows={3}
          value={form.notes}
          onChange={event =>
            change(
              "notes",
              event.target.value
            )
          }
          placeholder=
            "Example: Late opening for Christmas week"
          style={{
            resize: "vertical"
          }}
        />
      </TherapistField>


      <div
        style={{
          padding: 13,
          borderRadius: 8,
          background:
            "var(--bg-nude)"
        }}
      >
        <div className="caption">
          Extra Hours extend availability for this date only. Approved Leave or Blocked Time still wins if it overlaps these hours.
        </div>
      </div>

    </Drawer>
  );
}

function WeeklyRotaDrawer({
  editor,
  staff,
  onClose,
  onSaved,
  toast
}) {
  const [staffId, setStaffId] =
    useState("");

  const [effectiveFrom, setEffectiveFrom] =
    useState(
      new Date().toISOString().slice(0, 10)
    );

  const [days, setDays] =
    useState(
      EMPTY_WEEKLY_ROTA_DAYS.map(day => ({ ...day }))
    );

  const [loadingExisting, setLoadingExisting] =
    useState(false);

  const [saving, setSaving] =
    useState(false);

  const [formError, setFormError] =
    useState("");


  useEffect(() => {
    if (!editor) {
      return;
    }

    const memberId =
      editor.member?.id || "";

    setStaffId(memberId);
    setEffectiveFrom(
      new Date().toISOString().slice(0, 10)
    );
    setDays(
      EMPTY_WEEKLY_ROTA_DAYS.map(day => ({ ...day }))
    );
    setFormError("");

    if (memberId) {
      loadExisting(memberId);
    }
  }, [editor]);


  if (!editor) {
    return null;
  }


  async function loadExisting(memberId, targetDate) {
    if (!memberId) {
      return;
    }

    try {
      setLoadingExisting(true);
      setFormError("");

      const date =
        targetDate ||
        effectiveFrom ||
        new Date().toISOString().slice(0, 10);

      const rows =
        await window.API.WeeklyRota.getStaff(
          memberId,
          date
        );

      if (!rows?.length) {
        setDays(
          EMPTY_WEEKLY_ROTA_DAYS.map(day => ({ ...day }))
        );
        return;
      }

      const rowByDay =
        Object.fromEntries(
          rows.map(row => [
            Number(row.weekday),
            row
          ])
        );

      setDays(
        EMPTY_WEEKLY_ROTA_DAYS.map(day => {
          const existing =
            rowByDay[day.weekday];

          if (!existing) {
            return {
              ...day,
              is_working: false,
              break_minutes: 0
            };
          }

          return {
            ...day,

            is_working:
              existing.is_working === true,

            start_time:
              existing.start_time
                ? String(
                    existing.start_time
                  ).slice(0, 5)
                : day.start_time,

            end_time:
              existing.end_time
                ? String(
                    existing.end_time
                  ).slice(0, 5)
                : day.end_time,

            break_minutes:
              Number(
                existing.break_minutes ||
                0
              )
          };
        })
      );

    } catch (error) {
      console.error(
        "Recurring rota could not be loaded:",
        error
      );

      setFormError(
        error.message ||
        "Recurring rota could not be loaded."
      );

    } finally {
      setLoadingExisting(false);
    }
  }


  function updateDay(
    weekday,
    field,
    value
  ) {
    setDays(current =>
      current.map(day =>
        day.weekday === weekday
          ? {
              ...day,
              [field]: value
            }
          : day
      )
    );
  }


  async function save() {
    if (!staffId) {
      setFormError(
        "Choose a therapist."
      );
      return;
    }

    if (!effectiveFrom) {
      setFormError(
        "Choose the date this permanent rota should start."
      );
      return;
    }

    for (const day of days) {
      if (
        day.is_working &&
        (
          !day.start_time ||
          !day.end_time ||
          day.end_time <=
            day.start_time
        )
      ) {
        setFormError(
          `${day.label} needs a valid start and finish time.`
        );
        return;
      }

      if (
        Number(
          day.break_minutes ||
          0
        ) < 0
      ) {
        setFormError(
          `${day.label} break cannot be negative.`
        );
        return;
      }
    }

    try {
      setSaving(true);
      setFormError("");

      const payload =
        days.map(day => ({
          weekday:
            day.weekday,

          is_working:
            day.is_working,

          start_time:
            day.is_working
              ? day.start_time
              : null,

          end_time:
            day.is_working
              ? day.end_time
              : null,

          break_minutes:
            day.is_working
              ? Number(
                  day.break_minutes ||
                  0
                )
              : 0
        }));

      await window.API.WeeklyRota.save(
        staffId,
        effectiveFrom,
        payload
      );

      toast(
        "Permanent weekly rota saved.",
        "success"
      );

      await onSaved();

    } catch (error) {
      console.error(
        "Recurring rota save failed:",
        error
      );

      setFormError(
        error.message ||
        "Recurring rota could not be saved."
      );

    } finally {
      setSaving(false);
    }
  }


  return (
    <Drawer
      open={true}
      onClose={
        saving
          ? () => {}
          : onClose
      }
      title="Permanent Weekly Rota"
      subtitle="Repeats every week until Admin saves a new pattern"
      footer={
        <>
          <Button
            variant="ghost"
            size="sm"
            onClick={onClose}
            disabled={saving}
          >
            Cancel
          </Button>

          <Button
            variant="primary"
            size="sm"
            onClick={save}
            disabled={
              saving ||
              loadingExisting
            }
          >
            {saving
              ? "Saving…"
              : "Save Permanent Rota"}
          </Button>
        </>
      }
    >
      <div
        style={{
          maxHeight:
            "calc(100vh - 220px)",
          overflowY: "auto",
          overflowX: "hidden",
          paddingRight: 4,
          paddingBottom: 18
        }}
      >
        {formError && (
          <div
            style={{
              padding: 12,
              marginBottom: 16,
              borderRadius: 7,
              color:
                "var(--danger)",
              background:
                "rgba(154,74,58,0.10)"
            }}
          >
            {formError}
          </div>
        )}


        <div
          style={{
            padding:
              "12px 14px",
            borderRadius: 8,
            border:
              "1px solid var(--gold-soft)",
            background:
              "rgba(184,137,73,0.08)",
            marginBottom: 16
          }}
        >
          <div
            style={{
              fontFamily:
                "var(--font-display)",
              fontSize:
                "0.84rem",
              marginBottom: 4
            }}
          >
            Permanent weekly pattern
          </div>

          <div
            className="caption"
            style={{
              lineHeight: 1.5
            }}
          >
            Set the normal Monday–Sunday working pattern once.
            It will repeat every week until Admin saves another
            permanent pattern from a new Effective From date.
            Use Leave & availability for one-off days off,
            sickness or temporary exceptions.
          </div>
        </div>


        <TherapistField label="Therapist">
          <select
            className="a-input"
            value={staffId}
            disabled={
              !!editor.member ||
              saving
            }
            onChange={event => {
              const nextId =
                event.target.value;

              setStaffId(
                nextId
              );

              if (nextId) {
                loadExisting(
                  nextId,
                  effectiveFrom
                );
              }
            }}
          >
            <option value="">
              Select therapist…
            </option>

            {staff.map(member => (
              <option
                key={member.id}
                value={member.id}
              >
                {[
                  member.first_name,
                  member.last_name
                ]
                  .filter(Boolean)
                  .join(" ")}
              </option>
            ))}
          </select>
        </TherapistField>


        <TherapistField
          label="Effective from"
        >
          <input
            className="a-input"
            type="date"
            value={effectiveFrom}
            onChange={event => {
              const nextDate =
                event.target.value;

              setEffectiveFrom(
                nextDate
              );

              if (staffId) {
                loadExisting(
                  staffId,
                  nextDate
                );
              }
            }}
          />

          <div
            className="caption"
            style={{
              marginTop: 6,
              lineHeight: 1.45
            }}
          >
            For a permanent change, choose the first date the new
            weekly pattern should apply. Earlier rota history is kept.
          </div>
        </TherapistField>


        <div
          style={{
            marginTop: 18,
            border:
              "1px solid var(--line)",
            borderRadius: 8,
            overflow: "hidden"
          }}
        >
          <div
            style={{
              display: "grid",
              gridTemplateColumns:
                "minmax(96px,1.15fr) 62px minmax(82px,1fr) minmax(82px,1fr) 72px",
              gap: 8,
              alignItems: "center",
              padding:
                "9px 10px",
              background:
                "var(--bg-nude)",
              borderBottom:
                "1px solid var(--line)"
            }}
          >
            {[
              "Day",
              "Work",
              "Start",
              "Finish",
              "Break"
            ].map(label => (
              <div
                key={label}
                className="caption"
                style={{
                  fontSize:
                    "0.61rem",
                  textTransform:
                    "uppercase",
                  letterSpacing:
                    "0.08em"
                }}
              >
                {label}
              </div>
            ))}
          </div>


          {days.map(day => (
            <div
              key={day.weekday}
              style={{
                display: "grid",
                gridTemplateColumns:
                  "minmax(96px,1.15fr) 62px minmax(82px,1fr) minmax(82px,1fr) 72px",
                gap: 8,
                alignItems:
                  "center",
                padding:
                  "10px",
                borderBottom:
                  "1px solid var(--line)",
                background:
                  day.is_working
                    ? "transparent"
                    : "var(--bg-nude)"
              }}
            >
              <div
                style={{
                  minWidth: 0,
                  fontFamily:
                    "var(--font-display)",
                  fontSize:
                    "0.78rem"
                }}
              >
                {day.label}
              </div>

              <label
                title={
                  day.is_working
                    ? "Working"
                    : "Day off"
                }
                style={{
                  display: "flex",
                  justifyContent:
                    "center",
                  alignItems:
                    "center"
                }}
              >
                <input
                  type="checkbox"
                  checked={
                    day.is_working
                  }
                  onChange={event =>
                    updateDay(
                      day.weekday,
                      "is_working",
                      event.target.checked
                    )
                  }
                />
              </label>

              <input
                className="a-input"
                type="time"
                value={
                  day.start_time
                }
                disabled={
                  !day.is_working
                }
                title={`${day.label} start time`}
                style={{
                  width: "100%",
                  minWidth: 0,
                  boxSizing:
                    "border-box",
                  paddingLeft: 7,
                  paddingRight: 7
                }}
                onChange={event =>
                  updateDay(
                    day.weekday,
                    "start_time",
                    event.target.value
                  )
                }
              />

              <input
                className="a-input"
                type="time"
                value={
                  day.end_time
                }
                disabled={
                  !day.is_working
                }
                title={`${day.label} finish time`}
                style={{
                  width: "100%",
                  minWidth: 0,
                  boxSizing:
                    "border-box",
                  paddingLeft: 7,
                  paddingRight: 7
                }}
                onChange={event =>
                  updateDay(
                    day.weekday,
                    "end_time",
                    event.target.value
                  )
                }
              />

              <input
                className="a-input"
                type="number"
                min="0"
                max="480"
                step="5"
                title="Unpaid / non-bookable break minutes during this working day"
                value={
                  day.break_minutes
                }
                disabled={
                  !day.is_working
                }
                style={{
                  width: "100%",
                  minWidth: 0,
                  boxSizing:
                    "border-box",
                  paddingLeft: 7,
                  paddingRight: 5
                }}
                onChange={event =>
                  updateDay(
                    day.weekday,
                    "break_minutes",
                    event.target.value
                  )
                }
              />
            </div>
          ))}
        </div>


        <div
          style={{
            marginTop: 12,
            padding:
              "10px 12px",
            borderRadius: 7,
            background:
              "var(--bg-nude)"
          }}
        >
          <div
            style={{
              fontFamily:
                "var(--font-display)",
              fontSize:
                "0.76rem"
            }}
          >
            What does Break mean?
          </div>

          <div
            className="caption"
            style={{
              marginTop: 4,
              lineHeight: 1.5
            }}
          >
            Break is the number of break minutes recorded for that
            working day, entered in 5-minute steps such as 0, 5, 10,
            15 or 30. It is separate from treatment cleanup/buffer time.
          </div>
        </div>


        <div
          className="caption"
          style={{
            marginTop: 12,
            lineHeight: 1.55
          }}
        >
          Saving from a future Effective From date keeps the previous
          rota for earlier dates. Leave and one-off exceptions remain
          under Leave & availability.
        </div>
      </div>
    </Drawer>
  );
}


/* =========================================================
   ADD / EDIT SHIFT DRAWER
   ========================================================= */

// Empty form used for a new shift.
const EMPTY_SHIFT_FORM = {
  staff_id: "",
  date: "",
  start_time: "09:00",
  end_time: "17:00",
  break_minutes: "30",
  notes: ""
};


function ShiftDrawer({
  editor,
  staff,
  onClose,
  onSaved,
  onDelete,
  toast
}) {
  // Current form values.
  const [form, setForm] = useState({
    ...EMPTY_SHIFT_FORM
  });

  // Saving state.
  const [saving, setSaving] =
    useState(false);

  // Error shown inside the drawer.
  const [formError, setFormError] =
    useState("");


  // -------------------------------------------------------
  // Fill the form whenever the drawer opens.
  // -------------------------------------------------------
  useEffect(() => {
    if (!editor) {
      return;
    }


    // Editing an existing shift.
    if (
      editor.mode === "edit" &&
      editor.shift
    ) {
      const start =
        new Date(editor.shift.start_at);

      const end =
        new Date(editor.shift.end_at);


      // yyyy-mm-dd
      const date =
        start.getFullYear() +
        "-" +
        String(
          start.getMonth() + 1
        ).padStart(2, "0") +
        "-" +
        String(
          start.getDate()
        ).padStart(2, "0");


      // HH:mm
      const startTime =
        String(
          start.getHours()
        ).padStart(2, "0") +
        ":" +
        String(
          start.getMinutes()
        ).padStart(2, "0");


      const endTime =
        String(
          end.getHours()
        ).padStart(2, "0") +
        ":" +
        String(
          end.getMinutes()
        ).padStart(2, "0");


      setForm({
        staff_id:
          editor.shift.staff_id || "",

        date: date,

        start_time: startTime,

        end_time: endTime,

        break_minutes:
          String(
            editor.shift.break_minutes || 0
          ),

        notes:
          editor.shift.notes || ""
      });

    } else {

      // New shift.
      setForm({
        ...EMPTY_SHIFT_FORM,

        // Automatically select first
        // active therapist when available.
        staff_id:
          staff.find(
            (member) => member.is_active
          )?.id || ""
      });
    }


    setFormError("");
    setSaving(false);

  }, [editor, staff]);


  // Drawer closed.
  if (!editor) {
    return null;
  }


  const isEditing =
    editor.mode === "edit";


  // -------------------------------------------------------
  // Change one form value.
  // -------------------------------------------------------
  const change = (field, value) => {
    setForm((current) => ({
      ...current,
      [field]: value
    }));
  };


  // -------------------------------------------------------
  // SAVE SHIFT
  // -------------------------------------------------------
  const saveShift = async () => {
    setFormError("");


    // Basic validation.
    if (!form.staff_id) {
      setFormError(
        "Select a therapist."
      );
      return;
    }


    if (!form.date) {
      setFormError(
        "Select a shift date."
      );
      return;
    }


    if (
      !form.start_time ||
      !form.end_time
    ) {
      setFormError(
        "Enter the start and end time."
      );
      return;
    }


    // Build local date/time strings.
    const start =
      new Date(
        `${form.date}T${form.start_time}`
      );

    const end =
      new Date(
        `${form.date}T${form.end_time}`
      );


    // End must be later than start.
    if (end <= start) {
      setFormError(
        "End time must be after start time."
      );
      return;
    }


    // Data sent to Supabase.
    const payload = {
      staff_id:
        form.staff_id,

      start_at:
        start.toISOString(),

      end_at:
        end.toISOString(),

      break_minutes:
        Number(
          form.break_minutes || 0
        ),

      notes:
        form.notes.trim() || null
    };


    try {
      setSaving(true);


      if (isEditing) {

        // Update existing shift.
        await window.API.Shifts.update(
          editor.shift.id,
          payload
        );

        toast(
          "Shift updated",
          "success"
        );

      } else {

        // Create new shift.
        await window.API.Shifts.create(
          payload
        );

        toast(
          "Shift added",
          "success"
        );
      }


      // Close and reload rota.
      await onSaved();


    } catch (error) {

      console.error(
        "Shift save failed:",
        error
      );

      setFormError(
        error.message ||
        "The shift could not be saved."
      );

    } finally {

      setSaving(false);

    }
  };


  return (
    <Drawer
      open={true}
      onClose={
        saving
          ? () => {}
          : onClose
      }

      title={
        isEditing
          ? "Edit Shift"
          : "Add Shift"
      }

      subtitle="Staff rota"

      footer={
        <>
          {/* Delete only appears when editing */}
          {isEditing && (
            <Button
              variant="ghost"
              size="sm"
              onClick={() =>
                onDelete(
                  editor.shift
                )
              }
              disabled={saving}
            >
              Delete
            </Button>
          )}

          <Button
            variant="ghost"
            size="sm"
            onClick={onClose}
            disabled={saving}
          >
            Cancel
          </Button>

          <Button
            variant="primary"
            size="sm"
            onClick={saveShift}
            disabled={saving}
          >
            {saving
              ? "Saving…"
              : isEditing
                ? "Save Changes"
                : "Add Shift"}
          </Button>
        </>
      }
    >

      {/* Error */}
      {formError && (
        <div
          style={{
            padding: 12,
            marginBottom: 16,
            color: "var(--danger)",
            background:
              "rgba(154,74,58,0.10)",
            borderRadius: 7
          }}
        >
          {formError}
        </div>
      )}


      {/* Therapist */}
      <TherapistField label="Therapist">
        <select
          className="a-input"
          value={form.staff_id}
          onChange={(event) =>
            change(
              "staff_id",
              event.target.value
            )
          }
        >
          <option value="">
            Select therapist
          </option>

          {staff
            .filter(
              (member) =>
                member.is_active
            )
            .map((member) => (

              <option
                key={member.id}
                value={member.id}
              >
                {member.first_name}{" "}
                {member.last_name}
              </option>

            ))}
        </select>
      </TherapistField>


      {/* Date */}
      <TherapistField label="Date">
        <input
          className="a-input"
          type="date"
          value={form.date}
          onChange={(event) =>
            change(
              "date",
              event.target.value
            )
          }
        />
      </TherapistField>


      {/* Start + End */}
      <div
        style={{
          display: "grid",
          gridTemplateColumns:
            "1fr 1fr",
          gap: 12
        }}
      >

        <TherapistField label="Start">
          <input
            className="a-input"
            type="time"
            value={form.start_time}
            onChange={(event) =>
              change(
                "start_time",
                event.target.value
              )
            }
          />
        </TherapistField>


        <TherapistField label="Finish">
          <input
            className="a-input"
            type="time"
            value={form.end_time}
            onChange={(event) =>
              change(
                "end_time",
                event.target.value
              )
            }
          />
        </TherapistField>

      </div>


      {/* Break */}
      <TherapistField label="Break minutes">
        <input
          className="a-input"
          type="number"
          min="0"
          step="5"
          value={form.break_minutes}
          onChange={(event) =>
            change(
              "break_minutes",
              event.target.value
            )
          }
        />
      </TherapistField>


      {/* Notes */}
      <TherapistField label="Notes">
        <textarea
          className="a-input"
          rows={3}
          value={form.notes}
          onChange={(event) =>
            change(
              "notes",
              event.target.value
            )
          }
          placeholder="Optional"
        />
      </TherapistField>

    </Drawer>
  );
}

/* SHOW A LOADING PANEL, IN WHICH ALL THE DATA WILL BE SHOWN */

function TeamGrid({
  staff,
  loading,
  error,
  onReload,
  toast,
  onEdit
}) {
  // Show a simple loading panel.
  if (loading) {
    return (
      <Panel>
        <div className="caption">
          Loading therapists…
        </div>
      </Panel>
    );
  }

  // Display the database error with a retry button.
  if (error) {
    return (
      <Panel>
        <div
          style={{
            color: "var(--danger)",
            marginBottom: 14
          }}
        >
          {error}
        </div>

        <Button
          variant="primary"
          size="sm"
          onClick={onReload}
        >
          Try Again
        </Button>
      </Panel>
    );
  }

  // Display this until the first therapist is created.
  if (!staff.length) {
    return (
      <Panel>
        <h3 style={{ marginBottom: 6 }}>
          No therapists found
        </h3>

        <div className="caption">
          Use Add Therapist after completing Step 7C.
        </div>
      </Panel>
    );
  }

  return (
    <div
      style={{
        display: "grid",
        gridTemplateColumns:
          "repeat(auto-fill, minmax(280px, 1fr))",
        gap: 16
      }}
    >
      {staff.map((member) => {
        // Build the displayed name safely.
        const fullName = [
          member.first_name,
          member.last_name
        ]
          .filter(Boolean)
          .join(" ");

        return (
          <Panel key={member.id}>
            <div
              style={{
                display: "flex",
                alignItems: "center",
                gap: 14,
                marginBottom: 16
              }}
            >
              <Avatar
                name={fullName || "Staff"}
                size={48}
                color={member.colour}
              />

              <div style={{ flex: 1 }}>
                <div
                  style={{
                    fontFamily: "var(--font-display)",
                    fontSize: "1.05rem"
                  }}
                >
                  {fullName}
                </div>

                <div className="caption">
                  {member.job_title || "Therapist"}
                </div>
              </div>

              <Pill
                color={
                  member.is_active
                    ? "var(--success)"
                    : "var(--danger)"
                }
                bg={
                  member.is_active
                    ? "rgba(107,122,94,0.16)"
                    : "rgba(154,74,58,0.14)"
                }
                dot
              >
                {member.is_active
                  ? "Active"
                  : "Inactive"}
              </Pill>
            </div>

            <div
              style={{
                display: "grid",
                gap: 9,
                marginBottom: 16
              }}
            >
              <div className="caption">
                Email: {member.email || "—"}
              </div>

              <div className="caption">
                Phone: {member.phone || "—"}
              </div>

              <div className="caption">
                Commission:{" "}
                {Number(
                  member.commission_percent || 0
                ).toFixed(0)}
                %
              </div>

              <div className="caption">
                Online profile:{" "}
                {member.show_online ? "Visible" : "Hidden"}
              </div>
            </div>

            <Button
              variant="ghost"
              size="sm"

              onClick={() => onEdit(member)}
            >
              Manage Therapist
            </Button>
          </Panel>
        );
      })}
    </div>
  );
}

/* =========================================================
   ADD / EDIT THERAPIST FORM
   ========================================================= */

// Empty values used when adding a new therapist.
const EMPTY_THERAPIST_FORM = {
  first_name: "",
  last_name: "",
  job_title: "Therapist",
  email: "",
  phone: "",
  biography: "",
  photo_url: "",
  colour: "#c9a96e",
  commission_percent: "0",
  show_online: true,
  is_active: true,

  // =====================================================
  // SERVICE ROLE
  //
  // Controls treatment seniority and price uplift.
  //
  // skin_specialist  → configurable uplift, default +20%
  // senior_therapist → configurable uplift, default +10%
  // therapist        → normal website price
  // ""               → management/non-treatment staff
  // =====================================================
  service_role: "therapist",

  // =====================================================
  // SYSTEM ACCESS
  //
  // This is NOT stored in staff_members.
  // It belongs to profiles.access_role.
  //
  // Empty until this staff member has a linked login.
  // =====================================================
  access_role: "",

  // Treatments this person can perform.
  service_ids: []
};


// Convert an existing therapist into form values.
function therapistToForm(member) {
  // Adding a new therapist.
  if (!member) {
    return {
      ...EMPTY_THERAPIST_FORM
    };
  }

  // Editing an existing therapist.
  return {
    first_name: member.first_name || "",
    last_name: member.last_name || "",
    job_title: member.job_title || "Therapist",
    email: member.email || "",
    phone: member.phone || "",
    biography: member.biography || "",
    photo_url: member.photo_url || "",
    colour: member.colour || "#c9a96e",

    commission_percent: String(
      member.commission_percent || 0
    ),

    show_online:
      member.show_online !== false,

    is_active:
      member.is_active !== false,

    // Treatment seniority.
    service_role:
      member.service_role || "therapist",

    // System access is loaded separately from profiles
    // because it does not belong to staff_members.
    access_role: "",

    // Load treatments already assigned to this therapist.
    service_ids:
      Array.isArray(member.service_ids)
        ? member.service_ids
        : []
  };
}


function TherapistDrawer({
  editor,
  onClose,
  onSaved,
  services,
  servicesLoading,
  servicesError,
  toast
}) {
  // Holds all form values.
  const [form, setForm] = useState({
    ...EMPTY_THERAPIST_FORM
  });

  // Prevents double clicking Save.
  const [saving, setSaving] = useState(false);

  // Displays form errors.
  const [formError, setFormError] = useState("");

  // Shows while we load the staff member's login role.
  const [accessLoading, setAccessLoading] =
  useState(false);


  // Step 10G — treatment assignment UX.
  const [treatmentsExpanded, setTreatmentsExpanded] =
    useState(false);

  const [treatmentSearch, setTreatmentSearch] =
    useState("");

  const [expandedTreatmentCategories, setExpandedTreatmentCategories] =
    useState({});


  // Whenever a different therapist is opened,
  // populate the form again.
  useEffect(() => {
    if (editor) {
      setForm(
        therapistToForm(editor.member)
      );

      setFormError("");
      setSaving(false);
    }
  }, [editor]);


  // Don't display anything when the drawer is closed.
  if (!editor) {
    return null;
  }


  // Are we editing rather than creating?
  const isEditing =
    editor.mode === "edit";


  // Simple helper for changing form values.
  const change = (field, value) => {
    setForm((current) => ({
      ...current,
      [field]: value
    }));
  };

  // Add or remove a treatment from this therapist.
  const toggleService = (serviceId) => {
    setForm((current) => {
      // Check whether this treatment is already selected.
      const alreadySelected =
        current.service_ids.includes(serviceId);

      return {
        ...current,

        // If selected, remove it.
        // If not selected, add it.
        service_ids: alreadySelected
          ? current.service_ids.filter(
              (id) => id !== serviceId
            )
          : [
              ...current.service_ids,
              serviceId
            ]
      };
    });
  };




  const allServiceIds =
    (services || []).map(service => service.id);

  const allServicesSelected =
    allServiceIds.length > 0 &&
    allServiceIds.every(id => form.service_ids.includes(id));

  const selectedTreatmentCount =
    form.service_ids.length;

  const groupedTreatments =
    (services || []).reduce((groups, service) => {
      const categoryName =
        service.categories?.name ||
        service.category_name ||
        "Other Treatments";

      if (!groups[categoryName]) {
        groups[categoryName] = [];
      }

      groups[categoryName].push(service);
      return groups;
    }, {});

  const categoryNames =
    Object.keys(groupedTreatments).sort((a, b) =>
      a.localeCompare(b)
    );

  const toggleAllServices = () => {
    setForm(current => ({
      ...current,
      service_ids: allServicesSelected
        ? []
        : allServiceIds
    }));
  };

  const toggleCategorySelection = categoryName => {
    const categoryIds =
      (groupedTreatments[categoryName] || [])
        .map(service => service.id);

    const categorySelected =
      categoryIds.length > 0 &&
      categoryIds.every(id => form.service_ids.includes(id));

    setForm(current => ({
      ...current,
      service_ids: categorySelected
        ? current.service_ids.filter(id => !categoryIds.includes(id))
        : Array.from(
            new Set([
              ...current.service_ids,
              ...categoryIds
            ])
          )
    }));
  };

  const toggleCategoryOpen = categoryName => {
    setExpandedTreatmentCategories(current => ({
      ...current,
      [categoryName]: !current[categoryName]
    }));
  };




  // Save therapist to Supabase.
  const saveTherapist = async () => {
    setFormError("");

    // First and last name are required.
    if (!form.first_name.trim()) {
      setFormError(
        "Enter the therapist's first name."
      );
      return;
    }

    if (!form.last_name.trim()) {
      setFormError(
        "Enter the therapist's last name."
      );
      return;
    }


    // Build the data sent to Supabase.
    const payload = {
      first_name:
        form.first_name.trim(),

      last_name:
        form.last_name.trim(),

      job_title:
        form.job_title.trim() ||
        "Therapist",

      email:
        form.email.trim() || null,

      phone:
        form.phone.trim() || null,

      biography:
        form.biography.trim() || null,

      photo_url:
        form.photo_url.trim() || null,

      colour:
        form.colour || null,

      commission_percent:
        Number(
          form.commission_percent || 0
        ),

      show_online:
        form.show_online,

      is_active:
        form.is_active,

      // IMPORTANT:
      // Treatment IDs go to staff_services.
      service_ids:
        form.service_ids
    };


    try {
      setSaving(true);

      if (isEditing) {
        // Update existing therapist.
        await window.API.Staff.update(
          editor.member.id,
          payload
        );

        toast(
          "Therapist updated",
          "success"
        );
      } else {
        // Create a new therapist.
        await window.API.Staff.create(
          payload
        );

        toast(
          "Therapist added",
          "success"
        );
      }

      // Close drawer and refresh Team.
      await onSaved();

    } catch (error) {
      console.error(
        "Therapist save failed:",
        error
      );

      setFormError(
        error.message ||
        "Therapist could not be saved."
      );

    } finally {
      setSaving(false);
    }
  };


  return (
    <Drawer
      open={true}
      onClose={
        saving
          ? () => {}
          : onClose
      }

      title={
        isEditing
          ? "Edit Therapist"
          : "Add Therapist"
      }

      subtitle={
        isEditing
          ? `${form.first_name} ${form.last_name}`
          : "Create a staff member"
      }

      footer={
        <>
          <Button
            variant="ghost"
            size="sm"
            onClick={onClose}
            disabled={saving}
          >
            Cancel
          </Button>

          <Button
            variant="primary"
            size="sm"
            onClick={saveTherapist}
            disabled={saving}
          >
            {saving
              ? "Saving…"
              : isEditing
                ? "Save Changes"
                : "Add Therapist"}
          </Button>
        </>
      }
    >

      {/* Display errors here */}
      {formError && (
        <div
          style={{
            padding: 12,
            marginBottom: 18,
            borderRadius: 7,
            color: "var(--danger)",
            background:
              "rgba(154,74,58,0.10)"
          }}
        >
          {formError}
        </div>
      )}


      {/* FIRST NAME */}
      <TherapistField label="First name">
        <input
          className="a-input"
          value={form.first_name}
          onChange={(e) =>
            change(
              "first_name",
              e.target.value
            )
          }
        />
      </TherapistField>


      {/* LAST NAME */}
      <TherapistField label="Last name">
        <input
          className="a-input"
          value={form.last_name}
          onChange={(e) =>
            change(
              "last_name",
              e.target.value
            )
          }
        />
      </TherapistField>


      {/* JOB TITLE */}
      <TherapistField label="Job title">
        <input
          className="a-input"
          value={form.job_title}
          onChange={(e) =>
            change(
              "job_title",
              e.target.value
            )
          }
        />
      </TherapistField>


      {/* EMAIL */}
      <TherapistField label="Email">
        <input
          className="a-input"
          type="email"
          value={form.email}
          onChange={(e) =>
            change(
              "email",
              e.target.value
            )
          }
        />
      </TherapistField>


      {/* PHONE */}
      <TherapistField label="Phone">
        <input
          className="a-input"
          value={form.phone}
          onChange={(e) =>
            change(
              "phone",
              e.target.value
            )
          }
        />
      </TherapistField>


      {/* BIOGRAPHY */}
      <TherapistField label="Biography">
        <textarea
          className="a-input"
          rows={4}
          value={form.biography}
          onChange={(e) =>
            change(
              "biography",
              e.target.value
            )
          }
          style={{
            resize: "vertical"
          }}
        />
      </TherapistField>


      {/* COMMISSION */}
      <TherapistField label="Commission %">
        <input
          className="a-input"
          type="number"
          min="0"
          max="100"
          value={
            form.commission_percent
          }
          onChange={(e) =>
            change(
              "commission_percent",
              e.target.value
            )
          }
        />
      </TherapistField>

      {/* =====================================================
          STEP 10G — TREATMENTS THIS THERAPIST CAN PERFORM
          Grouped · collapsible · Select All
         ===================================================== */}

      <div style={{ marginTop: 24 }}>
        <div
          style={{
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between",
            gap: 12,
            marginBottom: 10
          }}
        >
          <div>
            <div className="a-label">
              Treatments performed
            </div>

            <div
              className="caption"
              style={{ marginTop: 4 }}
            >
              {selectedTreatmentCount} selected
            </div>
          </div>

          <div
            style={{
              display: "flex",
              gap: 8,
              flexWrap: "wrap"
            }}
          >
            <Button
              variant="ghost"
              size="sm"
              onClick={toggleAllServices}
              disabled={servicesLoading || !services.length}
            >
              {allServicesSelected
                ? "Clear all"
                : "Select all"}
            </Button>

            <Button
              variant="ghost"
              size="sm"
              onClick={() =>
                setTreatmentsExpanded(current => !current)
              }
              disabled={servicesLoading || !services.length}
            >
              {treatmentsExpanded
                ? "Collapse"
                : "See all"}
            </Button>
          </div>
        </div>

        {servicesLoading && (
          <div className="caption">
            Loading treatments…
          </div>
        )}

        {servicesError && (
          <div style={{ color: "var(--danger)" }}>
            {servicesError}
          </div>
        )}

        {!servicesLoading &&
          !servicesError &&
          !treatmentsExpanded && (
            <div
              style={{
                padding: "12px 14px",
                border: "1px solid var(--line)",
                borderRadius: 8,
                background: "var(--bg-nude)"
              }}
            >
              <div
                style={{
                  fontFamily: "var(--font-display)",
                  fontSize: "0.84rem"
                }}
              >
                {selectedTreatmentCount
                  ? `${selectedTreatmentCount} treatment${selectedTreatmentCount === 1 ? "" : "s"} selected`
                  : "No treatments selected"}
              </div>

              <div
                className="caption"
                style={{ marginTop: 4 }}
              >
                Click “See all” to browse treatments by category.
              </div>
            </div>
          )}

        {!servicesLoading &&
          !servicesError &&
          treatmentsExpanded && (
            <div>
              <input
                className="a-input"
                value={treatmentSearch}
                onChange={event =>
                  setTreatmentSearch(event.target.value)
                }
                placeholder="Search treatments…"
                style={{ marginBottom: 12 }}
              />

              <div
                style={{
                  border: "1px solid var(--line)",
                  borderRadius: 8,
                  overflow: "hidden"
                }}
              >
                {categoryNames.map(categoryName => {
                  const allCategoryServices =
                    groupedTreatments[categoryName] || [];

                  const query =
                    treatmentSearch.trim().toLowerCase();

                  const visibleServices =
                    query
                      ? allCategoryServices.filter(service =>
                          String(service.name || "")
                            .toLowerCase()
                            .includes(query)
                        )
                      : allCategoryServices;

                  if (!visibleServices.length) {
                    return null;
                  }

                  const categoryIds =
                    allCategoryServices.map(service => service.id);

                  const categorySelected =
                    categoryIds.length > 0 &&
                    categoryIds.every(id => form.service_ids.includes(id));

                  const categoryOpen =
                    query
                      ? true
                      : expandedTreatmentCategories[categoryName] === true;

                  const selectedInCategory =
                    categoryIds.filter(id => form.service_ids.includes(id)).length;

                  return (
                    <div
                      key={categoryName}
                      style={{
                        borderBottom: "1px solid var(--line)"
                      }}
                    >
                      <div
                        style={{
                          display: "flex",
                          alignItems: "center",
                          gap: 10,
                          padding: "11px 12px",
                          background: "var(--bg-nude)"
                        }}
                      >
                        <button
                          type="button"
                          onClick={() => toggleCategoryOpen(categoryName)}
                          style={{
                            flex: 1,
                            display: "flex",
                            alignItems: "center",
                            justifyContent: "space-between",
                            gap: 10,
                            textAlign: "left",
                            color: "var(--ink)"
                          }}
                        >
                          <span
                            style={{
                              fontFamily: "var(--font-display)",
                              fontSize: "0.85rem"
                            }}
                          >
                            {categoryName}
                          </span>

                          <span className="caption">
                            {selectedInCategory}/{categoryIds.length}
                            {" · "}
                            {categoryOpen ? "Hide" : "Show"}
                          </span>
                        </button>

                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() =>
                            toggleCategorySelection(categoryName)
                          }
                        >
                          {categorySelected
                            ? "Clear category"
                            : "Select category"}
                        </Button>
                      </div>

                      {categoryOpen && (
                        <div style={{ padding: "0 12px" }}>
                          {visibleServices.map(service => {
                            const selected =
                              form.service_ids.includes(service.id);

                            return (
                              <label
                                key={service.id}
                                style={{
                                  display: "flex",
                                  alignItems: "center",
                                  gap: 10,
                                  padding: "10px 0",
                                  borderBottom: "1px solid var(--line)",
                                  cursor: "pointer"
                                }}
                              >
                                <input
                                  type="checkbox"
                                  checked={selected}
                                  onChange={() => toggleService(service.id)}
                                />

                                <div style={{ flex: 1 }}>
                                  <div
                                    style={{
                                      fontFamily: "var(--font-display)"
                                    }}
                                  >
                                    {service.name}
                                  </div>

                                  <div className="caption">
                                    {service.duration_minutes} min · £
                                    {Number(
                                      service.sale_price ??
                                      service.price ??
                                      0
                                    ).toFixed(2)}
                                  </div>
                                </div>
                              </label>
                            );
                          })}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          )}
      </div>


      {/* ONLINE PROFILE */}
      <div
        style={{
          display: "flex",
          justifyContent:
            "space-between",
          alignItems: "center",
          marginTop: 24,
          padding: 14,
          background:
            "var(--bg-nude)",
          borderRadius: 8
        }}
      >

        <div>
          <div
            style={{
              fontFamily:
                "var(--font-display)"
            }}
          >
            Show online
          </div>

          <div className="caption">
            Allow clients to see and
            book this therapist.
          </div>
        </div>

        <Toggle
          checked={
            form.show_online
          }

          onChange={() =>
            change(
              "show_online",
              !form.show_online
            )
          }

          size={36}
        />

      </div>

    </Drawer>
  );
}


// Small reusable form-field wrapper.
function TherapistField({
  label,
  children
}) {
  return (
    <div
      style={{
        marginBottom: 16
      }}
    >

      <div className="a-label">
        {label}
      </div>

      {children}

    </div>
  );
}

/* =========================================================
   REAL LEAVE / SICKNESS PANEL
   ========================================================= */

function LeavePanel({
  staff,
  records,
  loading,
  error,
  onReload,
  onEdit,
  onApprove,
  onDecline,
  toast
}) {

  // -------------------------------------------------------
  // Loading
  // -------------------------------------------------------
  if (loading) {
    return (
      <Panel>
        <div className="caption">
          Loading leave records…
        </div>
      </Panel>
    );
  }


  // -------------------------------------------------------
  // Error
  // -------------------------------------------------------
  if (error) {
    return (
      <Panel>

        <div
          style={{
            color: "var(--danger)",
            marginBottom: 12
          }}
        >
          {error}
        </div>

        <Button
          variant="primary"
          size="sm"
          onClick={onReload}
        >
          Try Again
        </Button>

      </Panel>
    );
  }


  // -------------------------------------------------------
  // No records yet
  // -------------------------------------------------------
  if (!records.length) {
    return (
      <Panel>

        <h3 style={{ marginBottom: 6 }}>
          No leave records
        </h3>

        <div className="caption">
          Click Add Leave to record
          annual leave, sickness,
          training or blocked time.
        </div>

      </Panel>
    );
  }


  return (
    <Panel pad={false}>

      {/* Heading */}
      <div
        style={{
          padding: "16px 20px",
          borderBottom:
            "1px solid var(--line)"
        }}
      >
        <h3>
          Leave & Availability
        </h3>

        <div
          className="caption"
          style={{ marginTop: 4 }}
        >
          {records.length} record
          {records.length === 1
            ? ""
            : "s"}
        </div>
      </div>


      {/* Records */}
      {records.map((record) => {

        // Find staff member connected
        // to this leave record.
        const member =
          staff.find(
            (person) =>
              person.id ===
              record.staff_id
          );


        // Build therapist name.
        const therapistName =
          member
            ? [
                member.first_name,
                member.last_name
              ]
                .filter(Boolean)
                .join(" ")
            : "Unknown staff";


        // Format dates.
        const start =
          new Date(record.start_at);

        const end =
          new Date(record.end_at);


        const startText =
          start.toLocaleDateString(
            "en-GB",
            {
              day: "numeric",
              month: "short",
              year: "numeric"
            }
          );


        const endText =
          end.toLocaleDateString(
            "en-GB",
            {
              day: "numeric",
              month: "short",
              year: "numeric"
            }
          );


        // Nice label for each type.
        const typeLabels = {
          leave: "Annual Leave",
          sick: "Sickness",
          training: "Training",
          blocked: "Blocked Time"
        };


        const typeLabel =
          typeLabels[record.type] ||
          record.type;


        return (
          <div
            key={record.id}
            style={{
              display: "flex",
              alignItems: "center",
              gap: 14,
              padding: "16px 20px",
              borderBottom:
                "1px solid var(--line)"
            }}
          >

            {/* Staff avatar */}
            <Avatar
              name={therapistName}
              size={38}
              color={member?.colour}
            />


            {/* Leave information */}
            <div style={{ flex: 1 }}>

              <div
                style={{
                  fontFamily:
                    "var(--font-display)"
                }}
              >
                {therapistName}
              </div>

              <div className="caption">
                {typeLabel}
                {" · "}
                {startText}

                {startText !== endText &&
                  ` – ${endText}`}
              </div>

              {record.notes && (
                <div
                  className="caption"
                  style={{ marginTop: 3 }}
                >
                  {record.notes}
                </div>
              )}

            </div>


            {/* Status */}
            <Pill
              color={
                record.status === "approved"
                  ? "var(--success)"
                  : record.status === "declined"
                    ? "var(--danger)"
                    : "var(--gold-deep)"
              }

              bg={
                record.status === "approved"
                  ? "rgba(107,122,94,0.16)"
                  : record.status === "declined"
                    ? "rgba(154,74,58,0.14)"
                    : "var(--bg-nude)"
              }

              dot
            >
              {record.status}
            </Pill>


            {/* Pending requests get approve/decline buttons */}
            {record.status === "pending" && (
              <div
                style={{
                  display: "flex",
                  gap: 5
                }}
              >

                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() =>
                    onApprove(record)
                  }
                >
                  Approve
                </Button>

                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() =>
                    onDecline(record)
                  }
                >
                  Decline
                </Button>

              </div>
            )}


            {/* Edit */}
            <Button
              variant="ghost"
              size="sm"
              onClick={() =>
                onEdit(record)
              }
            >
              Edit
            </Button>

          </div>
        );
      })}

    </Panel>
  );
}

/* =========================================================
   ADD / EDIT LEAVE DRAWER
   ========================================================= */

const EMPTY_LEAVE_FORM = {
  staff_id: "",
  type: "leave",
  start_date: "",
  start_time: "09:00",
  end_date: "",
  end_time: "17:00",
  status: "pending",
  notes: ""
};


function LeaveDrawer({
  editor,
  staff,
  onClose,
  onSaved,
  onDelete,
  toast
}) {

  // Current form values.
  const [form, setForm] =
    useState({
      ...EMPTY_LEAVE_FORM
    });


  // Saving indicator.
  const [saving, setSaving] =
    useState(false);


  // Form error message.
  const [formError, setFormError] =
    useState("");


  // -------------------------------------------------------
  // Populate form when drawer opens.
  // -------------------------------------------------------
  useEffect(() => {

    if (!editor) {
      return;
    }


    // Editing existing record.
    if (
      editor.mode === "edit" &&
      editor.record
    ) {

      const start =
        new Date(editor.record.start_at);

      const end =
        new Date(editor.record.end_at);


      // Helper: yyyy-mm-dd
      const dateValue = (date) =>
        date.getFullYear() +
        "-" +
        String(
          date.getMonth() + 1
        ).padStart(2, "0") +
        "-" +
        String(
          date.getDate()
        ).padStart(2, "0");


      // Helper: HH:mm
      const timeValue = (date) =>
        String(
          date.getHours()
        ).padStart(2, "0") +
        ":" +
        String(
          date.getMinutes()
        ).padStart(2, "0");


      setForm({
        staff_id:
          editor.record.staff_id || "",

        type:
          editor.record.type || "leave",

        start_date:
          dateValue(start),

        start_time:
          timeValue(start),

        end_date:
          dateValue(end),

        end_time:
          timeValue(end),

        status:
          editor.record.status ||
          "pending",

        notes:
          editor.record.notes || ""
      });

    } else {

      // New record.
      setForm({
        ...EMPTY_LEAVE_FORM,

        // Select first active therapist
        // if available.
        staff_id:
          staff.find(
            (member) =>
              member.is_active
          )?.id || ""
      });
    }


    setFormError("");
    setSaving(false);

  }, [editor, staff]);


  // Drawer closed.
  if (!editor) {
    return null;
  }


  const isEditing =
    editor.mode === "edit";


  // -------------------------------------------------------
  // Change form field.
  // -------------------------------------------------------
  const change = (field, value) => {

    setForm((current) => ({
      ...current,
      [field]: value
    }));
  };


  // -------------------------------------------------------
  // SAVE
  // -------------------------------------------------------
  const saveLeave = async () => {

    setFormError("");


    if (!form.staff_id) {
      setFormError(
        "Select a staff member."
      );
      return;
    }


    if (
      !form.start_date ||
      !form.end_date
    ) {
      setFormError(
        "Select start and end dates."
      );
      return;
    }


    // Combine date + time.
    const start =
      new Date(
        `${form.start_date}T${form.start_time}`
      );


    const end =
      new Date(
        `${form.end_date}T${form.end_time}`
      );


    if (end <= start) {
      setFormError(
        "End date/time must be after the start."
      );

      return;
    }


    // Build Supabase payload.
    const payload = {
      staff_id:
        form.staff_id,

      type:
        form.type,

      start_at:
        start.toISOString(),

      end_at:
        end.toISOString(),

      status:
        form.status,

      notes:
        form.notes.trim() || null
    };


    try {

      setSaving(true);


      if (isEditing) {

        // Update existing record.
        await window.API.Leave.update(
          editor.record.id,
          payload
        );

        toast(
          "Leave record updated",
          "success"
        );

      } else {

        // Create new record.
        await window.API.Leave.create(
          payload
        );

        toast(
          "Leave record added",
          "success"
        );
      }


      await onSaved();


    } catch (error) {

      console.error(
        "Leave save failed:",
        error
      );


      setFormError(
        error.message ||
        "Leave record could not be saved."
      );


    } finally {

      setSaving(false);
    }
  };


  return (
    <Drawer
      open={true}

      onClose={
        saving
          ? () => {}
          : onClose
      }

      title={
        isEditing
          ? "Edit Leave"
          : "Add Leave"
      }

      subtitle="Staff availability"

      footer={
        <>
          {/* Delete only when editing */}
          {isEditing && (
            <Button
              variant="ghost"
              size="sm"
              onClick={() =>
                onDelete(
                  editor.record
                )
              }
              disabled={saving}
            >
              Delete
            </Button>
          )}

          <Button
            variant="ghost"
            size="sm"
            onClick={onClose}
            disabled={saving}
          >
            Cancel
          </Button>

          <Button
            variant="primary"
            size="sm"
            onClick={saveLeave}
            disabled={saving}
          >
            {saving
              ? "Saving…"
              : isEditing
                ? "Save Changes"
                : "Add Leave"}
          </Button>
        </>
      }
    >

      {/* Error */}
      {formError && (
        <div
          style={{
            padding: 12,
            marginBottom: 16,
            color: "var(--danger)",
            background:
              "rgba(154,74,58,0.10)",
            borderRadius: 7
          }}
        >
          {formError}
        </div>
      )}


      {/* Staff member */}
      <TherapistField label="Staff member">

        <select
          className="a-input"
          value={form.staff_id}

          onChange={(event) =>
            change(
              "staff_id",
              event.target.value
            )
          }
        >

          <option value="">
            Select staff member
          </option>

          {staff
            .filter(
              (member) =>
                member.is_active
            )
            .map((member) => (

              <option
                key={member.id}
                value={member.id}
              >
                {member.first_name}{" "}
                {member.last_name}
              </option>

            ))}

        </select>

      </TherapistField>


      {/* Leave type */}
      <TherapistField label="Type">

        <select
          className="a-input"
          value={form.type}

          onChange={(event) =>
            change(
              "type",
              event.target.value
            )
          }
        >

          <option value="leave">
            Annual Leave
          </option>

          <option value="sick">
            Sickness
          </option>

          <option value="training">
            Training
          </option>

          <option value="blocked">
            Blocked Time
          </option>

        </select>

      </TherapistField>


      {/* Start */}
      <TherapistField label="Start date">

        <input
          className="a-input"
          type="date"
          value={form.start_date}

          onChange={(event) =>
            change(
              "start_date",
              event.target.value
            )
          }
        />

      </TherapistField>


      <TherapistField label="Start time">

        <input
          className="a-input"
          type="time"
          value={form.start_time}

          onChange={(event) =>
            change(
              "start_time",
              event.target.value
            )
          }
        />

      </TherapistField>


      {/* End */}
      <TherapistField label="End date">

        <input
          className="a-input"
          type="date"
          value={form.end_date}

          onChange={(event) =>
            change(
              "end_date",
              event.target.value
            )
          }
        />

      </TherapistField>


      <TherapistField label="End time">

        <input
          className="a-input"
          type="time"
          value={form.end_time}

          onChange={(event) =>
            change(
              "end_time",
              event.target.value
            )
          }
        />

      </TherapistField>


      {/* Status */}
      <TherapistField label="Status">

        <select
          className="a-input"
          value={form.status}

          onChange={(event) =>
            change(
              "status",
              event.target.value
            )
          }
        >

          <option value="pending">
            Pending
          </option>

          <option value="approved">
            Approved
          </option>

          <option value="declined">
            Declined
          </option>

        </select>

      </TherapistField>


      {/* Notes */}
      <TherapistField label="Notes">

        <textarea
          className="a-input"
          rows={3}
          value={form.notes}

          onChange={(event) =>
            change(
              "notes",
              event.target.value
            )
          }

          placeholder="Optional notes"
        />

      </TherapistField>

    </Drawer>
  );
}

/* =========================================================
   SERVICE ROLE PRICING

   Admin and Super Admin can change the percentage
   added to treatment prices for each service role.
   ========================================================= */

function RolePricingPanel({
    settings,
    loading,
    error,
    onReload,
    toast
  }) {

    // Local editable percentage values.
    const [values, setValues] =
      useState({});

    // Stores which role is currently saving.
    const [savingRole, setSavingRole] =
      useState(null);


    // -------------------------------------------------------
    // Copy Supabase pricing into editable fields.
    // -------------------------------------------------------
    useEffect(() => {

      const nextValues = {};

      settings.forEach((setting) => {

        nextValues[
          setting.role_code
        ] =
          String(
            setting.price_markup_percent ?? 0
          );

      });

      setValues(nextValues);

    }, [settings]);


    // -------------------------------------------------------
    // Loading
    // -------------------------------------------------------
    if (loading) {

      return (
        <Panel>

          <div className="caption">
            Loading role pricing…
          </div>

        </Panel>
      );
    }


    // -------------------------------------------------------
    // Error
    // -------------------------------------------------------
    if (error) {

      return (
        <Panel>

          <div
            style={{
              color: "var(--danger)",
              marginBottom: 12
            }}
          >
            {error}
          </div>


          <Button
            variant="primary"
            size="sm"
            onClick={onReload}
          >
            Try Again
          </Button>

        </Panel>
      );
    }


    // -------------------------------------------------------
    // Save one role percentage.
    // -------------------------------------------------------
    const saveRole =
      async (setting) => {

        const percentage =
          Number(
            values[
              setting.role_code
            ]
          );


        // Validate.
        if (
          Number.isNaN(percentage) ||
          percentage < 0 ||
          percentage > 100
        ) {

          toast(
            "Enter a percentage between 0 and 100."
          );

          return;
        }


        try {

          setSavingRole(
            setting.role_code
          );


          // Save new percentage to Supabase.
          await window.API
            .ServiceRolePricing
            .update(
              setting.role_code,
              percentage
            );


          toast(
            `${setting.label} pricing updated`,
            "success"
          );


          // Reload latest database values.
          await onReload();


        } catch (error) {

          console.error(
            "Role pricing save failed:",
            error
          );


          toast(
            error.message ||
            "Pricing could not be updated."
          );


        } finally {

          setSavingRole(null);
        }
      };


    return (
      <Panel>

        {/* ===================================================
            HEADER
          =================================================== */}

        <div
          style={{
            marginBottom: 22
          }}
        >

          <h3>
            Treatment Role Pricing
          </h3>


          <div
            className="caption"
            style={{
              marginTop: 5,
              maxWidth: 620
            }}
          >
            Set the percentage added to the normal
            treatment price when a service is provided
            by each staff level.
          </div>

        </div>


        {/* ===================================================
            PRICING ROWS
          =================================================== */}

        <div
          style={{
            display: "flex",
            flexDirection: "column",
            gap: 12
          }}
        >

          {settings.map((setting) => {

            const value =
              values[
                setting.role_code
              ] ?? "0";


            // Preview based on a £100 treatment.
            const previewPrice =
              100 *
              (
                1 +
                Number(
                  value || 0
                ) / 100
              );


            return (

              <div
                key={setting.role_code}

                style={{
                  display: "grid",
                  gridTemplateColumns:
                    "1fr 130px 120px",
                  gap: 14,
                  alignItems: "center",
                  padding: 16,
                  border:
                    "1px solid var(--line)",
                  borderRadius: 8
                }}
              >

                {/* Role */}
                <div>

                  <div
                    style={{
                      fontFamily:
                        "var(--font-display)",
                      fontSize: "0.95rem"
                    }}
                  >
                    {setting.label}
                  </div>


                  <div
                    className="caption"
                    style={{
                      marginTop: 4
                    }}
                  >
                    £100 treatment becomes{" "}
                    £{previewPrice.toFixed(2)}
                  </div>

                </div>


                {/* Percentage */}
                <div
                  style={{
                    display: "flex",
                    alignItems: "center",
                    gap: 6
                  }}
                >

                  <input
                    className="a-input"
                    type="number"

                    min="0"
                    max="100"
                    step="0.5"

                    value={value}

                    onChange={(event) => {

                      setValues(
                        (current) => ({
                          ...current,

                          [setting.role_code]:
                            event.target.value
                        })
                      );

                    }}
                  />


                  <span>
                    %
                  </span>

                </div>


                {/* Save */}
                <Button
                  variant="primary"
                  size="sm"

                  disabled={
                    savingRole ===
                    setting.role_code
                  }

                  onClick={() =>
                    saveRole(setting)
                  }
                >

                  {savingRole ===
                  setting.role_code
                    ? "Saving…"
                    : "Save"}

                </Button>

              </div>

            );

          })}

        </div>


        {/* ===================================================
            INFORMATION
          =================================================== */}

        <div
          style={{
            marginTop: 20,
            padding: 14,
            borderRadius: 8,
            background:
              "var(--bg-nude)"
          }}
        >

          <div
            style={{
              fontFamily:
                "var(--font-display)",
              fontSize: "0.85rem"
            }}
          >
            Changes apply to future bookings
          </div>


          <div
            className="caption"
            style={{
              marginTop: 4
            }}
          >
            Existing confirmed bookings should retain
            the price recorded when the booking was made.
          </div>

        </div>

      </Panel>
    );
  }

/* =====================================================================
   CATALOG — services / products / packages / memberships / gift cards
   ===================================================================== */
function ModuleCatalog() {
  const [tab, setTab] =
    useState("services");

  // --------------------------------------------------------
  // REAL TREATMENTS
  // --------------------------------------------------------

  const [services, setServices] =
    useState([]);

  const [servicesLoading, setServicesLoading] =
    useState(false);

  const [servicesError, setServicesError] =
    useState("");

  const [serviceCategories, setServiceCategories] =
    useState([]);

  const [serviceEditor, setServiceEditor] =
    useState(null);


  // --------------------------------------------------------
  // CURRENT ACCESS ROLE
  // Catalogue remains readable by practitioners,
  // but only Admin/Super Admin get treatment controls.
  // --------------------------------------------------------

  const [catalogAccessRole, setCatalogAccessRole] =
    useState(null);

  const canManageCatalog =
    catalogAccessRole === "super_admin" ||
    catalogAccessRole === "admin";


  // --------------------------------------------------------
  // PRODUCTS — existing implementation
  // --------------------------------------------------------

  const [products, setProducts] =
    useState([]);

  const [productsLoading, setProductsLoading] =
    useState(false);

  const [productsError, setProductsError] =
    useState("");

  const [productEditor, setProductEditor] =
    useState(null);

  const toast = useToast();


  // --------------------------------------------------------
  // LOAD REAL ACCESS ROLE
  // --------------------------------------------------------

  useEffect(() => {

    let active = true;


    async function loadRole() {

      try {

        const {
          data,
          error
        } =
          await window.supabaseClient
            .rpc(
              "current_access_role"
            );


        if (error) {
          throw error;
        }


        if (active) {
          setCatalogAccessRole(data);
        }


      } catch (error) {

        console.error(
          "Catalog role loading failed:",
          error
        );


        if (active) {
          setCatalogAccessRole(null);
        }

      }

    }


    loadRole();


    return () => {
      active = false;
    };

  }, []);


  // --------------------------------------------------------
  // LOAD TREATMENTS + CATEGORIES
  // --------------------------------------------------------

  const loadServices =
    useCallback(async () => {

      try {

        setServicesLoading(true);
        setServicesError("");


        if (
          !window.API?.Services?.listAdmin ||
          !window.API?.Categories?.listServices
        ) {
          throw new Error(
            "Treatment API is unavailable. Replace src/services/api.jsx with the Step 10B2 version."
          );
        }


        const [
          treatmentRows,
          categoryRows
        ] =
          await Promise.all([
            window.API.Services.listAdmin(),
            window.API.Categories.listServices()
          ]);


        setServices(
          Array.isArray(treatmentRows)
            ? treatmentRows
            : []
        );


        setServiceCategories(
          Array.isArray(categoryRows)
            ? categoryRows
            : []
        );


      } catch (error) {

        console.error(
          "Treatment catalogue failed:",
          error
        );


        setServices([]);
        setServiceCategories([]);

        setServicesError(
          error.message ||
          "Treatments could not be loaded."
        );


      } finally {

        setServicesLoading(false);

      }

    }, []);


  useEffect(() => {

    if (tab === "services") {
      loadServices();
    }

  }, [tab, loadServices]);


  // --------------------------------------------------------
  // PRODUCTS — existing loading
  // --------------------------------------------------------

  const loadProducts =
    useCallback(async () => {

      try {

        setProductsLoading(true);
        setProductsError("");

        const result =
          await API.Products.list();

        const rows =
          Array.isArray(result)
            ? result
            : result?.results || [];

        setProducts(rows);


      } catch (error) {

        console.error(
          "Could not load products:",
          error
        );

        setProductsError(
          error.message ||
          "Products could not be loaded."
        );


      } finally {

        setProductsLoading(false);

      }

    }, []);


  useEffect(() => {

    if (tab === "products") {
      loadProducts();
    }

  }, [tab, loadProducts]);


  // --------------------------------------------------------
  // MAIN ADD BUTTON
  // --------------------------------------------------------

  const openAddItem = () => {

    if (!canManageCatalog) {

      toast(
        "Your role has read-only catalogue access."
      );

      return;
    }


    if (tab === "services") {

      setServiceEditor({
        mode: "create",
        service: null
      });

      return;
    }


    if (tab === "products") {

      setProductEditor({
        mode: "create",
        product: null
      });

      return;
    }


  };


  // --------------------------------------------------------
  // TREATMENT ACTIONS
  // --------------------------------------------------------

  const handleServiceSaved =
    async () => {

      setServiceEditor(null);
      await loadServices();

    };


  const handleToggleTreatmentOnline =
    async (service) => {

      try {

        if (
          !service.is_active &&
          !service.bookable_online
        ) {

          toast(
            "Activate the treatment before enabling online booking."
          );

          return;
        }


        await window.API.Services.update(
          service.id,
          {
            bookable_online:
              !service.bookable_online
          }
        );


        toast(
          service.bookable_online
            ? "Online booking disabled"
            : "Online booking enabled",
          "success"
        );


        await loadServices();


      } catch (error) {

        console.error(
          "Treatment online toggle failed:",
          error
        );

        toast(
          error.message ||
          "Treatment could not be updated."
        );

      }

    };


  const handleToggleTreatmentActive =
    async (service) => {

      try {

        if (service.is_active) {

          const confirmed =
            window.confirm(
              `Deactivate "${service.name}"?\n\n` +
              "It will be removed from online booking, but existing booking history and treatment relationships will be preserved."
            );


          if (!confirmed) {
            return;
          }


          await window.API.Services
            .deactivate(service.id);


          toast(
            "Treatment deactivated",
            "success"
          );


        } else {

          await window.API.Services
            .activate(service.id);


          toast(
            "Treatment activated",
            "success"
          );

        }


        await loadServices();


      } catch (error) {

        console.error(
          "Treatment status update failed:",
          error
        );

        toast(
          error.message ||
          "Treatment status could not be updated."
        );

      }

    };


  // --------------------------------------------------------
  // PRODUCTS — existing actions
  // --------------------------------------------------------

  const handleProductSaved =
    async () => {

      setProductEditor(null);
      await loadProducts();

    };


  const handleToggleOnline =
    async (product) => {

      try {

        await API.Products.update(
          product.id,
          {
            sellable_online:
              !product.sellable_online
          }
        );


        toast(
          product.sellable_online
            ? "Product removed from online shop"
            : "Product added to online shop",
          "success"
        );


        await loadProducts();


      } catch (error) {

        console.error(error);

        toast(
          error.message ||
          "Product could not be updated."
        );

      }

    };


  const handleDeactivateProduct =
    async (product) => {

      const confirmed =
        window.confirm(
          `Deactivate "${product.name}"?\n\n` +
          "It will no longer appear in the online shop, but its history will remain."
        );


      if (!confirmed) {
        return;
      }


      try {

        await API.Products
          .deactivate(product.id);


        toast(
          "Product deactivated",
          "success"
        );


        await loadProducts();


      } catch (error) {

        console.error(error);

        toast(
          error.message ||
          "Product could not be deactivated."
        );

      }

    };


  // --------------------------------------------------------
  // DISPLAY
  // --------------------------------------------------------

  return (

    <div>

      <PageHead
        eyebrow="Menu & retail"
        title="Catalog"
      >

        {canManageCatalog && (

          <Button
            variant="primary"
            size="sm"
            icon="plus"
            onClick={openAddItem}
          >
            {tab === "services"
              ? "Add Treatment"
              : "Add Product"}
          </Button>

        )}

      </PageHead>


      <div
        style={{
          marginBottom: 20
        }}
      >

        <Tabs
          active={tab}
          onChange={setTab}
          tabs={[
            {
              id: "services",
              label: "Treatments",
              count: services.length
            },
            {
              id: "products",
              label: "Products",
              count: products.length
            }
          ]}
        />

      </div>


      {tab === "services" && (

        <ServicesTable
          services={services}
          loading={servicesLoading}
          error={servicesError}
          canManage={canManageCatalog}
          onReload={loadServices}

          onEdit={(service) =>
            setServiceEditor({
              mode: "edit",
              service: service
            })
          }

          onToggleOnline={
            handleToggleTreatmentOnline
          }

          onToggleActive={
            handleToggleTreatmentActive
          }
        />

      )}


      {tab === "products" && (

        <ProductsTable
          products={products}
          loading={productsLoading}
          error={productsError}
          onReload={loadProducts}

          onEdit={(product) => {
            setProductEditor({
              mode: "edit",
              product
            });
          }}

          onToggleOnline={handleToggleOnline}

          onDeactivate={
            handleDeactivateProduct
          }
        />

      )}


      <TreatmentDrawer
        editor={serviceEditor}
        categories={serviceCategories}

        onClose={() =>
          setServiceEditor(null)
        }

        onSaved={
          handleServiceSaved
        }

        toast={toast}
      />


      <ProductDrawer
        editor={productEditor}

        onClose={() =>
          setProductEditor(null)
        }

        onSaved={
          handleProductSaved
        }

        toast={toast}
      />

    </div>

  );

}


/* =========================================================
   REAL SUPABASE TREATMENTS TABLE
   ========================================================= */

function ServicesTable({
  services,
  loading,
  error,
  canManage,
  onReload,
  onEdit,
  onToggleOnline,
  onToggleActive
}) {

  if (loading) {

    return (
      <Panel>
        <SkeletonRows rows={5}/>
      </Panel>
    );

  }


  if (error) {

    return (
      <Panel>

        <EmptyBlock
          icon="alert"
          title="Treatments could not be loaded"
          sub={error}

          action={
            <Button
              variant="primary"
              size="sm"
              onClick={onReload}
            >
              Try Again
            </Button>
          }
        />

      </Panel>
    );

  }


  if (!services.length) {

    return (
      <Panel>

        <EmptyBlock
          title="No treatments yet"
          sub={
            canManage
              ? 'Click "Add Treatment" to create the first treatment.'
              : "No treatments are currently available."
          }
        />

      </Panel>
    );

  }


  return (

    <Panel
      pad={false}
      style={{
        overflow: "hidden"
      }}
    >

      <div
        style={{
          overflowX: "auto"
        }}
        className="hide-scroll"
      >

        <table className="atable">

          <thead>
            <tr>
              <th>Treatment</th>
              <th>Category</th>
              <th>Duration</th>
              <th>Price</th>
              <th>Deposit</th>
              <th>Therapists</th>
              <th>Resources</th>
              <th>Online</th>
              <th>Status</th>
              {canManage && <th></th>}
            </tr>
          </thead>


          <tbody>

            {services.map(
              (service) => {

                const salePrice =
                  service.sale_price !== null &&
                  service.sale_price !== undefined
                    ? Number(
                        service.sale_price
                      )
                    : null;


                const categoryName =
                  service.categories?.name ||
                  "Uncategorised";


                return (

                  <tr
                    key={service.id}
                    style={{
                      opacity:
                        service.is_active
                          ? 1
                          : 0.62
                    }}
                  >

                    <td>

                      <div
                        style={{
                          fontFamily:
                            "var(--font-display)",
                          fontSize: "0.92rem"
                        }}
                      >
                        {service.name}
                      </div>


                      {service.buffer_minutes > 0 && (

                        <div
                          className="caption"
                          style={{
                            fontSize: "0.68rem",
                            marginTop: 2
                          }}
                        >
                          + {service.buffer_minutes} min buffer
                        </div>

                      )}

                    </td>


                    <td>

                      <span
                        className="chip chip-line"
                        style={{
                          fontSize: "0.64rem"
                        }}
                      >
                        {categoryName}
                      </span>

                    </td>


                    <td>
                      {service.duration_minutes} min
                    </td>


                    <td
                      style={{
                        fontFamily:
                          "var(--font-display)"
                      }}
                    >

                      {salePrice !== null ? (

                        <>
                          <span
                            style={{
                              color:
                                "var(--gold-deep)"
                            }}
                          >
                            £{salePrice.toFixed(2)}
                          </span>

                          <div
                            className="caption"
                            style={{
                              textDecoration:
                                "line-through"
                            }}
                          >
                            £{Number(
                              service.price
                            ).toFixed(2)}
                          </div>
                        </>

                      ) : (

                        <>£{Number(
                          service.price
                        ).toFixed(2)}</>

                      )}

                    </td>


                    <td>
                      {Number(
                        service.deposit_percent || 0
                      ).toFixed(0)}%
                    </td>


                    <td
                      style={{
                        fontFamily:
                          "var(--font-display)"
                      }}
                    >
                      {Number(
                        service.therapist_count || 0
                      )}
                    </td>


                    <td
                      style={{
                        fontFamily:
                          "var(--font-display)"
                      }}
                    >
                      {Number(
                        service.resource_count || 0
                      )}
                    </td>


                    <td>

                      {canManage ? (

                        <Toggle
                          checked={
                            service.bookable_online
                          }
                          onChange={() =>
                            onToggleOnline(service)
                          }
                          size={36}
                        />

                      ) : (

                        <span className="caption">
                          {service.bookable_online
                            ? "Yes"
                            : "No"}
                        </span>

                      )}

                    </td>


                    <td>

                      <Pill
                        color={
                          service.is_active
                            ? "var(--success)"
                            : "var(--danger)"
                        }
                        bg={
                          service.is_active
                            ? "rgba(107,122,94,0.16)"
                            : "rgba(154,74,58,0.14)"
                        }
                        dot
                      >
                        {service.is_active
                          ? "Active"
                          : "Inactive"}
                      </Pill>

                    </td>


                    {canManage && (

                      <td>

                        <div
                          style={{
                            display: "flex",
                            gap: 5,
                            alignItems: "center"
                          }}
                        >

                          <button
                            className="icon-btn"
                            style={{
                              width: 32,
                              height: 32
                            }}
                            onClick={() =>
                              onEdit(service)
                            }
                            title="Edit treatment"
                          >
                            <Icon
                              name="edit"
                              size={15}
                            />
                          </button>


                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() =>
                              onToggleActive(
                                service
                              )
                            }
                          >
                            {service.is_active
                              ? "Deactivate"
                              : "Activate"}
                          </Button>

                        </div>

                      </td>

                    )}

                  </tr>

                );

              }
            )}

          </tbody>

        </table>

      </div>

    </Panel>

  );

}


/* =========================================================
   ADD / EDIT TREATMENT
   ========================================================= */

const EMPTY_TREATMENT_FORM = {

  name: "",
  category_id: "",
  description: "",

  duration_minutes: "60",
  buffer_minutes: "10",

  price: "",
  sale_price: "",
  deposit_percent: "30",

  image_url: "",

  bookable_online: true,
  is_active: true

};


function serviceSlug(value) {

  return String(value || "")
    .toLowerCase()
    .trim()
    .replace(/&/g, "and")
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "");

}


function treatmentToForm(service) {

  if (!service) {

    return {
      ...EMPTY_TREATMENT_FORM
    };

  }


  return {

    name:
      service.name || "",

    category_id:
      service.category_id || "",

    description:
      service.description || "",

    duration_minutes:
      String(
        service.duration_minutes ?? 60
      ),

    buffer_minutes:
      String(
        service.buffer_minutes ?? 0
      ),

    price:
      service.price !== null &&
      service.price !== undefined
        ? String(service.price)
        : "",

    sale_price:
      service.sale_price !== null &&
      service.sale_price !== undefined
        ? String(service.sale_price)
        : "",

    deposit_percent:
      String(
        service.deposit_percent ?? 30
      ),

    image_url:
      service.image_url || "",

    bookable_online:
      service.bookable_online !== false,

    is_active:
      service.is_active !== false

  };

}


function TreatmentDrawer({
  editor,
  categories,
  onClose,
  onSaved,
  toast
}) {

  const [form, setForm] =
    useState({
      ...EMPTY_TREATMENT_FORM
    });


  const [
    categoryOptions,
    setCategoryOptions
  ] =
    useState([]);


  const [
    newCategory,
    setNewCategory
  ] =
    useState("");


  const [
    categorySaving,
    setCategorySaving
  ] =
    useState(false);


  const [saving, setSaving] =
    useState(false);


  const [
    formError,
    setFormError
  ] =
    useState("");


  useEffect(() => {

    setCategoryOptions(
      Array.isArray(categories)
        ? categories
        : []
    );

  }, [categories]);


  useEffect(() => {

    if (!editor) {
      return;
    }


    setForm(
      treatmentToForm(
        editor.service
      )
    );


    setNewCategory("");
    setFormError("");
    setSaving(false);

  }, [editor]);


  if (!editor) {
    return null;
  }


  const isEditing =
    editor.mode === "edit";


  const change =
    (field, value) => {

      setForm(
        current => ({
          ...current,
          [field]: value
        })
      );

    };


  // --------------------------------------------------------
  // CREATE A SERVICE CATEGORY INLINE
  // --------------------------------------------------------

  const addCategory =
    async () => {

      const name =
        newCategory.trim();


      if (!name) {

        setFormError(
          "Enter the new category name."
        );

        return;
      }


      try {

        setCategorySaving(true);
        setFormError("");


        const created =
          await window.API
            .Categories
            .createService(name);


        setCategoryOptions(
          current => [
            ...current,
            created
          ]
        );


        change(
          "category_id",
          created.id
        );


        setNewCategory("");


        toast(
          "Treatment category added",
          "success"
        );


      } catch (error) {

        console.error(
          "Category creation failed:",
          error
        );


        if (
          error?.code === "23505"
        ) {

          setFormError(
            "A treatment category with this name already exists."
          );

        } else {

          setFormError(
            error.message ||
            "Category could not be added."
          );

        }


      } finally {

        setCategorySaving(false);

      }

    };


  // --------------------------------------------------------
  // SAVE TREATMENT
  // --------------------------------------------------------

  const saveTreatment =
    async () => {

      setFormError("");


      const name =
        form.name.trim();


      const duration =
        Number(
          form.duration_minutes
        );


      const buffer =
        Number(
          form.buffer_minutes || 0
        );


      const price =
        Number(
          form.price
        );


      const salePrice =
        form.sale_price === ""
          ? null
          : Number(
              form.sale_price
            );


      const deposit =
        Number(
          form.deposit_percent
        );


      if (!name) {

        setFormError(
          "Enter the treatment name."
        );

        return;
      }


      if (
        !Number.isInteger(duration) ||
        duration <= 0
      ) {

        setFormError(
          "Duration must be a whole number greater than 0."
        );

        return;
      }


      if (
        !Number.isInteger(buffer) ||
        buffer < 0
      ) {

        setFormError(
          "Buffer must be a whole number of 0 or more."
        );

        return;
      }


      if (
        form.price === "" ||
        Number.isNaN(price) ||
        price < 0
      ) {

        setFormError(
          "Enter a valid treatment price."
        );

        return;
      }


      if (
        salePrice !== null &&
        (
          Number.isNaN(salePrice) ||
          salePrice < 0
        )
      ) {

        setFormError(
          "Enter a valid sale price."
        );

        return;
      }


      if (
        salePrice !== null &&
        salePrice > price
      ) {

        setFormError(
          "Sale price should not be higher than the normal price."
        );

        return;
      }


      if (
        Number.isNaN(deposit) ||
        deposit < 0 ||
        deposit > 100
      ) {

        setFormError(
          "Deposit must be between 0% and 100%."
        );

        return;
      }


      const payload = {

        name: name,

        slug:
          isEditing &&
          editor.service.slug
            ? editor.service.slug
            : serviceSlug(name),

        category_id:
          form.category_id || null,

        description:
          form.description.trim() ||
          null,

        duration_minutes:
          duration,

        buffer_minutes:
          buffer,

        price:
          price,

        sale_price:
          salePrice,

        deposit_percent:
          deposit,

        image_url:
          form.image_url.trim() ||
          null,

        bookable_online:
          form.is_active
            ? form.bookable_online
            : false,

        is_active:
          form.is_active

      };


      if (!payload.slug) {

        setFormError(
          "Treatment name must contain letters or numbers."
        );

        return;
      }


      try {

        setSaving(true);


        if (isEditing) {

          await window.API
            .Services
            .update(
              editor.service.id,
              payload
            );


          toast(
            "Treatment updated",
            "success"
          );


        } else {

          await window.API
            .Services
            .create(payload);


          toast(
            "Treatment added",
            "success"
          );

        }


        await onSaved();


      } catch (error) {

        console.error(
          "Treatment save failed:",
          error
        );


        if (
          error?.code === "23505"
        ) {

          setFormError(
            "A treatment with this name/URL slug already exists."
          );

        } else {

          setFormError(
            error.message ||
            "Treatment could not be saved."
          );

        }


      } finally {

        setSaving(false);

      }

    };


  return (

    <Drawer
      open={true}

      onClose={
        saving || categorySaving
          ? () => {}
          : onClose
      }

      title={
        isEditing
          ? "Edit Treatment"
          : "Add Treatment"
      }

      subtitle={
        isEditing
          ? editor.service.name
          : "Create a bookable treatment"
      }

      footer={
        <>

          <Button
            variant="ghost"
            size="sm"
            onClick={onClose}
            disabled={
              saving ||
              categorySaving
            }
          >
            Cancel
          </Button>


          <Button
            variant="primary"
            size="sm"
            onClick={saveTreatment}
            disabled={
              saving ||
              categorySaving
            }
          >
            {saving
              ? "Saving…"
              : isEditing
                ? "Save Changes"
                : "Add Treatment"}
          </Button>

        </>
      }
    >

      {formError && (

        <div
          style={{
            marginBottom: 18,
            padding: "11px 13px",
            borderRadius: 7,
            color: "var(--danger)",
            background:
              "rgba(154,74,58,0.1)",
            border:
              "1px solid rgba(154,74,58,0.3)",
            fontSize: "0.84rem"
          }}
        >
          {formError}
        </div>

      )}


      <TreatmentField
        label="Treatment name"
        required
      >

        <input
          className="a-input"

          value={form.name}

          onChange={(event) =>
            change(
              "name",
              event.target.value
            )
          }

          placeholder=
            "Example: Swedish Massage"
        />

      </TreatmentField>


      <TreatmentField label="Category">

        <select
          className="a-input"

          value={
            form.category_id
          }

          onChange={(event) =>
            change(
              "category_id",
              event.target.value
            )
          }
        >

          <option value="">
            Uncategorised
          </option>


          {categoryOptions.map(
            category => (

              <option
                key={category.id}
                value={category.id}
              >
                {category.name}
                {category.is_active
                  ? ""
                  : " (inactive)"}
              </option>

            )
          )}

        </select>

      </TreatmentField>


      <div
        style={{
          display: "grid",
          gridTemplateColumns:
            "1fr auto",
          gap: 8,
          alignItems: "end",
          marginTop: -6,
          marginBottom: 18
        }}
      >

        <div>

          <div
            className="caption"
            style={{
              marginBottom: 5
            }}
          >
            Need another category?
          </div>

          <input
            className="a-input"

            value={newCategory}

            onChange={(event) =>
              setNewCategory(
                event.target.value
              )
            }

            placeholder=
              "e.g. Massage"
          />

        </div>


        <Button
          variant="ghost"
          size="sm"
          onClick={addCategory}

          disabled={
            categorySaving ||
            !newCategory.trim()
          }
        >
          {categorySaving
            ? "Adding…"
            : "Add Category"}
        </Button>

      </div>


      <TreatmentField label="Description">

        <textarea
          className="a-input"
          rows={4}

          value={
            form.description
          }

          onChange={(event) =>
            change(
              "description",
              event.target.value
            )
          }

          placeholder=
            "Treatment description"

          style={{
            resize: "vertical"
          }}
        />

      </TreatmentField>


      <div
        style={{
          display: "grid",
          gridTemplateColumns:
            "1fr 1fr",
          gap: 14
        }}
      >

        <TreatmentField
          label="Duration (minutes)"
          required
        >

          <input
            className="a-input"
            type="number"
            min="1"
            step="5"

            value={
              form.duration_minutes
            }

            onChange={(event) =>
              change(
                "duration_minutes",
                event.target.value
              )
            }
          />

        </TreatmentField>


        <TreatmentField
          label="Buffer after treatment"
        >

          <input
            className="a-input"
            type="number"
            min="0"
            step="5"

            value={
              form.buffer_minutes
            }

            onChange={(event) =>
              change(
                "buffer_minutes",
                event.target.value
              )
            }
          />

        </TreatmentField>

      </div>


      <div
        style={{
          display: "grid",
          gridTemplateColumns:
            "1fr 1fr",
          gap: 14
        }}
      >

        <TreatmentField
          label="Normal price"
          required
        >

          <input
            className="a-input"
            type="number"
            min="0"
            step="0.01"

            value={
              form.price
            }

            onChange={(event) =>
              change(
                "price",
                event.target.value
              )
            }

            placeholder="0.00"
          />

        </TreatmentField>


        <TreatmentField
          label="Sale price"
        >

          <input
            className="a-input"
            type="number"
            min="0"
            step="0.01"

            value={
              form.sale_price
            }

            onChange={(event) =>
              change(
                "sale_price",
                event.target.value
              )
            }

            placeholder="Optional"
          />

        </TreatmentField>

      </div>


      <TreatmentField
        label="Deposit %"
        required
      >

        <input
          className="a-input"
          type="number"
          min="0"
          max="100"
          step="1"

          value={
            form.deposit_percent
          }

          onChange={(event) =>
            change(
              "deposit_percent",
              event.target.value
            )
          }
        />

      </TreatmentField>


      <TreatmentField label="Image URL">

        <input
          className="a-input"
          type="url"

          value={
            form.image_url
          }

          onChange={(event) =>
            change(
              "image_url",
              event.target.value
            )
          }

          placeholder="https://..."
        />

      </TreatmentField>


      <div
        style={{
          display: "flex",
          flexDirection: "column",
          gap: 14,
          marginTop: 20,
          padding: 16,
          background:
            "var(--bg-nude)",
          borderRadius: 8
        }}
      >

        <TreatmentOption
          label="Active treatment"
          description=
            "Inactive treatments remain in history but cannot be booked."

          checked={
            form.is_active
          }

          onChange={() =>
            change(
              "is_active",
              !form.is_active
            )
          }
        />


        <TreatmentOption
          label="Bookable online"
          description=
            "Allow customers to see this treatment in the public booking flow."

          checked={
            form.bookable_online
          }

          onChange={() =>
            change(
              "bookable_online",
              !form.bookable_online
            )
          }
        />

      </div>


      <div
        style={{
          marginTop: 18,
          padding: 13,
          borderRadius: 8,
          border:
            "1px solid var(--line)"
        }}
      >

        <div className="caption">
          Therapist qualifications are managed under
          Staff & Rota. Equipment/resource requirements
          are managed under Inventory → Resources &
          Equipment. Editing this treatment does not
          remove either relationship.
        </div>

      </div>

    </Drawer>

  );

}


function TreatmentField({
  label,
  required = false,
  children
}) {

  return (

    <div
      style={{
        marginBottom: 16
      }}
    >

      <div className="a-label">

        {label}

        {required
          ? " *"
          : ""}

      </div>


      {children}

    </div>

  );

}


function TreatmentOption({
  label,
  description,
  checked,
  onChange
}) {

  return (

    <div
      style={{
        display: "flex",
        justifyContent:
          "space-between",
        alignItems: "center",
        gap: 20
      }}
    >

      <div>

        <div
          style={{
            fontFamily:
              "var(--font-display)",
            fontSize: "0.88rem"
          }}
        >
          {label}
        </div>


        <div
          className="caption"
          style={{
            marginTop: 3,
            fontSize: "0.7rem"
          }}
        >
          {description}
        </div>

      </div>


      <Toggle
        checked={checked}
        onChange={onChange}
        size={36}
      />

    </div>

  );

}


function ProductsTable({
  products,
  loading,
  error,
  onReload,
  onEdit,
  onToggleOnline,
  onDeactivate
}) {
  if (loading) {
    return (
      <Panel>
        <SkeletonRows rows={6}/>
      </Panel>
    );
  }

  if (error) {
    return (
      <Panel>
        <EmptyBlock
          icon="alert"
          title="Products could not be loaded"
          sub={error}
          action={
            <Button
              variant="primary"
              size="sm"
              onClick={onReload}
            >
              Try again
            </Button>
          }
        />
      </Panel>
    );
  }

  if (!products.length) {
    return (
      <Panel>
        <EmptyBlock
          icon="package"
          title="No products yet"
          sub='Click "Add Product" to create your first product.'
        />
      </Panel>
    );
  }

  return (
    <Panel pad={false} style={{ overflow: "hidden" }}>
      <div
        style={{ overflowX: "auto" }}
        className="hide-scroll"
      >
        <table className="atable">
          <thead>
            <tr>
              <th>Product</th>
              <th>Category</th>
              <th>Price</th>
              <th>Stock</th>
              <th>Supplier</th>
              <th>Online</th>
              <th></th>
            </tr>
          </thead>

          <tbody>
            {products.map((product) => {
              const stock = Number(product.stock_quantity || 0);
              const reorderLevel = Number(
                product.reorder_level || 0
              );

              const outOfStock = stock === 0;
              const lowStock =
                stock > 0 && stock <= reorderLevel;

              const categoryName =
                product.categories?.name ||
                "Uncategorised";

              return (
                <tr key={product.id}>
                  <td>
                    <div
                      style={{
                        fontFamily: "var(--font-display)",
                        fontSize: "0.92rem"
                      }}
                    >
                      {product.name}
                    </div>

                    {product.sku && (
                      <div
                        className="caption"
                        style={{ fontSize: "0.68rem" }}
                      >
                        SKU: {product.sku}
                      </div>
                    )}
                  </td>

                  <td>
                    <span
                      className="chip chip-line"
                      style={{ fontSize: "0.64rem" }}
                    >
                      {categoryName}
                    </span>
                  </td>

                  <td
                    style={{
                      fontFamily: "var(--font-display)"
                    }}
                  >
                    £{Number(product.price).toFixed(2)}

                    {product.sale_price !== null &&
                      product.sale_price !== undefined && (
                        <span
                          style={{
                            color: "var(--gold-deep)",
                            marginLeft: 6
                          }}
                        >
                          £{Number(
                            product.sale_price
                          ).toFixed(2)}
                        </span>
                      )}
                  </td>

                  <td>
                    {outOfStock ? (
                      <Pill
                        color="var(--danger)"
                        bg="rgba(154,74,58,0.14)"
                        dot
                      >
                        Out of stock
                      </Pill>
                    ) : lowStock ? (
                      <Pill
                        color="var(--gold-deep)"
                        bg="var(--bg-nude)"
                        dot
                      >
                        {stock} · low
                      </Pill>
                    ) : (
                      <span
                        style={{
                          fontFamily: "var(--font-display)"
                        }}
                      >
                        {stock}
                      </span>
                    )}
                  </td>

                  <td>
                    <span className="caption">
                      {product.supplier_name || "—"}
                    </span>
                  </td>

                  <td>
                    <Toggle
                      checked={product.sellable_online}
                      onChange={() =>
                        onToggleOnline(product)
                      }
                      size={36}
                    />
                  </td>

                  <td>
                    <div
                      style={{
                        display: "flex",
                        gap: 4
                      }}
                    >
                      <button
                        className="icon-btn"
                        style={{
                          width: 32,
                          height: 32
                        }}
                        onClick={() => onEdit(product)}
                        title="Edit product"
                      >
                        <Icon name="edit" size={15}/>
                      </button>

                      <button
                        className="icon-btn"
                        style={{
                          width: 32,
                          height: 32
                        }}
                        onClick={() =>
                          onDeactivate(product)
                        }
                        title="Deactivate product"
                      >
                        <Icon name="trash" size={15}/>
                      </button>
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </Panel>
  );
}

const EMPTY_PRODUCT_FORM = {
  name: "",
  sku: "",
  description: "",
  price: "",
  sale_price: "",
  stock_quantity: "0",
  reorder_level: "5",
  supplier_name: "",
  image_url: "",
  track_inventory: true,
  sellable_online: true
};

function productSlug(value) {
  return String(value || "")
    .toLowerCase()
    .trim()
    .replace(/&/g, "and")
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "");
}

function productToForm(product) {
  if (!product) {
    return { ...EMPTY_PRODUCT_FORM };
  }

  return {
    name: product.name || "",
    sku: product.sku || "",
    description: product.description || "",
    price:
      product.price !== null &&
      product.price !== undefined
        ? String(product.price)
        : "",
    sale_price:
      product.sale_price !== null &&
      product.sale_price !== undefined
        ? String(product.sale_price)
        : "",
    stock_quantity: String(
      product.stock_quantity ?? 0
    ),
    reorder_level: String(
      product.reorder_level ?? 5
    ),
    supplier_name: product.supplier_name || "",
    image_url: product.image_url || "",
    track_inventory:
      product.track_inventory !== false,
    sellable_online:
      product.sellable_online !== false
  };
}

function ProductDrawer({
  editor,
  onClose,
  onSaved,
  toast
}) {
  const [form, setForm] = useState({
    ...EMPTY_PRODUCT_FORM
  });

  const [saving, setSaving] = useState(false);
  const [formError, setFormError] = useState("");

  useEffect(() => {
    if (editor) {
      setForm(productToForm(editor.product));
      setFormError("");
      setSaving(false);
    }
  }, [editor]);

  if (!editor) {
    return null;
  }

  const isEditing = editor.mode === "edit";

  const change = (field, value) => {
    setForm((current) => ({
      ...current,
      [field]: value
    }));
  };

  const saveProduct = async () => {
    setFormError("");

    const name = form.name.trim();
    const price = Number(form.price);
    const stockQuantity = Number(
      form.stock_quantity
    );
    const reorderLevel = Number(
      form.reorder_level
    );

    if (!name) {
      setFormError("Enter the product name.");
      return;
    }

    if (
      form.price === "" ||
      Number.isNaN(price) ||
      price < 0
    ) {
      setFormError(
        "Enter a valid product price."
      );
      return;
    }

    if (
      Number.isNaN(stockQuantity) ||
      stockQuantity < 0
    ) {
      setFormError(
        "Stock quantity cannot be negative."
      );
      return;
    }

    if (
      Number.isNaN(reorderLevel) ||
      reorderLevel < 0
    ) {
      setFormError(
        "Reorder level cannot be negative."
      );
      return;
    }

    const salePrice =
      form.sale_price === ""
        ? null
        : Number(form.sale_price);

    if (
      salePrice !== null &&
      (Number.isNaN(salePrice) || salePrice < 0)
    ) {
      setFormError(
        "Enter a valid sale price."
      );
      return;
    }

    const payload = {
      name,
      slug:
        isEditing && editor.product.slug
          ? editor.product.slug
          : productSlug(name),
      sku: form.sku.trim() || null,
      description:
        form.description.trim() || null,
      price,
      sale_price: salePrice,
      stock_quantity: stockQuantity,
      reorder_level: reorderLevel,
      supplier_name:
        form.supplier_name.trim() || null,
      image_url:
        form.image_url.trim() || null,
      track_inventory:
        form.track_inventory,
      sellable_online:
        form.sellable_online,
      is_active: true
    };

    try {
      setSaving(true);

      if (isEditing) {
        await API.Products.update(
          editor.product.id,
          payload
        );

        toast("Product updated", "success");
      } else {
        await API.Products.create(payload);
        toast("Product added", "success");
      }

      await onSaved();
    } catch (error) {
      console.error("Product save failed:", error);

      if (
        String(error.message || "")
          .toLowerCase()
          .includes("duplicate")
      ) {
        setFormError(
          "A product with this name, slug or SKU may already exist."
        );
      } else {
        setFormError(
          error.message ||
          "The product could not be saved."
        );
      }
    } finally {
      setSaving(false);
    }
  };

  return (
    <Drawer
      open={true}
      onClose={saving ? () => {} : onClose}
      title={
        isEditing
          ? "Edit Product"
          : "Add Product"
      }
      subtitle={
        isEditing
          ? editor.product.name
          : "Create a retail product"
      }
      footer={
        <>
          <Button
            variant="ghost"
            size="sm"
            onClick={onClose}
            disabled={saving}
          >
            Cancel
          </Button>

          <Button
            variant="primary"
            size="sm"
            onClick={saveProduct}
            disabled={saving}
          >
            {saving
              ? "Saving…"
              : isEditing
                ? "Save Changes"
                : "Add Product"}
          </Button>
        </>
      }
    >
      {formError && (
        <div
          style={{
            marginBottom: 18,
            padding: "11px 13px",
            borderRadius: 7,
            color: "var(--danger)",
            background: "rgba(154,74,58,0.1)",
            border:
              "1px solid rgba(154,74,58,0.3)",
            fontSize: "0.84rem"
          }}
        >
          {formError}
        </div>
      )}

      <ProductField label="Product name" required>
        <input
          className="a-input"
          value={form.name}
          onChange={(event) =>
            change("name", event.target.value)
          }
          placeholder="Example: Soothing Cleansing Gel"
        />
      </ProductField>

      <ProductField label="SKU">
        <input
          className="a-input"
          value={form.sku}
          onChange={(event) =>
            change("sku", event.target.value)
          }
          placeholder="Example: CC-CLEANSER-001"
        />
      </ProductField>

      <ProductField label="Description">
        <textarea
          className="a-input"
          rows={4}
          value={form.description}
          onChange={(event) =>
            change(
              "description",
              event.target.value
            )
          }
          placeholder="Describe the product"
          style={{ resize: "vertical" }}
        />
      </ProductField>

      <div
        style={{
          display: "grid",
          gridTemplateColumns: "1fr 1fr",
          gap: 14
        }}
      >
        <ProductField label="Price" required>
          <input
            className="a-input"
            type="number"
            min="0"
            step="0.01"
            value={form.price}
            onChange={(event) =>
              change("price", event.target.value)
            }
            placeholder="0.00"
          />
        </ProductField>

        <ProductField label="Sale price">
          <input
            className="a-input"
            type="number"
            min="0"
            step="0.01"
            value={form.sale_price}
            onChange={(event) =>
              change(
                "sale_price",
                event.target.value
              )
            }
            placeholder="Optional"
          />
        </ProductField>
      </div>

      <div
        style={{
          display: "grid",
          gridTemplateColumns: "1fr 1fr",
          gap: 14
        }}
      >
        <ProductField label="Stock quantity">
          <input
            className="a-input"
            type="number"
            min="0"
            step="1"
            value={form.stock_quantity}
            onChange={(event) =>
              change(
                "stock_quantity",
                event.target.value
              )
            }
          />
        </ProductField>

        <ProductField label="Reorder level">
          <input
            className="a-input"
            type="number"
            min="0"
            step="1"
            value={form.reorder_level}
            onChange={(event) =>
              change(
                "reorder_level",
                event.target.value
              )
            }
          />
        </ProductField>
      </div>

      <ProductField label="Supplier">
        <input
          className="a-input"
          value={form.supplier_name}
          onChange={(event) =>
            change(
              "supplier_name",
              event.target.value
            )
          }
          placeholder="Example: Crystal Clear"
        />
      </ProductField>

      <ProductField label="Image URL">
        <input
          className="a-input"
          type="url"
          value={form.image_url}
          onChange={(event) =>
            change(
              "image_url",
              event.target.value
            )
          }
          placeholder="https://..."
        />
      </ProductField>

      <div
        style={{
          display: "flex",
          flexDirection: "column",
          gap: 14,
          marginTop: 20,
          padding: 16,
          background: "var(--bg-nude)",
          borderRadius: 8
        }}
      >
        <ProductOption
          label="Track inventory"
          description="Store and monitor the product stock quantity."
          checked={form.track_inventory}
          onChange={() =>
            change(
              "track_inventory",
              !form.track_inventory
            )
          }
        />

        <ProductOption
          label="Sell online"
          description="Show this product in the public shop."
          checked={form.sellable_online}
          onChange={() =>
            change(
              "sellable_online",
              !form.sellable_online
            )
          }
        />
      </div>
    </Drawer>
  );
}

function ProductField({
  label,
  required = false,
  children
}) {
  return (
    <div style={{ marginBottom: 16 }}>
      <div className="a-label">
        {label}
        {required ? " *" : ""}
      </div>

      {children}
    </div>
  );
}

function ProductOption({
  label,
  description,
  checked,
  onChange
}) {
  return (
    <div
      style={{
        display: "flex",
        justifyContent: "space-between",
        alignItems: "center",
        gap: 20
      }}
    >
      <div>
        <div
          style={{
            fontFamily: "var(--font-display)",
            fontSize: "0.88rem"
          }}
        >
          {label}
        </div>

        <div
          className="caption"
          style={{
            marginTop: 3,
            fontSize: "0.7rem"
          }}
        >
          {description}
        </div>
      </div>

      <Toggle
        checked={checked}
        onChange={onChange}
        size={36}
      />
    </div>
  );
}

Object.assign(window, { ModuleCustomers, ModuleStaff, ModuleCatalog });
