/* =========================================================================
   STEP 10D — REAL PUBLIC TREATMENTS PAGE
   Only treatments enabled as bookable_online in Supabase are shown.
   ========================================================================= */

function TreatmentsPage() {
  const { navigate } = useRouter();

  const [services, setServices] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  const [category, setCategory] = useState("All");
  const [search, setSearch] = useState("");
  const [sort, setSort] = useState("featured");
  const [duration, setDuration] = useState("all");


  async function loadTreatments() {
    setLoading(true);
    setError("");

    try {
      if (!window.API?.Services?.listBookable) {
        throw new Error(
          "Public treatment API is not installed."
        );
      }

      const rows =
        await window.API.Services.listBookable();

      setServices(rows || []);
    } catch (err) {
      console.error(
        "Could not load online treatments:",
        err
      );

      setError(
        err?.message ||
        "Treatments could not be loaded."
      );
    } finally {
      setLoading(false);
    }
  }


  useEffect(() => {
    loadTreatments();
  }, []);


  const categories = useMemo(() => {
    const names = Array.from(
      new Set(
        services
          .map(service =>
            service.category_name
          )
          .filter(Boolean)
      )
    ).sort();

    return ["All", ...names];
  }, [services]);


  const filtered = useMemo(() => {
    let list = [...services];

    if (category !== "All") {
      list = list.filter(
        service =>
          service.category_name === category
      );
    }

    const q =
      String(search || "")
        .trim()
        .toLowerCase();

    if (q) {
      list = list.filter(service => {
        const haystack = [
          service.name,
          service.description,
          service.category_name
        ]
          .filter(Boolean)
          .join(" ")
          .toLowerCase();

        return haystack.includes(q);
      });
    }

    if (duration === "short") {
      list = list.filter(
        service =>
          Number(service.duration_minutes) <= 60
      );
    }

    if (duration === "medium") {
      list = list.filter(service => {
        const mins =
          Number(service.duration_minutes);

        return mins > 60 && mins <= 90;
      });
    }

    if (duration === "long") {
      list = list.filter(
        service =>
          Number(service.duration_minutes) > 90
      );
    }

    if (sort === "price-low") {
      list.sort(
        (a, b) =>
          Number(a.display_price || 0) -
          Number(b.display_price || 0)
      );
    }

    if (sort === "price-high") {
      list.sort(
        (a, b) =>
          Number(b.display_price || 0) -
          Number(a.display_price || 0)
      );
    }

    if (sort === "duration") {
      list.sort(
        (a, b) =>
          Number(a.duration_minutes || 0) -
          Number(b.duration_minutes || 0)
      );
    }

    return list;
  }, [
    services,
    category,
    search,
    sort,
    duration
  ]);


  return (
    <div>
      <Nav />

      <section
        style={{
          padding: "180px 0 64px",
          background: "var(--bg-cream)",
          borderBottom: "1px solid var(--line)"
        }}
      >
        <div className="container-wide">
          <div
            style={{
              display: "flex",
              justifyContent: "space-between",
              alignItems: "flex-end",
              flexWrap: "wrap",
              gap: 24
            }}
          >
            <div style={{ maxWidth: 720 }}>
              <div className="eyebrow">
                The full menu
              </div>

              <h1
                style={{
                  marginTop: 12,
                  marginBottom: 20
                }}
              >
                Treatments
                <span
                  style={{
                    color: "var(--gold-deep)"
                  }}
                >
                  .
                </span>
              </h1>

              <p
                className="body-lg"
                style={{ maxWidth: "52ch" }}
              >
                Browse the treatments currently available for online booking. Exact therapist pricing is shown after you choose your appointment time.
              </p>
            </div>

            <Button
              variant="ghost"
              size="sm"
              icon="refresh"
              onClick={loadTreatments}
            >
              Refresh
            </Button>
          </div>
        </div>
      </section>


      <div
        style={{
          position: "sticky",
          top: 84,
          zIndex: 40,
          background: "rgba(246,241,232,0.92)",
          backdropFilter: "blur(20px)",
          WebkitBackdropFilter: "blur(20px)",
          borderBottom: "1px solid var(--line)"
        }}
      >
        <div
          className="container-wide"
          style={{
            padding: "20px 32px",
            display: "flex",
            alignItems: "center",
            gap: 18,
            flexWrap: "wrap"
          }}
        >
          <div
            style={{
              display: "flex",
              gap: 4,
              flexWrap: "wrap"
            }}
          >
            {categories.map(name => (
              <button
                key={name}
                onClick={() =>
                  setCategory(name)
                }
                style={{
                  padding: "9px 15px",
                  fontFamily: "var(--font-display)",
                  fontSize: "0.72rem",
                  letterSpacing: "0.12em",
                  textTransform: "uppercase",
                  borderRadius: "var(--r-pill)",
                  background:
                    category === name
                      ? "var(--ink)"
                      : "transparent",
                  color:
                    category === name
                      ? "var(--ink-on-dark)"
                      : "var(--ink-2)",
                  border:
                    category === name
                      ? "1px solid var(--ink)"
                      : "1px solid var(--line-strong)"
                }}
              >
                {name}
              </button>
            ))}
          </div>

          <div style={{ flex: 1 }} />

          <div
            style={{
              display: "flex",
              alignItems: "center",
              gap: 10,
              padding: "8px 14px",
              border: "1px solid var(--line-strong)",
              borderRadius: "var(--r-pill)",
              background: "var(--bg-cream)",
              width: 240
            }}
          >
            <Icon
              name="search"
              size={14}
              className="text-ink-3"
            />

            <input
              value={search}
              onChange={event =>
                setSearch(event.target.value)
              }
              placeholder="Search treatments…"
              style={{
                background: "transparent",
                border: "none",
                outline: "none",
                flex: 1,
                fontFamily: "var(--font-body)",
                fontSize: "0.9rem"
              }}
            />
          </div>

          <select
            value={duration}
            onChange={event =>
              setDuration(event.target.value)
            }
            style={filterSelectStyle}
          >
            <option value="all">
              Any duration
            </option>
            <option value="short">
              ≤ 60 min
            </option>
            <option value="medium">
              61 – 90 min
            </option>
            <option value="long">
              90+ min
            </option>
          </select>

          <select
            value={sort}
            onChange={event =>
              setSort(event.target.value)
            }
            style={filterSelectStyle}
          >
            <option value="featured">
              A–Z
            </option>
            <option value="price-low">
              Price · low
            </option>
            <option value="price-high">
              Price · high
            </option>
            <option value="duration">
              Duration
            </option>
          </select>
        </div>
      </div>


      <section
        style={{
          padding: "56px 0 120px"
        }}
      >
        <div className="container-wide">
          {loading && (
            <PublicTreatmentMessage
              title="Loading treatments…"
              sub="Reading the live Chelsea Spa catalogue."
            />
          )}

          {!loading && error && (
            <PublicTreatmentMessage
              icon="alert"
              title="Treatments could not be loaded"
              sub={error}
              action={
                <Button
                  variant="primary"
                  size="sm"
                  onClick={loadTreatments}
                >
                  Try again
                </Button>
              }
            />
          )}

          {!loading &&
            !error &&
            services.length === 0 && (
              <PublicTreatmentMessage
                icon="calendar"
                title="Online booking is being prepared"
                sub="No treatments are currently enabled for online booking. Please call the spa to book."
              />
            )}

          {!loading &&
            !error &&
            services.length > 0 && (
              <>
                <div
                  className="caption"
                  style={{ marginBottom: 32 }}
                >
                  {filtered.length}{" "}
                  {filtered.length === 1
                    ? "treatment"
                    : "treatments"}
                  {category !== "All"
                    ? ` · ${category}`
                    : ""}
                </div>

                {filtered.length === 0 ? (
                  <PublicTreatmentMessage
                    icon="search"
                    title="No treatments match your filters"
                    sub="Try another category or clear your search."
                  />
                ) : (
                  <div
                    className="t-grid"
                    style={{
                      display: "grid",
                      gridTemplateColumns: "1fr 1fr",
                      gap: 24
                    }}
                  >
                    {filtered.map(
                      (service, index) => (
                        <LiveTreatmentCard
                          key={service.id}
                          service={service}
                          index={index}
                          onBook={() =>
                            navigate(
                              "/booking?t=" +
                              encodeURIComponent(
                                service.id
                              )
                            )
                          }
                        />
                      )
                    )}
                  </div>
                )}
              </>
            )}
        </div>

        <style>{`
          @media (max-width: 880px) {
            .t-grid {
              grid-template-columns: 1fr !important;
            }
          }
        `}</style>
      </section>

      <Footer />
    </div>
  );
}


const filterSelectStyle = {
  padding: "10px 16px",
  borderRadius: "var(--r-pill)",
  border: "1px solid var(--line-strong)",
  background: "var(--bg-cream)",
  fontFamily: "var(--font-display)",
  fontSize: "0.74rem",
  letterSpacing: "0.1em",
  textTransform: "uppercase",
  cursor: "pointer"
};


function LiveTreatmentCard({
  service,
  index,
  onBook
}) {
  const [hover, setHover] =
    useState(false);

  const description =
    service.description ||
    "A Chelsea Spa treatment tailored by your therapist on the day.";

  return (
    <div
      className="card fade-up"
      style={{
        animationDelay: `${index * 50}ms`,
        display: "grid",
        gridTemplateColumns: "180px 1fr",
        transition: "all 320ms var(--ease)",
        borderColor:
          hover
            ? "var(--gold-soft)"
            : "var(--line)",
        transform:
          hover
            ? "translateY(-2px)"
            : "none",
        boxShadow:
          hover
            ? "var(--shadow-3)"
            : "none"
      }}
      onMouseEnter={() =>
        setHover(true)
      }
      onMouseLeave={() =>
        setHover(false)
      }
    >
      <Placeholder
        label={String(
          service.category_name ||
          "treatment"
        ).toLowerCase()}
        height="100%"
        style={{ minHeight: 200 }}
      />

      <div
        style={{
          padding: 28,
          display: "flex",
          flexDirection: "column"
        }}
      >
        <div className="eyebrow">
          {service.category_name ||
            "Treatment"}
        </div>

        <h3 style={{ marginTop: 7 }}>
          {service.name}
        </h3>

        <p
          style={{
            marginTop: 12,
            fontSize: "0.94rem",
            flex: 1
          }}
        >
          {description}
        </p>

        <div
          style={{
            marginTop: 24,
            paddingTop: 20,
            borderTop: "1px solid var(--line)",
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            gap: 14
          }}
        >
          <div
            style={{
              display: "flex",
              gap: 16,
              alignItems: "center",
              fontFamily: "var(--font-display)",
              fontSize: "0.86rem"
            }}
          >
            <span
              style={{
                display: "inline-flex",
                alignItems: "center",
                gap: 6,
                color: "var(--ink-2)"
              }}
            >
              <Icon
                name="clock"
                size={14}
              />
              {service.duration_minutes} min
            </span>

            <span
              style={{
                color: "var(--gold-deep)",
                fontSize: "1.02rem"
              }}
            >
              From £
              {Number(
                service.display_price || 0
              ).toFixed(2)}
            </span>
          </div>

          <Button
            variant="ghost"
            size="sm"
            onClick={onBook}
          >
            Book
          </Button>
        </div>
      </div>

      <style>{`
        @media (max-width: 580px) {
          .card {
            grid-template-columns: 1fr !important;
          }
        }
      `}</style>
    </div>
  );
}


function PublicTreatmentMessage({
  icon,
  title,
  sub,
  action
}) {
  return (
    <div
      style={{
        padding: "72px 32px",
        textAlign: "center",
        border: "1px dashed var(--line-strong)",
        borderRadius: 8
      }}
    >
      {icon && (
        <div
          style={{
            display: "inline-flex",
            padding: 18,
            background: "var(--bg-nude)",
            borderRadius: "50%",
            marginBottom: 20
          }}
        >
          <Icon
            name={icon}
            size={22}
          />
        </div>
      )}

      <h3>{title}</h3>

      {sub && (
        <p
          style={{
            marginTop: 10,
            color: "var(--ink-2)"
          }}
        >
          {sub}
        </p>
      )}

      {action && (
        <div style={{ marginTop: 20 }}>
          {action}
        </div>
      )}
    </div>
  );
}


window.TreatmentsPage = TreatmentsPage;
