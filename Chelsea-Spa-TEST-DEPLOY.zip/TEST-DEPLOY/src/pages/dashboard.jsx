/* =========================================================================
   USER DASHBOARD — Bookings, profile, payment history
   ========================================================================= */

function DashboardPage() {
  const { navigate } = useRouter();
  const toast = useToast();
  const [tab, setTab] = useState("upcoming");

  // Combine last booking from checkout (if any) with seeded examples
  const upcoming = useMemo(() => {
    const seeded = [
      { ref: "CSAX7P21", treatment: "Oxygen Glow Therapy", duration: 60, therapist: "Mala", date: "Friday 30 May", time: "11:30", price: 145, status: "confirmed" },
    ];
    if (window.__lastBooking) {
      const b = window.__lastBooking;
      const newOne = {
        ref: b.ref,
        treatment: b.treatment.name,
        duration: b.treatment.duration,
        therapist: b.therapist?.name,
        date: formatDate(b.date).split(",")[0] + ", " + formatDate(b.date).split(", ")[1],
        time: b.time,
        price: b.treatment.price,
        status: "confirmed",
        new: true,
      };
      return [newOne, ...seeded];
    }
    return seeded;
  }, []);

  const past = [
    { ref: "CSPK4J11", treatment: "Hot Stone Ritual", duration: 90, therapist: "Shugar", date: "12 April 2026", time: "15:00", price: 195, status: "completed" },
    { ref: "CSMM2H72", treatment: "Chelsea Signature Facial", duration: 75, therapist: "Mala", date: "8 March 2026", time: "10:00", price: 165, status: "completed" },
    { ref: "CSDR9F33", treatment: "London Deep Tissue", duration: 60, therapist: "Shugar", date: "21 January 2026", time: "17:00", price: 135, status: "completed" },
    { ref: "CSFG3B82", treatment: "Cashmere Body Polish", duration: 60, therapist: "Riya", date: "5 December 2025", time: "14:00", price: 125, status: "cancelled" },
  ];

  const totalSpent = past.filter(b => b.status === "completed").reduce((sum, b) => sum + b.price, 0);

  return (
    <div style={{ background: "var(--bg)" }}>
      <Nav />

      {/* HEADER */}
      <section style={{ paddingTop: 130, paddingBottom: 32 }}>
        <div className="container-wide">
          <div className="eyebrow">My account</div>
          <h1 style={{ marginTop: 12, marginBottom: 0 }}>
            Welcome back, <em className="serif-italic" style={{ color: "var(--gold-deep)" }}>Eloise</em>.
          </h1>
          <p className="body-lg text-ink-2" style={{ marginTop: 12 }}>
            Your next ritual is in 6 days · Atelier Circle member since 2024
          </p>
        </div>
      </section>

      {/* STATS */}
      <section style={{ paddingBottom: 24 }}>
        <div className="container-wide">
          <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 16 }} className="stats-grid">
            <Stat label="Upcoming" value={upcoming.length} sub="bookings"/>
            <Stat label="This year" value={past.filter(b => b.status === "completed").length} sub="treatments"/>
            <Stat label="Spent" value={`£${totalSpent}`} sub="lifetime"/>
            <Stat label="Membership" value="Atelier" sub="renews Aug 2026" badge/>
          </div>
        </div>
        <style>{`
          @media (max-width: 880px) { .stats-grid { grid-template-columns: 1fr 1fr !important; } }
        `}</style>
      </section>

      {/* TABS + CONTENT */}
      <section style={{ paddingTop: 32, paddingBottom: 96 }}>
        <div className="container-wide" style={{ display: "grid", gridTemplateColumns: "240px 1fr", gap: 48 }}>

          {/* SIDEBAR */}
          <aside className="dash-side">
            <div className="caption" style={{ marginBottom: 14 }}>Manage</div>
            <nav style={{ display: "flex", flexDirection: "column", gap: 2 }}>
              {[
                { id: "upcoming", icon: "calendar", label: "Upcoming" },
                { id: "history",  icon: "clock",    label: "History" },
                { id: "payments", icon: "wallet",   label: "Payments" },
                { id: "profile",  icon: "user",     label: "Profile" },
              ].map(t => (
                <button key={t.id} onClick={() => setTab(t.id)} style={{
                  display: "flex", alignItems: "center", gap: 12,
                  padding: "12px 16px",
                  background: tab === t.id ? "var(--bg-nude)" : "transparent",
                  border: `1px solid ${tab === t.id ? "var(--gold-soft)" : "transparent"}`,
                  borderRadius: 6,
                  fontFamily: "var(--font-display)", fontSize: "0.88rem",
                  color: tab === t.id ? "var(--ink)" : "var(--ink-2)",
                  textAlign: "left",
                  transition: "all 180ms",
                }}>
                  <Icon name={t.icon} size={16}/> {t.label}
                </button>
              ))}
              <div className="divider" style={{ margin: "16px 0" }}/>
              <button style={{
                display: "flex", alignItems: "center", gap: 12,
                padding: "12px 16px",
                fontFamily: "var(--font-display)", fontSize: "0.88rem", color: "var(--ink-3)",
                textAlign: "left",
              }} onClick={() => { toast("Signed out"); navigate("/"); }}>
                <Icon name="logout" size={16}/> Sign out
              </button>
            </nav>
          </aside>

          {/* MAIN */}
          <div>
            {tab === "upcoming" && <UpcomingTab list={upcoming} navigate={navigate} toast={toast}/>}
            {tab === "history"  && <HistoryTab list={past}/>}
            {tab === "payments" && <PaymentsTab list={[...upcoming, ...past]}/>}
            {tab === "profile"  && <ProfileTab toast={toast}/>}
          </div>
        </div>
        <style>{`
          @media (max-width: 880px) {
            section .container-wide { grid-template-columns: 1fr !important; }
            .dash-side { display: flex; gap: 8px; overflow-x: auto; }
            .dash-side nav { flex-direction: row !important; gap: 4px !important; }
            .dash-side .caption, .dash-side .divider { display: none; }
          }
        `}</style>
      </section>

      <Footer />
    </div>
  );
}

function Stat({ label, value, sub, badge }) {
  return (
    <div style={{
      background: "var(--bg-cream)",
      border: "1px solid var(--line)",
      borderRadius: 8,
      padding: "24px 28px",
      position: "relative",
    }}>
      <div className="caption">{label}</div>
      <div style={{
        fontFamily: "var(--font-display)", fontSize: "2.2rem", fontWeight: 300,
        marginTop: 8, lineHeight: 1, letterSpacing: "-0.03em",
        color: badge ? "var(--gold-deep)" : "var(--ink)",
      }}>{value}</div>
      <div className="caption" style={{ marginTop: 6 }}>{sub}</div>
      {badge && (
        <div style={{
          position: "absolute", top: 16, right: 16,
          width: 6, height: 6, borderRadius: "50%", background: "var(--gold)",
        }}/>
      )}
    </div>
  );
}

/* ------------------ UPCOMING ------------------ */
function UpcomingTab({ list, navigate, toast }) {
  if (list.length === 0) {
    return (
      <EmptyDash icon="calendar" title="No upcoming bookings"
        sub="Book a ritual and your appointments will show up here."
        action={<Button variant="primary" onClick={() => navigate("/treatments")}>Browse treatments</Button>}/>
    );
  }
  return (
    <div>
      <h3 style={{ marginBottom: 16 }}>Upcoming appointments</h3>
      <div style={{ display: "grid", gap: 12 }}>
        {list.map(b => (
          <div key={b.ref} style={{
            background: "var(--bg-cream)",
            border: `1px solid ${b.new ? "var(--gold-deep)" : "var(--line)"}`,
            borderRadius: 8,
            padding: 24,
            display: "grid", gridTemplateColumns: "80px 1fr auto", gap: 20, alignItems: "center",
          }} className="appt-card">
            {/* date block */}
            <div style={{
              background: "var(--bg-nude)", borderRadius: 6, padding: "14px 8px",
              textAlign: "center",
            }}>
              <div className="caption" style={{ color: "var(--gold-deep)" }}>{b.date.split(" ")[0]}</div>
              <div style={{ fontFamily: "var(--font-display)", fontSize: "1.6rem", fontWeight: 400, lineHeight: 1, marginTop: 2 }}>
                {b.date.split(" ")[1]}
              </div>
              <div className="caption" style={{ marginTop: 2 }}>{b.date.split(" ").slice(2).join(" ")}</div>
            </div>
            <div>
              <div style={{ display: "flex", gap: 10, alignItems: "center", flexWrap: "wrap" }}>
                <h4>{b.treatment}</h4>
                {b.new && <span className="chip chip-gold">Just booked</span>}
              </div>
              <div className="caption" style={{ marginTop: 6 }}>
                {b.time} · {b.duration} min · with {b.therapist}
              </div>
              <div className="caption" style={{ marginTop: 2 }}>
                Reference <span style={{ fontFamily: "var(--font-mono)" }}>{b.ref}</span>
              </div>
            </div>
            <div style={{ display: "flex", flexDirection: "column", gap: 8, alignItems: "flex-end" }}>
              <Button variant="ghost" size="sm" onClick={() => toast("Reschedule flow opened")}>Reschedule</Button>
              <button onClick={() => toast("Cancellation requested")} style={{
                fontFamily: "var(--font-display)", fontSize: "0.72rem",
                letterSpacing: "0.16em", textTransform: "uppercase",
                color: "var(--ink-3)",
              }}>Cancel</button>
            </div>
            <style>{`
              @media (max-width: 580px) {
                .appt-card { grid-template-columns: 1fr !important; }
              }
            `}</style>
          </div>
        ))}
      </div>

      {/* Recommend */}
      <div style={{
        marginTop: 40,
        background: "var(--ink)", color: "var(--ink-on-dark)",
        borderRadius: 8, padding: 32,
        display: "flex", alignItems: "center", justifyContent: "space-between", gap: 24, flexWrap: "wrap",
      }}>
        <div>
          <div className="eyebrow" style={{ color: "var(--gold-soft)" }}>Recommended</div>
          <h3 style={{ color: "var(--ink-on-dark)", marginTop: 6 }}>You're due for a body polish.</h3>
          <p style={{ marginTop: 6, color: "rgba(246,241,232,0.7)" }}>It's been 11 weeks since your last one.</p>
        </div>
        <Button variant="gold" onClick={() => navigate("/booking?t=body-polish")} iconRight="arrow-right">Book again</Button>
      </div>
    </div>
  );
}

/* ------------------ HISTORY ------------------ */
function HistoryTab({ list }) {
  return (
    <div>
      <h3 style={{ marginBottom: 16 }}>Treatment history</h3>
      <div style={{
        background: "var(--bg-cream)", border: "1px solid var(--line)", borderRadius: 8,
        overflow: "hidden",
      }}>
        <table style={{ width: "100%", borderCollapse: "collapse" }} className="hist-table">
          <thead style={{ background: "var(--bg-shell)" }}>
            <tr>
              <Th>Date</Th><Th>Treatment</Th><Th>Therapist</Th><Th>Amount</Th><Th>Status</Th><Th></Th>
            </tr>
          </thead>
          <tbody>
            {list.map(b => (
              <tr key={b.ref} style={{ borderTop: "1px solid var(--line)" }}>
                <Td><div style={{ fontFamily: "var(--font-display)" }}>{b.date}</div><div className="caption">{b.time}</div></Td>
                <Td>{b.treatment}<div className="caption">{b.duration} min</div></Td>
                <Td>{b.therapist}</Td>
                <Td><span style={{ fontFamily: "var(--font-display)" }}>£{b.price}</span></Td>
                <Td>
                  <StatusPill status={b.status}/>
                </Td>
                <Td style={{ textAlign: "right" }}>
                  <button className="caption" style={{ color: "var(--gold-deep)", textTransform: "uppercase", letterSpacing: "0.14em" }}>
                    Rebook →
                  </button>
                </Td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <style>{`
        @media (max-width: 700px) {
          .hist-table th:nth-child(3), .hist-table td:nth-child(3),
          .hist-table th:nth-child(5), .hist-table td:nth-child(5) { display: none; }
        }
      `}</style>
    </div>
  );
}

function Th({ children }) {
  return <th style={{
    textAlign: "left", padding: "14px 20px",
    fontFamily: "var(--font-display)", fontSize: "0.7rem",
    letterSpacing: "0.16em", textTransform: "uppercase", color: "var(--ink-2)",
    fontWeight: 500,
  }}>{children}</th>;
}
function Td({ children, style }) {
  return <td style={{ padding: "18px 20px", fontSize: "0.92rem", ...style }}>{children}</td>;
}
function StatusPill({ status }) {
  const map = {
    confirmed: { bg: "var(--bg-nude)", color: "var(--gold-deep)", label: "Confirmed" },
    completed: { bg: "rgba(107,122,94,0.16)", color: "var(--success)", label: "Completed" },
    cancelled: { bg: "rgba(154,74,58,0.14)", color: "var(--danger)", label: "Cancelled" },
  };
  const s = map[status] || map.confirmed;
  return (
    <span style={{
      padding: "5px 10px", borderRadius: 999, background: s.bg, color: s.color,
      fontFamily: "var(--font-display)", fontSize: "0.7rem", letterSpacing: "0.1em", textTransform: "uppercase",
    }}>{s.label}</span>
  );
}

/* ------------------ PAYMENTS ------------------ */
function PaymentsTab({ list }) {
  return (
    <div>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 16 }}>
        <h3>Payment history</h3>
        <Button variant="ghost" size="sm" icon="plus">Add card</Button>
      </div>

      {/* Saved card */}
      <div style={{
        background: "var(--bg-cream)", border: "1px solid var(--line)", borderRadius: 8,
        padding: 24, marginBottom: 24,
        display: "flex", alignItems: "center", justifyContent: "space-between", gap: 16, flexWrap: "wrap",
      }}>
        <div style={{ display: "flex", alignItems: "center", gap: 16 }}>
          <CardLogo brand="visa"/>
          <div>
            <div style={{ fontFamily: "var(--font-display)" }}>•••• •••• •••• 4242</div>
            <div className="caption">Expires 08/27 · Eloise Whitfield</div>
          </div>
        </div>
        <span className="chip chip-gold">Default</span>
      </div>

      <div style={{
        background: "var(--bg-cream)", border: "1px solid var(--line)", borderRadius: 8,
        overflow: "hidden",
      }}>
        <table style={{ width: "100%", borderCollapse: "collapse" }}>
          <thead style={{ background: "var(--bg-shell)" }}>
            <tr><Th>Date</Th><Th>Description</Th><Th>Method</Th><Th>Amount</Th></tr>
          </thead>
          <tbody>
            {list.slice(0, 6).map(b => (
              <tr key={b.ref} style={{ borderTop: "1px solid var(--line)" }}>
                <Td>{b.date}</Td>
                <Td>{b.treatment}<div className="caption" style={{ fontFamily: "var(--font-mono)" }}>{b.ref}</div></Td>
                <Td>Visa •••• 4242</Td>
                <Td><span style={{ fontFamily: "var(--font-display)", color: "var(--gold-deep)" }}>£{b.price}</span></Td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

/* ------------------ PROFILE ------------------ */
function ProfileTab({ toast }) {
  const [form, setForm] = useState({
    first: "Eloise", last: "Whitfield", email: "eloise.w@example.com", phone: "+44 7700 900123",
    pressure: "medium", allergies: "Tree nuts",
    marketing: true, sms: false,
  });
  const upd = (k, v) => setForm({ ...form, [k]: v });
  return (
    <div>
      <h3 style={{ marginBottom: 24 }}>Profile</h3>

      <Card title="Personal details">
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
          <Field label="First name"><input className="input" value={form.first} onChange={e => upd("first", e.target.value)}/></Field>
          <Field label="Last name"><input className="input" value={form.last} onChange={e => upd("last", e.target.value)}/></Field>
          <Field label="Email"><input className="input" value={form.email} onChange={e => upd("email", e.target.value)}/></Field>
          <Field label="Phone"><input className="input" value={form.phone} onChange={e => upd("phone", e.target.value)}/></Field>
        </div>
      </Card>

      <Card title="Treatment preferences" sub="Your therapist will see these before every appointment.">
        <Field label="Preferred pressure">
          <div style={{ display: "flex", gap: 8 }}>
            {["light", "medium", "firm"].map(p => (
              <button key={p} onClick={() => upd("pressure", p)} style={{
                padding: "10px 18px", borderRadius: 999,
                background: form.pressure === p ? "var(--ink)" : "transparent",
                color: form.pressure === p ? "var(--ink-on-dark)" : "var(--ink-2)",
                border: `1px solid ${form.pressure === p ? "var(--ink)" : "var(--line-strong)"}`,
                fontFamily: "var(--font-display)", fontSize: "0.78rem",
                letterSpacing: "0.14em", textTransform: "uppercase",
              }}>{p}</button>
            ))}
          </div>
        </Field>
        <div style={{ marginTop: 14 }}>
          <Field label="Allergies & sensitivities">
            <input className="input" value={form.allergies} onChange={e => upd("allergies", e.target.value)}/>
          </Field>
        </div>
      </Card>

      <Card title="Notifications">
        <ToggleRow checked={form.marketing} onChange={v => upd("marketing", v)}
                   title="Monthly notes" sub="Seasonal rituals and member previews."/>
        <ToggleRow checked={form.sms} onChange={v => upd("sms", v)}
                   title="SMS reminders" sub="A gentle text the morning of your appointment."/>
      </Card>

      <div style={{ display: "flex", justifyContent: "flex-end", gap: 10, marginTop: 16 }}>
        <Button variant="ghost">Discard</Button>
        <Button variant="primary" onClick={() => toast("Profile saved", "success")}>Save changes</Button>
      </div>
    </div>
  );
}

function ToggleRow({ checked, onChange, title, sub }) {
  return (
    <div style={{
      display: "flex", alignItems: "center", justifyContent: "space-between",
      padding: "14px 0",
      borderBottom: "1px solid var(--line)",
    }}>
      <div>
        <div style={{ fontFamily: "var(--font-display)", fontSize: "0.95rem" }}>{title}</div>
        <div className="caption" style={{ marginTop: 2 }}>{sub}</div>
      </div>
      <button onClick={() => onChange(!checked)} style={{
        width: 42, height: 24, borderRadius: 12,
        background: checked ? "var(--gold-deep)" : "var(--line-strong)",
        position: "relative",
        transition: "all 240ms var(--ease)",
      }}>
        <span style={{
          position: "absolute", top: 2, left: checked ? 20 : 2,
          width: 20, height: 20, borderRadius: "50%",
          background: "white", boxShadow: "0 1px 2px rgba(0,0,0,0.2)",
          transition: "left 240ms var(--ease)",
        }}/>
      </button>
    </div>
  );
}

function EmptyDash({ icon, title, sub, action }) {
  return (
    <div style={{
      padding: "64px 32px", textAlign: "center",
      background: "var(--bg-cream)", border: "1px dashed var(--line-strong)", borderRadius: 8,
    }}>
      <div style={{ display: "inline-flex", padding: 18, background: "var(--bg-nude)", borderRadius: "50%", marginBottom: 20 }}>
        <Icon name={icon} size={20}/>
      </div>
      <h3>{title}</h3>
      <p style={{ marginTop: 8, color: "var(--ink-2)" }}>{sub}</p>
      {action && <div style={{ marginTop: 20 }}>{action}</div>}
    </div>
  );
}

window.DashboardPage = DashboardPage;
