/* =========================================================================
   API SERVICE LAYER — connects the frontend to a Django REST backend.

   • JWT auth (access + refresh) stored in localStorage
   • One small function per REST endpoint (see ADMIN_ARCHITECTURE.md §4)
   • Auto-retries once on 401 by refreshing the access token
   • Falls back to the bundled mock data when USE_API is false, so the
     prototype keeps working with no backend running.

   Runtime config is read from <script> tags in admin.html / index.html:
       window.__API_BASE__   e.g. "http://localhost:8000/api"
       window.__USE_API__    true → live backend, false → mock data
   ========================================================================= */

const CS_CONFIG = {
  API_BASE: (typeof window !== "undefined" && window.__API_BASE__) || "http://localhost:8000/api",
  USE_API:  (typeof window !== "undefined" && window.__USE_API__) || false,
};

/* ---- Token storage -------------------------------------------------- */
const TOKENS = {
  get access()  { return localStorage.getItem("cs_access"); },
  set access(v) { v ? localStorage.setItem("cs_access", v)  : localStorage.removeItem("cs_access"); },
  get refresh()  { return localStorage.getItem("cs_refresh"); },
  set refresh(v) { v ? localStorage.setItem("cs_refresh", v) : localStorage.removeItem("cs_refresh"); },
  clear() { localStorage.removeItem("cs_access"); localStorage.removeItem("cs_refresh"); },
};

/* ---- Error type ----------------------------------------------------- */
class ApiError extends Error {
  constructor(status, message, body) {
    super(message);
    this.name = "ApiError";
    this.status = status;
    this.body = body;
  }
}

async function safeError(res) {
  try {
    const data = await res.json();
    // DRF returns { detail: "..." } or field errors { field: ["msg"] }
    if (data.detail) return data.detail;
    const first = Object.values(data)[0];
    return Array.isArray(first) ? first[0] : (first || res.statusText);
  } catch {
    return res.statusText || `Request failed (${res.status})`;
  }
}

/* ---- Core request --------------------------------------------------- */
async function request(path, { method = "GET", body, auth = true, params } = {}) {
  const url = new URL(CS_CONFIG.API_BASE.replace(/\/$/, "") + path);
  if (params) Object.entries(params).forEach(([k, v]) => v != null && v !== "" && url.searchParams.set(k, v));

  const build = () => {
    const headers = { "Content-Type": "application/json" };
    if (auth && TOKENS.access) headers.Authorization = `Bearer ${TOKENS.access}`;
    return { method, headers, body: body ? JSON.stringify(body) : undefined };
  };

  let res = await fetch(url, build());

  // One transparent refresh-and-retry on expiry
  if (res.status === 401 && auth && TOKENS.refresh) {
    const ok = await API.Auth.refresh();
    if (ok) res = await fetch(url, build());
  }

  if (!res.ok) throw new ApiError(res.status, await safeError(res));
  if (res.status === 204) return null;
  const text = await res.text();
  return text ? JSON.parse(text) : null;
}

/* ---- CRUD factory --------------------------------------------------- */
/* DRF list endpoints are paginated: { count, next, previous, results }.
   .list() returns that envelope; read `.results` for the rows.          */
function crud(base) {
  return {
    list:   (params)    => request(`/${base}/`, { params }),
    get:    (id)        => request(`/${base}/${id}/`),
    create: (body)      => request(`/${base}/`, { method: "POST", body }),
    update: (id, body)  => request(`/${base}/${id}/`, { method: "PATCH", body }),
    remove: (id)        => request(`/${base}/${id}/`, { method: "DELETE" }),
  };
}

/* ---- The API surface ------------------------------------------------ */
async function getChelseaLocationId() {
  const { data, error } = await window.supabaseClient
    .from("locations")
    .select("id")
    .eq("name", "The Chelsea Spa")
    .single();

  if (error) {
    throw error;
  }

  return data.id;
}
const API = {
  config: CS_CONFIG,
  tokens: TOKENS,
  ApiError,
  request,

  Auth: {
    async login(email, password) {
      const data = await request("/auth/login/", { method: "POST", body: { email, password }, auth: false });
      TOKENS.access = data.access; TOKENS.refresh = data.refresh;
      return data;
    },
    async refresh() {
      if (!TOKENS.refresh) return false;
      try {
        const data = await request("/auth/refresh/", { method: "POST", body: { refresh: TOKENS.refresh }, auth: false });
        TOKENS.access = data.access;
        return true;
      } catch {
        TOKENS.clear();
        return false;
      }
    },
    me:           ()      => request("/auth/me/"),
    requestReset: (email) => request("/auth/password/reset/", { method: "POST", body: { email }, auth: false }),
    logout()  { TOKENS.clear(); },
    isAuthed: () => !!TOKENS.access,
  },

  // ============================================================
  // BUSINESS SETTINGS
  // Staff limits and other business-wide configuration.
  // ============================================================

  Settings: {

    // ----------------------------------------------------------
    // Read the Chelsea Spa settings.
    // Managers can READ this.
    // ----------------------------------------------------------
    async get() {

      // Find Chelsea Spa's location first.
      const locationId =
        await getChelseaLocationId();

      const { data, error } =
        await window.supabaseClient
          .from("business_settings")
          .select("*")
          .eq("location_id", locationId)
          .single();

      if (error) {
        throw error;
      }

      return data;
    },


    // ----------------------------------------------------------
    // Change the maximum number of active staff.
    //
    // IMPORTANT:
    // Supabase RLS only allows SUPER ADMIN to do this.
    // ----------------------------------------------------------
    async setStaffLimit(newLimit) {

      const locationId =
        await getChelseaLocationId();

      const limit = Number(newLimit);

      // Basic frontend validation.
      if (
        !Number.isInteger(limit) ||
        limit < 1 ||
        limit > 500
      ) {
        throw new Error(
          "Staff limit must be between 1 and 500."
        );
      }

      const { data, error } =
        await window.supabaseClient
          .from("business_settings")
          .update({
            max_active_staff: limit,
            updated_at:
              new Date().toISOString()
          })
          .eq("location_id", locationId)
          .select()
          .single();

      if (error) {
        throw error;
      }

      return data;
    }

  },

  /* Catalog */

  // ============================================================
  // SERVICES / TREATMENTS
  // Real Supabase treatment catalogue.
  // ============================================================

  Services: {

    // Active treatments used by staff assignment and normal UI.
    async list() {

      const { data, error } =
        await window.supabaseClient
          .from("services")
          .select(`
            id,
            location_id,
            category_id,
            name,
            slug,
            description,
            duration_minutes,
            buffer_minutes,
            price,
            sale_price,
            deposit_percent,
            image_url,
            bookable_online,
            is_active,
            categories (
              id,
              name,
              slug
            )
          `)
          .eq("is_active", true)
          .order("name");


      if (error) {
        throw error;
      }


      return data || [];
    },


    // ----------------------------------------------------------
    // PUBLIC ONLINE CATALOGUE
    //
    // Only active treatments explicitly enabled for online
    // booking are exposed to the public booking flow.
    // The displayed price is a "from" price; the exact price is
    // returned after the customer chooses an available therapist.
    // ----------------------------------------------------------
    async listBookable() {

      const locationId =
        await getChelseaLocationId();


      const {
        data,
        error
      } =
        await window.supabaseClient
          .from("services")
          .select(`
            id,
            location_id,
            category_id,
            name,
            slug,
            description,
            duration_minutes,
            buffer_minutes,
            price,
            sale_price,
            deposit_percent,
            image_url,
            bookable_online,
            is_active,
            categories (
              id,
              name,
              slug
            )
          `)
          .eq(
            "location_id",
            locationId
          )
          .eq(
            "is_active",
            true
          )
          .eq(
            "bookable_online",
            true
          )
          .order("name");


      if (error) {
        throw error;
      }


      return (data || []).map(
        function (service) {

          const displayPrice =
            service.sale_price != null
              ? Number(service.sale_price)
              : Number(service.price || 0);


          return Object.assign(
            {},
            service,
            {
              category_name:
                service.categories?.name ||
                "Treatments",

              display_price:
                displayPrice
            }
          );
        }
      );
    },


    // Full Admin catalogue, including inactive treatments,
    // therapist assignment counts and resource requirements.
    async listAdmin() {

      const { data, error } =
        await window.supabaseClient
          .from("services")
          .select(`
            id,
            location_id,
            category_id,
            legacy_id,
            name,
            slug,
            description,
            duration_minutes,
            buffer_minutes,
            price,
            sale_price,
            deposit_percent,
            image_url,
            gallery,
            bookable_online,
            is_active,
            created_at,
            updated_at,
            categories (
              id,
              name,
              is_active
            ),
            staff_services (
              staff_id,
              is_active
            ),
            service_resource_requirements (
              resource_id,
              quantity_required
            )
          `)
          .order(
            "is_active",
            { ascending: false }
          )
          .order("name");


      if (error) {
        throw error;
      }


      return (data || []).map(
        (service) => ({

          ...service,

          therapist_count:
            (service.staff_services || [])
              .filter(
                assignment =>
                  assignment.is_active
              )
              .length,

          resource_count:
            (service
              .service_resource_requirements
              || [])
              .length

        })
      );
    },


    async create(serviceData) {

      const locationId =
        serviceData.location_id ||
        await getChelseaLocationId();


      const insertData =
        Object.assign(
          {},
          serviceData,
          {
            location_id: locationId
          }
        );


      const { data, error } =
        await window.supabaseClient
          .from("services")
          .insert(insertData)
          .select()
          .single();


      if (error) {
        throw error;
      }


      return data;
    },


    async update(id, serviceData) {

      if (!id) {
        throw new Error(
          "Treatment ID is required."
        );
      }


      const updateData =
        Object.assign(
          {},
          serviceData,
          {
            updated_at:
              new Date().toISOString()
          }
        );


      const { data, error } =
        await window.supabaseClient
          .from("services")
          .update(updateData)
          .eq("id", id)
          .select()
          .single();


      if (error) {
        throw error;
      }


      return data;
    },


    async deactivate(id) {

      return await this.update(
        id,
        {
          is_active: false,
          bookable_online: false
        }
      );
    },


    async activate(id) {

      return await this.update(
        id,
        {
          is_active: true
        }
      );
    }

  },


  // ============================================================
  // SERVICE CATEGORIES
  // ============================================================

  Categories: {

    async listServices() {

      const locationId =
        await getChelseaLocationId();


      const { data, error } =
        await window.supabaseClient
          .from("categories")
          .select(`
            id,
            location_id,
            name,
            slug,
            kind,
            sort_order,
            is_active
          `)
          .eq(
            "location_id",
            locationId
          )
          .eq(
            "kind",
            "service"
          )
          .order(
            "sort_order",
            { ascending: true }
          )
          .order("name");


      if (error) {
        throw error;
      }


      return data || [];
    },


    async createService(name) {

      const cleanName =
        String(name || "")
          .trim();


      if (!cleanName) {
        throw new Error(
          "Category name is required."
        );
      }


      const locationId =
        await getChelseaLocationId();


      const slug =
        cleanName
          .toLowerCase()
          .replace(/&/g, "and")
          .replace(/[^a-z0-9]+/g, "-")
          .replace(/^-+|-+$/g, "");


      if (!slug) {
        throw new Error(
          "Enter a valid category name."
        );
      }


      const { data, error } =
        await window.supabaseClient
          .from("categories")
          .insert({
            location_id: locationId,
            name: cleanName,
            slug: slug,
            kind: "service",
            is_active: true
          })
          .select()
          .single();


      if (error) {
        throw error;
      }


      return data;
    }

  },

  // ==========================================================
// SERVICE ROLE PRICING
//
// Reads and updates:
//
// skin_specialist
// senior_therapist
// therapist
//
// The actual percentages are stored in Supabase.
// ==========================================================

  ServiceRolePricing: {

      // --------------------------------------------------------
      // LOAD ALL SERVICE ROLE PRICES
      // --------------------------------------------------------
      async list() {

        const { data, error } =
          await window.supabaseClient
            .from("service_role_settings")
            .select(`
              role_code,
              label,
              price_markup_percent,
              is_active,
              updated_at
            `)
            .order(
              "price_markup_percent",
              { ascending: false }
            );


        if (error) {
          throw error;
        }


        // Always return an array.
        return data || [];
      },


      // --------------------------------------------------------
      // UPDATE ONE ROLE'S PRICE UPLIFT
      // --------------------------------------------------------
      async update(roleCode, newPercentage) {

        const percentage =
          Number(newPercentage);


        // Basic validation.
        if (
          Number.isNaN(percentage) ||
          percentage < 0 ||
          percentage > 100
        ) {
          throw new Error(
            "Price uplift must be between 0% and 100%."
          );
        }


        // Get the logged-in user.
        // We store this for auditing.
        const {
          data: { user }
        } =
          await window.supabaseClient
            .auth
            .getUser();


        const { data, error } =
          await window.supabaseClient
            .from("service_role_settings")
            .update({

              // New configurable percentage.
              price_markup_percent:
                percentage,

              // Audit information.
              updated_at:
                new Date().toISOString(),

              updated_by:
                user?.id || null

            })
            .eq(
              "role_code",
              roleCode
            )
            .select()
            .single();


        if (error) {
          throw error;
        }


        return data;
      }

  },

  Products: {
                  async list() {
                    const { data, error } = await window.supabaseClient
                      .from("products")
                      .select("*")
                      .order("name");

                    if (error) {
                      throw error;
                    }

                    return data || [];
                  },

                  async create(productData) {
                    let locationId = productData.location_id;

                    if (!locationId) {
                      const { data: location, error: locationError } =
                        await window.supabaseClient
                          .from("locations")
                          .select("id")
                          .eq("name", "The Chelsea Spa")
                          .single();

                      if (locationError) {
                        throw locationError;
                      }

                      locationId = location.id;
                    }

                    const { data, error } = await window.supabaseClient
                      .from("products")
                      .insert({
                        ...productData,
                        location_id: locationId
                      })
                      .select()
                      .single();

                    if (error) {
                      throw error;
                    }

                    return data;
                  },

                  async update(id, productData) {
                    const { data, error } = await window.supabaseClient
                      .from("products")
                      .update({
                        ...productData,
                        updated_at: new Date().toISOString()
                      })
                      .eq("id", id)
                      .select()
                      .single();

                    if (error) {
                      throw error;
                    }

                    return data;
                  },

                  async deactivate(id) {
                    const { data, error } = await window.supabaseClient
                      .from("products")
                      .update({
                        is_active: false,
                        sellable_online: false,
                        updated_at: new Date().toISOString()
                      })
                      .eq("id", id)
                      .select()
                      .single();

                    if (error) {
                      throw error;
                    }

                    return data;
                  },

                  async activate(id) {
                    const { data, error } = await window.supabaseClient
                      .from("products")
                      .update({
                        is_active: true,
                        sellable_online: true,
                        updated_at: new Date().toISOString()
                      })
                      .eq("id", id)
                      .select()
                      .single();

                    if (error) {
                      throw error;
                    }

                    return data;
                  },

                  async remove(id) {
                    const { error } = await window.supabaseClient
                      .from("products")
                      .delete()
                      .eq("id", id);

                    if (error) {
                      throw error;
                    }

                    return true;
                  }
            },
  Packages:    crud("packages"),
  Memberships: crud("memberships"),
  GiftCards:   crud("gift-cards"),

  /* Bookings */
  Bookings: Object.assign(crud("bookings"), {
    cancel:       (id)     => request(`/bookings/${id}/cancel/`, { method: "POST" }),
    setStatus:    (id, status) => request(`/bookings/${id}/`, { method: "PATCH", body: { status } }),
    availability: (params) => request("/availability/", { params }),
  }),
  Waitlist: crud("waitlist"),

  /* Customers */
  /* ============================================================
   CUSTOMERS
   Real Supabase customer database
   ============================================================ */

  Customers: {

    // ----------------------------------------------------------
    // LIST ALL CUSTOMERS
    //
    // Supabase/PostgREST returns records in batches.
    // We therefore fetch customers page-by-page so the Admin
    // can search the entire Chelsea Spa customer database.
    // ----------------------------------------------------------
    async list() {

      const PAGE_SIZE = 1000;

      let from = 0;
      let allCustomers = [];


      while (true) {

        const {
          data,
          error
        } =
          await window.supabaseClient
            .from("customers")
            .select(`
              id,
              location_id,
              legacy_id,
              first_name,
              last_name,
              email,
              phone,
              date_of_birth,
              allergies,
              notes,
              loyalty_points,
              marketing_consent,
              sms_consent,
              created_at,
              updated_at
            `)

            // Newest customers first.
            .order(
              "created_at",
              { ascending: false }
            )

            // Important:
            // gives us a stable order when many imported
            // customers have the same created_at timestamp.
            .order(
              "id",
              { ascending: true }
            )

            .range(
              from,
              from + PAGE_SIZE - 1
            );


        if (error) {
          throw error;
        }


        const batch =
          data || [];


        allCustomers.push(
          ...batch
        );


        // Less than 1000 means we've reached
        // the final page.
        if (
          batch.length < PAGE_SIZE
        ) {
          break;
        }


        from += PAGE_SIZE;

      }


      return allCustomers;

    },

    // ----------------------------------------------------------
    // PAGINATED CUSTOMER LIST
    //
    // Used by the Admin Customer page.
    //
    // Instead of downloading thousands of customers,
    // this loads only one page at a time from Supabase.
    //
    // Example:
    // page 1 = rows 0–49
    // page 2 = rows 50–99
    //
    // Search also happens inside Supabase rather than
    // filtering thousands of records in the browser.
    // ----------------------------------------------------------
    async listPage({
      page = 1,
      pageSize = 50,
      search = ""
    } = {}) {

      // --------------------------------------------------------
      // SAFETY
      // --------------------------------------------------------

      const safePage =
        Math.max(
          1,
          Number(page) || 1
        );


      const safePageSize =
        Math.min(
          100,
          Math.max(
            10,
            Number(pageSize) || 50
          )
        );


      const from =
        (safePage - 1) *
        safePageSize;


      const to =
        from +
        safePageSize -
        1;


      // --------------------------------------------------------
      // QUERY
      // --------------------------------------------------------

      let query =
        window.supabaseClient
          .from("customers")
          .select(
            `
              id,
              location_id,
              legacy_id,
              first_name,
              last_name,
              email,
              phone,
              date_of_birth,
              allergies,
              notes,
              loyalty_points,
              marketing_consent,
              sms_consent,
              created_at,
              updated_at
            `,
            {
              count: "estimated"
            }
          );


      // --------------------------------------------------------
      // DATABASE SEARCH
      // --------------------------------------------------------

      const searchText =
        String(search || "")
          .trim();


      // --------------------------------------------------------
      // FAST MULTI-WORD CUSTOMER SEARCH
      //
      // Examples that now work:
      //
      // Farah
      // Farah Mehmood
      // Mehmood Farah
      // Farah gmail
      // 077 Farah
      //
      // Every search word must occur somewhere inside
      // customers.search_text.
      // --------------------------------------------------------

      const searchTerms =
        String(search || "")
          .trim()
          .toLowerCase()
          .split(/\s+/)

          // Remove blank pieces.
          .filter(Boolean)

          // Prevent somebody entering hundreds of words.
          .slice(0, 6);


      for (
        const term of searchTerms
      ) {

        // Remove SQL wildcard characters from user input.
        // They aren't needed for normal CRM searching.
        const safeTerm =
          term
            .replace(
              /[%_]/g,
              ""
            )
            .trim();


        if (!safeTerm) {
          continue;
        }


        query =
          query.ilike(
            "search_text",
            `%${safeTerm}%`
          );

      }


      // --------------------------------------------------------
      // SORT + PAGE
      // --------------------------------------------------------

      query =
        query
          .order(
            "created_at",
            {
              ascending: false
            }
          )
          .order(
            "id",
            {
              ascending: true
            }
          )
          .range(
            from,
            to
          );


      // --------------------------------------------------------
      // RUN QUERY
      // --------------------------------------------------------

      const {
        data,
        error,
        count
      } =
        await query;


      if (error) {
        throw error;
      }


      const total =
        Number(count || 0);


      return {

        customers:
          data || [],

        total,

        page:
          safePage,

        pageSize:
          safePageSize,

        totalPages:
          Math.max(
            1,
            Math.ceil(
              total /
              safePageSize
            )
          )

      };

    },

    // ----------------------------------------------------------
    // CUSTOMER DATABASE STATISTICS
    //
    // These are global counts for the Customer dashboard.
    // They do not depend on the current 50-row page.
    // ----------------------------------------------------------
    // ----------------------------------------------------------
    // CUSTOMER DATABASE STATISTICS
    //  
    // One Supabase RPC instead of four separate COUNT requests.
    // ----------------------------------------------------------
    async stats() {

      const {
        data,
        error
      } =
        await window.supabaseClient
          .rpc(
            "customer_stats"
          );


      if (error) {
        throw error;
      }


      // PostgreSQL RETURNS TABLE gives us an array.
      const row =
        Array.isArray(data)
          ? data[0]
          : data;


      return {

        total:
          Number(
            row?.total || 0
          ),

        marketing:
          Number(
            row?.marketing || 0
          ),

        sms:
          Number(
            row?.sms || 0
          ),

        loyalty:
          Number(
            row?.loyalty || 0
          )

      };

    },

    // ----------------------------------------------------------
    // GET ONE CUSTOMER
    // ----------------------------------------------------------
    async get(id) {

      if (!id) {
        throw new Error(
          "Customer ID is required."
        );
      }

      const {
        data,
        error
      } =
        await window.supabaseClient
          .from("customers")
          .select(`
            id,
            location_id,
            legacy_id,
            first_name,
            last_name,
            email,
            phone,
            date_of_birth,
            allergies,
            notes,
            loyalty_points,
            marketing_consent,
            sms_consent,
            created_at,
            updated_at
          `)
          .eq(
            "id",
            id
          )
          .single();

      if (error) {
        throw error;
      }

      return data;
    },

    // ----------------------------------------------------------
    // CUSTOMER PROFILE SUMMARY
    //
    // Calculates live customer information from appointments.
    // Nothing here is duplicated into the customers table.
    // ----------------------------------------------------------

    async purchaseHistory(customerId) {

      const { data, error } =
        await window.supabaseClient
          .from("orders")
          .select(`
            id,
            reference,
            status,
            total,
            created_at,
            order_items (
              id,
              product_name_snapshot,
              quantity,
              unit_price,
              line_total
            ),
            payments (
              id,
              provider,
              amount,
              currency,
              status,
              paid_at
            )
          `)
          .eq("customer_id", customerId)
          .order("created_at", {
            ascending: false
          });

      if (error) throw error;

      return data || [];
    },


    async summary(customerId) {

      if (!customerId) {
        throw new Error(
          "Customer ID is required."
        );
      }


      // --------------------------------------------------------
      // LOAD CUSTOMER APPOINTMENTS
      // --------------------------------------------------------

      const {
        data: appointments,
        error: appointmentsError
      } =
        await window.supabaseClient
          .from("appointments")
          .select(`
            id,
            customer_id,
            service_id,
            staff_id,
            start_at,
            end_at,
            status,
            service_name_snapshot,
            price_snapshot
          `)
          .eq(
            "customer_id",
            customerId
          )
          .order(
            "start_at",
            { ascending: false }
          );


      if (appointmentsError) {
        throw appointmentsError;
      }


      const rows =
        appointments || [];


      // --------------------------------------------------------
      // LOAD THERAPIST NAMES
      // --------------------------------------------------------

      const staffIds =
        [
          ...new Set(
            rows
              .map(
                (appointment) =>
                  appointment.staff_id
              )
              .filter(Boolean)
          )
        ];


      let staffMembers = [];


      if (staffIds.length > 0) {

        const {
          data,
          error
        } =
          await window.supabaseClient
            .from("staff_members")
            .select(`
              id,
              first_name,
              last_name,
              service_role
            `)
            .in(
              "id",
              staffIds
            );


        if (error) {
          throw error;
        }


        staffMembers =
          data || [];
      }


      const staffMap =
        Object.fromEntries(

          staffMembers.map(
            (member) => [

              member.id,

              {
                ...member,

                full_name:
                  [
                    member.first_name,
                    member.last_name
                  ]
                    .filter(Boolean)
                    .join(" ")
              }

            ]
          )

        );


      // Add therapist details to appointment.
      const enrich =
        (appointment) => {

          if (!appointment) {
            return null;
          }


          return {

            ...appointment,

            therapist:
              staffMap[
                appointment.staff_id
              ] || null

          };

        };


      // --------------------------------------------------------
      // COMPLETED VISITS
      // --------------------------------------------------------

      const completed =
        rows.filter(
          (appointment) =>
            appointment.status ===
            "completed"
        );


      // Because rows are already ordered newest first,
      // completed[0] is the latest completed visit.
      const lastVisit =
        completed[0] || null;


      // --------------------------------------------------------
      // UPCOMING BOOKINGS
      // --------------------------------------------------------

      const now =
        Date.now();


      const excludedUpcomingStatuses =
        [
          "completed",
          "cancelled",
          "no_show",
          "expired"
        ];


      const upcoming =
        rows
          .filter(
            (appointment) => {

              const startTime =
                new Date(
                  appointment.start_at
                ).getTime();


              return (
                startTime >= now &&
                !excludedUpcomingStatuses
                  .includes(
                    appointment.status
                  )
              );

            }
          )
          .sort(
            (a, b) =>
              new Date(a.start_at) -
              new Date(b.start_at)
          );


      const nextAppointment =
        upcoming[0] || null;


      // --------------------------------------------------------
      // COMPLETED TREATMENT VALUE
      //
      // This is the booked treatment value.
      // Actual payment totals will come from payments in 8H.
      // --------------------------------------------------------

      const treatmentValue =
        completed.reduce(
          (total, appointment) =>
            total +
            Number(
              appointment.price_snapshot || 0
            ),

          0
        );


      // --------------------------------------------------------
      // RETURN SUMMARY
      // --------------------------------------------------------

      return {

        total_appointments:
          rows.length,

        completed_visits:
          completed.length,

        upcoming_count:
          upcoming.length,

        treatment_value:
          treatmentValue,

        last_visit:
          enrich(lastVisit),

        next_appointment:
          enrich(nextAppointment)

      };
    },

    // ----------------------------------------------------------
    // CUSTOMER APPOINTMENT / TREATMENT HISTORY
    // ----------------------------------------------------------
    async history(customerId) {

      if (!customerId) {
        throw new Error(
          "Customer ID is required."
        );
      }


      // --------------------------------------------------------
      // LOAD ALL APPOINTMENTS VISIBLE TO CURRENT USER
      //
      // RLS still controls what the logged-in user is
      // actually allowed to see.
      // --------------------------------------------------------

      const {
        data: appointments,
        error: appointmentsError
      } =
        await window.supabaseClient
          .from("appointments")
          .select(`
            id,
            customer_id,
            service_id,
            staff_id,
            start_at,
            end_at,
            status,
            service_name_snapshot,
            price_snapshot,
            customer_notes,
            internal_notes,
            created_at
          `)
          .eq(
            "customer_id",
            customerId
          )
          .order(
            "start_at",
            { ascending: false }
          );


      if (appointmentsError) {
        throw appointmentsError;
      }


      const rows =
        appointments || [];


      // --------------------------------------------------------
      // FIND ALL THERAPISTS USED BY THESE APPOINTMENTS
      // --------------------------------------------------------

      const staffIds =
        [
          ...new Set(
            rows
              .map(
                appointment =>
                  appointment.staff_id
              )
              .filter(Boolean)
          )
        ];


      let staffMembers = [];


      if (staffIds.length > 0) {

        const {
          data,
          error
        } =
          await window.supabaseClient
            .from("staff_members")
            .select(`
              id,
              first_name,
              last_name,
              service_role
            `)
            .in(
              "id",
              staffIds
            );


        if (error) {
          throw error;
        }


        staffMembers =
          data || [];
      }


      const staffMap =
        Object.fromEntries(

          staffMembers.map(
            member => [

              member.id,

              {
                ...member,

                full_name:
                  [
                    member.first_name,
                    member.last_name
                  ]
                    .filter(Boolean)
                    .join(" ")
              }

            ]
          )

        );


      // --------------------------------------------------------
      // RETURN APPOINTMENTS WITH THERAPIST INFORMATION
      // --------------------------------------------------------

      return rows.map(
        appointment => ({

          ...appointment,

          therapist:
            staffMap[
              appointment.staff_id
            ] || null

        })
      );

    },


    // ----------------------------------------------------------
    // CREATE CUSTOMER
    // ----------------------------------------------------------
    async create(customerData) {

      if (!customerData?.first_name?.trim()) {
        throw new Error(
          "Customer first name is required."
        );
      }

      if (!customerData?.last_name?.trim()) {
        throw new Error(
          "Customer last name is required."
        );
      }


      // Find Chelsea Spa location automatically
      // when the form does not supply one.
      let locationId =
        customerData.location_id;


      if (!locationId) {

        const {
          data: location,
          error: locationError
        } =
          await window.supabaseClient
            .from("locations")
            .select("id")
            .eq(
              "name",
              "The Chelsea Spa"
            )
            .single();


        if (locationError) {
          throw locationError;
        }


        locationId =
          location.id;
      }


      const {
        data,
        error
      } =
        await window.supabaseClient
          .from("customers")
          .insert({

            location_id:
              locationId,

            first_name:
              customerData.first_name.trim(),

            last_name:
              customerData.last_name.trim(),

            // Empty optional fields should be NULL,
            // not empty strings.
            email:
              customerData.email?.trim()
                ? customerData.email
                    .trim()
                    .toLowerCase()
                : null,

            phone:
              customerData.phone?.trim()
                || null,

            date_of_birth:
              customerData.date_of_birth
                || null,

            allergies:
              customerData.allergies?.trim()
                || null,

            notes:
              customerData.notes?.trim()
                || null,

            loyalty_points:
              Number(
                customerData.loyalty_points
                || 0
              ),

            marketing_consent:
              Boolean(
                customerData.marketing_consent
              ),

            sms_consent:
              Boolean(
                customerData.sms_consent
              )

          })
          .select()
          .single();


      if (error) {
        throw error;
      }


      return data;
    },


    // ----------------------------------------------------------
    // UPDATE CUSTOMER
    // ----------------------------------------------------------
    async update(id, customerData) {

      if (!id) {
        throw new Error(
          "Customer ID is required."
        );
      }


      const payload = {};


      // Only update fields that were supplied.

      if (
        customerData.first_name !== undefined
      ) {
        payload.first_name =
          customerData.first_name.trim();
      }


      if (
        customerData.last_name !== undefined
      ) {
        payload.last_name =
          customerData.last_name.trim();
      }


      if (
        customerData.email !== undefined
      ) {
        payload.email =
          customerData.email?.trim()
            ? customerData.email
                .trim()
                .toLowerCase()
            : null;
      }


      if (
        customerData.phone !== undefined
      ) {
        payload.phone =
          customerData.phone?.trim()
            || null;
      }


      if (
        customerData.date_of_birth
        !== undefined
      ) {
        payload.date_of_birth =
          customerData.date_of_birth
            || null;
      }


      if (
        customerData.allergies
        !== undefined
      ) {
        payload.allergies =
          customerData.allergies?.trim()
            || null;
      }


      if (
        customerData.notes !== undefined
      ) {
        payload.notes =
          customerData.notes?.trim()
            || null;
      }


      if (
        customerData.loyalty_points
        !== undefined
      ) {
        payload.loyalty_points =
          Number(
            customerData.loyalty_points
            || 0
          );
      }


      if (
        customerData.marketing_consent
        !== undefined
      ) {
        payload.marketing_consent =
          Boolean(
            customerData.marketing_consent
          );
      }


      if (
        customerData.sms_consent
        !== undefined
      ) {
        payload.sms_consent =
          Boolean(
            customerData.sms_consent
          );
      }


      const {
        data,
        error
      } =
        await window.supabaseClient
          .from("customers")
          .update(payload)
          .eq(
            "id",
            id
          )
          .select()
          .single();


      if (error) {
        throw error;
      }


      return data;
    },


    // ----------------------------------------------------------
    // DELETE CUSTOMER
    //
    // RLS already controls who may delete:
    // Super Admin / Admin = allowed
    // Practitioner = blocked
    // ----------------------------------------------------------
    async remove(id) {

      if (!id) {
        throw new Error(
          "Customer ID is required."
        );
      }


      const {
        error
      } =
        await window.supabaseClient
          .from("customers")
          .delete()
          .eq(
            "id",
            id
          );


      if (error) {
        throw error;
      }


      return true;
    },


    // ----------------------------------------------------------
    // EXPORT
    //
    // For now return customer rows.
    // In Step 8D we connect this to the Export CSV button.
    // ----------------------------------------------------------
// ----------------------------------------------------------
// EXPORT ALL CUSTOMERS
//
// Uses the paginated list() function so CSV export includes
// the entire customer database, not only the first batch.
// ----------------------------------------------------------
    async export() {

      return await this.list();

    }
  },



  /*===================================================*/
  /* STEP 10C1 — REAL APPOINTMENTS / BOOKINGS READ API */
  /*===================================================*/

  Appointments: {

    /*
     * Load real appointments from Supabase for the
     * Admin Bookings and Calendar screens.
     *
     * RLS remains the source of truth:
     * - Super Admin / Admin can see operational bookings
     * - Practitioner visibility remains restricted by policy
     *
     * Optional filters:
     * {
     *   start: ISO timestamp,
     *   end: ISO timestamp,
     *   status: "confirmed"
     * }
     */
    async listAdmin(filters) {

      const options =
        filters || {};

      let query =
        window.supabaseClient
          .from("appointments")
          .select(`
            id,
            reference,
            location_id,
            customer_id,
            service_id,
            staff_id,
            start_at,
            end_at,
            blocked_end_at,
            room,
            channel,
            booking_source,
            created_by_user_id,
            created_by_staff_id,
            status,
            service_name_snapshot,
            price_snapshot,
            deposit_due,
            amount_paid,
            payment_status,
            customer_notes,
            internal_notes,
            hold_expires_at,
            confirmed_at,
            cancelled_at,
            created_at,
            updated_at,
            customers (
              id,
              first_name,
              last_name,
              email,
              phone
            ),
            staff_members!appointments_staff_id_fkey (
              id,
              first_name,
              last_name,
              colour,
              service_role
            ),
            booked_by:staff_members!appointments_created_by_staff_id_fkey (
              id,
              first_name,
              last_name,
              job_title
            )
          `)
          .order(
            "start_at",
            { ascending: false }
          );


      if (options.start) {
        query =
          query.gte(
            "start_at",
            options.start
          );
      }


      if (options.end) {
        query =
          query.lt(
            "start_at",
            options.end
          );
      }


      if (options.status) {
        query =
          query.eq(
            "status",
            options.status
          );
      }


      const {
        data,
        error
      } =
        await query;


      if (error) {
        throw error;
      }


      return (data || []).map(
        function (appointment) {

          const customer =
            appointment.customers || {};

          const staff =
            appointment.staff_members || {};

          const bookedBy =
            appointment.booked_by || {};

          const customerName =
            [
              customer.first_name,
              customer.last_name
            ]
              .filter(Boolean)
              .join(" ");

          const staffName =
            [
              staff.first_name,
              staff.last_name
            ]
              .filter(Boolean)
              .join(" ");

          const bookedByName =
            [
              bookedBy.first_name,
              bookedBy.last_name
            ]
              .filter(Boolean)
              .join(" ");

          let durationMinutes = null;

          if (
            appointment.start_at &&
            appointment.end_at
          ) {
            durationMinutes =
              Math.round(
                (
                  new Date(
                    appointment.end_at
                  ).getTime()
                  -
                  new Date(
                    appointment.start_at
                  ).getTime()
                )
                /
                60000
              );
          }


          return Object.assign(
            {},
            appointment,
            {
              customer_name:
                customerName ||
                "Unknown customer",

              customer_email:
                customer.email || null,

              customer_phone:
                customer.phone || null,

              staff_name:
                staffName ||
                "Unassigned",

              staff_colour:
                staff.colour || null,

              staff_service_role:
                staff.service_role || null,

              booked_by_name:
                bookedByName || null,

              booking_source_label:
                appointment.booking_source ||
                appointment.channel ||
                "legacy",

              duration_minutes:
                durationMinutes
            }
          );
        }
      );
    },


    /*
     * Load one real appointment by UUID.
     */
    async get(id) {

      if (!id) {
        throw new Error(
          "Appointment ID is required."
        );
      }


      const {
        data,
        error
      } =
        await window.supabaseClient
          .from("appointments")
          .select(`
            id,
            reference,
            location_id,
            customer_id,
            service_id,
            staff_id,
            start_at,
            end_at,
            blocked_end_at,
            room,
            channel,
            booking_source,
            created_by_user_id,
            created_by_staff_id,
            status,
            service_name_snapshot,
            price_snapshot,
            deposit_due,
            amount_paid,
            payment_status,
            customer_notes,
            internal_notes,
            hold_expires_at,
            confirmed_at,
            cancelled_at,
            created_at,
            updated_at,
            customers (
              id,
              first_name,
              last_name,
              email,
              phone
            ),
            staff_members!appointments_staff_id_fkey (
              id,
              first_name,
              last_name,
              colour,
              service_role
            ),
            booked_by:staff_members!appointments_created_by_staff_id_fkey (
              id,
              first_name,
              last_name,
              job_title
            )
          `)
          .eq(
            "id",
            id
          )
          .single();


      if (error) {
        throw error;
      }


      const customer =
        data.customers || {};

      const staff =
        data.staff_members || {};

      const bookedBy =
        data.booked_by || {};

      const bookedByName =
        [
          bookedBy.first_name,
          bookedBy.last_name
        ]
          .filter(Boolean)
          .join(" ");


      return Object.assign(
        {},
        data,
        {
          customer_name:
            [
              customer.first_name,
              customer.last_name
            ]
              .filter(Boolean)
              .join(" ")
              ||
              "Unknown customer",

          customer_email:
            customer.email || null,

          customer_phone:
            customer.phone || null,

          staff_name:
            [
              staff.first_name,
              staff.last_name
            ]
              .filter(Boolean)
              .join(" ")
              ||
              "Unassigned",

          staff_colour:
            staff.colour || null,

          staff_service_role:
            staff.service_role || null,

          booked_by_name:
            bookedByName || null,

          booking_source_label:
            data.booking_source ||
            data.channel ||
            "legacy",

          duration_minutes:
            (
              data.start_at &&
              data.end_at
            )
              ?
              Math.round(
                (
                  new Date(
                    data.end_at
                  ).getTime()
                  -
                  new Date(
                    data.start_at
                  ).getTime()
                )
                /
                60000
              )
              :
              null
        }
      );
    },


    /*
     * Send confirmation notifications for a REAL confirmed booking.
     *
     * The Edge Function checks the logged-in Admin JWT.
     * Twilio / Resend secrets remain server-side.
     */
    async sendConfirmationNotifications(
      appointmentId
    ) {

      if (!appointmentId) {
        throw new Error(
          "Appointment ID is required."
        );
      }


      const {
        data,
        error
      } =
        await window.supabaseClient
          .functions
          .invoke(
            "booking-notifications",
            {
              body: {
                appointment_id:
                  appointmentId,

                source:
                  "admin"
              }
            }
          );


      if (error) {

        let message =
          error.message ||
          "Booking notifications failed.";


        try {
          const payload =
            await error.context.json();

          message =
            payload?.error ||
            message;
        } catch {
          // Keep the original FunctionsHttpError message.
        }


        throw new Error(
          message
        );
      }


      return data;
    },


    /*
     * Update a booking status.
     *
     * This changes the real Supabase appointment.
     * Notification delivery is connected in a later step.
     */
    async updateStatus(id, status) {

      if (!id) {
        throw new Error(
          "Appointment ID is required."
        );
      }


      const allowedStatuses = [
        "pending_payment",
        "confirmed",
        "checked_in",
        "completed",
        "cancelled",
        "no_show",
        "expired"
      ];


      if (!allowedStatuses.includes(status)) {
        throw new Error(
          "Invalid appointment status."
        );
      }


      const now =
        new Date().toISOString();


      const patch = {
        status: status,
        updated_at: now
      };


      if (status === "confirmed") {
        patch.confirmed_at = now;
        patch.cancelled_at = null;
        patch.hold_expires_at = null;
      }


      if (status === "cancelled") {
        patch.cancelled_at = now;
      }


      const {
        error
      } =
        await window.supabaseClient
          .from("appointments")
          .update(patch)
          .eq(
            "id",
            id
          );


      if (error) {
        throw error;
      }


      const updated =
        await this.get(id);


      if (status === "confirmed") {

        try {
          await this
            .sendConfirmationNotifications(
              id
            );

        } catch (notificationError) {

          // Booking confirmation itself remains successful.
          // Provider failures are recorded in notification_logs.
          console.warn(
            "Booking confirmed, but confirmation notifications need attention:",
            notificationError
          );
        }

      }


      return updated;
    },


    /*
     * Save the private/internal booking note.
     */
    async updateInternalNotes(id, notes) {

      if (!id) {
        throw new Error(
          "Appointment ID is required."
        );
      }


      const {
        error
      } =
        await window.supabaseClient
          .from("appointments")
          .update({
            internal_notes:
              String(notes || "").trim()
                || null,

            updated_at:
              new Date().toISOString()
          })
          .eq(
            "id",
            id
          );


      if (error) {
        throw error;
      }


      return await this.get(id);
    },


    /*
     * Available booking times for an active treatment.
     *
     * The RPC uses real shifts, leave, current appointments,
     * treatment duration and configured buffer time.
     */
    async availableTimes(serviceId, date) {

      if (!serviceId) {
        throw new Error(
          "Treatment is required."
        );
      }


      if (!date) {
        throw new Error(
          "Date is required."
        );
      }


      const {
        data,
        error
      } =
        await window.supabaseClient
          .rpc(
            "available_times",
            {
              p_service_id:
                serviceId,

              p_date:
                date
            }
          );


      if (error) {
        throw error;
      }


      return data || [];
    },


    /*
     * Available qualified therapists for one exact slot.
     *
     * Each returned therapist already includes their trusted
     * role-specific price and treatment end time.
     */
    async availableStaff(
      serviceId,
      startAt
    ) {

      if (!serviceId) {
        throw new Error(
          "Treatment is required."
        );
      }


      if (!startAt) {
        throw new Error(
          "Start time is required."
        );
      }


      const {
        data,
        error
      } =
        await window.supabaseClient
          .rpc(
            "available_staff_for_slot",
            {
              p_service_id:
                serviceId,

              p_start_at:
                startAt
            }
          );


      if (error) {
        throw error;
      }


      return data || [];
    },


    /*
     * Create a REAL public pending-payment hold.
     *
     * The database recalculates price/duration and rechecks the
     * therapist + required physical resources before inserting.
     */
    async createHold(payload) {

      const booking =
        payload || {};


      const locationId =
        booking.location_id ||
        await getChelseaLocationId();


      const {
        data,
        error
      } =
        await window.supabaseClient
          .rpc(
            "create_booking_hold",
            {
              p_location_id:
                locationId,

              p_service_id:
                booking.service_id,

              p_staff_id:
                booking.staff_id,

              p_start_at:
                booking.start_at,

              p_first_name:
                booking.first_name,

              p_last_name:
                booking.last_name,

              p_email:
                booking.email,

              p_phone:
                booking.phone,

              p_customer_notes:
                booking.customer_notes || null
            }
          );


      if (error) {
        throw error;
      }


      const result =
        Array.isArray(data)
          ? data[0]
          : data;


      if (
        !result ||
        !result.appointment_id
      ) {
        throw new Error(
          "The booking hold was not created."
        );
      }


      return result;
    },


    /*
     * Create a REAL confirmed Admin / Phone / Walk-in booking.
     *
     * All important values are recalculated inside Supabase.
     * Browser-supplied price/duration values are never trusted.
     */
    async createAdmin(payload) {

      const booking =
        payload || {};


      const locationId =
        booking.location_id ||
        await getChelseaLocationId();


      const {
        data,
        error
      } =
        await window.supabaseClient
          .rpc(
            "create_admin_booking",
            {
              p_location_id:
                locationId,

              p_service_id:
                booking.service_id,

              p_staff_id:
                booking.staff_id,

              p_start_at:
                booking.start_at,

              p_first_name:
                booking.first_name,

              p_last_name:
                booking.last_name || "",

              p_email:
                booking.email || "",

              p_phone:
                booking.phone || "",

              p_customer_notes:
                booking.customer_notes || null,

              p_internal_notes:
                booking.internal_notes || null,

              p_channel:
                booking.channel || "admin"
            }
          );


      if (error) {
        throw error;
      }


      const result =
        Array.isArray(data)
          ? data[0]
          : data;


      if (
        !result ||
        !result.appointment_id
      ) {
        throw new Error(
          "Booking was created but no appointment ID was returned."
        );
      }


      const created =
        await this.get(
          result.appointment_id
        );


      try {
        await this
          .sendConfirmationNotifications(
            result.appointment_id
          );

      } catch (notificationError) {

        // Do not undo a valid admin booking because an external
        // email/SMS provider is temporarily unavailable.
        console.warn(
          "Booking created, but confirmation notifications need attention:",
          notificationError
        );
      }


      return created;
    },


    /*
     * Load one calendar range together with active staff.
     *
     * Used by:
     * - Admin Calendar
     * - Admin Dashboard today's schedule
     *
     * Range uses [start, end), so end is exclusive.
     */
    async calendarRange(
      startAt,
      endAt
    ) {

      if (!startAt || !endAt) {
        throw new Error(
          "Calendar start and end are required."
        );
      }


      const [
        appointments,
        staff
      ] =
        await Promise.all([
          this.listAdmin({
            start: startAt,
            end: endAt
          }),

          window.API.Staff.list()
        ]);


      return {
        appointments:
          appointments || [],

        staff:
          (staff || [])
            .filter(item =>
              item.is_active
            )
      };
    }

  },



  /*===================================================*/
  /* IMPORTANT SECTON HERE BELOW ARE THE PR SECTION, to -s
   * — Connect staff data to Supabase 
   * — Add, edit and deactivate therapists 
   * — Assign treatments to therapists 
   * — Create and edit weekly shifts 
   * — Record annual leave, sickness and blocked time 
   * — Give selected staff their own admin login 
  /*===================================================*/
  /* Staff CURD Operations here -*/

  Staff: {
    async list() {
      const { data, error } = await window.supabaseClient
        .from("staff_members")
        .select(`
          *,
          staff_services (
            service_id,
            is_active,
            services (
              id,
              name,
              duration_minutes,
              price,
              is_active
            )
          )
        `)
        .order("first_name");

      if (error) {
        throw error;
      }

      return (data || []).map((staff) => ({
        ...staff,

        full_name: [
          staff.first_name,
          staff.last_name
        ].filter(Boolean).join(" "),

        service_ids: (staff.staff_services || [])
          .filter((assignment) => assignment.is_active)
          .map((assignment) => assignment.service_id)
      }));
    },

    async get(id) {
      const { data, error } = await window.supabaseClient
        .from("staff_members")
        .select(`
          *,
          staff_services (
            service_id,
            is_active,
            services (
              id,
              name,
              duration_minutes,
              price,
              is_active
            )
          )
        `)
        .eq("id", id)
        .single();

      if (error) {
        throw error;
      }

      return {
        ...data,

        full_name: [
          data.first_name,
          data.last_name
        ].filter(Boolean).join(" "),

        service_ids: (data.staff_services || [])
          .filter((assignment) => assignment.is_active)
          .map((assignment) => assignment.service_id)
      };
    },

    /*CREATE STAFF FUNCTIONS */

    async create(staffData) {
      /*
      * Extract the treatment IDs.
      *
      * service_ids belongs in the staff_services table,
      * not directly inside staff_members.
      */
      const serviceIds = Array.isArray(staffData.service_ids)
        ? staffData.service_ids
        : [];

      /*
      * Make a separate copy of the staff information.
      *
      * Object.assign avoids Babel's problematic
      * "...staffFields" object-rest code.
      */
      const staffFields = Object.assign({}, staffData);

      /*
      * Remove service_ids from the staff_members data.
      *
      * Treatment assignments are saved separately below.
      */
      delete staffFields.service_ids;

      /*
      * Use the supplied location or find
      * The Chelsea Spa location automatically.
      */
      const locationId =
        staffFields.location_id ||
        await getChelseaLocationId();

      /*
      * Add the therapist to staff_members.
      */
      const insertData = Object.assign(
        {},
        staffFields,
        {
          location_id: locationId
        }
      );

      const { data: staff, error } =
        await window.supabaseClient
          .from("staff_members")
          .insert(insertData)
          .select()
          .single();

      if (error) {
        throw error;
      }

      /*
      * Connect the therapist to the treatments
      * they are qualified to perform.
      */
      if (serviceIds.length > 0) {
        const assignments = serviceIds.map(
          function (serviceId) {
            return {
              staff_id: staff.id,
              service_id: serviceId,
              is_active: true
            };
          }
        );

        const { error: assignmentError } =
          await window.supabaseClient
            .from("staff_services")
            .insert(assignments);

        if (assignmentError) {
          throw assignmentError;
        }
      }

      /*
      * Return the complete therapist record.
      */
      return this.get(staff.id);
    },

    /*UPDATE STAFF FUNCTIONS */
    async update(id, staffData) {
    /*
    * Check whether treatment assignments were included.
    *
    * If service_ids is omitted, existing assignments
    * will remain unchanged.
    */
    const hasServiceIds =
      Array.isArray(staffData.service_ids);

    const serviceIds = hasServiceIds
      ? staffData.service_ids
      : [];

    /*
    * Copy the normal therapist fields.
    *
    * Again, Object.assign avoids the Babel
    * "_excluded" variable problem.
    */
    const staffFields = Object.assign(
      {},
      staffData
    );

    /*
    * service_ids must not be written directly
    * into staff_members.
    */
    delete staffFields.service_ids;

    /*
    * Update the therapist's normal information.
    */
    if (Object.keys(staffFields).length > 0) {
      const updateData = Object.assign(
        {},
        staffFields,
        {
          updated_at: new Date().toISOString()
        }
      );

      const { error } =
        await window.supabaseClient
          .from("staff_members")
          .update(updateData)
          .eq("id", id);

      if (error) {
        throw error;
      }
    }

    /*
    * Update treatment assignments only when
    * service_ids was included in the request.
    */
    if (hasServiceIds) {
      /*
      * Remove the therapist's previous
      * treatment assignments.
      */
      const { error: deleteError } =
        await window.supabaseClient
          .from("staff_services")
          .delete()
          .eq("staff_id", id);

      if (deleteError) {
        throw deleteError;
      }

      /*
      * Add the newly selected treatments.
      */
      if (serviceIds.length > 0) {
        const assignments = serviceIds.map(
          function (serviceId) {
            return {
              staff_id: id,
              service_id: serviceId,
              is_active: true
            };
          }
        );

        const { error: insertError } =
          await window.supabaseClient
            .from("staff_services")
            .insert(assignments);

        if (insertError) {
          throw insertError;
        }
      }
    }

    /*
    * Reload and return the updated therapist.
    */
    return this.get(id);
  },

    async deactivate(id) {
      const { data, error } =
        await window.supabaseClient
          .from("staff_members")
          .update({
            is_active: false,
            show_online: false,
            updated_at: new Date().toISOString()
          })
          .eq("id", id)
          .select()
          .single();

      if (error) {
        throw error;
      }

      return data;
    },

    async activate(id) {
      const { data, error } =
        await window.supabaseClient
          .from("staff_members")
          .update({
            is_active: true,
            updated_at: new Date().toISOString()
          })
          .eq("id", id)
          .select()
          .single();

      if (error) {
        throw error;
      }

      return data;
    },

    async remove(id) {
      const { error } = await window.supabaseClient
        .from("staff_members")
        .delete()
        .eq("id", id);

      if (error) {
        throw error;
      }

      return true;
    }
  },

  // ==========================================================
  // STAFF LOGIN / ACCESS ROLE
  //
  // IMPORTANT:
  // Service role lives in staff_members.
  // Access role lives in profiles.
  // ==========================================================

  StaffAccess: {

    // --------------------------------------------------------
    // Load the access role for one linked Auth user.
    //
    // userId = staff_members.user_id
    // --------------------------------------------------------
    async get(userId) {

      // Staff without a login account have no profile yet.
      if (!userId) {
        return null;
      }

      const { data, error } =
        await window.supabaseClient
          .from("profiles")
          .select(`
            id,
            email,
            access_role,
            is_active
          `)
          .eq("id", userId)
          .maybeSingle();

      if (error) {
        throw error;
      }

      return data;
    },


  // --------------------------------------------------------
  // Change normal business access.
  //
  // Super Admin is deliberately NOT allowed here.
  // Super Admin promotion belongs in a separate
  // developer-only system screen.
  // --------------------------------------------------------
    async update(userId, accessRole) {

      if (!userId) {
        throw new Error(
          "This staff member does not have a login account yet."
        );
      }

      // Only these roles are assignable from Staff Management.
      const allowedRoles = [
        "practitioner",
        "admin"
      ];

      if (!allowedRoles.includes(accessRole)) {
        throw new Error(
          "Only Practitioner or Admin access can be assigned here."
        );
      }

      const { data, error } =
        await window.supabaseClient
          .from("profiles")
          .update({
            access_role: accessRole,
            updated_at:
              new Date().toISOString()
          })
          .eq("id", userId)
          .select()
          .single();

      if (error) {
        throw error;
      }

      return data;
    }

  },

  Shifts: {
    async list(options = {}) {
      let query = window.supabaseClient
        .from("shifts")
        .select(`
          *,
          staff_members (
            id,
            first_name,
            last_name,
            job_title,
            colour
          )
        `)
        .order("start_at");

      if (options.start) {
        query = query.gte(
          "start_at",
          options.start
        );
      }

      if (options.end) {
        query = query.lt(
          "start_at",
          options.end
        );
      }

      if (options.staff_id) {
        query = query.eq(
          "staff_id",
          options.staff_id
        );
      }

      const { data, error } = await query;

      if (error) {
        throw error;
      }

      return data || [];
    },

    async create(shiftData) {
      const locationId =
        shiftData.location_id ||
        await getChelseaLocationId();

      const { data, error } =
        await window.supabaseClient
          .from("shifts")
          .insert({
            ...shiftData,
            location_id: locationId
          })
          .select()
          .single();

      if (error) {
        throw error;
      }

      return data;
    },

    async update(id, shiftData) {
      const { data, error } =
        await window.supabaseClient
          .from("shifts")
          .update({
            ...shiftData,
            updated_at: new Date().toISOString()
          })
          .eq("id", id)
          .select()
          .single();

      if (error) {
        throw error;
      }

      return data;
    },

    async remove(id) {
      const { error } = await window.supabaseClient
        .from("shifts")
        .delete()
        .eq("id", id);

      if (error) {
        throw error;
      }

      return true;
    }
  },

  // ==========================================================
  // RECURRING WEEKLY ROTA — STEP 10G
  // ==========================================================
  WeeklyRota: {

    async listForDate(date) {
      const targetDate =
        date || new Date().toISOString().slice(0, 10);

      const { data, error } =
        await window.supabaseClient
          .from("staff_weekly_schedule")
          .select(`
            id,
            staff_id,
            location_id,
            weekday,
            is_working,
            start_time,
            end_time,
            break_minutes,
            effective_from,
            effective_to,
            notes,
            created_at,
            updated_at
          `)
          .lte("effective_from", targetDate)
          .or(
            `effective_to.is.null,effective_to.gte.${targetDate}`
          )
          .order("staff_id")
          .order("weekday");

      if (error) {
        throw error;
      }

      return data || [];
    },


    async getStaff(staffId, date) {
      if (!staffId) {
        throw new Error("Therapist is required.");
      }

      const targetDate =
        date || new Date().toISOString().slice(0, 10);

      const { data, error } =
        await window.supabaseClient
          .from("staff_weekly_schedule")
          .select(`
            id,
            staff_id,
            location_id,
            weekday,
            is_working,
            start_time,
            end_time,
            break_minutes,
            effective_from,
            effective_to,
            notes,
            created_at,
            updated_at
          `)
          .eq("staff_id", staffId)
          .lte("effective_from", targetDate)
          .or(
            `effective_to.is.null,effective_to.gte.${targetDate}`
          )
          .order("weekday");

      if (error) {
        throw error;
      }

      return data || [];
    },


    async save(staffId, effectiveFrom, schedule) {
      if (!staffId) {
        throw new Error("Therapist is required.");
      }

      if (!effectiveFrom) {
        throw new Error("Effective date is required.");
      }

      if (!Array.isArray(schedule) || schedule.length !== 7) {
        throw new Error("A complete Monday-Sunday rota is required.");
      }

      const { data, error } =
        await window.supabaseClient
          .rpc(
            "save_staff_weekly_schedule",
            {
              p_staff_id: staffId,
              p_effective_from: effectiveFrom,
              p_schedule: schedule
            }
          );

      if (error) {
        throw error;
      }

      return data || [];
    },


    async history(staffId) {
      if (!staffId) {
        throw new Error("Therapist is required.");
      }

      const { data, error } =
        await window.supabaseClient
          .from("staff_weekly_schedule")
          .select("*")
          .eq("staff_id", staffId)
          .order("effective_from", { ascending: false })
          .order("weekday");

      if (error) {
        throw error;
      }

      return data || [];
    }
  },

  Leave: {
    async list(options = {}) {
      let query = window.supabaseClient
        .from("staff_time_off")
        .select(`
          *,
          staff_members (
            id,
            first_name,
            last_name,
            job_title,
            colour
          )
        `)
        .order("start_at", {
          ascending: false
        });

      if (options.status) {
        query = query.eq(
          "status",
          options.status
        );
      }

      if (options.staff_id) {
        query = query.eq(
          "staff_id",
          options.staff_id
        );
      }

      const { data, error } = await query;

      if (error) {
        throw error;
      }

      return data || [];
    },

    async create(leaveData) {
      const { data, error } =
        await window.supabaseClient
          .from("staff_time_off")
          .insert(leaveData)
          .select()
          .single();

      if (error) {
        throw error;
      }

      return data;
    },

    async update(id, leaveData) {
      const { data, error } =
        await window.supabaseClient
          .from("staff_time_off")
          .update({
            ...leaveData,
            updated_at: new Date().toISOString()
          })
          .eq("id", id)
          .select()
          .single();

      if (error) {
        throw error;
      }

      return data;
    },

    async approve(id) {
      return this.update(id, {
        status: "approved"
      });
    },

    async decline(id) {
      return this.update(id, {
        status: "declined"
      });
    },

    async remove(id) {
      const { error } = await window.supabaseClient
        .from("staff_time_off")
        .delete()
        .eq("id", id);

      if (error) {
        throw error;
      }

      return true;
    }
  },

  /* ============================================================
     PAYMENTS — Stripe-hosted Checkout through Supabase Edge Functions
     ============================================================ */
  Invoices: crud("invoices"),
  Coupons:  crud("coupons"),

  Payments: {

    /*
     * Starts Stripe Checkout for an existing pending-payment
     * appointment. Amount is always read again on the server.
     */
    async startCheckout({
      appointment_id,
      reference,
      payment_type = "deposit"
    } = {}) {

      if (!appointment_id || !reference) {
        throw new Error(
          "Booking reference is missing. Please start the booking again."
        );
      }


      if (
        payment_type !== "deposit" &&
        payment_type !== "full"
      ) {
        throw new Error(
          "Choose deposit or full payment."
        );
      }


      const {
        data,
        error
      } =
        await window.supabaseClient
          .functions
          .invoke(
            "create-checkout-session",
            {
              body: {
                appointment_id,
                reference,
                payment_type
              }
            }
          );


      if (error) {
        console.error(
          "Stripe Checkout function failed:",
          error
        );

        throw new Error(
          error.message ||
          "Payment could not be started."
        );
      }


      if (!data?.url) {
        throw new Error(
          data?.error ||
          "Stripe did not return a Checkout URL."
        );
      }


      return data;
    },


    /*
     * Reads the server-confirmed payment/appointment state after
     * Stripe redirects the customer back to the website.
     * The success URL itself is never treated as proof of payment.
     */
    async checkoutStatus(sessionId) {

      if (!sessionId) {
        throw new Error(
          "Stripe session ID is missing."
        );
      }


      const {
        data,
        error
      } =
        await window.supabaseClient
          .functions
          .invoke(
            "checkout-status",
            {
              body: {
                session_id:
                  sessionId
              }
            }
          );


      if (error) {
        console.error(
          "Checkout status function failed:",
          error
        );

        throw new Error(
          error.message ||
          "Payment status could not be checked."
        );
      }


      if (data?.error) {
        throw new Error(
          data.error
        );
      }


      return data;
    },


    // Retained for a later authenticated Admin refund workflow.
    refund: (body) =>
      request(
        "/payments/refund/",
        {
          method: "POST",
          body
        }
      )
  },

  /* Inventory */
  Stock:          Object.assign(crud("stock"), { low: () => request("/stock/low/") }),
  Suppliers:      crud("suppliers"),
  PurchaseOrders: crud("purchase-orders"),

  /* CMS */
  CMS: {
    sections:      ()        => request("/cms/sections/"),
    updateSection: (id, body) => request(`/cms/sections/${id}/`, { method: "PATCH", body }),
    faq:           crud("cms/faq"),
    testimonials:  crud("cms/testimonials"),
    seo:           ()        => request("/cms/seo/"),
    media:         crud("cms/media"),
  },

  /* Analytics */
  Analytics: {
    overview:   ()            => request("/analytics/overview/"),
    revenue:    (range = "7d") => request("/analytics/revenue/", { params: { range } }),
    treatments: ()            => request("/analytics/treatments/"),
    staff:      ()            => request("/analytics/staff/"),
    retention:  ()            => request("/analytics/retention/"),
  },

  /* Notifications */
  Notify: {
    send: (body) => request("/notify/send/", { method: "POST", body }),
    log:  ()     => request("/notify/log/"),
  },
};

/* =====================================================================
   React data hooks — use these in modules to fetch live data with
   loading / error / empty states handled for you.

   Example:
     const { loading, data, error } = useResource(
       () => API.Bookings.list({ status: "pending" }),
       [status]
     );
   ===================================================================== */
function useResource(fetcher, deps = []) {
  const [state, setState] = React.useState({ loading: true, data: null, error: null });
  React.useEffect(() => {
    let alive = true;
    setState(s => ({ ...s, loading: true, error: null }));
    Promise.resolve(fetcher())
      .then(d => alive && setState({ loading: false, data: d, error: null }))
      .catch(e => alive && setState({ loading: false, data: null, error: e }));
    return () => { alive = false; };
  }, deps);            // eslint-disable-line
  return state;
}

/* Simple mutation helper for create/update/delete + toast wiring. */
function useMutation(fn) {
  const [pending, setPending] = React.useState(false);
  const [error, setError] = React.useState(null);
  const run = async (...args) => {
    setPending(true); setError(null);
    try { return await fn(...args); }
    catch (e) { setError(e); throw e; }
    finally { setPending(false); }
  };
  return { run, pending, error };
}

Object.assign(window, { API, CS_CONFIG, useResource, useMutation });
