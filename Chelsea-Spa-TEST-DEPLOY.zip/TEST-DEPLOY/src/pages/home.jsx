/* =========================================================================
   HOME PAGE — The Chelsea Spa
   ========================================================================= */

function HomePage() {
  const { navigate } = useRouter();
  const {
    siteText,
    settings
  } = useSiteContent();

  const openingHours =
    settings?.opening_hours || {};

  const todayHours =
    [0, 6].includes(
      new Date().getDay()
    )
      ? (
          openingHours.sat_sun ||
          "10:00 – 18:00"
        )
      : (
          openingHours.mon_fri ||
          "09:00 – 20:00"
        );

  return (
    <div>
      <Nav transparent />

      {/* HERO ---------------------------------------------------------- */}
      <section style={{
        position: "relative", height: "100vh", minHeight: 720, overflow: "hidden",
        color: "var(--ink-on-dark)"
      }}>
        <video
          src={siteText("home", "hero_video_url", "assets/hero.mp4")}
          autoPlay muted loop playsInline
          style={{
            position: "absolute", inset: 0,
            width: "100%", height: "100%",
            objectFit: "cover", zIndex: 0
          }}
          onError={(e) => {e.target.style.display = "none";}} />
        
        {/* fallback gradient under video */}
        <div style={{
          position: "absolute", inset: 0, zIndex: -1,
          background: "linear-gradient(160deg, #4a3f33 0%, #2a2622 60%, #1a1612 100%)"
        }} />
        {/* darkening overlays */}
        <div style={{
          position: "absolute", inset: 0, zIndex: 1,
          background: "linear-gradient(180deg, rgba(42,38,34,0.55) 0%, rgba(42,38,34,0.15) 40%, rgba(42,38,34,0.75) 100%)"
        }} />

        <div className="container-wide" style={{
          position: "relative", zIndex: 2,
          height: "100%", display: "flex", flexDirection: "column",
          justifyContent: "flex-end", paddingBottom: 96, paddingTop: 140
        }}>
          <div className="eyebrow fade-up" style={{ color: "rgb(187, 194, 245)" }}>
            {siteText("home", "hero_eyebrow", "✦ Chelsea, London · Est. 2014")}
          </div>
          <h1 className="fade-up-1" style={{
            color: "var(--ink-on-dark)",
            maxWidth: "16ch", marginTop: 18,
            fontWeight: 300, fontFamily: "Roboto", fontSize: "50px"
          }}>
            {siteText("home", "hero_headline", "Elevate Your Beauty,")}
          </h1>
          <p className="body-lg fade-up-2" style={{
            color: "rgba(246,241,232,0.82)",
            maxWidth: "44ch", marginTop: 28, fontSize: "1.1rem"
          }}>{siteText(
            "home",
            "hero_subtext",
            "Experience the finest luxury beauty treatments, bespoke facials, ceremonial massage and slow, well-thought rituals on Hollywood Road, Chelsea. Eleven years in the making."
          )}</p>
          <div className="fade-up-3" style={{ display: "flex", gap: 14, marginTop: 40, flexWrap: "wrap" }}>
            <Button variant="gold" size="lg" onClick={() => navigate("/booking")} iconRight="arrow-right">
              Book a treatment
            </Button>
            <Button variant="ghost-light" size="lg" onClick={() => navigate("/treatments")}>
              View the menu
            </Button>
          </div>
        </div>

        {/* corner meta */}
        <div className="fade-up-4" style={{
          position: "absolute", right: 32, bottom: 32, zIndex: 2,
          display: "flex", alignItems: "center", gap: 24,
          color: "rgba(246,241,232,0.7)",
          fontFamily: "var(--font-display)", fontSize: "0.72rem", letterSpacing: "0.18em", textTransform: "uppercase"
        }} id="hero-meta">
          <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
            <span style={{ width: 6, height: 6, background: "var(--gold)", borderRadius: "50%" }} />
            Open today · {todayHours}
          </div>
          <span style={{ opacity: 0.5 }}>|</span>
          <span>↓ scroll</span>
        </div>
      </section>

      {/* INTRO MARQUEE / VALUE PROPS ----------------------------------- */}
      <section style={{ padding: "72px 0 0", background: "var(--bg)" }}>
        <div className="container-wide">
          <div style={{
            display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 1,
            background: "var(--line)", border: "1px solid var(--line)"
          }} className="props-grid">
            {[
            { label: "Bespoke", value: "Every ritual, tailored" },
            { label: "Therapists", value: "12+ years on average" },
            { label: "Products", value: "Apothecary-grade only" },
            { label: "Booking", value: "Confirmed in 60 seconds" }].
            map((item) =>
            <div key={item.label} style={{ background: "var(--bg)", padding: "40px 32px" }}>
                <div className="eyebrow">{item.label}</div>
                <div style={{ marginTop: 14, fontFamily: "var(--font-display)", fontSize: "1.4rem", lineHeight: 1.2, letterSpacing: "-0.02em" }}>
                  {item.value}
                </div>
              </div>
            )}
          </div>
        </div>
        <style>{`
          @media (max-width: 880px) {
            .props-grid { grid-template-columns: 1fr 1fr !important; }
          }
        `}</style>
      </section>

      {/* FEATURED TREATMENTS ------------------------------------------ */}
      <section className="section-lg">
        <div className="container-wide">
          <div style={{
            display: "flex", justifyContent: "space-between", alignItems: "flex-end",
            marginBottom: 56, flexWrap: "wrap", gap: 24
          }}>
            <div style={{ maxWidth: 600 }}>
              <div className="eyebrow">The menu</div>
              <h2 style={{ marginTop: 12 }}>
                A small, careful <em className="serif-italic" style={{ color: "var(--gold-deep)" }}>edit</em><br />of treatments.
              </h2>
            </div>
            <Button variant="ghost" onClick={() => navigate("/treatments")} iconRight="arrow-right">
              All treatments
            </Button>
          </div>

          <div style={{
            display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 24
          }} className="featured-grid">
            {TREATMENTS.slice(0, 3).map((t, i) =>
            <div key={t.id} className="card card-hover fade-up" style={{
              animationDelay: `${i * 120}ms`, cursor: "pointer"
            }} onClick={() => navigate("/booking?t=" + t.id)}>
                <Placeholder label={`${t.category.toLowerCase()} · imagery`} height={320} />
                <div style={{ padding: 28 }}>
                  <div className="eyebrow" style={{ color: "var(--ink-3)" }}>{t.category}</div>
                  <h3 style={{ marginTop: 8 }}>{t.name}</h3>
                  <p style={{ marginTop: 12, fontSize: "0.95rem" }}>{t.blurb}</p>
                  <div style={{
                  marginTop: 24, paddingTop: 20, borderTop: "1px solid var(--line)",
                  display: "flex", justifyContent: "space-between", alignItems: "center"
                }}>
                    <div style={{ display: "flex", gap: 16, fontFamily: "var(--font-display)", fontSize: "0.8rem", letterSpacing: "0.08em", color: "var(--ink-2)" }}>
                      <span>{t.duration} min</span>
                      <span style={{ color: "var(--gold-deep)" }}>£{t.price}</span>
                    </div>
                    <Icon name="arrow-right" size={16} />
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
        <style>{`
          @media (max-width: 980px) { .featured-grid { grid-template-columns: 1fr 1fr !important; } }
          @media (max-width: 680px) { .featured-grid { grid-template-columns: 1fr !important; } }
        `}</style>
      </section>

      {/* ABOUT / EDITORIAL ------------------------------------------- */}
      <section className="section-lg" style={{ background: "var(--bg-cream)" }}>
        <div className="container-wide">
          <div style={{
            display: "grid", gridTemplateColumns: "1fr 1fr", gap: 80, alignItems: "center"
          }} className="about-grid">
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16 }}>
              <Placeholder label="interior · long" height={420} style={{ gridRow: "1 / 3" }} />
              <Placeholder label="ritual · top" height={200} />
              <Placeholder label="hands · bottom" height={200} />
            </div>
            <div>
              <div className="eyebrow">Our intention</div>
              <h2 style={{ marginTop: 14, marginBottom: 28 }}>
                {siteText(
                  "home",
                  "about_heading",
                  "Eleven years of quiet practice, perfected in a single room."
                )}
              </h2>
              <p className="body-lg" style={{ marginBottom: 20 }}>
                {siteText(
                  "home",
                  "about_intro",
                  "We opened in 2014 with one rule: nothing rushed. Our therapists each carry over a decade of pressure in their hands, and our treatment rooms hold only one guest at a time."
                )}
              </p>
              <p style={{ marginBottom: 36 }}>
                Every product on our shelves is apothecary-grade — sourced for what it does, not for what it sells.
                Every ritual begins with a long conversation. We promise you'll feel the difference within twenty minutes.
              </p>
              <Button variant="ghost" onClick={() => navigate("/about")} iconRight="arrow-right">
                Our story
              </Button>
            </div>
          </div>
        </div>
        <style>{`
          @media (max-width: 980px) { .about-grid { grid-template-columns: 1fr !important; gap: 48px !important; } }
        `}</style>
      </section>

      {/* TESTIMONIAL ------------------------------------------------- */}
      <HomeTestimonials />

      {/* MEMBERSHIP -------------------------------------------------- */}
      <section className="section-lg" style={{ background: "var(--ink)", color: "var(--ink-on-dark)" }}>
        <div className="container-wide">
          <div style={{
            display: "grid", gridTemplateColumns: "1fr 1.2fr", gap: 80, alignItems: "center"
          }} className="member-grid">
            <div>
              <div className="eyebrow" style={{ color: "var(--gold-soft)" }}>Membership</div>
              <h2 style={{ marginTop: 14, color: "var(--ink-on-dark)", marginBottom: 28 }}>
                The <em className="serif-italic" style={{ color: "var(--gold)" }}>Atelier</em> Circle.
              </h2>
              <p className="body-lg" style={{ color: "rgba(246,241,232,0.78)", marginBottom: 24 }}>
                Two rituals each month, priority bookings, member-only products and a slow afternoon in our private suite each season.
              </p>
              <div style={{ display: "flex", gap: 14, flexWrap: "wrap" }}>
                <Button variant="gold" onClick={() => navigate("/about")} iconRight="arrow-right">From £240/month</Button>
                <Button variant="ghost-light" onClick={() => navigate("/about")}>Learn more</Button>
              </div>
            </div>
            <div style={{ border: "1px solid rgba(246,241,232,0.16)", padding: 40, borderRadius: 8 }}>
              {[
              ["Monthly rituals included", "2"],
              ["Priority booking window", "21 days"],
              ["Product discount", "15%"],
              ["Guest passes per year", "4"],
              ["Seasonal half-day", "Included"]].
              map(([k, v], i, arr) =>
              <div key={k} style={{
                display: "flex", justifyContent: "space-between", alignItems: "center",
                padding: "18px 0",
                borderBottom: i < arr.length - 1 ? "1px solid rgba(246,241,232,0.1)" : "none"
              }}>
                  <span style={{ color: "rgba(246,241,232,0.72)", fontFamily: "var(--font-body)" }}>{k}</span>
                  <span style={{ fontFamily: "var(--font-display)", fontSize: "1.05rem", color: "var(--gold-soft)" }}>{v}</span>
                </div>
              )}
            </div>
          </div>
        </div>
        <style>{`
          @media (max-width: 980px) { .member-grid { grid-template-columns: 1fr !important; gap: 40px !important; } }
        `}</style>
      </section>

      {/* INSTAGRAM GALLERY ------------------------------------------- */}
      <section className="section">
        <div className="container-wide">
          <div className="section-head" style={{ textAlign: "center", margin: "0 auto 56px" }}>
            <div className="eyebrow">@thechelseaspa</div>
            <h2>Notes from our diary.</h2>
          </div>
          <div style={{
            display: "grid", gridTemplateColumns: "repeat(6, 1fr)", gap: 8
          }} className="ig-grid">
            {Array.from({ length: 6 }).map((_, i) =>
            <Placeholder key={i} label={`ig · 0${i + 1}`} height={180} style={{ cursor: "pointer" }} />
            )}
          </div>
        </div>
        <style>{`
          @media (max-width: 980px) { .ig-grid { grid-template-columns: repeat(3, 1fr) !important; } }
          @media (max-width: 480px) { .ig-grid { grid-template-columns: repeat(2, 1fr) !important; } }
        `}</style>
      </section>

      {/* CTA --------------------------------------------------------- */}
      <section style={{ paddingBottom: 120 }}>
        <div className="container-wide">
          <div style={{
            background: "var(--bg-nude)",
            padding: "96px 64px",
            borderRadius: 8,
            display: "grid", gridTemplateColumns: "1fr 1fr", gap: 64, alignItems: "center",
            position: "relative", overflow: "hidden"
          }} className="cta-block">
            <div>
              <h2>Ready to be<br /><em className="serif-italic" style={{ color: "var(--gold-deep)" }}>looked after?</em></h2>
              <p className="body-lg" style={{ marginTop: 20, maxWidth: "40ch" }}>
                Sixty seconds, three choices, your therapist confirmed by name. The hardest part is choosing what to wear afterwards.
              </p>
            </div>
            <div style={{ display: "flex", flexDirection: "column", gap: 14, alignItems: "flex-start" }}>
              <Button variant="primary" size="lg" onClick={() => navigate("/booking")} iconRight="arrow-right">Book your ritual</Button>
              <span className="caption">Or call us · 020 7351 4555</span>
            </div>
            {/* Decorative lotus */}
            <div style={{ position: "absolute", right: -40, top: -40, opacity: 0.08 }}>
              <LogoMark size={280} color="var(--ink)" />
            </div>
          </div>
        </div>
        <style>{`
          @media (max-width: 880px) { .cta-block { grid-template-columns: 1fr !important; padding: 56px 32px !important; gap: 32px !important; } }
        `}</style>
      </section>

      <Footer />
    </div>);

}

/* --- Testimonials carousel (auto-rotating) ----------------------- */
function HomeTestimonials() {
  const {
    testimonials
  } = useSiteContent();

  const fallbackReviews = [
    {
      quote:
        "The closest London gets to a Kyoto onsen. I came in clenched and left a different person.",
      author: "Eloise H.",
      author_meta:
        "Member · 3 years",
      rating: 5
    },
    {
      quote:
        "Mala's facial work is on another plane. Skin still soft a week later, and that has never happened to me before.",
      author: "Saskia R.",
      author_meta: "Guest",
      rating: 5
    },
    {
      quote:
        "I've been to spas across four continents and this is the only one I rebook before I leave the room.",
      author: "Daniel A.",
      author_meta:
        "Member · 2 years",
      rating: 5
    }
  ];

  const reviews =
    testimonials?.length
      ? testimonials
      : fallbackReviews;

  const [idx, setIdx] =
    useState(0);

  useEffect(() => {
    if (idx >= reviews.length) {
      setIdx(0);
    }
  }, [reviews.length, idx]);

  useEffect(() => {
    if (reviews.length <= 1) {
      return;
    }

    const id =
      setInterval(
        () =>
          setIdx(
            current =>
              (current + 1)
              %
              reviews.length
          ),
        6500
      );

    return () =>
      clearInterval(id);
  }, [reviews.length]);

  const review =
    reviews[idx] ||
    reviews[0];

  if (!review) {
    return null;
  }

  const rating =
    Math.min(
      5,
      Math.max(
        1,
        Number(review.rating) || 5
      )
    );

  return (
    <section className="section-lg">
      <div
        className="container-narrow"
        style={{
          textAlign: "center"
        }}
      >
        <div
          className="eyebrow"
          style={{
            marginBottom: 28
          }}
        >
          What our guests say
        </div>

        <div
          style={{
            display: "flex",
            justifyContent:
              "center",
            gap: 6,
            marginBottom: 32
          }}
        >
          {Array
            .from({
              length: rating
            })
            .map((_, i) => (
              <Icon
                key={i}
                name="star"
                size={18}
                className="text-gold"
              />
            ))}
        </div>

        <div
          style={{
            minHeight: 160
          }}
          key={idx}
          className="fade-in"
        >
          <p
            style={{
              fontFamily:
                "var(--font-body)",
              fontStyle: "italic",
              fontSize: "1.6rem",
              lineHeight: 1.45,
              color: "var(--ink)",
              maxWidth: "30ch",
              margin: "0 auto"
            }}
          >
            "{review.quote}"
          </p>

          <div
            style={{
              marginTop: 28
            }}
            className="eyebrow"
          >
            {review.author}
            {review.author_meta && (
              <>
                {" · "}
                <span
                  style={{
                    color:
                      "var(--ink-3)"
                  }}
                >
                  {review.author_meta}
                </span>
              </>
            )}
          </div>
        </div>

        {reviews.length > 1 && (
          <div
            style={{
              display: "flex",
              justifyContent:
                "center",
              gap: 8,
              marginTop: 32
            }}
          >
            {reviews.map(
              (_, i) => (
                <button
                  key={i}
                  onClick={() =>
                    setIdx(i)
                  }
                  style={{
                    width:
                      i === idx
                        ? 28
                        : 8,
                    height: 4,
                    background:
                      i === idx
                        ? "var(--gold-deep)"
                        : "var(--line-strong)",
                    borderRadius: 2,
                    transition:
                      "all 320ms var(--ease)"
                  }}
                />
              )
            )}
          </div>
        )}
      </div>
    </section>
  );
}

window.HomePage = HomePage;