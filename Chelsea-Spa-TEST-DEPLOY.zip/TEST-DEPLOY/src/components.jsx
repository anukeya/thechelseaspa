/* =========================================================================
   THE CHELSEA SPA — Shared components & primitives
   This file is plain React + JSX (no JSX transform — relies on Babel standalone)
   Exports to window for cross-script consumption.
   ========================================================================= */

const { useState, useEffect, useRef, useCallback, useMemo, createContext, useContext } = React;

/* ----------------------------- ROUTING ----------------------------------- */
/* Simple hash-based router. State lives in <App />.  */
const RouterCtx = createContext(null);

function RouterProvider({ children }) {
  const [path, setPath] = useState(() => window.location.hash.replace(/^#/, "") || "/");
  useEffect(() => {
    const onHash = () => setPath(window.location.hash.replace(/^#/, "") || "/");
    window.addEventListener("hashchange", onHash);
    return () => window.removeEventListener("hashchange", onHash);
  }, []);
  const navigate = useCallback((to) => {
    window.location.hash = to;
    window.scrollTo({ top: 0, behavior: "instant" });
  }, []);
  return <RouterCtx.Provider value={{ path, navigate }}>{children}</RouterCtx.Provider>;
}
const useRouter = () => useContext(RouterCtx);


/* ----------------------- LIVE SITE CONTENT / SEO ------------------------- */
const SiteContentCtx = createContext({
  loading: false,
  location: null,
  settings: null,
  sections: {},
  testimonials: [],
  faqs: [],
  seoPages: {},
  siteText: (_page, _key, fallback = "") => fallback,
  siteJson: (_page, _key, fallback = {}) => fallback
});

function setMetaTag(selector, attrs) {
  let node =
    document.head.querySelector(selector);

  if (!node) {
    node =
      document.createElement("meta");

    Object.entries(attrs).forEach(
      ([key, value]) =>
        node.setAttribute(key, value)
    );

    document.head.appendChild(node);
  }

  return node;
}

function setCanonicalLink(href) {
  let node =
    document.head.querySelector(
      'link[rel="canonical"]'
    );

  if (!node) {
    node =
      document.createElement("link");

    node.setAttribute(
      "rel",
      "canonical"
    );

    document.head.appendChild(node);
  }

  node.setAttribute("href", href);
}

function SiteContentProvider({
  children
}) {
  const { path } =
    useRouter();

  const [state, setState] =
    useState({
      loading: true,
      location: null,
      settings: null,
      sections: {},
      testimonials: [],
      faqs: [],
      seoPages: {}
    });


  useEffect(() => {
    let cancelled = false;

    (async () => {
      try {
        const {
          data: location,
          error: locationError
        } =
          await window
            .supabaseClient
            .from("locations")
            .select(`
              id,
              name,
              address_line_1,
              address_line_2,
              city,
              postcode,
              phone,
              email,
              timezone
            `)
            .eq(
              "name",
              "The Chelsea Spa"
            )
            .eq("is_active", true)
            .single();

        if (locationError) {
          throw locationError;
        }

        const locationId =
          location.id;

        const [
          settingsResult,
          sectionResult,
          testimonialResult,
          faqResult,
          seoResult
        ] =
          await Promise.all([
            window.supabaseClient
              .from(
                "public_site_settings"
              )
              .select("*")
              .eq(
                "location_id",
                locationId
              )
              .maybeSingle(),

            window.supabaseClient
              .from("cms_sections")
              .select(`
                page_key,
                section_key,
                content_text,
                content_json,
                sort_order
              `)
              .eq(
                "location_id",
                locationId
              )
              .eq(
                "is_published",
                true
              )
              .order("sort_order"),

            window.supabaseClient
              .from(
                "cms_testimonials"
              )
              .select(`
                id,
                quote,
                author,
                author_meta,
                rating,
                sort_order
              `)
              .eq(
                "location_id",
                locationId
              )
              .eq(
                "is_published",
                true
              )
              .order("sort_order"),

            window.supabaseClient
              .from("cms_faqs")
              .select(`
                id,
                question,
                answer,
                sort_order
              `)
              .eq(
                "location_id",
                locationId
              )
              .eq(
                "is_published",
                true
              )
              .order("sort_order"),

            window.supabaseClient
              .from("seo_pages")
              .select("*")
              .eq(
                "location_id",
                locationId
              )
          ]);


        const firstError =
          settingsResult.error ||
          sectionResult.error ||
          testimonialResult.error ||
          faqResult.error ||
          seoResult.error;

        if (firstError) {
          throw firstError;
        }


        const sections = {};

        (sectionResult.data || [])
          .forEach(row => {
            if (!sections[row.page_key]) {
              sections[row.page_key] = {};
            }

            sections[row.page_key][
              row.section_key
            ] = {
              text:
                row.content_text,
              json:
                row.content_json || {}
            };
          });


        const seoPages = {};

        (seoResult.data || [])
          .forEach(row => {
            seoPages[
              row.page_key
            ] = row;
          });


        if (!cancelled) {
          setState({
            loading: false,
            location,
            settings:
              settingsResult.data ||
              null,
            sections,
            testimonials:
              testimonialResult.data ||
              [],
            faqs:
              faqResult.data ||
              [],
            seoPages
          });
        }

      } catch (error) {
        console.warn(
          "Public CMS content could not be loaded; using built-in page fallbacks.",
          error
        );

        if (!cancelled) {
          setState(
            current => ({
              ...current,
              loading: false
            })
          );
        }
      }
    })();


    return () => {
      cancelled = true;
    };
  }, []);


  const siteText =
    useCallback(
      (
        page,
        key,
        fallback = ""
      ) => {
        const value =
          state
            .sections
            ?.[page]
            ?.[key]
            ?.text;

        return value === null ||
               value === undefined ||
               value === ""
          ? fallback
          : value;
      },
      [state.sections]
    );


  const siteJson =
    useCallback(
      (
        page,
        key,
        fallback = {}
      ) => {
        const value =
          state
            .sections
            ?.[page]
            ?.[key]
            ?.json;

        return value &&
               typeof value ===
                 "object"
          ? value
          : fallback;
      },
      [state.sections]
    );


  useEffect(() => {
    const base =
      String(path || "/")
        .split("?")[0]
        .split("#")[0];

    let pageKey = "home";

    if (
      base.startsWith(
        "/treatments"
      )
    ) {
      pageKey = "treatments";
    } else if (
      base.startsWith("/shop")
    ) {
      pageKey = "shop";
    } else if (
      base.startsWith(
        "/booking"
      )
    ) {
      pageKey = "booking";
    } else if (
      base.startsWith("/about")
    ) {
      pageKey = "about";
    } else if (
      base.startsWith(
        "/contact"
      )
    ) {
      pageKey = "contact";
    }

    const seo =
      state.seoPages?.[pageKey];

    if (!seo) {
      return;
    }

    if (seo.meta_title) {
      document.title =
        seo.meta_title;
    }

    const description =
      setMetaTag(
        'meta[name="description"]',
        {
          name: "description"
        }
      );

    description.setAttribute(
      "content",
      seo.meta_description || ""
    );

    const robots =
      setMetaTag(
        'meta[name="robots"]',
        {
          name: "robots"
        }
      );

    robots.setAttribute(
      "content",
      seo.noindex
        ? "noindex,nofollow"
        : "index,follow"
    );

    const ogTitle =
      setMetaTag(
        'meta[property="og:title"]',
        {
          property: "og:title"
        }
      );

    ogTitle.setAttribute(
      "content",
      seo.og_title ||
      seo.meta_title ||
      ""
    );

    const ogDescription =
      setMetaTag(
        'meta[property="og:description"]',
        {
          property:
            "og:description"
        }
      );

    ogDescription.setAttribute(
      "content",
      seo.og_description ||
      seo.meta_description ||
      ""
    );

    const ogType =
      setMetaTag(
        'meta[property="og:type"]',
        {
          property: "og:type"
        }
      );

    ogType.setAttribute(
      "content",
      "website"
    );

    if (seo.og_image_url) {
      const ogImage =
        setMetaTag(
          'meta[property="og:image"]',
          {
            property: "og:image"
          }
        );

      ogImage.setAttribute(
        "content",
        seo.og_image_url
      );
    }

    const canonicalPath =
      seo.canonical_path ||
      (
        pageKey === "home"
          ? "#/"
          : `#/${pageKey}`
      );

    const baseUrl =
      window.location.origin
      +
      window.location.pathname;

    setCanonicalLink(
      canonicalPath
        .startsWith("http")
          ? canonicalPath
          : baseUrl +
            canonicalPath
    );

  }, [
    path,
    state.seoPages
  ]);


  const value =
    useMemo(
      () => ({
        ...state,
        siteText,
        siteJson
      }),
      [
        state,
        siteText,
        siteJson
      ]
    );


  return (
    <SiteContentCtx.Provider
      value={value}
    >
      {children}
    </SiteContentCtx.Provider>
  );
}

const useSiteContent =
  () =>
    useContext(SiteContentCtx);


/* ----------------------------- ICONS ------------------------------------- */
/* Stroke icons, hand-tuned for an editorial feel — keep these tiny.        */
const Icon = ({ name, size = 18, className = "" }) => {
  const common = {
    width: size, height: size, viewBox: "0 0 24 24",
    fill: "none", stroke: "currentColor", strokeWidth: 1.4,
    strokeLinecap: "round", strokeLinejoin: "round", className
  };
  switch (name) {
    case "arrow-right":return <svg {...common}><path d="M5 12h14M13 6l6 6-6 6" /></svg>;
    case "arrow-left":return <svg {...common}><path d="M19 12H5M11 18l-6-6 6-6" /></svg>;
    case "arrow-down":return <svg {...common}><path d="M12 5v14M6 13l6 6 6-6" /></svg>;
    case "check":return <svg {...common}><path d="M5 13l4 4L19 7" /></svg>;
    case "x":return <svg {...common}><path d="M6 6l12 12M18 6L6 18" /></svg>;
    case "phone":return <svg {...common}><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72c.13.96.37 1.9.72 2.81a2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45c.91.35 1.85.59 2.81.72A2 2 0 0 1 22 16.92z" /></svg>;
    case "calendar":return <svg {...common}><rect x="3" y="4" width="18" height="18" rx="2" /><path d="M16 2v4M8 2v4M3 10h18" /></svg>;
    case "clock":return <svg {...common}><circle cx="12" cy="12" r="10" /><path d="M12 6v6l4 2" /></svg>;
    case "user":return <svg {...common}><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2" /><circle cx="12" cy="7" r="4" /></svg>;
    case "users":return <svg {...common}><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2" /><circle cx="9" cy="7" r="4" /><path d="M23 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75" /></svg>;
    case "menu":return <svg {...common}><path d="M3 6h18M3 12h18M3 18h18" /></svg>;
    case "search":return <svg {...common}><circle cx="11" cy="11" r="7" /><path d="M21 21l-4.35-4.35" /></svg>;
    case "star":return <svg {...common} fill="currentColor" stroke="none"><path d="M12 2l2.9 6.5 7 .7-5.3 4.8 1.6 6.9L12 17.3 5.8 21l1.6-6.9L2.1 9.2l7-.7L12 2z" /></svg>;
    case "heart":return <svg {...common}><path d="M20.8 4.6a5.5 5.5 0 0 0-7.8 0L12 5.7l-1-1.1a5.5 5.5 0 0 0-7.8 7.8l1 1L12 21l7.8-7.6 1-1a5.5 5.5 0 0 0 0-7.8z" /></svg>;
    case "map":return <svg {...common}><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z" /><circle cx="12" cy="10" r="3" /></svg>;
    case "instagram":return <svg {...common}><rect x="2" y="2" width="20" height="20" rx="5" /><path d="M16 11.4A4 4 0 1 1 12.6 8 4 4 0 0 1 16 11.4z" /><path d="M17.5 6.5h.01" /></svg>;
    case "facebook":return <svg {...common}><path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z" /></svg>;
    case "mail":return <svg {...common}><path d="M4 4h16c1 0 2 1 2 2v12c0 1-1 2-2 2H4c-1 0-2-1-2-2V6c0-1 1-2 2-2z" /><path d="M22 6l-10 7L2 6" /></svg>;
    case "lock":return <svg {...common}><rect x="3" y="11" width="18" height="11" rx="2" /><path d="M7 11V7a5 5 0 0 1 10 0v4" /></svg>;
    case "credit-card":return <svg {...common}><rect x="2" y="5" width="20" height="14" rx="2" /><path d="M2 10h20" /></svg>;
    case "shield":return <svg {...common}><path d="M12 2l8 4v6c0 5-3.5 9-8 10-4.5-1-8-5-8-10V6l8-4z" /></svg>;
    case "leaf":return <svg {...common}><path d="M11 20A7 7 0 0 1 4 13c0-3 2-9 9-11 0 5-3 8-5 10" /><path d="M2 22c2-2 4-3 8-3" /></svg>;
    case "sparkle":return <svg {...common}><path d="M12 2v6m0 8v6M2 12h6m8 0h6M5 5l4 4m6 6l4 4M19 5l-4 4M9 15l-4 4" /></svg>;
    case "filter":return <svg {...common}><path d="M22 3H2l8 9.46V19l4 2v-8.54L22 3z" /></svg>;
    case "chevron-down":return <svg {...common}><path d="M6 9l6 6 6-6" /></svg>;
    case "chevron-up":return <svg {...common}><path d="M18 15l-6-6-6 6" /></svg>;
    case "chevron-right":return <svg {...common}><path d="M9 18l6-6-6-6" /></svg>;
    case "plus":return <svg {...common}><path d="M12 5v14M5 12h14" /></svg>;
    case "minus":return <svg {...common}><path d="M5 12h14" /></svg>;
    case "dots":return <svg {...common}><circle cx="5" cy="12" r="1" /><circle cx="12" cy="12" r="1" /><circle cx="19" cy="12" r="1" /></svg>;
    case "logout":return <svg {...common}><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4M16 17l5-5-5-5M21 12H9" /></svg>;
    case "trending":return <svg {...common}><path d="M23 6l-9.5 9.5-5-5L1 18M17 6h6v6" /></svg>;
    case "wallet":return <svg {...common}><path d="M20 12V8H6a2 2 0 0 1 0-4h12v4" /><path d="M20 12v8H6a2 2 0 0 1-2-2V6" /><path d="M16 14h.01" /></svg>;
    case "grid":return <svg {...common}><rect x="3" y="3" width="7" height="7" rx="1" /><rect x="14" y="3" width="7" height="7" rx="1" /><rect x="14" y="14" width="7" height="7" rx="1" /><rect x="3" y="14" width="7" height="7" rx="1" /></svg>;
    case "scissors":return <svg {...common}><circle cx="6" cy="6" r="3" /><circle cx="6" cy="18" r="3" /><path d="M20 4L8.12 15.88M14.47 14.48L20 20M8.12 8.12L12 12" /></svg>;
    case "package":return <svg {...common}><path d="M16.5 9.4L7.5 4.21M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z" /><path d="M3.27 6.96L12 12.01l8.73-5.05M12 22.08V12" /></svg>;
    case "tag":return <svg {...common}><path d="M20.59 13.41l-7.17 7.17a2 2 0 0 1-2.83 0L2 12V2h10l8.59 8.59a2 2 0 0 1 0 2.82z" /><path d="M7 7h.01" /></svg>;
    case "bell":return <svg {...common}><path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9" /><path d="M13.73 21a2 2 0 0 1-3.46 0" /></svg>;
    case "settings":return <svg {...common}><circle cx="12" cy="12" r="3" /><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z" /></svg>;
    case "bar-chart":return <svg {...common}><path d="M12 20V10M18 20V4M6 20v-4" /></svg>;
    case "gift":return <svg {...common}><path d="M20 12v10H4V12M2 7h20v5H2zM12 22V7M12 7H7.5a2.5 2.5 0 0 1 0-5C11 2 12 7 12 7zM12 7h4.5a2.5 2.5 0 0 0 0-5C13 2 12 7 12 7z" /></svg>;
    case "megaphone":return <svg {...common}><path d="M3 11l18-5v12L3 14v-3zM11.6 16.8a3 3 0 1 1-5.8-1.6" /></svg>;
    case "moon":return <svg {...common}><path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z" /></svg>;
    case "sun":return <svg {...common}><circle cx="12" cy="12" r="4" /><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4" /></svg>;
    case "edit":return <svg {...common}><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7" /><path d="M18.5 2.5a2.12 2.12 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z" /></svg>;
    case "trash":return <svg {...common}><path d="M3 6h18M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2" /></svg>;
    case "home":return <svg {...common}><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z" /><path d="M9 22V12h6v10" /></svg>;
    case "building":return <svg {...common}><rect x="4" y="2" width="16" height="20" rx="2" /><path d="M9 22v-4h6v4M9 6h.01M15 6h.01M9 10h.01M15 10h.01M9 14h.01M15 14h.01" /></svg>;
    case "file-text":return <svg {...common}><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" /><path d="M14 2v6h6M16 13H8M16 17H8M10 9H8" /></svg>;
    case "alert":return <svg {...common}><path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z" /><path d="M12 9v4M12 17h.01" /></svg>;
    case "refresh":return <svg {...common}><path d="M23 4v6h-6M1 20v-6h6" /><path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15" /></svg>;
    case "download":return <svg {...common}><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4M7 10l5 5 5-5M12 15V3" /></svg>;
    case "globe":return <svg {...common}><circle cx="12" cy="12" r="10" /><path d="M2 12h20M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z" /></svg>;
    case "zap":return <svg {...common}><path d="M13 2L3 14h9l-1 8 10-12h-9l1-8z" /></svg>;
    case "camera":return <svg {...common}><path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z" /><circle cx="12" cy="13" r="4" /></svg>;
    case "percent":return <svg {...common}><path d="M19 5L5 19" /><circle cx="6.5" cy="6.5" r="2.5" /><circle cx="17.5" cy="17.5" r="2.5" /></svg>;
    case "award":return <svg {...common}><circle cx="12" cy="8" r="6" /><path d="M15.5 13.5L17 22l-5-3-5 3 1.5-8.5" /></svg>;
    case "clipboard":return <svg {...common}><path d="M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2" /><rect x="8" y="2" width="8" height="4" rx="1" /></svg>;
    case "external":return <svg {...common}><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6M15 3h6v6M10 14L21 3" /></svg>;
    case "more-v":return <svg {...common}><circle cx="12" cy="5" r="1" /><circle cx="12" cy="12" r="1" /><circle cx="12" cy="19" r="1" /></svg>;
    case "message":return <svg {...common}><path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z" /></svg>;
    case "eye":return <svg {...common}><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z" /><circle cx="12" cy="12" r="3" /></svg>;
    default:return null;
  }
};

/* ----------------------------- LOGO -------------------------------------- */
/* Lotus petal mark — original geometric form, not a tracing of any existing brand. */
function LogoMark({ size = 28, color }) {
  return (
    <svg width={size} height={size} viewBox="0 0 40 40" fill="none" style={{ color: color || "var(--gold-deep)" }}>
      {/* outer petals */}
      <path d="M20 4 C 13 14, 13 22, 20 32 C 27 22, 27 14, 20 4 Z" stroke="currentColor" strokeWidth="1.2" fill="none" />
      <path d="M4 20 C 14 13, 22 13, 32 20 C 22 27, 14 27, 4 20 Z" stroke="currentColor" strokeWidth="1.2" fill="none" />
      {/* diagonal petals */}
      <path d="M8.5 8.5 C 16 12, 22 16, 31.5 31.5" stroke="currentColor" strokeWidth="1" opacity="0.6" />
      <path d="M31.5 8.5 C 24 12, 18 16, 8.5 31.5" stroke="currentColor" strokeWidth="1" opacity="0.6" />
      {/* center */}
      <circle cx="20" cy="20" r="1.6" fill="currentColor" />
    </svg>);

}

function Logo({ light = false, size = 28 }) {
  const {
    location
  } = useSiteContent();

  const businessName =
    location?.name ||
    "The Chelsea Spa";

  return (
    <div className="lotus" style={{ color: light ? "var(--ink-on-dark)" : "var(--ink)" }}>
      <LogoMark size={size} color={light ? "#e6d2a8" : "var(--gold-deep)"} />
      <span>{businessName}</span>
    </div>);

}

/* ----------------------------- BUTTON ------------------------------------ */
function Button({ variant = "primary", size = "md", children, icon, iconRight, onClick, type, disabled, className = "", ...rest }) {
  const cls = `btn btn-${variant} ${size === "sm" ? "btn-sm" : size === "lg" ? "btn-lg" : ""} ${className}`.trim();
  return (
    <button type={type || "button"} className={cls} onClick={onClick} disabled={disabled} {...rest}>
      {icon && <Icon name={icon} size={14} />}
      {children}
      {iconRight && <Icon name={iconRight} size={14} />}
    </button>);

}

/* ----------------------------- NAV --------------------------------------- */
function Nav({ transparent = false }) {
  const { path, navigate } = useRouter();
  const {
    location
  } = useSiteContent();
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24);
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const items = [
  { label: "Treatments", to: "/treatments" },
  { label: "Shop", to: "/shop" },
  { label: "About", to: "/about" },
  { label: "Membership", to: "/about#membership" },
  { label: "Contact", to: "/contact" }];


  const isTransparent = transparent && !scrolled;
  const navStyle = {
    position: "fixed", top: 0, left: 0, right: 0, zIndex: 60,
    transition: "all 360ms var(--ease)",
    background: isTransparent ? "transparent" : "rgba(246, 241, 232, 0.88)",
    backdropFilter: isTransparent ? "none" : "saturate(140%) blur(18px)",
    WebkitBackdropFilter: isTransparent ? "none" : "saturate(140%) blur(18px)",
    borderBottom: isTransparent ? "1px solid transparent" : "1px solid var(--line)",
    color: isTransparent ? "var(--ink-on-dark)" : "var(--ink)"
  };

  const linkBase = {
    fontFamily: "var(--font-display)",
    fontSize: "0.78rem",
    letterSpacing: "0.22em",
    textTransform: "uppercase",
    padding: "8px 4px",
    position: "relative"
  };

  return (
    <header style={navStyle}>
      <div className="container-wide" style={{
        display: "flex", alignItems: "center", justifyContent: "space-between",
        height: 84
      }}>
        <button onClick={() => navigate("/")} style={{ display: "flex", alignItems: "center" }}>
          <Logo light={isTransparent} size={26} />
        </button>
        <nav style={{ display: "flex", alignItems: "center", gap: 36 }} className="nav-links">
          {items.map((item) => {
            const active = path.startsWith(item.to.split("#")[0]) && item.to !== "/";
            return (
              <a key={item.to} onClick={() => navigate(item.to)} style={{
                ...linkBase,
                cursor: "pointer",
                opacity: active ? 1 : 0.78,
                color: "inherit"
              }}>
                {item.label}
                {active &&
                <span style={{
                  position: "absolute", bottom: 0, left: 4, right: 4, height: 1,
                  background: "var(--gold)"
                }} />
                }
              </a>);

          })}
        </nav>
        <div style={{ display: "flex", alignItems: "center", gap: 16 }}>
          <a href={`tel:${String(location?.phone || "020 7351 4555").replace(/[^+\d]/g, "")}`} style={{
            ...linkBase,
            display: "flex", alignItems: "center", gap: 8,
            opacity: 0.78
          }} className="nav-phone">
            <Icon name="phone" size={14} /> {location?.phone || "020 7351 4555"}
          </a>
          <Button variant={isTransparent ? "ghost-light" : "primary"} size="sm" onClick={() => navigate("/booking")}>
            Book Now
          </Button>
          <button onClick={() => navigate("/dashboard")} style={{
            padding: 8, opacity: 0.7
          }} title="Account">
            <Icon name="user" size={18} />
          </button>
        </div>
      </div>
      <style>{`
        @media (max-width: 980px) {
          .nav-links, .nav-phone { display: none !important; }
        }
      `}</style>
    </header>);

}

/* ----------------------------- FOOTER ------------------------------------ */
function Footer() {
  const { navigate } = useRouter();
  const {
    location,
    settings
  } = useSiteContent();

  const address =
    [
      location?.address_line_1,
      location?.address_line_2,
      location?.city,
      location?.postcode
    ]
      .filter(Boolean)
      .join(", ")
      ||
      "53 Hollywood Road, London SW10 9HX";

  const footerTagline =
    settings?.footer_tagline ||
    "Begin Your Year of Radiance with Expert Care and Chelsea Warmth.";

  const col = (title, links) =>
  <div className="stack" style={{ gap: 14 }}>
      <div className="eyebrow" style={{ color: "var(--gold-soft)" }}>{title}</div>
      {links.map((l) =>
    <a key={l.label} onClick={() => l.to && navigate(l.to)} style={{
      cursor: l.to ? "pointer" : "default",
      fontFamily: "var(--font-body)",
      color: "rgba(246, 241, 232, 0.78)",
      fontSize: "0.95rem"
    }}>{l.label}</a>
    )}
    </div>;

  return (
    <footer style={{ background: "var(--ink)", color: "var(--ink-on-dark)" }}>
      <div className="container-wide" style={{ padding: "96px 32px 32px" }}>
        <div style={{
          display: "grid", gap: 48,
          gridTemplateColumns: "1.4fr 1fr 1fr 1fr 1.2fr"
        }} className="footer-grid">
          <div className="stack" style={{ gap: 24 }}>
            <Logo light size={28} />
            <p style={{ color: "rgba(246, 241, 232, 0.6)", maxWidth: 280, lineHeight: 1.7 }}>{footerTagline}</p>
            <div style={{ display: "flex", gap: 14 }}>
              <a
                href={settings?.instagram_url || undefined}
                target={settings?.instagram_url ? "_blank" : undefined}
                rel={settings?.instagram_url ? "noopener noreferrer" : undefined}
                style={{ color: "var(--gold-soft)" }}
              ><Icon name="instagram" size={18} /></a>
              <a
                href={settings?.facebook_url || undefined}
                target={settings?.facebook_url ? "_blank" : undefined}
                rel={settings?.facebook_url ? "noopener noreferrer" : undefined}
                style={{ color: "var(--gold-soft)" }}
              ><Icon name="facebook" size={18} /></a>
              <a
                href={location?.email ? `mailto:${location.email}` : undefined}
                style={{ color: "var(--gold-soft)" }}
              ><Icon name="mail" size={18} /></a>
            </div>
          </div>
          {col("Treatments", [
          { label: "Facials", to: "/treatments" },
          { label: "Massage", to: "/treatments" },
          { label: "Body rituals", to: "/treatments" },
          { label: "Specialist", to: "/treatments" },
          { label: "Memberships", to: "/about" }]
          )}
          {col("The Spa", [
          { label: "Our story", to: "/about" },
          { label: "Therapists", to: "/about" },
          { label: "Press", to: "/about" },
          { label: "Gift cards", to: "/treatments" }]
          )}
          {col("Visit", [
          { label: "Contact", to: "/contact" },
          { label: "Find us", to: "/contact" },
          { label: "Opening hours", to: "/contact" },
          { label: "FAQ", to: "/contact" }]
          )}
          <div className="stack" style={{ gap: 14 }}>
            <div className="eyebrow" style={{ color: "var(--gold-soft)" }}>Notes &amp; Offers</div>
            <p style={{ color: "rgba(246, 241, 232, 0.6)", fontSize: "0.9rem", lineHeight: 1.6 }}>
              Seasonal rituals, member previews. One quiet email a month.
            </p>
            <div style={{ display: "flex", gap: 0, borderBottom: "1px solid rgba(246, 241, 232, 0.24)", padding: "8px 0" }}>
              <input placeholder="you@example.com" style={{
                background: "transparent", border: "none", outline: "none",
                color: "var(--ink-on-dark)", flex: 1, fontFamily: "var(--font-body)"
              }} />
              <button style={{ color: "var(--gold-soft)" }}><Icon name="arrow-right" size={16} /></button>
            </div>
          </div>
        </div>
        <div style={{
          marginTop: 72, paddingTop: 24,
          borderTop: "1px solid rgba(246, 241, 232, 0.12)",
          display: "flex", justifyContent: "space-between", alignItems: "center",
          flexWrap: "wrap", gap: 16
        }}>
          <div style={{ fontFamily: "var(--font-display)", fontSize: "0.7rem", letterSpacing: "0.18em", textTransform: "uppercase", color: "rgba(246, 241, 232, 0.4)" }}>
            © 2026 {location?.name || "The Chelsea Spa"} &nbsp;·&nbsp; {address}
          </div>
          <div style={{ display: "flex", gap: 32, fontSize: "0.78rem", color: "rgba(246, 241, 232, 0.4)", fontFamily: "var(--font-display)", letterSpacing: "0.14em", textTransform: "uppercase" }}>
            <a>Privacy</a><a>Terms</a><a>Cookies</a>
            <a href="admin.html" style={{ cursor: "pointer" }}>Staff login</a>
          </div>
        </div>
      </div>
      <style>{`
        @media (max-width: 980px) {
          .footer-grid { grid-template-columns: 1fr 1fr !important; }
        }
        @media (max-width: 580px) {
          .footer-grid { grid-template-columns: 1fr !important; }
        }
      `}</style>
    </footer>);

}

/* --------------------------- IMG PLACEHOLDER ----------------------------- */
function Placeholder({ label = "image", height = 240, style }) {
  return (
    <div className="img-placeholder" style={{ height, ...style }}>
      {label}
    </div>);

}

/* --------------------------- TOAST CONTEXT ------------------------------- */
const ToastCtx = createContext(null);
function ToastProvider({ children }) {
  const [toasts, setToasts] = useState([]);
  const push = (msg, kind = "default") => {
    const id = Math.random().toString(36).slice(2);
    setToasts((t) => [...t, { id, msg, kind }]);
    setTimeout(() => setToasts((t) => t.filter((x) => x.id !== id)), 3600);
  };
  return (
    <ToastCtx.Provider value={push}>
      {children}
      <div style={{
        position: "fixed", bottom: 24, right: 24, zIndex: 200,
        display: "flex", flexDirection: "column", gap: 8
      }}>
        {toasts.map((t) =>
        <div key={t.id} className="fade-up" style={{
          background: "var(--ink)", color: "var(--ink-on-dark)",
          padding: "14px 20px", borderRadius: "var(--r-md)",
          boxShadow: "var(--shadow-3)",
          fontFamily: "var(--font-display)", fontSize: "0.85rem", letterSpacing: "0.04em",
          display: "flex", alignItems: "center", gap: 12,
          borderLeft: `2px solid ${t.kind === "success" ? "var(--gold)" : "var(--gold-soft)"}`,
          minWidth: 260
        }}>
            {t.kind === "success" && <Icon name="check" size={16} />}
            {t.msg}
          </div>
        )}
      </div>
    </ToastCtx.Provider>);

}
const useToast = () => useContext(ToastCtx);

/* --------------------------- DATA (shared) ------------------------------- */
const TREATMENTS = [
{ id: "signature-facial", category: "Facials", name: "Chelsea Signature Facial", duration: 75, price: 165,
  blurb: "A bespoke pressure-point ritual with cold-stone sculpting and bio-active serums.",
  benefits: ["Brightening", "Lifting", "Hydration"] },
{ id: "oxygen-glow", category: "Facials", name: "Oxygen Glow Therapy", duration: 60, price: 145,
  blurb: "Calibrated oxygen infusion to plump, soothe and prime the skin for evening.",
  benefits: ["Plumping", "Calming"] },
{ id: "ldn-deep", category: "Massage", name: "London Deep Tissue", duration: 60, price: 135,
  blurb: "Firm, considered work to undo desk posture and city tension.",
  benefits: ["Releasing", "Postural"] },
{ id: "hot-stone", category: "Massage", name: "Hot Stone Ritual", duration: 90, price: 195,
  blurb: "Volcanic basalt placed along the meridian lines for profound calm.",
  benefits: ["Grounding", "Warming"] },
{ id: "body-polish", category: "Body", name: "Cashmere Body Polish", duration: 60, price: 125,
  blurb: "Pink-clay polish and ceremonial oils for silken, luminous skin.",
  benefits: ["Smoothing", "Glow"] },
{ id: "wrap", category: "Body", name: "Botanical Mud Cocoon", duration: 75, price: 155,
  blurb: "Detoxifying wrap with marine clay and a slow scalp massage.",
  benefits: ["Detox", "Slimming"] },
{ id: "couples", category: "Specialist", name: "Two Together", duration: 90, price: 360,
  blurb: "A side-by-side ritual in our private suite with champagne service.",
  benefits: ["Couples", "Private suite"] },
{ id: "radiance", category: "Specialist", name: "Radiance Half Day", duration: 180, price: 425,
  blurb: "Facial, body polish, scalp ritual and a long lunch. Our love letter to a slow afternoon.",
  benefits: ["Half day", "Lunch included"] }];


const THERAPISTS = [
{ id: "amara", name: "Mala", title: "Skin Specialist", years: 12, specialties: ["Facials", "Skin"] },
{ id: "isolde", name: "Shugar", title: "Senior Therapist", years: 8, specialties: ["Massage", "Body"] },
{ id: "noor", name: "Riya", title: "Therapist", years: 6, specialties: ["Facials", "Body"] },
{ id: "priya", name: "Neel", title: "Therapist", years: 5, specialties: ["Massage"] },
{ id: "sarkar", name: "Sarkar", title: "Therapist", years: 7, specialties: ["Body", "Specialist"] },
{ id: "any", name: "First available", title: "Any therapist", years: 0, specialties: [] }];


const TIMES_AM = ["09:00", "09:30", "10:00", "10:30", "11:00", "11:30"];
const TIMES_PM = ["12:00", "13:30", "14:00", "14:30", "15:30", "16:00", "16:30", "17:00", "17:30", "18:00", "18:30", "19:00"];

/* --------------------------- GLOBAL EXPORTS ------------------------------ */
Object.assign(window, {
  React, ReactDOM, useState, useEffect, useRef, useCallback, useMemo,
  RouterProvider, useRouter,
  SiteContentProvider, useSiteContent,
  ToastProvider, useToast,
  Icon, LogoMark, Logo, Button, Nav, Footer, Placeholder,
  TREATMENTS, THERAPISTS, TIMES_AM, TIMES_PM
});