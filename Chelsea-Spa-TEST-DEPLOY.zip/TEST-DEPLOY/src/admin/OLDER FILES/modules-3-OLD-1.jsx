/* =========================================================================
   ADMIN MODULES (3/3) — Sales · Inventory · Marketing/CMS · Notifications · Settings
   ========================================================================= */

/* =====================================================================
   SALES & PAYMENTS
   ===================================================================== */
function ModuleSales() {
  const [tab, setTab] = useState("overview");
  const toast = useToast();
  return (
    <div>
      <PageHead eyebrow="Finance" title="Sales & payments">
        <Button variant="ghost" size="sm" icon="download">Report</Button>
        <Button variant="primary" size="sm" icon="file-text" onClick={() => toast("Invoice created")}>New invoice</Button>
      </PageHead>
      <div style={{ marginBottom: 20 }}>
        <Tabs active={tab} onChange={setTab} tabs={[
          { id: "overview", label: "Overview" },
          { id: "invoices", label: "Invoices" },
          { id: "coupons", label: "Coupons & promos" },
          { id: "refunds", label: "Refunds & tips" },
        ]}/>
      </div>

      {tab === "overview" && <SalesOverview/>}
      {tab === "invoices" && <InvoicesTable toast={toast}/>}
      {tab === "coupons" && <CouponsTable toast={toast}/>}
      {tab === "refunds" && <RefundsPanel toast={toast}/>}
    </div>
  );
}

function SalesOverview() {
  return (
    <div>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(4,1fr)", gap: 16, marginBottom: 16 }} className="kpi-row">
        <AStat label="Revenue (MTD)" value="£42.8k" delta="18%" spark={AD.REVENUE_30D.slice(-12)} icon="wallet"/>
        <AStat label="Avg. transaction" value="£163" delta="5%" icon="credit-card"/>
        <AStat label="Deposits held" value="£3,240" icon="lock"/>
        <AStat label="Tips (MTD)" value="£1,180" delta="9%" icon="heart"/>
      </div>
      <div style={{ display: "grid", gridTemplateColumns: "1.7fr 1fr", gap: 16 }} className="ov-grid">
        <Panel>
          <h3 style={{ fontSize: "1.1rem", marginBottom: 18 }}>Revenue trend · 30 days</h3>
          <LineChart data={AD.REVENUE_30D} height={200}/>
          <div style={{ display: "flex", justifyContent: "space-between", marginTop: 8 }}>
            <span className="caption">1 May</span><span className="caption">15 May</span><span className="caption">30 May</span>
          </div>
        </Panel>
        <Panel>
          <h3 style={{ fontSize: "1.1rem", marginBottom: 18 }}>Payment methods</h3>
          <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
            <HBars rows={[
              { label: "Card", value: 62, display: "62%", color: "var(--ink)" },
              { label: "Apple / Google Pay", value: 24, display: "24%", color: "var(--gold-deep)" },
              { label: "Gift card", value: 9, display: "9%", color: "var(--gold)" },
              { label: "Cash", value: 5, display: "5%", color: "var(--ink-3)" },
            ]}/>
          </div>
          <div className="a-divider" style={{ margin: "20px 0" }}/>
          <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
            <Icon name="shield" size={16} className="text-gold"/>
            <span className="caption">Stripe connected · payouts daily</span>
          </div>
        </Panel>
      </div>
    </div>
  );
}

function InvoicesTable({ toast }) {
  return (
    <Panel pad={false} style={{ overflow: "hidden" }}>
      <table className="atable">
        <thead><tr><th>Invoice</th><th>Customer</th><th>Amount</th><th>Method</th><th>Date</th><th>Status</th><th></th></tr></thead>
        <tbody>
          {AD.INVOICES.map(inv => (
            <tr key={inv.id}>
              <td style={{ fontFamily: "var(--font-mono)", fontSize: "0.8rem" }}>{inv.id}</td>
              <td style={{ fontFamily: "var(--font-display)" }}>{inv.customer}</td>
              <td style={{ fontFamily: "var(--font-display)", color: "var(--gold-deep)" }}>£{inv.amount}</td>
              <td><span className="caption">{inv.method}</span></td>
              <td><span className="caption">{inv.date}</span></td>
              <td>
                {inv.status === "paid" ? <Pill color="var(--success)" bg="rgba(107,122,94,0.16)" dot>Paid</Pill>
                  : inv.status === "partial" ? <Pill color="var(--gold-deep)" bg="var(--bg-nude)" dot>Partial</Pill>
                  : <Pill color="var(--danger)" bg="rgba(154,74,58,0.14)" dot>Refunded</Pill>}
              </td>
              <td><button className="icon-btn" style={{ width: 32, height: 32 }} onClick={() => toast("Invoice " + inv.id)}><Icon name="eye" size={15}/></button></td>
            </tr>
          ))}
        </tbody>
      </table>
    </Panel>
  );
}

function CouponsTable({ toast }) {
  return (
    <div>
      <div style={{ display: "flex", justifyContent: "flex-end", marginBottom: 16 }}>
        <Button variant="ghost" size="sm" icon="percent" onClick={() => toast("New promo code")}>Create promo</Button>
      </div>
      <Panel pad={false} style={{ overflow: "hidden" }}>
        <table className="atable">
          <thead><tr><th>Code</th><th>Type</th><th>Uses</th><th>Cap</th><th>Expires</th><th>Status</th></tr></thead>
          <tbody>
            {AD.COUPONS.map(c => (
              <tr key={c.code}>
                <td style={{ fontFamily: "var(--font-mono)", fontSize: "0.82rem", color: "var(--gold-deep)" }}>{c.code}</td>
                <td>{c.type}</td>
                <td style={{ fontFamily: "var(--font-display)" }}>{c.uses}</td>
                <td>{c.cap}</td>
                <td><span className="caption">{c.expires}</span></td>
                <td>{c.status === "active" ? <Pill color="var(--success)" bg="rgba(107,122,94,0.16)" dot>Active</Pill> : <Pill color="var(--ink-3)" bg="var(--bg-shell)">Expired</Pill>}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </Panel>
    </div>
  );
}

function RefundsPanel({ toast }) {
  return (
    <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16 }} className="ov-grid">
      <Panel>
        <h3 style={{ fontSize: "1.05rem", marginBottom: 16 }}>Process a refund</h3>
        <div style={{ display: "grid", gap: 14 }}>
          <div><div className="a-label">Booking reference</div><input className="a-input" placeholder="CSAX…"/></div>
          <div><div className="a-label">Amount</div><input className="a-input" placeholder="£0.00"/></div>
          <div><div className="a-label">Reason</div><select className="a-input"><option>Cancelled in policy window</option><option>Service issue</option><option>Duplicate charge</option><option>Goodwill</option></select></div>
          <Button variant="primary" size="sm" onClick={() => toast("Refund issued via Stripe", "success")}>Issue refund</Button>
        </div>
      </Panel>
      <Panel>
        <h3 style={{ fontSize: "1.05rem", marginBottom: 16 }}>Tips by therapist · MTD</h3>
        <HBars rows={AD.STAFF.map(s => ({ label: s.name.split(" ")[0], value: Math.round(s.util * 4.2), display: `£${Math.round(s.util*4.2)}`, color: s.color }))}/>
        <div className="a-divider" style={{ margin: "18px 0" }}/>
        <div style={{ display: "flex", justifyContent: "space-between" }}>
          <span className="caption">Total tips pooled</span>
          <span style={{ fontFamily: "var(--font-display)", fontSize: "1.2rem", color: "var(--gold-deep)" }}>£1,180</span>
        </div>
      </Panel>
    </div>
  );
}

/* =====================================================================
   INVENTORY
   ===================================================================== */
function ModuleInventory() {
  const [tab, setTab] = useState("stock");
  const toast = useToast();
  const low = AD.PRODUCTS.filter(p => p.stock <= p.low);
  return (
    <div>
      <PageHead eyebrow="Stock & supply" title="Inventory">
        <Button variant="ghost" size="sm" icon="download">Stock report</Button>
        <Button variant="primary" size="sm" icon="plus" onClick={() => toast("Purchase order created")}>New order</Button>
      </PageHead>

      <div style={{ marginBottom: 20 }}>
        <Tabs
          active={tab}
          onChange={setTab}
          tabs={[
            { id: "stock", label: "Stock" },
            { id: "resources", label: "Resources & Equipment" }
          ]}
        />
        
      </div>

      {tab === "stock" && (
        <>

      <div style={{ display: "grid", gridTemplateColumns: "repeat(4,1fr)", gap: 16, marginBottom: 16 }} className="kpi-row">
        <AStat label="SKUs tracked" value={AD.PRODUCTS.length} icon="package"/>
        <AStat label="Low stock" value={low.length} deltaDir="down" delta="needs reorder" icon="alert"/>
        <AStat label="Stock value" value={"£" + AD.PRODUCTS.reduce((s, p) => s + p.stock * p.price, 0).toLocaleString("en-GB")} icon="wallet"/>
        <AStat label="Suppliers" value={AD.SUPPLIERS.length} icon="building"/>
      </div>

      {low.length > 0 && (
        <Panel style={{ marginBottom: 16, borderColor: "var(--gold-soft)", background: "var(--bg-nude)" }}>
          <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
            <Icon name="alert" size={18} className="text-gold"/>
            <div style={{ flex: 1 }}>
              <div style={{ fontFamily: "var(--font-display)", fontSize: "0.95rem" }}>{low.length} products need reordering</div>
              <div className="caption">{low.map(p => p.name).join(" · ")}</div>
            </div>
            <Button variant="primary" size="sm" onClick={() => toast("Reorder drafted")}>Reorder all</Button>
          </div>
        </Panel>
      )}

      <div style={{ display: "grid", gridTemplateColumns: "1.6fr 1fr", gap: 16 }} className="ov-grid">
        <Panel pad={false} style={{ overflow: "hidden" }}>
          <div style={{ padding: "16px 20px", borderBottom: "1px solid var(--line)" }}><h3 style={{ fontSize: "1.05rem" }}>Stock levels</h3></div>
          <table className="atable">
            <thead><tr><th>Product</th><th>Stock</th><th>Reorder at</th><th>Status</th><th>Supplier</th></tr></thead>
            <tbody>
              {AD.PRODUCTS.map(p => {
                const pct = Math.min(100, (p.stock / (p.low * 3)) * 100);
                const out = p.stock === 0, lowS = p.stock <= p.low;
                return (
                  <tr key={p.id}>
                    <td style={{ fontFamily: "var(--font-display)", fontSize: "0.9rem" }}>{p.name}</td>
                    <td style={{ width: 140 }}>
                      <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                        <span style={{ fontFamily: "var(--font-display)", minWidth: 24 }}>{p.stock}</span>
                        <ProgressBar pct={pct} color={out ? "var(--danger)" : lowS ? "var(--gold-deep)" : "var(--success)"} height={5}/>
                      </div>
                    </td>
                    <td><span className="caption">{p.low}</span></td>
                    <td>{out ? <Pill color="var(--danger)" bg="rgba(154,74,58,0.14)" dot>Out</Pill> : lowS ? <Pill color="var(--gold-deep)" bg="var(--bg-nude)" dot>Low</Pill> : <Pill color="var(--success)" bg="rgba(107,122,94,0.16)" dot>In stock</Pill>}</td>
                    <td><span className="caption">{p.supplier}</span></td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </Panel>
        <Panel>
          <h3 style={{ fontSize: "1.05rem", marginBottom: 14 }}>Suppliers</h3>
          <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
            {AD.SUPPLIERS.map(s => (
              <div key={s.name} style={{ padding: "12px 14px", border: "1px solid var(--line)", borderRadius: 8 }}>
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                  <span style={{ fontFamily: "var(--font-display)", fontSize: "0.9rem" }}>{s.name}</span>
                  <span className="caption">{s.products} SKUs</span>
                </div>
                <div className="caption" style={{ marginTop: 4 }}>{s.contact}</div>
                <div className="caption" style={{ marginTop: 2 }}>Lead time {s.lead}</div>
              </div>
            ))}
          </div>
        </Panel>
      </div>

      </>
      )}

      {tab === "resources" && (
        <ResourcesPanel toast={toast} />
      )}

    </div>
  );
}

function ResourcesPanel({ toast }) {
  const [resources, setResources] = useState([]);
  const [units, setUnits] = useState([]);
  const [services, setServices] = useState([]);
  const [requirements, setRequirements] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [resourceEditor, setResourceEditor] = useState(false);
  const [unitEditor, setUnitEditor] = useState(null);
  const [requirementEditor, setRequirementEditor] = useState(null);
  const [statusSavingUnit, setStatusSavingUnit] = useState(null);
  const [locations, setLocations] = useState([]);

  const loadResources = useCallback(async () => {
    try {
      setLoading(true);
      setError("");

      const [
        { data: resourceRows, error: resourceError },
        { data: unitRows, error: unitError },
        { data: locationRows, error: locationError },
        { data: serviceRows, error: serviceError },
        { data: requirementRows, error: requirementError }
      ] = await Promise.all([

        window.supabaseClient
          .from("resources")
          .select("*")
          .order("name"),

        window.supabaseClient
          .from("resource_units")
          .select("*")
          .order("name"),

        window.supabaseClient
          .from("locations")
          .select("id, name, is_active")
          .eq("is_active", true)
          .order("name"),

        window.supabaseClient
          .from("services")
          .select("id, name, location_id, is_active")
          .eq("is_active", true)
          .order("name"),

        window.supabaseClient
          .from("service_resource_requirements")
          .select("service_id, resource_id, quantity_required")
      ]);

      if (resourceError) throw resourceError;
      if (unitError) throw unitError;
      if (locationError) throw locationError;
      if (serviceError) throw serviceError;
      if (requirementError) throw requirementError;

      setResources(resourceRows || []);
      setUnits(unitRows || []);
      setLocations(locationRows || []);
      setServices(serviceRows || []);
      setRequirements(requirementRows || []);

    } catch (err) {
      console.error("Resource loading failed:", err);

      setError(
        err.message ||
        "Resources could not be loaded."
      );

    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadResources();
  }, [loadResources]);


  const updateUnitStatus =
    async (unit, status) => {

      try {

        setStatusSavingUnit(unit.id);

        const {
          error
        } =
          await window.supabaseClient
            .from("resource_units")
            .update({
              status: status
            })
            .eq("id", unit.id)
            .select("id")
            .single();

        if (error) {
          throw error;
        }

        toast(
          `${unit.name} status updated`,
          "success"
        );

        await loadResources();

      } catch (error) {

        console.error(
          "Resource unit status update failed:",
          error
        );

        toast(
          error.message ||
          "Unit status could not be updated."
        );

      } finally {

        setStatusSavingUnit(null);

      }

    };


  if (loading) {
    return (
      <Panel>
        <div className="caption">
          Loading resources…
        </div>
      </Panel>
    );
  }


  if (error) {
    return (
      <Panel>
        <div
          style={{
            color: "var(--danger)",
            marginBottom: 12
          }}
        >
          {error}
        </div>

        <Button
          variant="primary"
          size="sm"
          onClick={loadResources}
        >
          Try Again
        </Button>
      </Panel>
    );
  }


  return (
    <div>

      <div
        style={{
          display: "flex",
          justifyContent: "flex-end",
          marginBottom: 16
        }}
      >
        <Button
          variant="primary"
          size="sm"
          icon="plus"
          onClick={() =>
            setResourceEditor(true)
          }
        >
          Add Resource
        </Button>
      </div>


      {resources.length === 0 ? (

        <Panel>
          <EmptyBlock
            title="No resources yet"
            sub="Add machines, treatment rooms, beds or other booking resources."
          />
        </Panel>

      ) : (

        <div
          style={{
            display: "grid",
            gap: 16
          }}
        >

          {resources.map((resource) => {

            const resourceUnits =
              units.filter(
                unit =>
                  unit.resource_id === resource.id
              );

            const activeCount =
              resourceUnits.filter(
                unit =>
                  unit.status === "active"
              ).length;

            return (

              <Panel key={resource.id}>

                <div
                  style={{
                    display: "flex",
                    justifyContent: "space-between",
                    gap: 16,
                    alignItems: "flex-start",
                    flexWrap: "wrap"
                  }}
                >

                  <div>
                    <h3>
                      {resource.name}
                    </h3>

                    <div className="caption">
                      {resource.resource_type}
                      {" · "}
                      {activeCount} active unit
                      {activeCount === 1 ? "" : "s"}
                      {" · "}
                      {resourceUnits.length} total
                    </div>
                  </div>


                  <div
                    style={{
                      display: "flex",
                      alignItems: "center",
                      gap: 8,
                      flexWrap: "wrap"
                    }}
                  >

                    <Pill
                      color={
                        resource.is_active
                          ? "var(--success)"
                          : "var(--danger)"
                      }
                      bg={
                        resource.is_active
                          ? "rgba(107,122,94,0.16)"
                          : "rgba(154,74,58,0.14)"
                      }
                      dot
                    >
                      {resource.is_active
                        ? "Active"
                        : "Inactive"}
                    </Pill>


                    <Button
                      variant="ghost"
                      size="sm"
                      icon="plus"
                      onClick={() =>
                        setUnitEditor({
                          resource: resource
                        })
                      }
                    >
                      Add Unit
                    </Button>

                  </div>

                </div>


                <div
                  style={{
                    marginTop: 16
                  }}
                >

                  {resourceUnits.length === 0 && (

                    <div
                      className="caption"
                      style={{
                        padding: "12px 0",
                        borderTop:
                          "1px solid var(--line)"
                      }}
                    >
                      No physical units added yet.
                    </div>

                  )}


                  {resourceUnits.map(unit => (

                    <div
                      key={unit.id}
                      style={{
                        display: "flex",
                        justifyContent: "space-between",
                        alignItems: "center",
                        gap: 14,
                        padding: "10px 0",
                        borderTop:
                          "1px solid var(--line)"
                      }}
                    >

                      <div style={{ flex: 1 }}>

                        <div
                          style={{
                            fontFamily:
                              "var(--font-display)"
                          }}
                        >
                          {unit.name}
                        </div>

                        {unit.notes && (
                          <div
                            className="caption"
                            style={{
                              marginTop: 2
                            }}
                          >
                            {unit.notes}
                          </div>
                        )}

                      </div>


                      <select
                        className="a-input"
                        value={unit.status}
                        disabled={
                          statusSavingUnit === unit.id
                        }
                        onChange={(event) =>
                          updateUnitStatus(
                            unit,
                            event.target.value
                          )
                        }
                        style={{
                          width: 170,
                          paddingTop: 7,
                          paddingBottom: 7
                        }}
                      >
                        <option value="active">
                          Active
                        </option>

                        <option value="maintenance">
                          Maintenance
                        </option>

                        <option value="out_of_order">
                          Out of order
                        </option>

                        <option value="retired">
                          Retired
                        </option>
                      </select>

                    </div>

                  ))}

                </div>

              </Panel>

            );

          })}

        </div>

      )}


      <Panel
        pad={false}
        style={{
          overflow: "hidden",
          marginTop: 20
        }}
      >

        <div
          style={{
            padding: "16px 20px",
            borderBottom:
              "1px solid var(--line)"
          }}
        >

          <h3>
            Treatment Resource Requirements
          </h3>

          <div
            className="caption"
            style={{
              marginTop: 4
            }}
          >
            Choose which machines, rooms or beds
            each treatment needs before it can be booked.
          </div>

        </div>


        {services.length === 0 ? (

          <div
            className="caption"
            style={{
              padding: 20
            }}
          >
            No active treatments found.
          </div>

        ) : (

          services.map((service) => {

            const serviceRequirements =
              requirements.filter(
                item =>
                  item.service_id === service.id
              );

            const requirementText =
              serviceRequirements
                .map((item) => {

                  const resource =
                    resources.find(
                      row =>
                        row.id === item.resource_id
                    );

                  if (!resource) {
                    return null;
                  }

                  return (
                    `${resource.name} × ${item.quantity_required}`
                  );

                })
                .filter(Boolean)
                .join(" · ");

            return (

              <div
                key={service.id}
                style={{
                  display: "flex",
                  justifyContent: "space-between",
                  alignItems: "center",
                  gap: 16,
                  padding: "14px 20px",
                  borderBottom:
                    "1px solid var(--line)"
                }}
              >

                <div style={{ flex: 1 }}>

                  <div
                    style={{
                      fontFamily:
                        "var(--font-display)"
                    }}
                  >
                    {service.name}
                  </div>

                  <div
                    className="caption"
                    style={{
                      marginTop: 3
                    }}
                  >
                    {requirementText ||
                      "No resource requirement"}
                  </div>

                </div>


                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() =>
                    setRequirementEditor({
                      service: service
                    })
                  }
                >
                  Manage
                </Button>

              </div>

            );

          })

        )}

      </Panel>


      <ResourceDrawer
        open={resourceEditor}
        locations={locations}

        onClose={() =>
          setResourceEditor(false)
        }

        onSaved={async () => {
          setResourceEditor(false);
          await loadResources();
        }}

        toast={toast}
      />


      <ResourceUnitDrawer
        editor={unitEditor}

        onClose={() =>
          setUnitEditor(null)
        }

        onSaved={async () => {
          setUnitEditor(null);
          await loadResources();
        }}

        toast={toast}
      />


      <ServiceResourceDrawer
        editor={requirementEditor}
        resources={resources}
        requirements={requirements}

        onClose={() =>
          setRequirementEditor(null)
        }

        onSaved={async () => {
          setRequirementEditor(null);
          await loadResources();
        }}

        toast={toast}
      />

    </div>
  );
}


function ResourceDrawer({
  open,
  locations,
  onClose,
  onSaved,
  toast
}) {

  const [name, setName] = useState("");
  const [type, setType] = useState("equipment");
  const [locationId, setLocationId] = useState("");
  const [saving, setSaving] = useState(false);
  const [formError, setFormError] = useState("");


  useEffect(() => {

    if (!open) return;

    setName("");
    setType("equipment");

    setLocationId(
      locations?.[0]?.id || ""
    );

    setFormError("");

  }, [open, locations]);


  if (!open) {
    return null;
  }


  const save = async () => {

    const cleanName =
      name.trim();

    if (!cleanName) {
      setFormError(
        "Enter a resource name."
      );
      return;
    }


    if (!locationId) {
      setFormError(
        "Select a location."
      );
      return;
    }


    try {

      setSaving(true);
      setFormError("");


      const {
        error
      } =
        await window.supabaseClient
          .from("resources")
          .insert({
            location_id: locationId,
            name: cleanName,
            resource_type: type,
            is_active: true
          });


      if (error) {
        throw error;
      }


      toast(
        "Resource added",
        "success"
      );

      await onSaved();


    } catch (error) {

      console.error(
        "Resource creation failed:",
        error
      );


      if (error?.code === "23505") {

        setFormError(
          "A resource with this name already exists at this location."
        );

      } else {

        setFormError(
          error.message ||
          "Resource could not be added."
        );

      }


    } finally {

      setSaving(false);

    }

  };


  return (

    <Drawer
      open={true}

      onClose={
        saving
          ? () => {}
          : onClose
      }

      title="Add Resource"

      subtitle=
        "Machine, room, bed or other booking resource"

      footer={
        <>

          <Button
            variant="ghost"
            size="sm"
            onClick={onClose}
            disabled={saving}
          >
            Cancel
          </Button>

          <Button
            variant="primary"
            size="sm"
            onClick={save}
            disabled={saving}
          >
            {saving
              ? "Saving…"
              : "Add Resource"}
          </Button>

        </>
      }
    >

      {formError && (

        <div
          style={{
            padding: 12,
            marginBottom: 16,
            borderRadius: 7,
            color: "var(--danger)",
            background:
              "rgba(154,74,58,0.10)"
          }}
        >
          {formError}
        </div>

      )}


      <TherapistField label="Resource name">

        <input
          className="a-input"
          value={name}
          onChange={(event) =>
            setName(
              event.target.value
            )
          }
          placeholder=
            "e.g. HydraFacial Machine"
        />

      </TherapistField>


      <TherapistField label="Type">

        <select
          className="a-input"
          value={type}
          onChange={(event) =>
            setType(
              event.target.value
            )
          }
        >

          <option value="equipment">
            Equipment / Machine
          </option>

          <option value="room">
            Treatment Room
          </option>

          <option value="bed">
            Treatment Bed
          </option>

          <option value="other">
            Other
          </option>

        </select>

      </TherapistField>


      <TherapistField label="Location">

        <select
          className="a-input"
          value={locationId}
          onChange={(event) =>
            setLocationId(
              event.target.value
            )
          }
        >

          {locations.map(
            (location) => (

              <option
                key={location.id}
                value={location.id}
              >
                {location.name}
              </option>

            )
          )}

        </select>

      </TherapistField>


      <div
        style={{
          padding: 13,
          borderRadius: 8,
          background: "var(--bg-nude)"
        }}
      >

        <div className="caption">

          This creates the resource type only.
          Physical machines or rooms are added
          as individual units.

        </div>

      </div>

    </Drawer>

  );

}


function ResourceUnitDrawer({
  editor,
  onClose,
  onSaved,
  toast
}) {

  const [name, setName] = useState("");
  const [status, setStatus] = useState("active");
  const [notes, setNotes] = useState("");
  const [saving, setSaving] = useState(false);
  const [formError, setFormError] = useState("");


  useEffect(() => {

    if (!editor) {
      return;
    }

    setName("");
    setStatus("active");
    setNotes("");
    setFormError("");
    setSaving(false);

  }, [editor]);


  if (!editor) {
    return null;
  }


  const resource =
    editor.resource;


  const save =
    async () => {

      const cleanName =
        name.trim();

      if (!cleanName) {

        setFormError(
          "Enter a unit name."
        );

        return;
      }


      try {

        setSaving(true);
        setFormError("");


        const {
          error
        } =
          await window.supabaseClient
            .from("resource_units")
            .insert({
              resource_id: resource.id,
              name: cleanName,
              status: status,
              notes:
                notes.trim() || null
            });


        if (error) {
          throw error;
        }


        toast(
          "Resource unit added",
          "success"
        );


        await onSaved();


      } catch (error) {

        console.error(
          "Resource unit creation failed:",
          error
        );


        if (error?.code === "23505") {

          setFormError(
            "A unit with this name already exists for this resource."
          );

        } else {

          setFormError(
            error.message ||
            "Resource unit could not be added."
          );

        }


      } finally {

        setSaving(false);

      }

    };


  return (

    <Drawer
      open={true}

      onClose={
        saving
          ? () => {}
          : onClose
      }

      title="Add Unit"

      subtitle={
        resource?.name ||
        "Physical resource"
      }

      footer={
        <>

          <Button
            variant="ghost"
            size="sm"
            onClick={onClose}
            disabled={saving}
          >
            Cancel
          </Button>

          <Button
            variant="primary"
            size="sm"
            onClick={save}
            disabled={saving}
          >
            {saving
              ? "Saving…"
              : "Add Unit"}
          </Button>

        </>
      }
    >

      {formError && (

        <div
          style={{
            padding: 12,
            marginBottom: 16,
            borderRadius: 7,
            color: "var(--danger)",
            background:
              "rgba(154,74,58,0.10)"
          }}
        >
          {formError}
        </div>

      )}


      <TherapistField label="Unit name">

        <input
          className="a-input"

          value={name}

          onChange={(event) =>
            setName(
              event.target.value
            )
          }

          placeholder=
            "e.g. HF-01"
        />

      </TherapistField>


      <TherapistField label="Status">

        <select
          className="a-input"

          value={status}

          onChange={(event) =>
            setStatus(
              event.target.value
            )
          }
        >

          <option value="active">
            Active
          </option>

          <option value="maintenance">
            Maintenance
          </option>

          <option value="out_of_order">
            Out of order
          </option>

          <option value="retired">
            Retired
          </option>

        </select>

      </TherapistField>


      <TherapistField label="Notes">

        <textarea
          className="a-input"
          rows={3}

          value={notes}

          onChange={(event) =>
            setNotes(
              event.target.value
            )
          }

          placeholder=
            "Serial number, maintenance note, room details, etc."

          style={{
            resize: "vertical"
          }}
        />

      </TherapistField>


      <div
        style={{
          padding: 13,
          borderRadius: 8,
          background: "var(--bg-nude)"
        }}
      >

        <div className="caption">
          Use Retired instead of deleting an old unit.
          This preserves historical booking records.
        </div>

      </div>

    </Drawer>

  );

}


function ServiceResourceDrawer({
  editor,
  resources,
  requirements,
  onClose,
  onSaved,
  toast
}) {

  const [selected, setSelected] = useState({});
  const [saving, setSaving] = useState(false);
  const [formError, setFormError] = useState("");


  useEffect(() => {

    if (!editor?.service) {
      return;
    }


    const nextSelected = {};


    requirements
      .filter(
        row =>
          row.service_id === editor.service.id
      )
      .forEach((row) => {

        nextSelected[row.resource_id] =
          String(
            row.quantity_required || 1
          );

      });


    setSelected(nextSelected);
    setSaving(false);
    setFormError("");

  }, [editor, requirements]);


  if (!editor?.service) {
    return null;
  }


  const service =
    editor.service;


  const eligibleResources =
    resources.filter(
      resource =>
        resource.location_id ===
        service.location_id
    );


  const toggleResource =
    (resourceId) => {

      setSelected(
        current => {

          const next = {
            ...current
          };


          if (
            Object.prototype
              .hasOwnProperty
              .call(next, resourceId)
          ) {

            delete next[resourceId];

          } else {

            next[resourceId] = "1";

          }


          return next;

        }
      );

    };


  const changeQuantity =
    (resourceId, value) => {

      setSelected(
        current => ({
          ...current,
          [resourceId]: value
        })
      );

    };


  const save =
    async () => {

      setFormError("");


      const payload = [];


      for (
        const [resourceId, quantityValue]
        of Object.entries(selected)
      ) {

        const quantity =
          Number(quantityValue);


        if (
          !Number.isInteger(quantity) ||
          quantity < 1
        ) {

          setFormError(
            "Every selected resource needs a quantity of at least 1."
          );

          return;
        }


        payload.push({
          resource_id: resourceId,
          quantity_required: quantity
        });

      }


      try {

        setSaving(true);


        const {
          error
        } =
          await window.supabaseClient
            .rpc(
              "set_service_resource_requirements",
              {
                p_service_id: service.id,
                p_requirements: payload
              }
            );


        if (error) {
          throw error;
        }


        toast(
          "Treatment resources updated",
          "success"
        );


        await onSaved();


      } catch (error) {

        console.error(
          "Treatment resource save failed:",
          error
        );


        setFormError(
          error.message ||
          "Treatment resources could not be saved."
        );


      } finally {

        setSaving(false);

      }

    };


  return (

    <Drawer
      open={true}

      onClose={
        saving
          ? () => {}
          : onClose
      }

      title="Treatment Resources"

      subtitle={
        service.name
      }

      footer={
        <>

          <Button
            variant="ghost"
            size="sm"
            onClick={onClose}
            disabled={saving}
          >
            Cancel
          </Button>

          <Button
            variant="primary"
            size="sm"
            onClick={save}
            disabled={saving}
          >
            {saving
              ? "Saving…"
              : "Save Requirements"}
          </Button>

        </>
      }
    >

      {formError && (

        <div
          style={{
            padding: 12,
            marginBottom: 16,
            borderRadius: 7,
            color: "var(--danger)",
            background:
              "rgba(154,74,58,0.10)"
          }}
        >
          {formError}
        </div>

      )}


      <div
        className="caption"
        style={{
          marginBottom: 16
        }}
      >
        Select every physical resource this
        treatment must have available at the
        same time as the therapist.
      </div>


      {eligibleResources.length === 0 ? (

        <div
          className="caption"
          style={{
            padding: 16,
            border:
              "1px solid var(--line)",
            borderRadius: 8
          }}
        >
          No resources exist for this treatment's location.
        </div>

      ) : (

        eligibleResources.map(
          resource => {

            const isSelected =
              Object.prototype
                .hasOwnProperty
                .call(
                  selected,
                  resource.id
                );


            return (

              <div
                key={resource.id}

                style={{
                  display: "grid",
                  gridTemplateColumns:
                    "1fr 100px",
                  gap: 14,
                  alignItems: "center",
                  padding: "12px 0",
                  borderBottom:
                    "1px solid var(--line)"
                }}
              >

                <label
                  style={{
                    display: "flex",
                    gap: 10,
                    alignItems: "center",
                    cursor: "pointer"
                  }}
                >

                  <input
                    type="checkbox"

                    checked={isSelected}

                    onChange={() =>
                      toggleResource(
                        resource.id
                      )
                    }
                  />


                  <div>

                    <div
                      style={{
                        fontFamily:
                          "var(--font-display)"
                      }}
                    >
                      {resource.name}
                    </div>


                    <div
                      className="caption"
                      style={{
                        marginTop: 2
                      }}
                    >
                      {resource.resource_type}

                      {!resource.is_active
                        ? " · Inactive"
                        : ""}
                    </div>

                  </div>

                </label>


                <input
                  className="a-input"
                  type="number"
                  min="1"
                  step="1"

                  disabled={
                    !isSelected
                  }

                  value={
                    isSelected
                      ? selected[resource.id]
                      : ""
                  }

                  onChange={(event) =>
                    changeQuantity(
                      resource.id,
                      event.target.value
                    )
                  }

                  placeholder="Qty"
                />

              </div>

            );

          }
        )

      )}


      <div
        style={{
          marginTop: 18,
          padding: 13,
          borderRadius: 8,
          background: "var(--bg-nude)"
        }}
      >

        <div className="caption">
          Example: HydraFacial can require
          HydraFacial Machine × 1 and Treatment Room × 1.
          Booking availability will then require both
          resources to be free.
        </div>

      </div>

    </Drawer>

  );

}


/* =====================================================================
   MARKETING & CMS
   ===================================================================== */
function ModuleMarketing() {
  const [tab, setTab] = useState("content");
  const toast = useToast();
  return (
    <div>
      <PageHead eyebrow="Website & marketing" title="Content (CMS)">
        <Button variant="ghost" size="sm" icon="external">View site</Button>
        <Button variant="primary" size="sm" onClick={() => toast("Changes published", "success")}>Publish</Button>
      </PageHead>
      <div style={{ marginBottom: 20 }}>
        <Tabs active={tab} onChange={setTab} tabs={[
          { id: "content", label: "Pages & sections" },
          { id: "media", label: "Media library" },
          { id: "faq", label: "FAQ" },
          { id: "testimonials", label: "Testimonials" },
          { id: "seo", label: "SEO" },
        ]}/>
      </div>
      {tab === "content" && <CMSContent toast={toast}/>}
      {tab === "media" && <CMSMedia toast={toast}/>}
      {tab === "faq" && <CMSFaq toast={toast}/>}
      {tab === "testimonials" && <CMSTestimonials toast={toast}/>}
      {tab === "seo" && <CMSSeo toast={toast}/>}
    </div>
  );
}

function CMSContent({ toast }) {
  const sections = [
    { page: "Homepage", section: "Hero headline", value: "Elevate Your Beauty," },
    { page: "Homepage", section: "Hero subtext", value: "Bespoke facials, ceremonial massage and slow rituals on Hollywood Road, Chelsea." },
    { page: "Homepage", section: "About intro", value: "Eleven years of quiet practice, perfected in a single room." },
    { page: "About", section: "Brand story", value: "We opened in 2014 with one rule: nothing rushed." },
    { page: "Contact", section: "Opening hours", value: "Mon–Fri 09:00–20:00 · Sat–Sun 10:00–18:00" },
  ];
  return (
    <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16 }} className="ov-grid">
      <Panel pad={false} style={{ overflow: "hidden" }}>
        <div style={{ padding: "16px 20px", borderBottom: "1px solid var(--line)" }}><h3 style={{ fontSize: "1.05rem" }}>Editable sections</h3></div>
        {sections.map((s, i) => (
          <div key={i} style={{ padding: "14px 20px", borderBottom: i < sections.length-1 ? "1px solid var(--line)" : "none" }}>
            <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 6 }}>
              <span className="caption">{s.page} · {s.section}</span>
              <button onClick={() => toast("Editing " + s.section)} className="caption" style={{ color: "var(--gold-deep)", textTransform: "uppercase", letterSpacing: "0.12em" }}>Edit</button>
            </div>
            <div style={{ fontSize: "0.9rem", color: "var(--ink-2)" }}>{s.value}</div>
          </div>
        ))}
      </Panel>
      <Panel>
        <h3 style={{ fontSize: "1.05rem", marginBottom: 14 }}>Hero video</h3>
        <div style={{ position: "relative", borderRadius: 8, overflow: "hidden", aspectRatio: "16/9", background: "var(--bg-shell)" }}>
          <video src="assets/hero.mp4" muted loop autoPlay playsInline style={{ width: "100%", height: "100%", objectFit: "cover" }}/>
          <div style={{ position: "absolute", inset: 0, background: "rgba(20,16,12,0.3)", display: "flex", alignItems: "center", justifyContent: "center" }}>
            <Button variant="gold" size="sm" icon="refresh" onClick={() => toast("Upload new hero video")}>Replace video</Button>
          </div>
        </div>
        <p className="caption" style={{ marginTop: 12 }}>MP4 · max 50MB · 16:9 recommended. Stored on Cloudinary / S3.</p>
      </Panel>
    </div>
  );
}

function CMSMedia({ toast }) {
  const [drag, setDrag] = useState(null);
  const imgs = ["hero · interior", "facial room", "apothecary", "reception", "ritual oils", "couples suite", "garden", "detail"];
  return (
    <Panel>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 16 }}>
        <h3 style={{ fontSize: "1.05rem" }}>Media library · drag to reorder</h3>
        <Button variant="ghost" size="sm" icon="plus" onClick={() => toast("Upload media")}>Upload</Button>
      </div>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 12 }} className="media-grid">
        {imgs.map((label, i) => (
          <div key={i} draggable onDragStart={() => setDrag(i)} onDragOver={e => e.preventDefault()} onDrop={() => { setDrag(null); toast("Gallery reordered"); }}
            style={{ position: "relative", cursor: "grab" }}>
            <div className="img-placeholder" style={{ height: 120, borderRadius: 8 }}>{label}</div>
            <button onClick={() => toast("Deleted")} style={{ position: "absolute", top: 6, right: 6, width: 26, height: 26, borderRadius: 6, background: "rgba(20,16,12,0.6)", color: "#fff", display: "flex", alignItems: "center", justifyContent: "center" }}><Icon name="trash" size={13}/></button>
          </div>
        ))}
      </div>
      <style>{`@media (max-width: 720px) { .media-grid { grid-template-columns: repeat(2,1fr) !important; } }`}</style>
    </Panel>
  );
}

function CMSFaq({ toast }) {
  const faqs = [
    ["What should I wear?", "Whatever's comfortable — we provide robes, slippers and a private changing area."],
    ["Do you offer parking?", "Metered street parking on Hollywood Road; nearby car parks are a short walk."],
    ["Can I request a specific therapist?", "Always. Choose by name when booking, or call us for a recommendation."],
    ["What is your cancellation policy?", "Free cancellation up to 24 hours before. Deposits are refunded in full."],
  ];
  return (
    <Panel>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 8 }}>
        <h3 style={{ fontSize: "1.05rem" }}>Frequently asked questions</h3>
        <Button variant="ghost" size="sm" icon="plus" onClick={() => toast("Add FAQ")}>Add</Button>
      </div>
      {faqs.map((f, i) => (
        <div key={i} style={{ display: "flex", gap: 14, padding: "16px 0", borderTop: "1px solid var(--line)", alignItems: "flex-start" }}>
          <Icon name="message" size={16} className="text-gold" style={{ marginTop: 3 }}/>
          <div style={{ flex: 1 }}>
            <div style={{ fontFamily: "var(--font-display)", fontSize: "0.95rem" }}>{f[0]}</div>
            <div style={{ fontSize: "0.86rem", color: "var(--ink-2)", marginTop: 4 }}>{f[1]}</div>
          </div>
          <div style={{ display: "flex", gap: 4 }}>
            <button className="icon-btn" style={{ width: 30, height: 30 }} onClick={() => toast("Edit FAQ")}><Icon name="edit" size={14}/></button>
            <button className="icon-btn" style={{ width: 30, height: 30 }}><Icon name="trash" size={14}/></button>
          </div>
        </div>
      ))}
    </Panel>
  );
}

function CMSTestimonials({ toast }) {
  const items = [
    { text: "The closest London gets to a Kyoto onsen.", author: "Eloise H.", shown: true },
    { text: "Mala's facial work is on another plane.", author: "Saskia R.", shown: true },
    { text: "The only spa I rebook before I leave the room.", author: "Daniel A.", shown: true },
    { text: "Beautiful space, faultless service.", author: "Marcus T.", shown: false },
  ];
  return (
    <div style={{ display: "grid", gridTemplateColumns: "repeat(2,1fr)", gap: 16 }} className="ov-grid">
      {items.map((t, i) => (
        <Panel key={i}>
          <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 10 }}>
            <div style={{ display: "flex", gap: 3 }}>{[1,2,3,4,5].map(s => <Icon key={s} name="star" size={13} className="text-gold"/>)}</div>
            <Toggle checked={t.shown} onChange={() => toast(t.shown ? "Hidden from site" : "Shown on site")} size={36}/>
          </div>
          <p style={{ fontFamily: "var(--font-body)", fontStyle: "italic", fontSize: "0.95rem", lineHeight: 1.5 }}>"{t.text}"</p>
          <div className="caption" style={{ marginTop: 10 }}>{t.author}</div>
        </Panel>
      ))}
    </div>
  );
}

function CMSSeo({ toast }) {
  const pages = [
    { page: "Homepage", title: "The Chelsea Spa — Luxury Facials & Massage, Hollywood Road", desc: "Bespoke facials, ceremonial massage and slow rituals in the heart of Chelsea.", score: 92 },
    { page: "Treatments", title: "Treatments & Pricing | The Chelsea Spa", desc: "Explore our full menu of facials, massage, body rituals and specialist treatments.", score: 88 },
    { page: "About", title: "Our Story | The Chelsea Spa", desc: "Eleven years of quiet practice on Hollywood Road. Meet our therapists.", score: 79 },
  ];
  return (
    <Panel pad={false} style={{ overflow: "hidden" }}>
      {pages.map((p, i) => (
        <div key={i} style={{ padding: "18px 22px", borderBottom: i < pages.length-1 ? "1px solid var(--line)" : "none" }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 10 }}>
            <span className="caption">{p.page}</span>
            <span style={{ display: "flex", alignItems: "center", gap: 8 }}>
              <span className="caption">SEO score</span>
              <span style={{ fontFamily: "var(--font-display)", color: p.score >= 90 ? "var(--success)" : p.score >= 80 ? "var(--gold-deep)" : "var(--danger)" }}>{p.score}</span>
            </span>
          </div>
          <div style={{ marginBottom: 8 }}><div className="a-label">Meta title</div><input className="a-input" defaultValue={p.title}/></div>
          <div><div className="a-label">Meta description</div><textarea className="a-input" rows={2} defaultValue={p.desc} style={{ resize: "vertical" }}/></div>
        </div>
      ))}
    </Panel>
  );
}

/* =====================================================================
   NOTIFICATIONS
   ===================================================================== */
function ModuleNotifications() {
  const toast = useToast();
  const [channels, setChannels] = useState({ email: true, sms: true, whatsapp: true, push: false });
  return (
    <div>
      <PageHead eyebrow="Communications" title="Notifications"/>
      <div style={{ display: "grid", gridTemplateColumns: "1.4fr 1fr", gap: 16 }} className="ov-grid">
        <Panel pad={false} style={{ overflow: "hidden" }}>
          <div style={{ padding: "16px 20px", borderBottom: "1px solid var(--line)" }}><h3 style={{ fontSize: "1.05rem" }}>Recent activity</h3></div>
          {AD.NOTIFS.map((n, i) => (
            <div key={i} style={{ display: "flex", gap: 14, padding: "14px 20px", borderBottom: i < AD.NOTIFS.length-1 ? "1px solid var(--line)" : "none", alignItems: "flex-start" }}>
              <span style={{ color: n.type === "alert" ? "var(--gold-deep)" : "var(--ink-3)", marginTop: 2 }}><Icon name={n.icon} size={16}/></span>
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: "0.88rem" }}>{n.text}</div>
                <div className="caption" style={{ fontSize: "0.68rem", marginTop: 2 }}>{n.time}</div>
              </div>
              <span className="chip chip-line" style={{ fontSize: "0.6rem" }}>{n.channel}</span>
            </div>
          ))}
        </Panel>
        <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
          <Panel>
            <h3 style={{ fontSize: "1.05rem", marginBottom: 14 }}>Channels</h3>
            {[["email","Email","mail"],["sms","SMS reminders","message"],["whatsapp","WhatsApp","message"],["push","Push notifications","bell"]].map(([k, label, icon]) => (
              <div key={k} style={{ display: "flex", alignItems: "center", justifyContent: "space-between", padding: "11px 0", borderTop: "1px solid var(--line)" }}>
                <span style={{ display: "flex", alignItems: "center", gap: 10, fontFamily: "var(--font-display)", fontSize: "0.88rem" }}><Icon name={icon} size={15} className="text-ink-3"/>{label}</span>
                <Toggle checked={channels[k]} onChange={v => { setChannels({...channels, [k]: v}); toast(label + (v ? " enabled" : " disabled")); }} size={38}/>
              </div>
            ))}
          </Panel>
          <Panel>
            <h3 style={{ fontSize: "1.05rem", marginBottom: 12 }}>Calendar sync</h3>
            <SyncRow icon="calendar" label="Google Calendar" connected/>
            <SyncRow icon="calendar" label="Outlook" connected={false} toast={toast}/>
          </Panel>
        </div>
      </div>
    </div>
  );
}

function SyncRow({ icon, label, connected, toast }) {
  return (
    <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", padding: "11px 0", borderTop: "1px solid var(--line)" }}>
      <span style={{ display: "flex", alignItems: "center", gap: 10, fontFamily: "var(--font-display)", fontSize: "0.88rem" }}><Icon name={icon} size={15} className="text-ink-3"/>{label}</span>
      {connected ? <Pill color="var(--success)" bg="rgba(107,122,94,0.16)" dot>Connected</Pill> : <Button variant="ghost" size="sm" onClick={() => toast && toast("Connecting…")}>Connect</Button>}
    </div>
  );
}

/* =====================================================================
   SETTINGS — roles, locations, audit log, advanced
   ===================================================================== */
function ModuleSettings() {
  const [tab, setTab] = useState("roles");
  const toast = useToast();
  return (
    <div>
      <PageHead eyebrow="Configuration" title="Settings"/>
      <div style={{ marginBottom: 20 }}>
        <Tabs active={tab} onChange={setTab} tabs={[
          { id: "roles", label: "Roles & permissions" },
          { id: "locations", label: "Locations" },
          { id: "advanced", label: "Advanced features" },
          { id: "audit", label: "Audit log" },
        ]}/>
      </div>
      {tab === "roles" && <RolesPanel/>}
      {tab === "locations" && <LocationsPanel toast={toast}/>}
      {tab === "advanced" && <AdvancedPanel toast={toast}/>}
      {tab === "audit" && <AuditPanel/>}
    </div>
  );
}

function RolesPanel() {
  const matrix = [
    ["Module", "Super Admin", "Manager", "Receptionist", "Therapist"],
    ["Calendar & bookings", "✓", "✓", "✓", "Own only"],
    ["Customers (CRM)", "✓", "✓", "✓", "View"],
    ["Catalog & pricing", "✓", "✓", "—", "—"],
    ["Sales & refunds", "✓", "✓", "View", "—"],
    ["Staff & rota", "✓", "✓", "View", "Own"],
    ["CMS / website", "✓", "✓", "—", "—"],
    ["Settings & roles", "✓", "—", "—", "—"],
  ];
  return (
    <Panel pad={false} style={{ overflow: "hidden" }}>
      <table className="atable">
        <thead><tr>{matrix[0].map((h, i) => <th key={i} style={{ textAlign: i === 0 ? "left" : "center" }}>{h}</th>)}</tr></thead>
        <tbody>
          {matrix.slice(1).map((row, i) => (
            <tr key={i}>
              {row.map((cell, j) => (
                <td key={j} style={{ textAlign: j === 0 ? "left" : "center", fontFamily: j === 0 ? "var(--font-display)" : "var(--font-body)", fontSize: j === 0 ? "0.9rem" : "0.84rem" }}>
                  {cell === "✓" ? <Icon name="check" size={15} className="text-gold"/> : cell === "—" ? <span style={{ color: "var(--ink-3)" }}>—</span> : <span className="caption" style={{ fontSize: "0.7rem" }}>{cell}</span>}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </Panel>
  );
}

function LocationsPanel({ toast }) {
  const locs = [
    { name: "Chelsea — Hollywood Road", rooms: 4, staff: 4, status: "Open", flagship: true },
    { name: "Notting Hill (coming soon)", rooms: 3, staff: 0, status: "Setup", flagship: false },
  ];
  return (
    <div>
      <div style={{ display: "flex", justifyContent: "flex-end", marginBottom: 16 }}>
        <Button variant="ghost" size="sm" icon="plus" onClick={() => toast("Add location")}>Add location</Button>
      </div>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(300px,1fr))", gap: 16 }}>
        {locs.map(l => (
          <Panel key={l.name}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
              <Icon name="building" size={20} className="text-gold"/>
              {l.flagship && <span className="chip chip-gold" style={{ fontSize: "0.6rem" }}>Flagship</span>}
            </div>
            <h3 style={{ fontSize: "1.1rem", marginTop: 12 }}>{l.name}</h3>
            <div style={{ display: "flex", gap: 20, marginTop: 14 }}>
              <div><div className="caption">Rooms</div><div style={{ fontFamily: "var(--font-display)", fontSize: "1.2rem" }}>{l.rooms}</div></div>
              <div><div className="caption">Staff</div><div style={{ fontFamily: "var(--font-display)", fontSize: "1.2rem" }}>{l.staff}</div></div>
              <div><div className="caption">Status</div><div style={{ fontFamily: "var(--font-display)", fontSize: "1.2rem", color: l.status === "Open" ? "var(--success)" : "var(--gold-deep)" }}>{l.status}</div></div>
            </div>
          </Panel>
        ))}
      </div>
    </div>
  );
}

function AdvancedPanel({ toast }) {
  const [feats, setFeats] = useState({
    ai: true, dynamic: false, autoSchedule: true, consult: true, photos: false, autoRenew: true, commission: true, multilang: false,
  });
  const features = [
    ["ai", "AI booking assistant", "Suggests slots, fills gaps from the waitlist", "zap"],
    ["autoSchedule", "Auto schedule optimisation", "Minimise idle time across therapists", "refresh"],
    ["dynamic", "Dynamic pricing", "Adjust prices by demand and time of day", "trending"],
    ["consult", "Online consultation forms", "Pre-visit skin & health questionnaires", "clipboard"],
    ["photos", "Before / after photo tracking", "Client progress galleries (consent-gated)", "camera"],
    ["autoRenew", "Membership auto-renewals", "Charge recurring memberships via Stripe", "refresh"],
    ["commission", "Staff commission system", "Per-treatment commission tracking", "percent"],
    ["multilang", "Multi-language site", "EN · FR · AR for the public website", "globe"],
  ];
  return (
    <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }} className="ov-grid">
      {features.map(([k, title, sub, icon]) => (
        <Panel key={k}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", gap: 12 }}>
            <div style={{ display: "flex", gap: 12 }}>
              <span style={{ color: feats[k] ? "var(--gold-deep)" : "var(--ink-3)", marginTop: 2 }}><Icon name={icon} size={18}/></span>
              <div>
                <div style={{ fontFamily: "var(--font-display)", fontSize: "0.95rem" }}>{title}</div>
                <div className="caption" style={{ marginTop: 3 }}>{sub}</div>
              </div>
            </div>
            <Toggle checked={feats[k]} onChange={v => { setFeats({...feats, [k]: v}); toast(title + (v ? " on" : " off")); }} size={38}/>
          </div>
        </Panel>
      ))}
    </div>
  );
}

function AuditPanel() {
  return (
    <Panel pad={false} style={{ overflow: "hidden" }}>
      <table className="atable">
        <thead><tr><th>Time</th><th>User</th><th>Role</th><th>Action</th><th>IP</th></tr></thead>
        <tbody>
          {AD.AUDIT.map((a, i) => (
            <tr key={i}>
              <td style={{ fontFamily: "var(--font-mono)", fontSize: "0.78rem", color: "var(--ink-3)" }}>{a.time}</td>
              <td style={{ fontFamily: "var(--font-display)", fontSize: "0.86rem" }}>{a.who}</td>
              <td><span className="caption">{a.role}</span></td>
              <td style={{ fontSize: "0.86rem" }}>{a.action}</td>
              <td><span className="caption" style={{ fontFamily: "var(--font-mono)" }}>{a.ip}</span></td>
            </tr>
          ))}
        </tbody>
      </table>
    </Panel>
  );
}

Object.assign(window, { ModuleSales, ModuleInventory, ModuleMarketing, ModuleNotifications, ModuleSettings });
