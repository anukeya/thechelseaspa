/* =========================================================================
   APP — Router shell. Resolves the current path to a page component.
   ========================================================================= */

function App() {
  return (
    <RouterProvider>
      <ToastProvider>
        <Router />
      </ToastProvider>
    </RouterProvider>
  );
}

function Router() {
  const { path } = useRouter();

  // Stripe return data is deliberately kept AFTER # so Apache / ModSecurity
  // never receives the Stripe session id. Read the raw browser hash first,
  // before relying on any router state.
  const rawHash =
    String(window.location.hash || "");

  const isStripeReturn =
    rawHash.startsWith("#/checkout/success/") ||
    rawHash === "#/checkout/cancelled" ||
    rawHash.startsWith("#/checkout?success=1") ||
    rawHash.startsWith("#/checkout?cancelled=1");

  if (isStripeReturn) {
    return <CheckoutPage/>;
  }

  const base = path.split("?")[0].split("#")[0];

  // Match by prefix so /booking?t=foo resolves to /booking
  if (base === "/" || base === "")          return <HomePage/>;
  if (base.startsWith("/treatments"))       return <TreatmentsPage/>;
  if (base.startsWith("/shop"))             return <ShopPage/>;
  if (base.startsWith("/booking"))          return <BookingPage/>;
  if (base.startsWith("/checkout"))         return <CheckoutPage/>;
  if (base.startsWith("/dashboard"))        return <DashboardPage/>;
  if (base.startsWith("/admin"))            return <AdminPage/>;
  if (base.startsWith("/about"))            return <AboutPage/>;
  if (base.startsWith("/contact"))          return <ContactPage/>;

  // 404
  return <NotFound/>;
}

function NotFound() {
  const { navigate } = useRouter();
  return (
    <div>
      <Nav/>
      <section style={{ paddingTop: 200, paddingBottom: 200, textAlign: "center" }}>
        <div className="container-narrow">
          <div className="eyebrow">404</div>
          <h1 style={{ marginTop: 12 }}>That page is taking a moment.</h1>
          <p className="body-lg" style={{ marginTop: 16, marginBottom: 32 }}>
            Let us pour you a cup of something while you find your way back.
          </p>
          <Button variant="primary" onClick={() => navigate("/")} iconRight="arrow-right">Return home</Button>
        </div>
      </section>
      <Footer/>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<App/>);
