/* =========================================================================
   ADMIN SHELL — STEP 10I1B
   Secure role preview + real top-right notification centre
   ========================================================================= */

const ADMIN_NAV = [
  { group: "Workspace", items: [
    { id: "overview",  label: "Overview",     icon: "grid" },
    { id: "calendar",  label: "Calendar",     icon: "calendar" },
    { id: "bookings",  label: "Bookings",     icon: "clock" },
  ]},
  { group: "Manage", items: [
    { id: "customers", label: "Customers",    icon: "users" },
    { id: "staff",     label: "Staff & rota", icon: "user" },
    { id: "catalog",   label: "Catalog",      icon: "scissors" },
    { id: "inventory", label: "Inventory",    icon: "package" },
  ]},
  { group: "Business", items: [
    { id: "sales",     label: "Sales & payments", icon: "wallet" },
    { id: "marketing", label: "Content (CMS)",    icon: "megaphone" },
    // The old prototype Notifications page is intentionally hidden.
    // The real notification centre now lives in the top-right bell.
    { id: "settings",  label: "Settings",         icon: "settings" },
  ]},
];

const MODULE_MAP = {
  overview: ModuleOverview,
  calendar: ModuleCalendar,
  bookings: ModuleBookings,
  customers: ModuleCustomers,
  staff: ModuleStaff,
  catalog: ModuleCatalog,
  inventory: ModuleInventory,
  sales: ModuleSales,
  marketing: ModuleMarketing,
  notifications: ModuleNotifications,
  settings: ModuleSettings,
};

const MODULE_TITLE = {
  overview: "Overview",
  calendar: "Calendar",
  bookings: "Bookings",
  customers: "Customers",
  staff: "Staff & rota",
  catalog: "Catalog",
  inventory: "Inventory",
  sales: "Sales & payments",
  marketing: "Content",
  notifications: "Notifications",
  settings: "Settings",
};


// ==========================================================
// ACCESS ROLE NORMALISATION
// ==========================================================

function normalizeAccessRole(accessRole, legacyRole) {
  const validRoles = [
    "super_admin",
    "admin",
    "practitioner",
  ];

  if (validRoles.includes(accessRole)) {
    return accessRole;
  }

  const oldRoleMap = {
    super_admin: "super_admin",
    manager: "admin",
    receptionist: "practitioner",
    therapist: "practitioner",
  };

  return oldRoleMap[legacyRole] || "practitioner";
}


// ==========================================================
// LOAD THE REAL LOGGED-IN IDENTITY
//
// This is deliberately separate from the preview role.
// A Super Admin may preview another UI role, but their real
// authenticated role never changes in browser state.
// ==========================================================

async function loadAdminIdentityFromSession(session) {
  if (!session?.user?.id) {
    throw new Error("No authenticated session was found.");
  }

  const { data: profile, error: profileError } =
    await window.supabaseClient
      .from("profiles")
      .select(`
        id,
        email,
        access_role,
        role,
        is_active
      `)
      .eq("id", session.user.id)
      .single();

  if (profileError) {
    throw profileError;
  }

  if (!profile?.is_active || profile.role === "inactive") {
    throw new Error(
      "This staff account is not active. Ask a Super Admin to enable it."
    );
  }

  const realRole = normalizeAccessRole(
    profile.access_role,
    profile.role
  );

  let staff = null;

  try {
    const { data, error } =
      await window.supabaseClient
        .from("staff_members")
        .select(`
          id,
          first_name,
          last_name,
          colour,
          job_title
        `)
        .eq("user_id", session.user.id)
        .maybeSingle();

    if (error) throw error;
    staff = data || null;
  } catch (error) {
    // Login should not fail just because the optional staff profile
    // could not be loaded. Auth + profiles remain the source of truth.
    console.warn(
      "Could not load linked staff display profile:",
      error
    );
  }

  const staffName = [
    staff?.first_name,
    staff?.last_name,
  ]
    .filter(Boolean)
    .join(" ");

  const email =
    profile.email ||
    session.user.email ||
    "Staff";

  return {
    role: realRole,
    email,
    name: staffName || email.split("@")[0] || "Staff",
    colour: staff?.colour || "var(--gold-deep)",
    staff_id: staff?.id || null,
    job_title: staff?.job_title || null,
  };
}


function AdminApp() {
  return (
    <ToastProvider>
      <AdminShell/>
    </ToastProvider>
  );
}


function AdminShell() {
  const [authed, setAuthed] = useState(false);
  const [checkingSession, setCheckingSession] = useState(true);
  const [module, setModule] = useState("overview");

  // realRole is the authenticated database role.
  // role is only the UI role currently being viewed.
  const [realRole, setRealRole] = useState("practitioner");
  const [role, setRole] = useState("practitioner");
  const [identity, setIdentity] = useState({
    name: "Staff",
    email: "",
    colour: "var(--gold-deep)",
  });

  const [dark, setDark] = useState(
    () => localStorage.getItem("cs-admin-dark") === "1"
  );
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [search, setSearch] = useState("");

  // ----------------------------------------------------------
  // Session restore — fixes the old access_role omission bug.
  // ----------------------------------------------------------
  useEffect(() => {
    let cancelled = false;

    async function restoreSupabaseSession() {
      try {
        const { data, error } =
          await window.supabaseClient.auth.getSession();

        if (error) throw error;

        const session = data.session;
        if (!session) return;

        const loaded =
          await loadAdminIdentityFromSession(session);

        if (cancelled) return;

        setIdentity(loaded);
        setRealRole(loaded.role);
        setRole(loaded.role);
        setAuthed(true);

      } catch (error) {
        console.error(
          "Could not restore admin session:",
          error
        );

        try {
          await window.supabaseClient.auth.signOut();
        } catch {
          // Nothing else required.
        }

      } finally {
        if (!cancelled) {
          setCheckingSession(false);
        }
      }
    }

    restoreSupabaseSession();

    return () => {
      cancelled = true;
    };
  }, []);


  useEffect(() => {
    document.documentElement.classList.toggle(
      "admin-dark",
      dark
    );
    document.body.classList.toggle(
      "admin-dark",
      dark
    );
    localStorage.setItem(
      "cs-admin-dark",
      dark ? "1" : "0"
    );
  }, [dark]);


  const allowed = AD.PERMS?.[role] || [];

  useEffect(() => {
    if (!allowed.includes(module)) {
      setModule("overview");
    }
  }, [role, module]);


  const go = (targetModule) => {
    setModule(targetModule);
    setSidebarOpen(false);
    window.scrollTo({ top: 0 });
  };


  const completeLogin = (loadedIdentity) => {
    setIdentity(loadedIdentity);
    setRealRole(loadedIdentity.role);
    setRole(loadedIdentity.role);
    setAuthed(true);
  };


  const signOut = async () => {
    await window.supabaseClient.auth.signOut();
    setAuthed(false);
    setRealRole("practitioner");
    setRole("practitioner");
    setIdentity({
      name: "Staff",
      email: "",
      colour: "var(--gold-deep)",
    });
  };


  if (checkingSession) {
    return (
      <div
        style={{
          minHeight: "100vh",
          display: "grid",
          placeItems: "center",
          background: "var(--bg)",
        }}
      >
        <div className="caption">
          Checking secure session…
        </div>
      </div>
    );
  }


  if (!authed) {
    return (
      <AdminLogin
        onLogin={completeLogin}
        dark={dark}
        setDark={setDark}
      />
    );
  }


  const Module = MODULE_MAP[module];
  const isManagement = [
    "super_admin",
    "admin",
  ].includes(realRole);


  return (
    <div className="admin-root">

      {/* SIDEBAR */}
      <aside
        className={`admin-sidebar ${sidebarOpen ? "open" : ""}`}
      >
        <div
          style={{
            padding: "22px 22px 18px",
            borderBottom: "1px solid var(--line)",
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between",
          }}
        >
          <Logo size={24}/>

          <button
            className="icon-btn mobile-only"
            style={{ width: 34, height: 34 }}
            onClick={() => setSidebarOpen(false)}
          >
            <Icon name="x" size={18}/>
          </button>
        </div>

        <div
          className="hide-scroll"
          style={{
            flex: 1,
            overflowY: "auto",
            padding: "8px 14px 20px",
          }}
        >
          {ADMIN_NAV.map(group => {
            const items = group.items.filter(
              item => allowed.includes(item.id)
            );

            if (!items.length) return null;

            return (
              <div key={group.group}>
                <div className="nav-group-label">
                  {group.group}
                </div>

                <div
                  style={{
                    display: "flex",
                    flexDirection: "column",
                    gap: 2,
                  }}
                >
                  {items.map(item => (
                    <button
                      key={item.id}
                      className={
                        `nav-item ${module === item.id ? "active" : ""}`
                      }
                      onClick={() => go(item.id)}
                    >
                      <span className="nav-ic">
                        <Icon name={item.icon} size={17}/>
                      </span>
                      {item.label}
                    </button>
                  ))}
                </div>
              </div>
            );
          })}
        </div>

        <div
          style={{
            padding: "14px",
            borderTop: "1px solid var(--line)",
          }}
        >
          <a
            href="index.html"
            className="nav-item"
            style={{ marginBottom: 2 }}
          >
            <span className="nav-ic">
              <Icon name="external" size={17}/>
            </span>
            View website
          </a>

          <button
            className="nav-item"
            onClick={signOut}
          >
            <span className="nav-ic">
              <Icon name="logout" size={17}/>
            </span>
            Sign out
          </button>
        </div>
      </aside>


      {sidebarOpen && (
        <div
          onClick={() => setSidebarOpen(false)}
          style={{
            position: "fixed",
            inset: 0,
            zIndex: 90,
            background: "rgba(20,16,12,0.4)",
          }}
          className="mobile-only"
        />
      )}


      {/* MAIN */}
      <div className="admin-main">
        <header className="admin-topbar">

          <button
            className="icon-btn mobile-only"
            onClick={() => setSidebarOpen(true)}
          >
            <Icon name="menu" size={20}/>
          </button>

          <SearchInput
            value={search}
            onChange={setSearch}
            placeholder="Search bookings, customers, treatments…"
            width={340}
          />

          <div style={{ flex: 1 }}/>

          {/* SECURITY FIX: only the REAL Super Admin can preview roles. */}
          {realRole === "super_admin" && (
            <RoleSwitcher
              role={role}
              setRole={setRole}
            />
          )}

          <IconBtn
            icon={dark ? "sun" : "moon"}
            title="Toggle theme"
            onClick={() => setDark(!dark)}
          />

          {/* REAL NOTIFICATION CENTRE */}
          {isManagement && (
            <AdminNotificationBell
              go={go}
            />
          )}

          {/* REAL LOGGED-IN USER */}
          <div
            style={{
              display: "flex",
              alignItems: "center",
              gap: 10,
              paddingLeft: 8,
              borderLeft: "1px solid var(--line)",
            }}
          >
            <Avatar
              name={identity.name}
              size={34}
              color={identity.colour}
            />

            <div
              className="topbar-user"
              style={{ lineHeight: 1.2 }}
            >
              <div
                style={{
                  fontFamily: "var(--font-display)",
                  fontSize: "0.82rem",
                }}
              >
                {identity.name}
              </div>

              <div
                className="caption"
                style={{ fontSize: "0.64rem" }}
              >
                {AD.ROLES?.[realRole]?.label || "Staff"}
              </div>
            </div>
          </div>
        </header>

        <main
          className="admin-content"
          key={module}
        >
          <Module go={go}/>
        </main>
      </div>

      <style>{`
        @media (max-width: 720px) {
          .topbar-user { display: none; }
        }
      `}</style>
    </div>
  );
}


// ============================================================================
// REAL NOTIFICATION BELL
// ============================================================================

function formatAdminNotificationTime(value) {
  if (!value) return "";

  const time = new Date(value).getTime();
  const diff = Date.now() - time;

  if (!Number.isFinite(diff)) return "";

  const minutes = Math.max(0, Math.floor(diff / 60000));

  if (minutes < 1) return "Just now";
  if (minutes < 60) return `${minutes}m ago`;

  const hours = Math.floor(minutes / 60);
  if (hours < 24) return `${hours}h ago`;

  const days = Math.floor(hours / 24);
  if (days < 7) return `${days}d ago`;

  return new Date(value).toLocaleDateString(
    "en-GB",
    {
      day: "numeric",
      month: "short",
    }
  );
}


function adminNotificationIcon(category) {
  const map = {
    booking: "calendar",
    staff: "user",
    leave: "clock",
    resource: "package",
    integration: "refresh",
    system: "bell",
  };

  return map[category] || "bell";
}


function AdminNotificationBell({ go }) {
  const [open, setOpen] = useState(false);
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [unreadCount, setUnreadCount] = useState(0);
  const ref = useRef(null);


  const load = useCallback(async () => {
    if (!window.API?.AdminNotifications) {
      return;
    }

    try {
      setLoading(true);
      setError("");

      // Load the notification list and unread count independently.
      //
      // IMPORTANT:
      // A temporary network/DNS failure on the unread-count RPC must NOT
      // make the whole notification centre look broken when the actual
      // notification rows were loaded successfully.
      const results =
        await Promise.allSettled([
          window.API.AdminNotifications.list(12),
          window.API.AdminNotifications.unreadCount(),
        ]);

      const rowsResult = results[0];
      const countResult = results[1];

      if (rowsResult.status === "fulfilled") {
        const rows =
          Array.isArray(rowsResult.value)
            ? rowsResult.value
            : [];

        setItems(rows);

        if (countResult.status === "fulfilled") {
          setUnreadCount(
            Number(countResult.value || 0)
          );
        } else {
          // Graceful fallback:
          // derive a temporary badge count from the rows that DID load.
          // The next poll/realtime refresh will restore the exact count.
          setUnreadCount(
            rows.filter(row => !row.is_read).length
          );

          console.warn(
            "Admin notification unread count temporarily unavailable; using loaded rows as fallback:",
            countResult.reason
          );
        }

        // The list itself loaded, so do not show a user-facing error.
        setError("");

      } else {
        // The actual notification list failed.
        throw rowsResult.reason;
      }

    } catch (loadError) {
      console.warn(
        "Admin notifications could not be loaded:",
        loadError
      );

      setError(
        loadError?.message ||
        "Notifications could not be loaded."
      );

    } finally {
      setLoading(false);
    }
  }, []);


  useEffect(() => {
    load();

    const poll = window.setInterval(
      load,
      30000
    );

    let channel = null;

    try {
      channel = window.supabaseClient
        .channel("chelsea-admin-notifications")
        .on(
          "postgres_changes",
          {
            event: "INSERT",
            schema: "public",
            table: "admin_notifications",
          },
          () => load()
        )
        .subscribe();
    } catch (realtimeError) {
      console.warn(
        "Notification realtime unavailable; polling remains active:",
        realtimeError
      );
    }

    return () => {
      window.clearInterval(poll);

      if (channel) {
        window.supabaseClient
          .removeChannel(channel)
          .catch(() => {});
      }
    };
  }, [load]);


  useEffect(() => {
    const close = (event) => {
      if (
        ref.current &&
        !ref.current.contains(event.target)
      ) {
        setOpen(false);
      }
    };

    window.addEventListener("mousedown", close);

    return () => {
      window.removeEventListener("mousedown", close);
    };
  }, []);


  const openBell = () => {
    setOpen(value => !value);
    load();
  };


  const markRead = async (item) => {
    if (!item?.id) return;

    try {
      if (!item.is_read) {
        await window.API.AdminNotifications
          .markRead(item.id);
      }

      setItems(current =>
        current.map(row =>
          row.id === item.id
            ? { ...row, is_read: true }
            : row
        )
      );

      if (!item.is_read) {
        setUnreadCount(current =>
          Math.max(0, current - 1)
        );
      }

      setOpen(false);

      if (item.action_module) {
        go(item.action_module);
      }

    } catch (readError) {
      console.error(
        "Notification could not be marked read:",
        readError
      );
    }
  };


  const markAllRead = async () => {
    try {
      await window.API.AdminNotifications
        .markAllRead();

      setItems(current =>
        current.map(row => ({
          ...row,
          is_read: true,
        }))
      );
      setUnreadCount(0);

    } catch (readError) {
      console.error(
        "Notifications could not be marked read:",
        readError
      );
    }
  };


  return (
    <div
      ref={ref}
      style={{ position: "relative" }}
    >
      <button
        type="button"
        className="icon-btn"
        title="Admin notifications"
        onClick={openBell}
        style={{
          width: 38,
          height: 38,
          position: "relative",
        }}
      >
        <Icon name="bell" size={18}/>

        {unreadCount > 0 && (
          <span
            style={{
              position: "absolute",
              top: -4,
              right: -4,
              minWidth: 18,
              height: 18,
              padding: "0 4px",
              borderRadius: 9,
              display: "grid",
              placeItems: "center",
              background: "var(--danger)",
              color: "#fff",
              border: "2px solid var(--bg)",
              fontSize: "0.58rem",
              fontFamily: "var(--font-display)",
              lineHeight: 1,
            }}
          >
            {unreadCount > 99 ? "99+" : unreadCount}
          </span>
        )}
      </button>


      {open && (
        <div
          className="fade-in"
          style={{
            position: "absolute",
            top: "calc(100% + 9px)",
            right: 0,
            width: "min(390px, calc(100vw - 24px))",
            maxHeight: "min(560px, calc(100vh - 90px))",
            overflow: "hidden",
            zIndex: 120,
            background: "var(--bg-cream)",
            border: "1px solid var(--line)",
            borderRadius: 12,
            boxShadow: "var(--shadow-3)",
          }}
        >
          <div
            style={{
              padding: "14px 16px",
              display: "flex",
              alignItems: "center",
              justifyContent: "space-between",
              gap: 12,
              borderBottom: "1px solid var(--line)",
            }}
          >
            <div>
              <div
                style={{
                  fontFamily: "var(--font-display)",
                  fontSize: "0.95rem",
                }}
              >
                Notifications
              </div>

              <div
                className="caption"
                style={{ marginTop: 2 }}
              >
                {unreadCount > 0
                  ? `${unreadCount} unread`
                  : "You're all caught up"}
              </div>
            </div>

            {unreadCount > 0 && (
              <button
                type="button"
                className="caption"
                onClick={markAllRead}
                style={{
                  color: "var(--gold-deep)",
                  textTransform: "uppercase",
                  letterSpacing: "0.08em",
                }}
              >
                Mark all read
              </button>
            )}
          </div>


          <div
            className="hide-scroll"
            style={{
              maxHeight: 470,
              overflowY: "auto",
            }}
          >
            {loading && !items.length && (
              <div
                className="caption"
                style={{ padding: 20 }}
              >
                Loading notifications…
              </div>
            )}

            {!loading && error && !items.length && (
              <div
                style={{
                  padding: 18,
                  color: "var(--danger)",
                  fontSize: "0.82rem",
                }}
              >
                {error}
              </div>
            )}

            {!loading && !error && !items.length && (
              <div
                style={{
                  padding: "28px 20px",
                  textAlign: "center",
                }}
              >
                <Icon
                  name="bell"
                  size={20}
                  className="text-ink-3"
                />
                <div
                  className="caption"
                  style={{ marginTop: 8 }}
                >
                  No notifications yet.
                </div>
              </div>
            )}


            {items.map((item, index) => {
              const urgent =
                item.priority === "urgent" ||
                item.priority === "attention";

              return (
                <button
                  type="button"
                  key={item.id}
                  onClick={() => markRead(item)}
                  style={{
                    width: "100%",
                    textAlign: "left",
                    display: "flex",
                    gap: 12,
                    padding: "13px 16px",
                    borderBottom:
                      index < items.length - 1
                        ? "1px solid var(--line)"
                        : "none",
                    background:
                      item.is_read
                        ? "transparent"
                        : "var(--bg-nude)",
                    cursor: "pointer",
                  }}
                >
                  <span
                    style={{
                      width: 31,
                      height: 31,
                      borderRadius: 16,
                      display: "grid",
                      placeItems: "center",
                      flex: "0 0 auto",
                      color:
                        urgent
                          ? "var(--gold-deep)"
                          : "var(--ink-3)",
                      background:
                        urgent
                          ? "rgba(190,151,80,0.12)"
                          : "var(--bg-shell)",
                    }}
                  >
                    <Icon
                      name={adminNotificationIcon(item.category)}
                      size={15}
                    />
                  </span>

                  <span style={{ flex: 1, minWidth: 0 }}>
                    <span
                      style={{
                        display: "flex",
                        alignItems: "center",
                        gap: 7,
                      }}
                    >
                      <span
                        style={{
                          fontFamily: "var(--font-display)",
                          fontSize: "0.82rem",
                          fontWeight: item.is_read ? 400 : 600,
                        }}
                      >
                        {item.title}
                      </span>

                      {!item.is_read && (
                        <span
                          style={{
                            width: 6,
                            height: 6,
                            borderRadius: 3,
                            background: "var(--gold-deep)",
                            flex: "0 0 auto",
                          }}
                        />
                      )}
                    </span>

                    <span
                      style={{
                        display: "block",
                        marginTop: 3,
                        fontSize: "0.77rem",
                        lineHeight: 1.4,
                        color: "var(--ink-2)",
                      }}
                    >
                      {item.message}
                    </span>

                    <span
                      className="caption"
                      style={{
                        display: "block",
                        marginTop: 4,
                        fontSize: "0.64rem",
                      }}
                    >
                      {formatAdminNotificationTime(item.created_at)}
                    </span>
                  </span>
                </button>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}


// ============================================================================
// SUPER ADMIN ROLE PREVIEW
//
// This component is rendered only when realRole === "super_admin".
// It changes presentation permissions only. Supabase RLS remains the
// server-side source of truth.
// ============================================================================

function RoleSwitcher({ role, setRole }) {
  const [open, setOpen] = useState(false);
  const ref = useRef(null);

  useEffect(() => {
    const onClick = (event) => {
      if (
        ref.current &&
        !ref.current.contains(event.target)
      ) {
        setOpen(false);
      }
    };

    window.addEventListener("mousedown", onClick);

    return () => {
      window.removeEventListener("mousedown", onClick);
    };
  }, []);

  return (
    <div
      ref={ref}
      style={{ position: "relative" }}
    >
      <button
        onClick={() => setOpen(!open)}
        style={{
          display: "flex",
          alignItems: "center",
          gap: 8,
          padding: "8px 12px",
          borderRadius: 8,
          border: "1px solid var(--line-strong)",
          background: "var(--bg)",
          fontFamily: "var(--font-display)",
          fontSize: "0.76rem",
          letterSpacing: "0.04em",
          color: "var(--ink-2)",
        }}
        title="Preview as role"
      >
        <Icon name="eye" size={14}/>
        <span className="role-text">
          Viewing as {AD.ROLES[role]?.label || "Staff"}
        </span>
        <Icon name="chevron-down" size={13}/>
      </button>

      {open && (
        <div
          className="fade-in"
          style={{
            position: "absolute",
            top: "calc(100% + 8px)",
            right: 0,
            zIndex: 60,
            background: "var(--bg-cream)",
            border: "1px solid var(--line)",
            borderRadius: 10,
            boxShadow: "var(--shadow-3)",
            padding: 6,
            width: 220,
          }}
        >
          <div
            className="nav-group-label"
            style={{ margin: "6px 10px 4px" }}
          >
            Preview as role
          </div>

          {Object.values(AD.ROLES).map(item => (
            <button
              key={item.id}
              onClick={() => {
                setRole(item.id);
                setOpen(false);
              }}
              style={{
                display: "flex",
                alignItems: "center",
                justifyContent: "space-between",
                width: "100%",
                padding: "9px 12px",
                borderRadius: 6,
                textAlign: "left",
                background:
                  role === item.id
                    ? "var(--bg-nude)"
                    : "transparent",
                fontFamily: "var(--font-display)",
                fontSize: "0.82rem",
                color: "var(--ink)",
              }}
            >
              {item.label}
              {role === item.id && (
                <Icon
                  name="check"
                  size={14}
                  className="text-gold"
                />
              )}
            </button>
          ))}
        </div>
      )}

      <style>{`
        @media (max-width: 980px) {
          .role-text { display: none; }
        }
      `}</style>
    </div>
  );
}


// ============================================================================
// LOGIN
// ============================================================================

function AdminLogin({ onLogin, dark, setDark }) {
  const [mode, setMode] = useState("login");
  const [email, setEmail] = useState("thechelseaspa@gmail.com");
  const [pw, setPw] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);


  const submit = async (event) => {
    event.preventDefault();
    setError(null);
    setLoading(true);

    try {
      const { data, error: signInError } =
        await window.supabaseClient.auth
          .signInWithPassword({
            email: email.trim(),
            password: pw,
          });

      if (signInError) throw signInError;

      if (!data.user || !data.session) {
        throw new Error(
          "Supabase did not create a login session."
        );
      }

      const loaded =
        await loadAdminIdentityFromSession(
          data.session
        );

      onLogin(loaded);

    } catch (loginError) {
      console.error(
        "Supabase sign-in failed:",
        loginError
      );

      setError(
        loginError.message ||
        "Sign in failed"
      );

      try {
        await window.supabaseClient.auth.signOut();
      } catch {
        // Nothing else required.
      }

    } finally {
      setLoading(false);
    }
  };


  return (
    <div
      style={{
        minHeight: "100vh",
        display: "grid",
        gridTemplateColumns: "1fr 1fr",
        background: "var(--bg)",
      }}
      className="login-root"
    >
      <div
        style={{
          background: "var(--ink)",
          color: "var(--ink-on-dark)",
          padding: "56px 64px",
          display: "flex",
          flexDirection: "column",
          justifyContent: "space-between",
          position: "relative",
          overflow: "hidden",
        }}
        className="login-brand"
      >
        <Logo light size={26}/>

        <div
          style={{
            position: "relative",
            zIndex: 2,
          }}
        >
          <div
            className="eyebrow"
            style={{ color: "var(--gold-soft)" }}
          >
            Staff console
          </div>

          <h1
            style={{
              color: "var(--ink-on-dark)",
              fontSize: "3rem",
              marginTop: 14,
              fontWeight: 300,
              lineHeight: 1.05,
            }}
          >
            Everything,<br/>
            <em
              className="serif-italic"
              style={{ color: "var(--gold)" }}
            >
              quietly in order
            </em>.
          </h1>

          <p
            style={{
              color: "rgba(246,241,232,0.7)",
              marginTop: 20,
              maxWidth: "42ch",
              lineHeight: 1.6,
            }}
          >
            Calendar, customers, catalogue and cash — one calm place to run The Chelsea Spa.
          </p>
        </div>

        <div
          style={{
            position: "relative",
            zIndex: 2,
            display: "flex",
            gap: 28,
          }}
        >
          <div>
            <div
              style={{
                fontFamily: "var(--font-display)",
                fontSize: "1.2rem",
                color: "var(--gold-soft)",
              }}
            >
              Secure
            </div>
            <div
              className="caption"
              style={{ color: "rgba(246,241,232,0.5)" }}
            >
              Supabase Auth
            </div>
          </div>

          <div>
            <div
              style={{
                fontFamily: "var(--font-display)",
                fontSize: "1.2rem",
                color: "var(--gold-soft)",
              }}
            >
              Live
            </div>
            <div
              className="caption"
              style={{ color: "rgba(246,241,232,0.5)" }}
            >
              Operations
            </div>
          </div>
        </div>

        <div
          style={{
            position: "absolute",
            right: -80,
            bottom: -80,
            opacity: 0.08,
            zIndex: 1,
          }}
        >
          <LogoMark size={420} color="#fff"/>
        </div>
      </div>


      <div
        style={{
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          padding: 40,
          position: "relative",
        }}
      >
        <button
          className="icon-btn"
          style={{
            position: "absolute",
            top: 24,
            right: 24,
          }}
          onClick={() => setDark(!dark)}
        >
          <Icon
            name={dark ? "sun" : "moon"}
            size={18}
          />
        </button>

        <div
          style={{
            width: "100%",
            maxWidth: 380,
          }}
        >
          {mode === "login" ? (
            <form onSubmit={submit}>
              <h2 style={{ fontSize: "1.8rem" }}>
                Welcome back
              </h2>

              <p
                className="text-ink-2"
                style={{
                  marginTop: 8,
                  marginBottom: 32,
                }}
              >
                Sign in to the staff console.
              </p>

              <div style={{ marginBottom: 16 }}>
                <div className="a-label">
                  Email
                </div>
                <input
                  className="a-input"
                  value={email}
                  onChange={event =>
                    setEmail(event.target.value)
                  }
                  type="email"
                />
              </div>

              <div style={{ marginBottom: 12 }}>
                <div
                  style={{
                    display: "flex",
                    justifyContent: "space-between",
                    alignItems: "center",
                  }}
                >
                  <span className="a-label">
                    Password
                  </span>

                  <button
                    type="button"
                    onClick={() => setMode("forgot")}
                    className="caption"
                    style={{
                      color: "var(--gold-deep)",
                      textTransform: "uppercase",
                      letterSpacing: "0.1em",
                      marginBottom: 7,
                    }}
                  >
                    Forgot?
                  </button>
                </div>

                <input
                  className="a-input"
                  value={pw}
                  onChange={event =>
                    setPw(event.target.value)
                  }
                  type="password"
                  placeholder="••••••••"
                />
              </div>

              <label
                style={{
                  display: "flex",
                  alignItems: "center",
                  gap: 8,
                  marginBottom: 24,
                  fontSize: "0.84rem",
                  color: "var(--ink-2)",
                  cursor: "pointer",
                }}
              >
                <input
                  type="checkbox"
                  defaultChecked
                  style={{ accentColor: "var(--gold-deep)" }}
                />
                Keep me signed in
              </label>

              <Button
                variant="primary"
                type="submit"
                size="lg"
                disabled={loading}
                style={{ width: "100%" }}
              >
                {loading ? "Signing in…" : "Sign in"}
              </Button>

              {error && (
                <div
                  style={{
                    marginTop: 14,
                    padding: "10px 14px",
                    borderRadius: 6,
                    background: "rgba(154,74,58,0.1)",
                    border: "1px solid rgba(154,74,58,0.3)",
                    color: "var(--danger)",
                    fontSize: "0.84rem",
                    display: "flex",
                    gap: 8,
                    alignItems: "center",
                  }}
                >
                  <Icon name="alert" size={15}/>
                  {error}
                </div>
              )}

              <div
                style={{
                  marginTop: 24,
                  display: "flex",
                  alignItems: "center",
                  gap: 10,
                  justifyContent: "center",
                }}
              >
                <Icon
                  name="lock"
                  size={13}
                  className="text-ink-3"
                />
                <span className="caption">
                  Secured with Supabase Auth · RLS protected
                </span>
              </div>
            </form>

          ) : (
            <div>
              <h2 style={{ fontSize: "1.8rem" }}>
                Reset password
              </h2>

              <p
                className="text-ink-2"
                style={{
                  marginTop: 8,
                  marginBottom: 32,
                }}
              >
                Password-reset delivery will be enabled before production launch.
              </p>

              <Button
                variant="ghost"
                size="lg"
                onClick={() => setMode("login")}
                style={{ width: "100%" }}
              >
                ← Back to sign in
              </Button>
            </div>
          )}
        </div>
      </div>

      <style>{`
        @media (max-width: 880px) {
          .login-root {
            grid-template-columns: 1fr !important;
          }
          .login-brand {
            display: none !important;
          }
        }
      `}</style>
    </div>
  );
}


ReactDOM
  .createRoot(
    document.getElementById("admin-root")
  )
  .render(<AdminApp/>);
