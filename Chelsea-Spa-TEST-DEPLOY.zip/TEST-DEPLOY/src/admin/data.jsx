/* =========================================================================
   ADMIN DATA LAYER — mock data approximating Django REST resources.
   In production each array maps to a DRF ViewSet endpoint.
   Exposed on window.AD.* for module consumption.
   ========================================================================= */

const AD = {};

// ==========================================================
// SYSTEM ACCESS ROLES
//
// These control ADMIN PANEL permissions.
// They do NOT determine treatment prices.
// ==========================================================

AD.ROLES = {

  super_admin: {
    id: "super_admin",
    label: "Super Admin"
  },

  admin: {
    id: "admin",
    label: "Admin / Manager"
  },

  practitioner: {
    id: "practitioner",
    label: "Practitioner"
  }

};

// ==========================================================
// SERVICE ROLES
//
// These describe treatment seniority.
// Percentage values should eventually come from Supabase,
// NOT remain permanently hard-coded here.
// ==========================================================

AD.SERVICE_ROLES = {

  skin_specialist: {
    id: "skin_specialist",
    label: "Skin Specialist"
  },

  senior_therapist: {
    id: "senior_therapist",
    label: "Senior Therapist"
  },

  therapist: {
    id: "therapist",
    label: "Therapist"
  }

};

/* Which modules each role can open */
// ==========================================================
// MODULE VISIBILITY
// ==========================================================

AD.PERMS = {

  // Developer.
  super_admin: [
    "overview",
    "calendar",
    "bookings",
    "customers",
    "staff",
    "catalog",
    "inventory",
    "sales",
    "marketing",
    "notifications",
    "settings"
  ],


  // Day-to-day business manager.
  admin: [
    "overview",
    "calendar",
    "bookings",
    "customers",
    "staff",
    "catalog",
    "inventory",
    "sales",
    "marketing",
    "notifications",
    "settings"
  ],


  // Skin Specialist / Senior Therapist / Therapist.
  practitioner: [
    "overview",
    "calendar",
    "bookings",
    "customers",

    // Required for viewing personal rota
    // and submitting leave.
    "staff",

    // Read-only treatment catalogue.
    "catalog",

    "notifications"
  ]

};

// ==========================================================
// ACTION-LEVEL PERMISSIONS
//
// These decide which controls/buttons are available.
//
// Supabase RLS must later enforce the same rules.
// ==========================================================

AD.CAN = {

  super_admin: {

    customerCreate: true,
    customerEdit: true,
    customerDelete: true,

    bookingCreate: true,
    bookingEdit: true,
    bookingDelete: true,

    treatmentCreate: true,
    treatmentEdit: true,
    treatmentDelete: true,

    productCreate: true,
    productEdit: true,
    productDelete: true,

    packageCreate: true,
    packageEdit: true,
    packageDelete: true,

    staffCreate: true,
    staffEdit: true,
    staffDeactivate: true,

    rotaManage: true,

    leaveRequest: true,
    leaveApprove: true,
    leaveDecline: true,

    servicePricingManage: true,

    inventoryManage: true,
    refundsManage: true,

    // ======================================================
    // USER / ROLE MANAGEMENT
    // ======================================================

    // Can create/invite staff login accounts.
    usersManage: true,

    // Can manage/reset authentication/passwords.
    passwordsManage: true,

    // Can assign system access roles.
    accessRolesManage: true,

    // Can assign Skin Specialist / Senior Therapist / Therapist.
    serviceRolesManage: true,

    // Can create/promote another Super Admin.
    superAdminManage: true,

    // Developer-only areas.
    databaseManage: true,
    systemManage: true
  },


  admin: {

    customerCreate: true,
    customerEdit: true,
    customerDelete: true,

    bookingCreate: true,
    bookingEdit: true,
    bookingDelete: true,

    treatmentCreate: true,
    treatmentEdit: true,
    treatmentDelete: true,

    productCreate: true,
    productEdit: true,
    productDelete: true,

    packageCreate: true,
    packageEdit: true,
    packageDelete: true,

    staffCreate: true,
    staffEdit: true,
    staffDeactivate: true,

    rotaManage: true,

    leaveRequest: true,
    leaveApprove: true,
    leaveDecline: true,

    // Admin CAN change 20%, 10%, etc.
    servicePricingManage: true,

    inventoryManage: true,
    refundsManage: true,

    // Developer/system actions are prohibited.
    // ======================================================
    // USER / ROLE MANAGEMENT
    // ======================================================

    // Admin can manage normal staff accounts as part of
    // running the business day-to-day.
    //
    // We can later limit this to invite/deactivate only.
    usersManage: true,

    // Admin must NOT reset/manage passwords.
    passwordsManage: false,

    // Admin can assign normal business access,
    // such as Practitioner.
    //
    // Database security will prevent assigning Super Admin.
    accessRolesManage: true,

    // Admin can choose:
    // Skin Specialist
    // Senior Therapist
    // Therapist
    serviceRolesManage: true,

    // Only Super Admin can create/promote Super Admins.
    superAdminManage: false,

    // Developer-only areas.
    databaseManage: false,
    systemManage: false
  },


  practitioner: {

    // Customer CRM.
    customerCreate: true,
    customerEdit: true,
    customerDelete: false,

    // Booking creation permitted.
    bookingCreate: true,

    // Initially keep destructive booking
    // modifications restricted.
    bookingEdit: false,
    bookingDelete: false,

    // Catalogue is read-only.
    treatmentCreate: false,
    treatmentEdit: false,
    treatmentDelete: false,

    productCreate: false,
    productEdit: false,
    productDelete: false,

    packageCreate: false,
    packageEdit: false,
    packageDelete: false,

    // Cannot manage other staff.
    staffCreate: false,
    staffEdit: false,
    staffDeactivate: false,

    // View own rota only.
    rotaManage: false,

    // Can request leave.
    leaveRequest: true,

    // Cannot approve themselves/others.
    leaveApprove: false,
    leaveDecline: false,

    // Cannot alter service-role uplift.
    servicePricingManage: false,

    inventoryManage: false,
    refundsManage: false,
    // Cannot manage login accounts.
    usersManage: false,

    // Cannot manage passwords.
    passwordsManage: false,

    // Cannot change system access roles.
    accessRolesManage: false,

    // Cannot promote/demote treatment level.
    serviceRolesManage: false,

    // Cannot manage Super Admin.
    superAdminManage: false,

    // No developer/system access.
    databaseManage: false,
    systemManage: false
  }

};

/* ---- Therapists / staff -------------------------------------------- */
/* ==========================================================
   LEGACY / DEMO STAFF DATA

   Real Staff & Rota now comes from Supabase.
   These records remain temporarily because some older
   dashboard widgets may still reference AD.STAFF.
   ========================================================== */

AD.STAFF = [

  {
    id: "amara",
    name: "Mala",

    // System permission level.
    access_role: "admin",

    // Treatment seniority.
    service_role: "skin_specialist",

    // Display label used by older UI components.
    role: "Skin Specialist",

    color: "#c9a96e",
    hours: 38,
    util: 86,
    rating: 4.9,
    commission: 18,
    leave: "—"
  },

  {
    id: "isolde",
    name: "Shugar",

    access_role: "practitioner",
    service_role: "senior_therapist",

    role: "Senior Therapist",

    color: "#8a9a7e",
    hours: 34,
    util: 78,
    rating: 4.8,
    commission: 15,
    leave: "12 Jun"
  },

  {
    id: "noor",
    name: "Riya",

    access_role: "practitioner",
    service_role: "therapist",

    role: "Therapist",

    color: "#b08968",
    hours: 30,
    util: 71,
    rating: 4.9,
    commission: 15,
    leave: "—"
  },

  {
    id: "priya",
    name: "Neel",

    access_role: "practitioner",
    service_role: "therapist",

    role: "Therapist",

    color: "#9a7aa0",
    hours: 22,
    util: 64,
    rating: 4.7,
    commission: 12,
    leave: "Sick"
  },

  {
    id: "sarkar",
    name: "Sarkar",

    access_role: "practitioner",
    service_role: "therapist",

    role: "Therapist",

    color: "#7d96a8",
    hours: 28,
    util: 68,
    rating: 4.8,
    commission: 12,
    leave: "—"
  }

];

/* ---- Customers (CRM) ----------------------------------------------- */
AD.CUSTOMERS = [
  { id: "c1", name: "Eloise Whitfield", email: "eloise.w@example.com", phone: "+44 7700 900123", tier: "Atelier", visits: 24, ltv: 3260, last: "8 Mar 2026", loyalty: 1840, tags: ["VIP","Sensitive skin"], allergies: "Tree nuts", consent: true, notes: "Prefers Mala. Loves the hot stone ritual. Always books late afternoon." },
  { id: "c2", name: "Saskia Ramos", email: "s.ramos@example.com", phone: "+44 7700 900221", tier: "Atelier", visits: 18, ltv: 2450, last: "23 May 2026", loyalty: 1220, tags: ["VIP"], allergies: "—", consent: true, notes: "Photographer. Often reschedules — flexible." },
  { id: "c3", name: "Marcus Thane", email: "marcus.t@example.com", phone: "+44 7700 900318", tier: "Guest", visits: 4, ltv: 540, last: "20 May 2026", loyalty: 270, tags: ["New"], allergies: "—", consent: false, notes: "Deep tissue only. Firm pressure." },
  { id: "c4", name: "Anika Patel", email: "anika.p@example.com", phone: "+44 7700 900410", tier: "Patron", visits: 31, ltv: 4180, last: "23 May 2026", loyalty: 2510, tags: ["VIP","Member"], allergies: "Lavender", consent: true, notes: "Patron tier. Private suite preferred." },
  { id: "c5", name: "Reuben Cole", email: "r.cole@example.com", phone: "+44 7700 900512", tier: "Guest", visits: 2, ltv: 285, last: "11 May 2026", loyalty: 140, tags: ["New"], allergies: "—", consent: true, notes: "" },
  { id: "c6", name: "Sophia Lin", email: "s.lin@example.com", phone: "+44 7700 900613", tier: "Guest", visits: 7, ltv: 985, last: "23 May 2026", loyalty: 490, tags: [], allergies: "Nuts", consent: true, notes: "Gift card balance £40." },
  { id: "c7", name: "James Kovac", email: "j.kovac@example.com", phone: "+44 7700 900714", tier: "Atelier", visits: 12, ltv: 1840, last: "23 May 2026", loyalty: 920, tags: ["Member"], allergies: "—", consent: true, notes: "Books couples treatments for anniversaries." },
  { id: "c8", name: "Lily Whitfield", email: "lily.w@example.com", phone: "+44 7700 900815", tier: "Guest", visits: 1, ltv: 165, last: "23 May 2026", loyalty: 80, tags: ["New"], allergies: "—", consent: false, notes: "Referred by Eloise." },
];

/* ---- Bookings ------------------------------------------------------ */
AD.STATUSES = {
  pending:    { label: "Pending",    color: "var(--ink-2)",   bg: "var(--bg-shell)" },
  confirmed:  { label: "Confirmed",  color: "var(--gold-deep)",bg: "var(--bg-nude)" },
  checkedin:  { label: "Checked in", color: "#6a82c4",         bg: "rgba(106,130,196,0.14)" },
  completed:  { label: "Completed",  color: "var(--success)",  bg: "rgba(107,122,94,0.16)" },
  cancelled:  { label: "Cancelled",  color: "var(--danger)",   bg: "rgba(154,74,58,0.14)" },
  noshow:     { label: "No show",    color: "#9a4a3a",         bg: "rgba(154,74,58,0.10)" },
};

AD.BOOKINGS = [
  { id: "CSAX01", customer: "Saskia Ramos", treatment: "Oxygen Glow Therapy", staff: "amara", date: "2026-05-23", time: "09:00", duration: 60, price: 145, status: "completed", channel: "Online", room: "Suite 1" },
  { id: "CSAX02", customer: "Lily Whitfield", treatment: "Chelsea Signature Facial", staff: "amara", date: "2026-05-23", time: "10:30", duration: 75, price: 165, status: "checkedin", channel: "Online", room: "Suite 1" },
  { id: "CSAX03", customer: "Marcus Thane", treatment: "London Deep Tissue", staff: "isolde", date: "2026-05-23", time: "11:00", duration: 60, price: 135, status: "confirmed", channel: "Phone", room: "Suite 2" },
  { id: "CSAX04", customer: "Eloise Whitfield", treatment: "Hot Stone Ritual", staff: "isolde", date: "2026-05-23", time: "12:30", duration: 90, price: 195, status: "confirmed", channel: "Online", room: "Suite 2", note: "Tree nut allergy" },
  { id: "CSAX05", customer: "Anika Patel", treatment: "Botanical Mud Cocoon", staff: "noor", date: "2026-05-23", time: "14:00", duration: 75, price: 155, status: "confirmed", channel: "App", room: "Suite 3" },
  { id: "CSAX06", customer: "James Kovac", treatment: "Two Together", staff: "amara", date: "2026-05-23", time: "15:30", duration: 90, price: 360, status: "confirmed", channel: "Phone", room: "Couples", note: "Anniversary" },
  { id: "CSAX07", customer: "Sophia Lin", treatment: "Cashmere Body Polish", staff: "noor", date: "2026-05-23", time: "17:00", duration: 60, price: 125, status: "pending", channel: "Online", room: "Suite 3" },
  { id: "CSAX08", customer: "Reuben Cole", treatment: "London Deep Tissue", staff: "priya", date: "2026-05-23", time: "11:30", duration: 60, price: 135, status: "cancelled", channel: "Online", room: "Suite 4" },
  { id: "CSAX09", customer: "Neel (walk-in)", treatment: "Oxygen Glow Therapy", staff: "amara", date: "2026-05-24", time: "10:00", duration: 60, price: 145, status: "confirmed", channel: "Walk-in", room: "Suite 1" },
  { id: "CSAX10", customer: "Saskia Ramos", treatment: "Radiance Half Day", staff: "isolde", date: "2026-05-25", time: "11:00", duration: 180, price: 425, status: "pending", channel: "Online", room: "Suite 2" },
];

/* Today's calendar blocks: [staffIdx, startOffsetHours(from 9), lengthHours, customer, treatment, status] */
AD.CAL_BLOCKS = [
  [0, 0,   1,    "Saskia R.",  "Oxygen Glow",      "completed"],
  [0, 1.5, 1.25, "Lily W.",    "Signature Facial", "checkedin"],
  [0, 6.5, 1.5,  "James K.",   "Two Together",     "confirmed"],
  [1, 2,   1,    "Marcus T.",  "Deep Tissue",      "confirmed"],
  [1, 3.5, 1.5,  "Eloise W.",  "Hot Stone",        "confirmed"],
  [1, 8,   1.5,  "Reuben C.",  "Hot Stone",        "pending"],
  [2, 5,   1.25, "Anika P.",   "Botanical Cocoon", "confirmed"],
  [2, 8,   1,    "Sophia L.",  "Cashmere Polish",  "pending"],
  [3, 1,   1,    "Walk-in",    "Express Facial",   "confirmed"],
];

/* ---- Catalog: treatments, products, packages, memberships, gift cards */
AD.SERVICES = [
  { id: "s1", name: "Chelsea Signature Facial", cat: "Facials", duration: 75, price: 165, sale: null, online: true, staff: 3 },
  { id: "s2", name: "Oxygen Glow Therapy", cat: "Facials", duration: 60, price: 145, sale: 125, online: true, staff: 3 },
  { id: "s3", name: "London Deep Tissue", cat: "Massage", duration: 60, price: 135, sale: null, online: true, staff: 2 },
  { id: "s4", name: "Hot Stone Ritual", cat: "Massage", duration: 90, price: 195, sale: null, online: true, staff: 2 },
  { id: "s5", name: "Cashmere Body Polish", cat: "Body", duration: 60, price: 125, sale: null, online: true, staff: 4 },
  { id: "s6", name: "Botanical Mud Cocoon", cat: "Body", duration: 75, price: 155, sale: null, online: false, staff: 2 },
  { id: "s7", name: "Two Together", cat: "Specialist", duration: 90, price: 360, sale: null, online: true, staff: 2 },
  { id: "s8", name: "Radiance Half Day", cat: "Specialist", duration: 180, price: 425, sale: 385, online: true, staff: 4 },
];

/* Real WooCommerce catalog — loaded from src/services/db.js (imported dump).
   Stock isn't tracked in the source sDB (services/vouchers), so untracked
   items show a nominal on-hand figure derived from the product id. */
AD.PRODUCTS = window.SpaDB.all("products").map(p => ({
  id: p.id, name: p.name, cat: p.cat, price: p.price, sale: p.sale,
  stock: p.stock != null ? p.stock : (p.stockStatus === "instock" ? 8 + (p.wpId % 17) : 0),
  low: 5, supplier: /CRYSTAL/i.test(p.name) ? "Crystal Clear (trade)" : "In-house",
  online: true, image: p.image, sku: p.sku,
}));

AD.PACKAGES = [
  { id: "pk1", name: "The Slow Afternoon", items: "Facial + Body Polish + Lunch", price: 320, save: 30, sold: 42 },
  { id: "pk2", name: "Couple's Escape", items: "Two Together + Champagne", price: 420, save: 40, sold: 28 },
  { id: "pk3", name: "Glow Trio", items: "3× Oxygen Glow", price: 360, save: 75, sold: 64 },
];

AD.MEMBERSHIPS = [
  { id: "m1", name: "Quiet", price: 120, members: 84, period: "monthly" },
  { id: "m2", name: "Atelier", price: 240, members: 156, period: "monthly" },
  { id: "m3", name: "Patron", price: 480, members: 38, period: "monthly" },
];

AD.GIFTCARDS = [
  { id: "g1", code: "CSGIFT-4821", balance: 150, issued: "150", to: "—", status: "active", expires: "Dec 2026" },
  { id: "g2", code: "CSGIFT-7733", balance: 40, issued: "100", to: "Sophia Lin", status: "active", expires: "Aug 2026" },
  { id: "g3", code: "CSGIFT-1180", balance: 0, issued: "75", to: "Gift", status: "redeemed", expires: "—" },
  { id: "g4", code: "CSGIFT-9042", balance: 200, issued: "200", to: "Corporate", status: "active", expires: "Mar 2027" },
];

/* ---- Suppliers (derived from imported catalog) --------------------- */
AD.SUPPLIERS = [...new Set(AD.PRODUCTS.map(p => p.supplier))].map(name => ({
  name,
  contact: name === "In-house" ? "admin@shop.thechelseaspa.co.uk" : "trade orders · via account manager",
  lead: name === "In-house" ? "—" : "5 days",
  products: AD.PRODUCTS.filter(p => p.supplier === name).length,
}));

/* ---- Coupons / promos --------------------------------------------- */
AD.COUPONS = [
  { code: "SPRING15", type: "15% off", uses: 142, cap: 500, status: "active", expires: "30 Jun" },
  { code: "WELCOME25", type: "£25 off first visit", uses: 88, cap: "—", status: "active", expires: "—" },
  { code: "MEMBER10", type: "10% members", uses: 310, cap: "—", status: "active", expires: "—" },
  { code: "NYE2026", type: "20% off", uses: 64, cap: 200, status: "expired", expires: "5 Jan" },
];

/* ---- Invoices ------------------------------------------------------ */
AD.INVOICES = [
  { id: "INV-2041", customer: "Anika Patel", amount: 425, method: "Visa ••4242", date: "23 May", status: "paid" },
  { id: "INV-2040", customer: "James Kovac", amount: 360, method: "Apple Pay", date: "23 May", status: "paid" },
  { id: "INV-2039", customer: "Saskia Ramos", amount: 145, method: "Visa ••8810", date: "23 May", status: "paid" },
  { id: "INV-2038", customer: "Marcus Thane", amount: 40, method: "Deposit", date: "23 May", status: "partial" },
  { id: "INV-2037", customer: "Reuben Cole", amount: 135, method: "—", date: "22 May", status: "refunded" },
];

/* ---- Notifications log -------------------------------------------- */
AD.NOTIFS = [
  { type: "email", icon: "mail", text: "Booking confirmation sent to Anika Patel", time: "2 min ago", channel: "Email" },
  { type: "sms", icon: "message", text: "Reminder SMS to James Kovac · tomorrow 15:30", time: "18 min ago", channel: "SMS" },
  { type: "whatsapp", icon: "message", text: "WhatsApp reminder delivered to Eloise W.", time: "1 hr ago", channel: "WhatsApp" },
  { type: "alert", icon: "alert", text: "Low stock: Pink Clay Polish (3 left)", time: "1 hr ago", channel: "System" },
  { type: "email", icon: "mail", text: "Membership renewal receipt · Patron tier", time: "3 hr ago", channel: "Email" },
  { type: "push", icon: "bell", text: "Staff alert: Neel marked sick leave today", time: "5 hr ago", channel: "Push" },
];

/* ---- Audit log ----------------------------------------------------- */
AD.AUDIT = [
  { who: "Mala", role: "Admin / Manager", action: "Edited treatment 'Oxygen Glow Therapy' — set sale price £125", time: "10:24", ip: "82.14.x.x" },
  { who: "Reception", role: "Receptionist", action: "Created booking CSAX09 (walk-in)", time: "10:02", ip: "82.14.x.x" },
  { who: "Mala", role: "Manager", action: "Approved leave request — Shugar, 12 Jun", time: "09:41", ip: "82.14.x.x" },
  { who: "System", role: "Super Admin", action: "Nightly backup completed", time: "03:00", ip: "internal" },
  { who: "Neel", role: "Therapist", action: "Marked unavailable — today (sick)", time: "08:12", ip: "mobile" },
];

/* ---- Analytics series --------------------------------------------- */
AD.REVENUE_7D = [820, 1140, 985, 1320, 1480, 1180, 985];
AD.REVENUE_DAYS = ["Mon","Tue","Wed","Thu","Fri","Sat","Sun"];
AD.REVENUE_30D = [12,14,11,16,18,15,13,17,19,16,14,18,21,19,17,20,22,18,16,19,23,21,19,24,26,22,20,25,28,24];
AD.BOOKINGS_TREND = [38,42,40,48,52,47,44,51,55,49,46,53];
AD.CATEGORY_SPLIT = [
  { label: "Facials", pct: 42, color: "var(--gold-deep)" },
  { label: "Massage", pct: 31, color: "var(--ink)" },
  { label: "Body", pct: 18, color: "var(--gold)" },
  { label: "Specialist", pct: 9, color: "var(--ink-3)" },
];
AD.TOP_TREATMENTS = [
  ["Chelsea Signature Facial", 18, 2970],
  ["Hot Stone Ritual", 12, 2340],
  ["London Deep Tissue", 11, 1485],
  ["Radiance Half Day", 4, 1700],
  ["Oxygen Glow Therapy", 9, 1305],
];
AD.RETENTION = [100, 78, 64, 58, 54, 51, 49, 47];

/* ---- Waitlist ------------------------------------------------------ */
AD.WAITLIST = [
  { customer: "Eloise Whitfield", treatment: "Hot Stone Ritual", pref: "Sat AM", added: "2 days ago" },
  { customer: "Marcus Thane", treatment: "Any with Shugar", pref: "Eve", added: "1 day ago" },
  { customer: "Sophia Lin", treatment: "Cashmere Polish", pref: "Weekend", added: "4 hr ago" },
];

window.AD = AD;
